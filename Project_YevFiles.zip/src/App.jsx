import React, { useState, useEffect, useRef, useCallback, useLayoutEffect, useDeferredValue } from "react";
import { Filesystem, Directory, Encoding } from "@capacitor/filesystem";
import { App as CapApp } from "@capacitor/app";
import { registerPlugin, Capacitor } from "@capacitor/core";
import pdfWorkerUrl from "pdfjs-dist/legacy/build/pdf.worker.min.mjs?url";
const Apps = registerPlugin("Apps");

/* ===== YevFiles — leshugan.fm =====  стиль Notenger (шоколад) */

const BG = "var(--bg)", BAR = "var(--bar)", ROW2 = "var(--row2)", ACC = "var(--acc)";
const GOLD = "var(--gold)", RED = "var(--red)", TXT = "var(--txt)", SUB = "var(--sub)", LINE = "var(--line)", INK = "var(--ink)";
const THEMES = {
  dark:  { "--bg": "#1B130B", "--bar": "#2C2219", "--row2": "#332619", "--acc": "#EF6C00", "--accbg": "rgba(239,108,0,.18)", "--gold": "#F5A623", "--red": "#E05252", "--txt": "#F2EAE0", "--ink": "#E0D5C8", "--sub": "#B0A498", "--line": "#4A3A2A", "--chip": "rgba(255,255,255,.06)", "--hair": "rgba(255,255,255,.07)", "--tgloff": "#4A3A2A", "--barsh": "0 6px 18px rgba(0,0,0,.34), 0 1px 4px rgba(0,0,0,.26)" },
  light: { "--bg": "#EEF1F4", "--bar": "#FFFFFF", "--row2": "#E4E8EC", "--acc": "#2F80ED", "--accbg": "rgba(47,128,237,.14)", "--gold": "#2F80ED", "--red": "#D14343", "--txt": "#1E2329", "--ink": "#3D4754", "--sub": "#6B7280", "--line": "#D3D8DE", "--chip": "rgba(0,0,0,.05)", "--hair": "rgba(0,0,0,.08)", "--tgloff": "#C2C8D0", "--barsh": "0 8px 26px rgba(17,24,39,.14), 0 2px 6px rgba(17,24,39,.06)" },
};
const DIR = Directory.ExternalStorage;
const APP_VERSION = "1.004";
const TKEY = "fm_tabs_v1", SKEY = "fm_startup_v1", METAKEY = "fm_meta_v1", SORTKEY = "fm_sort_v1";
const DEFKEY = "fm_defaults_v1", HIDEKEY = "fm_hideapps_v1", ICONKEY = "fm_foldericons_v1", ORDERKEY = "fm_menuorder_v1";
// ключи настроек для резервной копии (кэши и токены НЕ включаем)
const BACKUP_KEYS = ["fm_theme_v1", "fm_themebtn_v1", "fm_fonts_v1", "fm_sort_v1", "fm_systop_v2", "fm_view_v1", "fm_defaults_v1", "fm_foldericons_v1", "fm_menuorder_v1", "fm_drawer_order_v1", "fm_bookmarks_v1", "fm_drawer_hidden_v1", "fm_hideapps_v1", "fm_meta_v1", "fm_startup_v1", "fm_audio_autonext_v1", "fm_dirsize_v1"];
const BACKUP_TABS_KEYS = ["fm_tabs_v1", "fm_startup_v1"];
const loadMap = (k) => { try { return JSON.parse(ls.get(k)) || {}; } catch { return {}; } };
const saveMap = (k, m) => ls.set(k, JSON.stringify(m));
const OPEN_AS = [["*/*", "Любой тип"], ["text/plain", "Текст"], ["image/*", "Изображение"], ["video/*", "Видео"], ["audio/*", "Аудио"], ["application/pdf", "PDF"]];

let mem = null;
const ls = { get: (k) => { try { return localStorage.getItem(k); } catch { return null; } },
  set: (k, v) => { try { localStorage.setItem(k, v); } catch {} },
  del: (k) => { try { localStorage.removeItem(k); } catch {} } };
function buildInitial() {
  const saved = loadTabs();
  const base = saved && saved.length ? saved : [{ id: 1, path: "" }];
  let active = base.findIndex((t) => t.startup);
  if (active < 0) active = 0;
  return { base, active };
}
const loadTabs = () => { try { return JSON.parse(ls.get(TKEY)); } catch { return mem; } };
const saveTabs = (t) => { const keep = t.filter((x) => x.saved).map((x) => (x.src && x.src.kind === "search" ? { ...x, src: null, path: (x.src.back && x.src.back.path != null) ? x.src.back.path : x.path } : x)); mem = keep; ls.set(TKEY, JSON.stringify(keep)); };
const loadMeta = () => { try { const m = JSON.parse(ls.get(METAKEY)) || {}; return { hidden: new Set(m.hidden || []), pinTop: new Set(m.pinTop || []), pinBot: new Set(m.pinBot || []) }; } catch { return { hidden: new Set(), pinTop: new Set(), pinBot: new Set() }; } };
const saveMeta = (m) => ls.set(METAKEY, JSON.stringify({ hidden: [...m.hidden], pinTop: [...m.pinTop], pinBot: [...m.pinBot] }));

const join = (a, b) => (a ? a + "/" + b : b);
const parent = (p) => (p.includes("/") ? p.slice(0, p.lastIndexOf("/")) : "");
const baseName = (p) => (p.includes("/") ? p.slice(p.lastIndexOf("/") + 1) : p);
const buzz = (ms) => { try { navigator.vibrate && navigator.vibrate(ms); } catch {} };
const splitExt = (name, isDir) => {
  if (isDir) return { base: name, ext: "" };
  const i = name.lastIndexOf(".");
  if (i <= 0) return { base: name, ext: "" };
  return { base: name.slice(0, i), ext: name.slice(i + 1) };
};
const fmtSize = (b) => { if (b == null) return "—"; const u = ["Б", "КБ", "МБ", "ГБ"]; let i = 0, n = b; while (n >= 1024 && i < 3) { n /= 1024; i++; } return (i ? n.toFixed(1) : n) + " " + u[i] + (i ? " (" + b.toLocaleString("ru") + " Б)" : ""); };
const fmtTime = (ms) => { if (!ms || ms < 0) return "0:00"; const s = Math.floor(ms / 1000); return Math.floor(s / 60) + ":" + String(s % 60).padStart(2, "0"); };
const fmtShort = (b) => { if (b == null) return ""; const u = ["Б", "КБ", "МБ", "ГБ"]; let i = 0, n = b; while (n >= 1024 && i < 3) { n /= 1024; i++; } return (i ? n.toFixed(1) : n) + " " + u[i]; };
const fmtSizeShort = (b) => { if (b == null) return ""; const u = ["Б", "КБ", "МБ", "ГБ"]; let i = 0, n = b; while (n >= 1024 && i < 3) { n /= 1024; i++; } return (i ? n.toFixed(1) : n) + " " + u[i]; };
const plural = (n, a, b, c) => { const m10 = n % 10, m100 = n % 100; if (m10 === 1 && m100 !== 11) return a; if (m10 >= 2 && m10 <= 4 && (m100 < 12 || m100 > 14)) return b; return c; };
const fmtDate = (ms) => {
  if (!ms) return "";
  const d = new Date(ms), diff = Date.now() - ms;
  if (diff < 60000) return "только что";
  if (diff < 3600000) { const m = Math.floor(diff / 60000); return m + " " + plural(m, "минуту", "минуты", "минут") + " назад"; }
  if (d.toDateString() === new Date().toDateString()) { const h = Math.floor(diff / 3600000); return h + " " + plural(h, "час", "часа", "часов") + " назад"; }
  return d.toLocaleDateString("ru") + " " + d.toLocaleTimeString("ru", { hour: "2-digit", minute: "2-digit" });
};
const ago = (ms) => { if (!ms) return "—"; const d = new Date(ms), diff = (Date.now() - ms) / 60000; const rel = diff < 1 ? "только что" : diff < 60 ? Math.floor(diff) + " мин назад" : diff < 1440 ? Math.floor(diff / 60) + " ч назад" : Math.floor(diff / 1440) + " дн назад"; const p = (n) => String(n).padStart(2, "0"); return `${p(d.getHours())}:${p(d.getMinutes())}, ${p(d.getDate())}.${p(d.getMonth() + 1)}.${String(d.getFullYear()).slice(2)} · ${rel}`; };

const MIME = {
  txt: "text/plain", md: "text/plain", markdown: "text/plain", log: "text/plain", ini: "text/plain", cfg: "text/plain", conf: "text/plain", csv: "text/csv", tsv: "text/tab-separated-values", html: "text/html", htm: "text/html", xhtml: "application/xhtml+xml", json: "text/plain", json5: "text/plain", xml: "text/xml", plist: "text/xml", yml: "text/plain", yaml: "text/plain", java: "text/plain", kt: "text/plain", kts: "text/plain", js: "text/plain", mjs: "text/plain", cjs: "text/plain", jsx: "text/plain", ts: "text/plain", tsx: "text/plain", vue: "text/plain", svelte: "text/plain", py: "text/plain", pyw: "text/plain", rb: "text/plain", php: "text/plain", c: "text/plain", h: "text/plain", hpp: "text/plain", cpp: "text/plain", cxx: "text/plain", cc: "text/plain", cs: "text/plain", go: "text/plain", rs: "text/plain", swift: "text/plain", m: "text/plain", mm: "text/plain", scala: "text/plain", dart: "text/plain", lua: "text/plain", pl: "text/plain", r: "text/plain", sh: "text/plain", bash: "text/plain", zsh: "text/plain", bat: "text/plain", cmd: "text/plain", ps1: "text/plain", gradle: "text/plain", properties: "text/plain", css: "text/css", scss: "text/plain", sass: "text/plain", less: "text/plain", sql: "text/plain", toml: "text/plain", env: "text/plain", gitignore: "text/plain", dockerfile: "text/plain", makefile: "text/plain", diff: "text/plain", patch: "text/plain", srt: "text/plain", vtt: "text/plain", ass: "text/plain", tex: "text/plain",
  pdf: "application/pdf", djvu: "image/vnd.djvu", djv: "image/vnd.djvu",
  doc: "application/msword", docx: "application/vnd.openxmlformats-officedocument.wordprocessingml.document", dot: "application/msword", odt: "application/vnd.oasis.opendocument.text", ott: "application/vnd.oasis.opendocument.text", rtf: "application/rtf",
  xls: "application/vnd.ms-excel", xlsx: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", ods: "application/vnd.oasis.opendocument.spreadsheet",
  ppt: "application/vnd.ms-powerpoint", pptx: "application/vnd.openxmlformats-officedocument.presentationml.presentation", odp: "application/vnd.oasis.opendocument.presentation",
  epub: "application/epub+zip", mobi: "application/x-mobipocket-ebook", azw: "application/vnd.amazon.ebook", azw3: "application/vnd.amazon.ebook", fb2: "application/x-fictionbook+xml",
  jpg: "image/jpeg", jpeg: "image/jpeg", jpe: "image/jpeg", jfif: "image/jpeg", png: "image/png", apng: "image/apng", gif: "image/gif", webp: "image/webp", bmp: "image/bmp", dib: "image/bmp", svg: "image/svg+xml", svgz: "image/svg+xml", ico: "image/x-icon", cur: "image/x-icon", tif: "image/tiff", tiff: "image/tiff", heic: "image/heic", heif: "image/heif", avif: "image/avif", jxl: "image/jxl", raw: "image/x-panasonic-raw", dng: "image/x-adobe-dng", cr2: "image/x-canon-cr2", nef: "image/x-nikon-nef", arw: "image/x-sony-arw", psd: "image/vnd.adobe.photoshop",
  mp4: "video/mp4", m4v: "video/x-m4v", mkv: "video/x-matroska", webm: "video/webm", avi: "video/x-msvideo", mov: "video/quicktime", qt: "video/quicktime", wmv: "video/x-ms-wmv", flv: "video/x-flv", f4v: "video/x-f4v", "3gp": "video/3gpp", "3g2": "video/3gpp2", mpg: "video/mpeg", mpeg: "video/mpeg", mpe: "video/mpeg", m2v: "video/mpeg", ts: "video/mp2t", m2ts: "video/mp2t", mts: "video/mp2t", vob: "video/dvd", ogv: "video/ogg", rm: "application/vnd.rn-realmedia", rmvb: "application/vnd.rn-realmedia-vbr", divx: "video/divx", asf: "video/x-ms-asf",
  mp3: "audio/mpeg", wav: "audio/wav", wave: "audio/wav", flac: "audio/flac", aac: "audio/aac", ogg: "audio/ogg", oga: "audio/ogg", opus: "audio/opus", m4a: "audio/mp4", m4b: "audio/mp4", wma: "audio/x-ms-wma", amr: "audio/amr", aiff: "audio/aiff", aif: "audio/aiff", ape: "audio/x-ape", ac3: "audio/ac3", dts: "audio/vnd.dts", mid: "audio/midi", midi: "audio/midi", mka: "audio/x-matroska", ra: "audio/x-realaudio", au: "audio/basic", weba: "audio/webm",
  zip: "application/zip", rar: "application/vnd.rar", "7z": "application/x-7z-compressed", tar: "application/x-tar", gz: "application/gzip", tgz: "application/gzip", bz2: "application/x-bzip2", tbz: "application/x-bzip2", tbz2: "application/x-bzip2", xz: "application/x-xz", txz: "application/x-xz", lz: "application/x-lzip", lzma: "application/x-lzma", zst: "application/zstd", z: "application/x-compress", cab: "application/vnd.ms-cab-compressed", arj: "application/x-arj", lha: "application/x-lzh", lzh: "application/x-lzh", ace: "application/x-ace-compressed", iso: "application/x-iso9660-image", img: "application/x-iso9660-image", dmg: "application/x-apple-diskimage", deb: "application/vnd.debian.binary-package", rpm: "application/x-rpm", jar: "application/java-archive", war: "application/java-archive", obb: "application/octet-stream",
  apk: "application/vnd.android.package-archive", apks: "application/octet-stream", xapk: "application/octet-stream", apkm: "application/octet-stream", aab: "application/octet-stream",
  ttf: "font/ttf", otf: "font/otf", woff: "font/woff", woff2: "font/woff2", eot: "application/vnd.ms-fontobject",
  apk_: "application/vnd.android.package-archive",
};
const mimeOf = (name) => MIME[(name.split(".").pop() || "").toLowerCase()] || "*/*";
const TEXT_EXT = new Set(["txt", "md", "log", "ini", "cfg", "conf", "yml", "yaml", "java", "kt", "kts", "js", "jsx", "ts", "tsx", "py", "c", "h", "cpp", "cc", "cs", "go", "rs", "rb", "php", "swift", "sh", "bat", "gradle", "properties", "css", "sql", "lua", "toml", "xml", "json", "html", "htm", "csv"]);
const defaultOpenAs = (name) => { const e = (name.split(".").pop() || "").toLowerCase(); const m = mimeOf(name); if (TEXT_EXT.has(e)) return "text/plain"; if (m.startsWith("image/")) return "image/*"; if (m.startsWith("video/")) return "video/*"; if (m.startsWith("audio/")) return "audio/*"; if (m === "application/pdf") return "application/pdf"; return "*/*"; };

const I = {
  chipIc: <><rect x="6" y="6" width="12" height="12" rx="2" /><path d="M9 3v3M15 3v3M9 18v3M15 18v3M3 9h3M3 15h3M18 9h3M18 15h3" /></>,
  back: <path d="M15 18l-6-6 6-6" />,
  search: <><circle cx="11" cy="11" r="7" /><path d="M21 21l-4-4" /></>,
  check: <path d="M5 12l4 4 10-11" />,
  dl: <><path d="M12 3v12" /><path d="M7 11l5 5 5-5" /><path d="M5 21h14" /></>,
  bell: <><path d="M18 8a6 6 0 0 0-12 0c0 7-3 9-3 9h18s-3-2-3-9" /><path d="M13.7 21a2 2 0 0 1-3.4 0" /></>,
  ring: <><path d="M8 14a4 4 0 0 1 8 0" /><path d="M12 3v3M5.6 6.6l2 2M18.4 6.6l-2 2" /><rect x="4" y="14" width="16" height="6" rx="2" /><path d="M10 17h4" /></>,
  alarm: <><circle cx="12" cy="13" r="8" /><path d="M12 9v4l2 2" /><path d="M5 3L2 6M19 3l3 3" /></>,
  mic: <><rect x="9" y="3" width="6" height="11" rx="3" /><path d="M5 11a7 7 0 0 0 14 0" /><path d="M12 18v3" /></>,
  cam: <><path d="M3 8a2 2 0 0 1 2-2h2l1.5-2h7L19 6h0a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z" /><circle cx="12" cy="12.5" r="3.5" /></>,
  android: <g stroke="none"><path d="M7 6 L5.6 4.2" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" fill="none" /><path d="M17 6 L18.4 4.2" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" fill="none" /><path d="M5.5 12a6.5 6.5 0 0 1 13 0z" fill="currentColor" /><rect x="6" y="12.4" width="12" height="7.2" rx="1.6" fill="currentColor" /><rect x="3" y="12.6" width="2.4" height="6.4" rx="1.2" fill="currentColor" /><rect x="18.6" y="12.6" width="2.4" height="6.4" rx="1.2" fill="currentColor" /><circle cx="9.6" cy="8.8" r=".85" fill="#0d0d0d" /><circle cx="14.4" cy="8.8" r=".85" fill="#0d0d0d" /></g>,
  doc2: <><path d="M6 2h9l5 5v15H6z" /><path d="M14 2v6h6" /><path d="M9 13h6M9 16h6" /></>,
  gamepad: <><path d="M7.5 7h9a4.5 4.5 0 0 1 4.4 3.6l1 5A2.6 2.6 0 0 1 18.4 18l-2-2.2a2 2 0 0 0-1.5-.7H9.1a2 2 0 0 0-1.5.7L5.6 18A2.6 2.6 0 0 1 2.1 15.6l1-5A4.5 4.5 0 0 1 7.5 7z" /><path d="M6.2 10.4v2.4M5 11.6h2.4" /><circle cx="15.4" cy="10.8" r=".8" fill="currentColor" /><circle cx="17.6" cy="12.6" r=".8" fill="currentColor" /></>,
  emuPad: <><rect x="3" y="8" width="18" height="9" rx="4.5" /><path d="M7 10.5v4M5 12.5h4" /><circle cx="16" cy="11" r=".8" fill="currentColor" /><circle cx="18.2" cy="13" r=".8" fill="currentColor" /><circle cx="13.8" cy="13" r=".8" fill="currentColor" /><circle cx="16" cy="15" r=".8" fill="currentColor" /></>,
  switchCon: <><path stroke="#5AA9E6" d="M11 4H7.5A3.5 3.5 0 0 0 4 7.5v9A3.5 3.5 0 0 0 7.5 20H11z" /><circle cx="7.5" cy="8.5" r="1.1" stroke="#5AA9E6" /><path stroke="#5AA9E6" d="M6.4 14.6h2.2" /><rect x="11" y="4" width="12" height="16" rx="1.2" stroke="#CFC6BA" /><path stroke="#E60012" d="M23 4h3.5A3.5 3.5 0 0 1 30 7.5v9A3.5 3.5 0 0 1 26.5 20H23z" /><circle cx="26.5" cy="14.6" r="1.1" stroke="#E60012" /><circle cx="26.5" cy="7.6" r=".55" fill="#E60012" stroke="#E60012" /><circle cx="27.9" cy="9" r=".55" fill="#E60012" stroke="#E60012" /><circle cx="25.1" cy="9" r=".55" fill="#E60012" stroke="#E60012" /><circle cx="26.5" cy="10.4" r=".55" fill="#E60012" stroke="#E60012" /></>,
  media: <><rect x="3" y="4" width="18" height="16" rx="3" /><path d="M10 9l5 3-5 3z" fill="currentColor" /></>,
  win: <><rect x="3" y="3" width="18" height="18" rx="2" /><path d="M12 3v18M3 12h18" /></>,
  fontA: <><path d="M5 19l5-13 5 13M7 14h6" /><path d="M17 19V9M17 9c2 0 3 1 3 2s-1 2-3 2" /></>,
  launcher: <><rect x="3" y="3" width="7" height="7" rx="1.5" /><rect x="14" y="3" width="7" height="7" rx="1.5" /><rect x="3" y="14" width="7" height="7" rx="1.5" /><rect x="14" y="14" width="7" height="7" rx="1.5" /></>,
  book: <><path d="M4 4h11a3 3 0 0 1 3 3v13H7a3 3 0 0 0-3 3z" /><path d="M4 4v16" /></>,
  bookOpen: <><path d="M12 6.8c-1.7-1.1-4.3-1.6-8-1.4v11.2c3.7-.2 6.3.3 8 1.4 1.7-1.1 4.3-1.6 8-1.4V5.4c-3.7-.2-6.3.3-8 1.4z" /><path d="M12 6.8v11.2" /></>,
  tool: <><path d="M14 7a4 4 0 0 1-5 5l-5 5 2 2 5-5a4 4 0 0 0 5-5z" /><path d="M14 7l3-3 3 3-3 3z" /></>,
  home: <><path d="M3 11l9-7 9 7" /><path d="M5 10v9a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-9" /><path d="M10 20v-6h4v6" /></>,
  selectAll: <><rect x="4" y="4" width="16" height="16" rx="4" /><path d="M8.5 12l2.5 2.5 4.5-5" /></>,
  chev: <path d="M6 9l6 6 6-6" />,
  bars: <path d="M4 6h16M4 12h16M4 18h16" />,
  gdrive: <g stroke="none" fill="currentColor"><path d="M7.7 20.5h9.9l-2.6-4.5H10.3z" opacity=".55" /><path d="M9.6 3.5L2 16.7l2.5 4.3 7.6-13.2z" /><path d="M14.4 3.5H9.6l7.6 13.2h4.8z" opacity=".8" /></g>,
  refresh: <><path d="M21 12a9 9 0 1 1-2.6-6.4" /><path d="M21 4v5h-5" /></>,
  plus: <><path d="M12 5v14" /><path d="M5 12h14" /></>,
  x: <><path d="M6 6l12 12" /><path d="M18 6L6 18" /></>,
  cut: <><circle cx="6" cy="6" r="3" /><circle cx="6" cy="18" r="3" /><path d="M20 4L8.5 15.5" /><path d="M20 20L8.5 8.5" /></>,
  copy: <><rect x="9" y="9" width="11" height="11" rx="2" /><path d="M5 15V5a2 2 0 0 1 2-2h8" /></>,
  trash: <><path d="M3 6h18" /><path d="M8 6V4h8v2" /><path d="M6 6l1 14h10l1-14" /></>,
  rename: <><path d="M12 20h9" /><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4z" /></>,
  paste: <><rect x="6" y="4" width="12" height="16" rx="2" /><path d="M9 4h6v3H9z" /></>,
  info: <><circle cx="12" cy="12" r="9" /><path d="M12 11v5M12 8h.01" /></>,
  share: <><circle cx="18" cy="5" r="3" /><circle cx="6" cy="12" r="3" /><circle cx="18" cy="19" r="3" /><path d="M8.6 13.5l6.8 4M15.4 6.5l-6.8 4" /></>,
  openext: <><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6" /><path d="M15 3h6v6" /><path d="M10 14L21 3" /></>,
  dots: <g fill="currentColor" stroke="none"><circle cx="12" cy="5" r="2" /><circle cx="12" cy="12" r="2" /><circle cx="12" cy="19" r="2" /></g>,
  sun: <><circle cx="12" cy="12" r="4.5" /><path d="M12 2v2M12 20v2M4.2 4.2l1.4 1.4M18.4 18.4l1.4 1.4M2 12h2M20 12h2M4.2 19.8l1.4-1.4M18.4 5.6l1.4-1.4" /></>,
  moon: <><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z" /></>,
  sort: <><path d="M7 4v16M7 20l-3-3M7 4l3 3" /><path d="M17 20V4M17 4l3 3M17 20l-3-3" /></>,
  gear: <><circle cx="12" cy="12" r="3" /><path d="M12 2v3M12 19v3M2 12h3M19 12h3M5 5l2 2M17 17l2 2M19 5l-2 2M7 17l-2 2" /></>,
  eye: <><path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7-10-7-10-7z" /><circle cx="12" cy="12" r="3" /></>,
  drag: <><path d="M4 8h16M4 12h16M4 16h16" /></>,
  eyeOff: <><path d="M3 3l18 18" /><path d="M10.6 10.6a3 3 0 0 0 4.2 4.2" /><path d="M9.9 5.1A9.7 9.7 0 0 1 12 5c6.5 0 10 7 10 7a16 16 0 0 1-3.2 3.9M6.2 6.2A16 16 0 0 0 2 12s3.5 7 10 7a9.7 9.7 0 0 0 3.1-.5" /></>,
  pinT: <><path d="M12 3v8M8 7l4-4 4 4" /><path d="M5 14h14M5 14v6h14v-6" /></>,
  pinB: <><path d="M12 21v-8M8 17l4 4 4-4" /><path d="M5 10h14M5 10V4h14v6" /></>,
  folder: <path d="M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z" />,
  file: <><path d="M6 2h9l5 5v15H6z" /><path d="M14 2v6h6" /></>,
  txt: <><path d="M6 2h9l5 5v15H6z" /><path d="M14 2v6h6" /><path d="M9 13h6M9 16h6M9 10h3" /></>,
  pdf: <><path d="M6 2h9l5 5v15H6z" /><path d="M14 2v6h6" /><path d="M9 12h6M9 15h6M9 18h3" /></>,
  apk: <g stroke="none"><path d="M7 6 L5.6 4.2" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" fill="none" /><path d="M17 6 L18.4 4.2" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" fill="none" /><path d="M5.5 12a6.5 6.5 0 0 1 13 0z" fill="currentColor" /><rect x="6" y="12.4" width="12" height="7.2" rx="1.6" fill="currentColor" /><rect x="3" y="12.6" width="2.4" height="6.4" rx="1.2" fill="currentColor" /><rect x="18.6" y="12.6" width="2.4" height="6.4" rx="1.2" fill="currentColor" /><circle cx="9.6" cy="8.8" r=".85" fill="#0d0d0d" /><circle cx="14.4" cy="8.8" r=".85" fill="#0d0d0d" /></g>,
  lnk: <><rect x="4" y="4" width="16" height="16" rx="2" /><path d="M9 15l6-6M10.5 9H15v4.5" /></>,
  img: <><rect x="3" y="3" width="18" height="18" rx="2" /><circle cx="8.5" cy="8.5" r="1.5" /><path d="M21 15l-5-5L5 21" /></>,
  video: <><rect x="2" y="5" width="14" height="14" rx="2" /><path d="M16 10l6-3v10l-6-3z" /></>,
  audio: <><path d="M9 18V5l10-2v13" /><circle cx="6" cy="18" r="3" /><circle cx="16" cy="16" r="3" /></>,
  play: <><path d="M8 5v14l11-7z" fill="currentColor" stroke="none" /></>,
  pause: <><rect x="6" y="5" width="4" height="14" rx="1" fill="currentColor" stroke="none" /><rect x="14" y="5" width="4" height="14" rx="1" fill="currentColor" stroke="none" /></>,
  prev: <><path d="M18 5v14l-9-7z" fill="currentColor" stroke="none" /><rect x="5" y="5" width="2.4" height="14" rx="1" fill="currentColor" stroke="none" /></>,
  next: <><path d="M6 5v14l9-7z" fill="currentColor" stroke="none" /><rect x="16.6" y="5" width="2.4" height="14" rx="1" fill="currentColor" stroke="none" /></>,
  archive: <><rect x="3" y="3" width="18" height="18" rx="2" /><path d="M12 3v18M9 7h6M9 11h6" /></>,
  code: <><path d="M8 9l-4 3 4 3" /><path d="M16 9l4 3-4 3" /></>,
  star: <path d="M12 3l2.9 5.9 6.5.9-4.7 4.6 1.1 6.5L12 18.8 6.2 21.8l1.1-6.5L2.6 10.7l6.5-.9z" />,
  pin: <><path d="M9 4h6l-1 7 4 3v2H6v-2l4-3z" /><path d="M12 16v4" /></>,
};
const Svg = ({ d, size = 24, vw }) => (
  <svg width={vw ? size * (vw / 24) : size} height={size} viewBox={"0 0 " + (vw || 24) + " 24"} fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">{d}</svg>
);
const ArcBadge = ({ name }) => {
  const ext = (name.split(".").pop() || "").toUpperCase();
  const c = ARCH_COLORS[ext.toLowerCase()] || "#E3B14F";
  return (
    <svg width="30" height="30" viewBox="0 0 24 24" fill="none">
      <rect x="3" y="3" width="18" height="18" rx="4" stroke={c} strokeWidth="2" fill="none" />
      <text x="12" y="15.5" textAnchor="middle" fontSize="7.5" fontWeight="700" fill={c} fontFamily="system-ui,sans-serif">{ext}</text>
    </svg>
  );
};
/* ===== Редкие форматы картинок: RAW и HEIC отдаёт нативная часть (встроенное превью / системный декодер),
   TIFF и JPEG XL раскодируются прямо в веб-части, TGS — анимация Lottie, AVIF/APNG/анимированный WebP показывает сам движок ===== */
const RAW_RE = /\.(dng|cr2|cr3|nef|nrw|arw|orf|rw2|pef|srw|raf|x3f|3fr|erf|kdc|mrw|mos|srf|sr2|rwl|iiq)$/i;
const isRaw = (n) => RAW_RE.test(n);
const isHeic = (n) => /\.(heic|heif|hif)$/i.test(n);
const isTiff = (n) => /\.(tif|tiff)$/i.test(n);
const isJxl = (n) => /\.jxl$/i.test(n);
const isTgs = (n) => /\.tgs$/i.test(n);
const isAvif = (n) => /\.avif$/i.test(n);
const isJsImg = (n) => isTiff(n) || isJxl(n) || isAvif(n);   // раскодируем в веб-части (AVIF — силами самого движка)
const cfsG = (u) => { try { return Capacitor.convertFileSrc(u); } catch { return u; } };
const readBytes = async (uri) => { const r = await fetch(cfsG(uri)); if (!r.ok) throw new Error("не удалось прочитать файл"); return await r.arrayBuffer(); };
// RGBA-байты -> картинка в памяти (не больше max по стороне), возвращает blob-ссылку
const rgbaToUrl = async (rgba, w, h, max) => {
  const src = document.createElement("canvas"); src.width = w; src.height = h;
  src.getContext("2d").putImageData(new ImageData(new Uint8ClampedArray(rgba.buffer, rgba.byteOffset, w * h * 4), w, h), 0, 0);
  let out = src;
  const m = Math.max(w, h);
  if (max && m > max) { const sc = max / m; out = document.createElement("canvas"); out.width = Math.max(1, Math.round(w * sc)); out.height = Math.max(1, Math.round(h * sc)); out.getContext("2d").drawImage(src, 0, 0, out.width, out.height); }
  return await new Promise((res, rej) => out.toBlob((b) => (b ? res(URL.createObjectURL(b)) : rej(new Error("canvas"))), max && max <= 200 ? "image/jpeg" : "image/png", 0.86));
};
const imgToUrl = async (srcUrl, max) => {
  const im = new Image(); im.decoding = "async";
  await new Promise((res, rej) => { im.onload = res; im.onerror = () => rej(new Error("формат не поддерживается")); im.src = srcUrl; });
  const w = im.naturalWidth, h = im.naturalHeight; const m = Math.max(w, h); const sc = max && m > max ? max / m : 1;
  const c = document.createElement("canvas"); c.width = Math.max(1, Math.round(w * sc)); c.height = Math.max(1, Math.round(h * sc));
  c.getContext("2d").drawImage(im, 0, 0, c.width, c.height);
  return await new Promise((res, rej) => c.toBlob((b) => (b ? res(URL.createObjectURL(b)) : rej(new Error("canvas"))), "image/jpeg", 0.86));
};
let utifMod = null;
const decodeTiff = async (uri, max) => {
  if (!utifMod) { try { const pk = await import("pako"); window.pako = pk.default || pk; } catch {} const m = await import("utif"); utifMod = m.default || m; }
  const buf = await readBytes(uri);
  const ifds = utifMod.decode(buf);
  if (!ifds || !ifds.length) throw new Error("пустой TIFF");
  const page = ifds[0];
  utifMod.decodeImage(buf, page, ifds);
  const rgba = utifMod.toRGBA8(page);
  return await rgbaToUrl(rgba, page.width, page.height, max);
};
let jxlDec = null;
const decodeJxl = async (uri, max) => {
  if (!jxlDec) { const m = await import("@jsquash/jxl/decode.js"); jxlDec = m.default; }
  const buf = await readBytes(uri);
  const img = await jxlDec(buf);
  return await rgbaToUrl(img.data, img.width, img.height, max);
};
const decodeTgs = async (uri) => {
  const { gunzipSync } = await import("fflate");
  const buf = await readBytes(uri);
  const raw = new Uint8Array(buf);
  const bytes = raw[0] === 0x1f && raw[1] === 0x8b ? gunzipSync(raw) : raw;
  return JSON.parse(new TextDecoder("utf-8").decode(bytes));
};
// картинка для показа в просмотрщике: blob-ссылка или данные анимации
const decodeForView = async (uri, name) => {
  if (isTiff(name)) return { kind: "img", src: await decodeTiff(uri, 4096) };
  if (isJxl(name)) return { kind: "img", src: await decodeJxl(uri, 4096) };
  if (isTgs(name)) return { kind: "lottie", data: await decodeTgs(uri) };
  return null;
};
// превью для списка (сторона ~150 px)
const decodeForThumb = async (uri, name) => {
  if (isTiff(name)) return await decodeTiff(uri, 150);
  if (isJxl(name)) return await decodeJxl(uri, 150);
  if (isAvif(name)) return await imgToUrl(cfsG(uri), 150);
  if (isTgs(name)) {
    const data = await decodeTgs(uri);
    const lottie = (await import("lottie-web")).default;
    const box = document.createElement("div"); box.style.cssText = "position:fixed;left:-9999px;top:0;width:150px;height:150px";
    document.body.appendChild(box);
    try {
      const anim = lottie.loadAnimation({ container: box, renderer: "canvas", loop: false, autoplay: false, animationData: data, rendererSettings: { clearCanvas: true } });
      await new Promise((res) => { anim.addEventListener("DOMLoaded", res); setTimeout(res, 800); });
      anim.goToAndStop(Math.floor((anim.totalFrames || 1) * 0.15), true);
      await new Promise((r) => setTimeout(r, 30));
      const cv = box.querySelector("canvas"); const url = cv ? cv.toDataURL("image/png") : null;
      anim.destroy();
      if (!url) throw new Error("tgs");
      return url;
    } finally { box.remove(); }
  }
  return null;
};
// Анимация Lottie/TGS в просмотрщике
function LottieView({ data, style }) {
  const ref = useRef(null);
  useEffect(() => {
    let anim = null, dead = false;
    import("lottie-web").then((m) => { if (dead || !ref.current) return; anim = m.default.loadAnimation({ container: ref.current, renderer: "svg", loop: true, autoplay: true, animationData: data }); });
    return () => { dead = true; if (anim) anim.destroy(); };
  }, [data]);
  return <div ref={ref} style={style} />;
}

// Кольцо загрузки: с процентами, если известен общий размер, иначе просто крутится
function DlRing({ pct, paused }) {
  const S2 = 28, R = 11.6, C = 2 * Math.PI * R;
  const known = pct != null && pct >= 0;
  const spin = !known && !paused;
  return (
    <span style={{ position: "relative", display: "inline-flex", alignItems: "center", justifyContent: "center", width: S2, height: S2, flexShrink: 0 }}>
      <svg width={S2} height={S2} viewBox="0 0 28 28" style={spin ? { animation: "dlspin 1.1s linear infinite" } : undefined}>
        <circle cx="14" cy="14" r={R} fill="none" stroke="var(--line)" strokeWidth="2.2" />
        <circle cx="14" cy="14" r={R} fill="none" stroke={paused ? "var(--sub)" : "var(--acc)"} strokeWidth="2.2" strokeLinecap="round"
          strokeDasharray={known ? C : C * 0.28 + " " + C} strokeDashoffset={known ? C * (1 - Math.min(1, pct / 100)) : 0}
          transform="rotate(-90 14 14)" style={known ? { transition: "stroke-dashoffset .3s linear" } : undefined} />
      </svg>
      {known && <span style={{ position: "absolute", fontSize: 9.5, fontWeight: 700, color: paused ? "var(--sub)" : "var(--acc)", lineHeight: 1 }}>{pct}%</span>}
    </span>
  );
}

const ThumbIcon = ({ uri, tkey, gd, cached, request, release, fallback, radius, big }) => {
  const ref = useRef(null);
  useEffect(() => {
    if (cached) return;
    const el = ref.current; if (!el) return;
    const io = new IntersectionObserver((ents) => {
      ents.forEach((en) => { if (en.isIntersecting) request(uri, tkey, gd, big); else release(uri, tkey); });
    }, { rootMargin: "800px 0px" }); // грузим заранее, ~11 строк за пределами экрана
    io.observe(el);
    return () => { io.disconnect(); release(uri, tkey); };
  }, [uri, tkey, cached]);
  if (cached) return <img src={cached} alt="" style={{ width: "100%", height: "100%", objectFit: "cover", borderRadius: radius != null ? radius : 13, animation: "fS .18s ease" }} />;
  return <span ref={ref} style={{ display: "flex", alignItems: "center", justifyContent: "center", width: "100%", height: "100%" }}>{fallback}</span>;
};
const EXT = {
  img: ["jpg", "jpeg", "jpe", "jfif", "png", "apng", "gif", "webp", "bmp", "dib", "svg", "svgz", "ico", "cur", "tif", "tiff", "heic", "heif", "avif", "jxl", "psd", "raw", "dng", "cr2", "nef", "arw"],
  video: ["mp4", "m4v", "mkv", "webm", "avi", "mov", "qt", "wmv", "flv", "f4v", "3gp", "3g2", "mpg", "mpeg", "mpe", "m2v", "ts", "m2ts", "mts", "vob", "ogv", "rm", "rmvb", "divx", "asf"],
  audio: ["mp3", "wav", "wave", "flac", "aac", "ogg", "oga", "opus", "m4a", "m4b", "wma", "amr", "aiff", "aif", "ape", "ac3", "dts", "mid", "midi", "mka", "ra", "au", "weba"],
  archive: ["zip", "rar", "7z", "tar", "gz", "tgz", "bz2", "tbz", "tbz2", "xz", "txz", "lz", "lzma", "zst", "z", "cab", "arj", "lha", "lzh", "ace", "iso", "dmg", "deb", "rpm", "jar", "war", "apk", "obb", "crx", "xpi", "epub", "001", "z01", "r00"],
  font: ["ttf", "otf", "woff", "woff2", "eot"],
  doc: ["doc", "docx", "dot", "odt", "ott", "rtf", "xls", "xlsx", "ods", "ppt", "pptx", "odp"],
  ebook: ["epub", "mobi", "azw", "azw3", "fb2", "djvu", "djv"],
  code: ["js", "mjs", "cjs", "jsx", "ts", "tsx", "vue", "json", "json5", "html", "htm", "css", "scss", "less", "xml", "py", "java", "kt", "kts", "c", "h", "hpp", "cpp", "cc", "cs", "go", "rs", "rb", "php", "swift", "dart", "lua", "sh", "bash", "bat", "ps1", "sql", "yml", "yaml", "toml", "gradle"],
};
const SYS_FOLDERS = {
  download: { d: I.dl, c: "#5AA9E6" }, downloads: { d: I.dl, c: "#5AA9E6" },
  music: { d: I.audio, c: "#E36FB0" }, ringtones: { d: I.ring, c: "#E3B14F" }, notifications: { d: I.bell, c: "#E3B14F" }, alarms: { d: I.alarm, c: "#E36F6F" },
  pictures: { d: I.img, c: "#6FD3A8" }, dcim: { d: I.cam, c: "#6FD3A8" }, screenshots: { d: I.img, c: "#6FD3A8" },
  movies: { d: I.video, c: "#A98BE0" }, video: { d: I.video, c: "#A98BE0" }, videos: { d: I.video, c: "#A98BE0" },
  podcasts: { d: I.mic, c: "#E3B14F" }, recordings: { d: I.mic, c: "#E3B14F" },
  documents: { d: I.doc2, c: "#5AA9E6" },
  android: { d: I.android, c: "#A4C639" }, data: { d: I.android, c: "#A4C639" }, obb: { d: I.android, c: "#A4C639" },
  apk: { d: I.apk, c: "#A4C639" },
  bannerhub: { d: I.img, c: "#E36FB0" }, fonts: { d: I.fontA, c: "#C9A227" }, books: { d: I.bookOpen, c: "#C98A4B" },
  games: { d: I.gamepad, c: "#A4C639" }, gamehub: { d: I.gamepad, c: "#A4C639" }, emu: { d: I.emuPad, c: "#A4C639" }, arcade: { d: I.emuPad, c: "#A4C639" }, mame: { d: I.emuPad, c: "#A4C639" },
  retroarch: { d: I.gamepad, c: "#7C5CFF" }, winlator: { d: I.win, c: "#5AA9E6" }, windows: { d: I.win, c: "#5AA9E6" },
  switch: { d: I.switchCon, c: "#5AA9E6", w: 34 }, "nintendo switch": { d: I.switchCon, c: "#5AA9E6", w: 34 }, nes: { d: I.gamepad, c: "#E05252" }, dandy: { d: I.gamepad, c: "#E05252" },
  media: { d: I.media, c: "#E0709A" },
  sega: { d: I.gamepad, c: "#3A7BD5" }, ps1: { d: I.gamepad, c: "#5AA9E6" }, ps2: { d: I.gamepad, c: "#5AA9E6" }, ps3: { d: I.gamepad, c: "#5AA9E6" }, psp: { d: I.gamepad, c: "#5AA9E6" }, vita3k: { d: I.gamepad, c: "#5AA9E6" },
  mt2: { d: I.tool, c: "#E3B14F" }, "mt manager": { d: I.tool, c: "#E3B14F" }, apkeditor: { d: I.tool, c: "#6FD3A8" },
  "smart launcher": { d: I.launcher, c: "#5AA9E6" }, smartlauncher: { d: I.launcher, c: "#5AA9E6" }, "mx player": { d: I.video, c: "#3A7BD5" }, mxplayer: { d: I.video, c: "#3A7BD5" },
};
// Настоящие системные папки — ТОЛЬКО для сортировки «сверху» (НЕ приложения)
const REAL_SYS = new Set(["android","alarms","audiobooks","dcim","documents","download","downloads","movies","music","notifications","pictures","podcasts","recordings","ringtones","screenshots","screenrecord","screenrecords","bluetooth","fonts","camera","data","media","obb","coloros","oppo","oneplus","heytap","realme","samsung","smartswitch","miui","xiaomi","huawei","vivo"]);
const EMPTY_SET = new Set();
const COLL = new Intl.Collator("ru", { numeric: true, sensitivity: "base" });
const scriptRank = (n) => { const c = (n || " ").charCodeAt(0); if (c < 128) return 0; if (c >= 0x400 && c <= 0x4FF) return 1; return 2; };
const nameCmp = (a, b) => { const ra = scriptRank(a), rb = scriptRank(b); if (ra !== rb) return ra - rb; return COLL.compare(a || "", b || ""); };
const sizeCache = new Map();
const ARCH_COLORS = { zip: "#E3B14F", rar: "#9B59B6", "7z": "#5AA9E6", tar: "#6FD3A8", gz: "#6FD3A8", xz: "#6FD3A8", bz2: "#6FD3A8", jar: "#E0574F" };
const fileIcon = (name) => {
  const ext = (name.split(".").pop() || "").toLowerCase();
  if (ext === "pdf") return { d: I.pdf, c: "#E0574F" };
  if (ext === "apk") return { d: I.apk, c: "#6FD3A8" };
  if (["apks", "xapk", "apkm", "apkx"].includes(ext)) return { d: I.apk, c: "#A4C639" };
  if (["ttf", "otf", "woff", "woff2"].includes(ext)) return { d: I.txt, c: "#C9A0FF" };
  if (ext === "lnk") return { d: I.lnk, c: GOLD };
  if (["txt", "md", "log", "ini", "cfg"].includes(ext)) return { d: I.txt, c: "#9FD0FF" };
  if (EXT.img.includes(ext)) return { d: I.img, c: "#7FB3FF" };
  if (EXT.video.includes(ext)) return { d: I.video, c: "#C98BFF" };
  if (EXT.audio.includes(ext)) return { d: I.audio, c: "#FF9D6B" };
  if (EXT.archive.includes(ext)) return { d: I.archive, c: ARCH_COLORS[ext] || GOLD };
  if (EXT.code.includes(ext)) return { d: I.code, c: "#6FD3A8" };
  return { d: I.file, c: SUB };
};
const SORTS = [
  ["az", "Имя: А-Я / A-Z"], ["za", "Имя: Я-А / Z-A"],
  ["sizeD", "Размер: больше → меньше"], ["sizeA", "Размер: меньше → больше"],
  ["dateN", "Дата: новые сверху"], ["dateO", "Дата: старые сверху"],
];

export default function App() {
  const init0 = useRef(buildInitial());
  const [tabs, setTabs] = useState(init0.current.base);
  const [active, setActive] = useState(init0.current.active);
  const [entries, setEntries] = useState([]);
  const [curUri, setCurUri] = useState("");
  // путь тома-флешки помечается префиксом @abs: и ведёт на абсолютный file://,
  // обычные пути по-прежнему резолвятся относительно базовой директории
  const uriForPath = async (pth) => {
    if (pth && pth.startsWith("@abs:")) {
      let raw = pth.slice(5);
      const enc = raw.split("/").map((seg) => encodeURIComponent(seg)).join("/");
      return { uri: "file://" + enc };
    }
    return Filesystem.getUri({ path: pth, directory: DIR });
  };
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [sel, setSel] = useState(() => new Set());
  const [selMode, setSelMode] = useState(false);
  const [clip, setClip] = useState(null);
  const [pasteMenu, setPasteMenu] = useState(false);
  const [progress, setProgress] = useState(null);
  const progressRef = useRef(null); progressRef.current = progress;
  // пока идёт операция — держим приложение живым службой, иначе система обрывает работу в фоне
  const opLive = useRef(false);
  const opArm = useRef(null);
  useEffect(() => {
    if (!progress || progress.native) {
      clearTimeout(opArm.current); opArm.current = null;
      if (opLive.current) { opLive.current = false; Apps.opEnd().catch(() => {}); }
      return;
    }
    // Android не даёт держать приложение в фоне без уведомления. Поэтому службу поднимаем
    // только если работа затянулась дольше 4 секунд: короткие операции проходят молча,
    // длинные получают защиту от выгрузки (ценой уведомления — иначе система не разрешает).
    if (!opLive.current && !opArm.current) {
      opArm.current = setTimeout(() => {
        opArm.current = null;
        const pr = progressRef.current;
        if (!pr) return;
        opLive.current = true;
        const lbl = pr.mode === "del" ? "Удаление" : pr.mode === "cut" ? "Перемещение" : pr.mode === "ext" ? "Распаковка" : pr.mode === "zip" ? "Архивирование" : "Копирование";
        Apps.opBegin({ title: lbl, text: pr.name || "", progress: 0, max: 100 }).catch(() => {});
      }, 4000);
    }
    if (!opLive.current) return;
    const label = progress.mode === "del" ? "Удаление" : progress.mode === "cut" ? "Перемещение" : progress.mode === "ext" ? "Распаковка" : progress.mode === "zip" ? "Архивирование" : "Копирование";
    const sub = progress.sub;
    const pct = progress.total ? Math.round(((progress.current + (sub && sub.total ? sub.done / sub.total : 0)) / progress.total) * 100) : 0;
    Apps.opUpdate({ title: label, text: (sub && sub.name) || progress.name || "", progress: pct, max: 100 }).catch(() => {});
  }, [progress]);
  useEffect(() => { if (!progress) Apps.cancelNotify().catch(() => {}); }, [progress]);
  // Копирование настраивать нечего: всё делается так, как правильно —
  // дата оригинала сохраняется, права и ссылки переносятся, мелочь копируется пачкой,
  // конец каждого файла сверяется с источником.
  const [zipProg, setZipProg] = useState(null);
  const cancelRef = useRef(false);
  const [query, setQuery] = useState(null);
  const [createOpen, setCreateOpen] = useState(false);
  const [createSub, setCreateSub] = useState(null);
  const [confirmDel, setConfirmDel] = useState(false);
  const [delInfo, setDelInfo] = useState(null);
  useEffect(() => {
    if (!confirmDel) { setDelInfo(null); return; }
    const items = [...sel].map((n) => entries.find((x) => x.name === n)).filter(Boolean);
    let cancelled = false;
    (async () => {
      let bytes = 0, count = 0;
      const rs = await Promise.all(items.map(async (e) => {
        if (e.type === "directory") { try { const r = await Apps.pathSize({ uri: e.uri }); return { b: r.bytes || 0, c: r.count || 0 }; } catch { return { b: 0, c: 0 }; } }
        return { b: e.size || 0, c: 1 };
      }));
      for (const r of rs) { bytes += r.b; count += r.c; }
      if (!cancelled) setDelInfo({ items: items.length, bytes, count });
    })();
    return () => { cancelled = true; };
  }, [confirmDel]);
  const [sheet, setSheet] = useState(null);
  const [toast, setToast] = useState(null);
  const [slide, setSlide] = useState(0);
  const [meta, setMeta] = useState(loadMeta);
  const [showHidden, setShowHidden] = useState(false);
  const VIEWKEY = "fm_view_v1";
  const [viewMode, setViewMode] = useState(() => ls.get(VIEWKEY) || "list");
  const FILTERS = [["all", "Все"], ["img", "Изображения"], ["vid", "Видео"], ["aud", "Аудио"], ["doc", "Документы"], ["apk", "APK"]];
  const [typeFilter, setTypeFilter] = useState("all");
  const [headSub, setHeadSub] = useState(null); // подсписок в меню трёх точек: sort | view | filter
  const headSubRef = useRef(null);
  const matchFilter = (e) => {
    if (typeFilter === "all" || e.type === "directory") return true;
    const n = e.name;
    if (typeFilter === "img") return isImg(n);
    if (typeFilter === "vid") return isVid(n);
    if (typeFilter === "aud") return isAudio(n);
    if (typeFilter === "apk") return /\.(apk|aab|apks|apkm|xapk)$/i.test(n);
    if (typeFilter === "doc") {
      const ext = (n.split(".").pop() || "").toLowerCase();
      return EXT.doc.includes(ext) || EXT.ebook.includes(ext) || ["pdf", "txt", "md", "csv", "log", "json", "xml", "html", "htm"].includes(ext);
    }
    return true;
  };
  const [sortMap, setSortMap] = useState(() => { try { return JSON.parse(ls.get("fm_sortmap_v1")) || {}; } catch { return {}; } });
  const [sortAsk, setSortAsk] = useState(null); // { mode } — спросить область применения
  // приоритет: точное правило папки > правило ближайшего родителя-поддерева ("sub://путь") > глобальная
  const effSortFor = (p) => {
    const m = sortMap;
    if (typeof m[p] === "string") return m[p];
    let best = null, bestLen = -1;
    for (const k in m) {
      if (!k.startsWith("sub://")) continue;
      const base = k.slice(6);
      if (base === "" || p === base || p.startsWith(base + "/")) { if (base.length > bestLen) { bestLen = base.length; best = m[k]; } }
    }
    return best || sortMode;
  };
  const [sortMode, setSortMode] = useState(() => ls.get(SORTKEY) || "az");
  const [sysTop, setSysTop] = useState(() => ls.get("fm_systop_v2") === "1");
  const [animFolders, setAnimFolders] = useState(() => ls.get("fm_anim_folders_v1") !== "0");
  const slideNav = (dir) => { if (!animFolders) return; setSlide(dir); setTimeout(() => setSlide(0), 300); };
  const [theme, setTheme] = useState(() => ls.get("fm_theme_v1") || "dark");
  const [themeBtn, setThemeBtn] = useState(() => ls.get("fm_themebtn_v1") !== "0");
  const FONT_KEY = "fm_fonts_v1";
  const BUILTIN_FONTS = [
    { id: "sys", name: "По умолчанию", css: "'Noto Sans',sans-serif" },
    { id: "comfortaa", name: "Comfortaa", css: "'Comfortaa',cursive" },
    { id: "roboto", name: "Roboto", css: "'Roboto',sans-serif" },
    { id: "verdana", name: "Verdana", css: "Verdana,Geneva,sans-serif" },
  ];
  const loadFonts = () => { try { const r = ls.get(FONT_KEY); return r ? JSON.parse(r) : { sel: "sys", custom: [] }; } catch { return { sel: "sys", custom: [] }; } };
  const [fonts, setFonts] = useState(loadFonts);
  const saveFonts = (f) => { try { ls.set(FONT_KEY, JSON.stringify(f)); } catch {} setFonts(f); };
  const allFonts = [...BUILTIN_FONTS, ...(fonts.custom || [])];
  const fontCss = (() => { const f = allFonts.find((x) => x.id === fonts.sel); return f ? f.css : "'Noto Sans',sans-serif"; })();
  useEffect(() => {
    let css = "";
    (fonts.custom || []).forEach((f) => { if (f.dataUrl) css += `@font-face{font-family:'${f.id}';src:url('${f.dataUrl}');}`; });
    let st = document.getElementById("fm-custom-fonts"); if (!st) { st = document.createElement("style"); st.id = "fm-custom-fonts"; document.head.appendChild(st); } st.textContent = css;
  }, [fonts.custom]);
  const fontFileRef = useRef(null);
  const onFontFile = (e) => {
    const f = e.target.files && e.target.files[0]; if (!f) return;
    const r = new FileReader();
    r.onload = (ev) => {
      const id = "cf_" + Date.now().toString(36);
      const name = f.name.replace(/\.(ttf|otf|woff2?)$/i, "");
      const nf = { id, name, css: `'${id}',sans-serif`, dataUrl: ev.target.result };
      saveFonts({ ...fonts, custom: [...(fonts.custom || []), nf], sel: id });
      showToast("Шрифт добавлен: " + name);
    };
    r.readAsDataURL(f); e.target.value = "";
  };
  const removeFont = (id) => {
    if (id === "sys") return;
    const isCustom = (fonts.custom || []).some((f) => f.id === id);
    const next = { ...fonts, sel: fonts.sel === id ? "sys" : fonts.sel };
    if (isCustom) next.custom = (fonts.custom || []).filter((f) => f.id !== id);
    saveFonts(next); showToast("Шрифт удалён");
  };
  const toggleTheme = () => { const t = theme === "dark" ? "light" : "dark"; setTheme(t); ls.set("fm_theme_v1", t); };
  const [headMenu, setHeadMenu] = useState(false);
  const [drawer, setDrawer] = useState(false);
  const [plusMenu, setPlusMenu] = useState(false);
  const DORDERKEY = "fm_drawer_order_v1";
  const [drawerOrder, setDrawerOrder] = useState(() => { try { return JSON.parse(localStorage.getItem(DORDERKEY) || "[]"); } catch { return []; } });
  // закладки пользователя в шторке: [{ id, name, path }]
  const BOOKKEY = "fm_bookmarks_v1";
  const [bookmarks, setBookmarks] = useState(() => { try { return JSON.parse(localStorage.getItem(BOOKKEY) || "[]"); } catch { return []; } });
  const saveBookmarks = (list) => { setBookmarks(list); try { localStorage.setItem(BOOKKEY, JSON.stringify(list)); } catch {} };
  // спрятанные стандартные пункты шторки (Data, OBB и прочее)
  const DHIDEKEY = "fm_drawer_hidden_v1";
  const [drawerHidden, setDrawerHidden] = useState(() => { try { return JSON.parse(localStorage.getItem(DHIDEKEY) || "[]"); } catch { return []; } });
  const hideDrawerItem = (id) => { const list = [...new Set([...drawerHidden, id])]; setDrawerHidden(list); try { localStorage.setItem(DHIDEKEY, JSON.stringify(list)); } catch {} };
  const showAllDrawerItems = () => { setDrawerHidden([]); try { localStorage.removeItem(DHIDEKEY); } catch {} };
  const addBookmark = () => {
    const items = [...sel].map(byName).filter((e) => e && e.type === "directory" && !e.remote);
    if (!items.length) { showToast("Выделите папку"); return; }
    const cur = [...bookmarks];
    let added = 0;
    for (const e of items) {
      const abs = absOfUri(e.uri);
      if (cur.some((b) => b.path === abs)) continue;
      cur.push({ id: "bm:" + abs, name: e.name, path: abs });
      added++;
    }
    saveBookmarks(cur);
    exitSel();
    if (added === 1) {
      const nb = cur[cur.length - 1];
      setSheet({ kind: "bmName", id: nb.id, val: nb.name });      // сразу даём переименовать
    } else showToast(added ? "В закладки: " + added : "Уже в закладках");
  };
  const [dDragId, setDDragId] = useState(null);
  const [dSwipeId, setDSwipeId] = useState(null);   // у какого пункта шторки открыты кнопки (свайп вправо)
  const dStartX = useRef(0);
  const dItemRefs = useRef({});
  const dRenderedRef = useRef([]);
  const dLp = useRef(); const dMovedR = useRef(false); const dLpFired = useRef(false); const dStartY = useRef(0);
  const dRects = useRef([]); const dTo = useRef(-1); const dDragPid = useRef(null); const dDragIdRef = useRef(null);
  const dSwipeTarget = useRef(null);
  const clearDDrag = () => { Object.values(dItemRefs.current).forEach((el) => { if (el) el.style.transform = ""; }); };
  const persistDOrder = (list) => { const ids = list.map((x) => x.id); localStorage.setItem(DORDERKEY, JSON.stringify(ids)); setDrawerOrder(ids); };
  const dDown = (ev, id) => {
    dMovedR.current = false; dLpFired.current = false; dStartY.current = ev.clientY; dStartX.current = ev.clientX; dSwipeTarget.current = id;
    const pid = ev.pointerId, tgt = ev.currentTarget;
    clearTimeout(dLp.current);
    dLp.current = setTimeout(() => {
      if (dMovedR.current) return;
      const list = dRenderedRef.current;
      dRects.current = list.map((it) => { const el = dItemRefs.current[it.id]; return el ? el.getBoundingClientRect() : null; });
      dLpFired.current = true; dDragPid.current = pid; dDragIdRef.current = id; dTo.current = list.findIndex((it) => it.id === id);
      setDDragId(id); buzz(15);
      try { tgt.setPointerCapture(pid); } catch {}
    }, 250);
  };
  const dMove = (ev) => {
    if (!dLpFired.current) {
      const dx = ev.clientX - dStartX.current, dy = ev.clientY - dStartY.current;
      // свайп вправо по пункту — показать кнопки
      if (dx > 34 && Math.abs(dx) > Math.abs(dy) * 1.6) {
        dMovedR.current = true; clearTimeout(dLp.current);
        const id = dSwipeTarget.current;
        if (id && dSwipeId !== id) { setDSwipeId(id); buzz(10); }
        return;
      }
      if (dx < -20 && dSwipeId) { dMovedR.current = true; clearTimeout(dLp.current); setDSwipeId(null); return; }
      if (Math.abs(dy) > 8) { dMovedR.current = true; clearTimeout(dLp.current); }
      return;
    }
    ev.preventDefault();
    const list = dRenderedRef.current;
    const from = list.findIndex((it) => it.id === dDragIdRef.current);
    const rf = dRects.current[from]; if (!rf) return;
    const dy = ev.clientY - dStartY.current;
    const fingerY = rf.top + rf.height / 2 + dy;
    let count = 0;
    for (let j = 0; j < dRects.current.length; j++) { const r = dRects.current[j]; if (!r || j === from) continue; if (r.top + r.height / 2 < fingerY) count++; }
    let to = count; if (to < 0) to = 0; if (to > list.length - 1) to = list.length - 1;
    dTo.current = to;
    const span = rf.height;
    for (let j = 0; j < list.length; j++) {
      const el = dItemRefs.current[list[j].id]; if (!el) continue;
      if (j === from) { el.style.transform = "translateY(" + dy + "px)"; continue; }
      let t = 0;
      if (from < to && j > from && j <= to) t = -span;
      else if (to < from && j >= to && j < from) t = span;
      el.style.transform = t ? "translateY(" + t + "px)" : "translateY(0)";
    }
  };
  const dUp = (item) => {
    clearTimeout(dLp.current);
    try { if (dDragPid.current != null) { const el = dItemRefs.current[dDragIdRef.current]; el && el.releasePointerCapture(dDragPid.current); } } catch {}
    if (dLpFired.current) {
      const list = dRenderedRef.current, from = list.findIndex((it) => it.id === dDragIdRef.current), to = dTo.current;
      dLpFired.current = false; dDragIdRef.current = null; clearDDrag(); setDDragId(null);
      if (from !== -1 && to !== -1 && from !== to) { const nl = [...list]; const [m] = nl.splice(from, 1); nl.splice(to, 0, m); persistDOrder(nl); }
      return;
    }
    if (dMovedR.current) return;
    if (dSwipeId) { setDSwipeId(null); return; }        // кнопки открыты — первый тап их прячет
    if (item.kind === "wd") openWebdav(item.a);
    else if (item.kind === "gd") openGDrive();
    else if (typeof item.p === "string" && item.p.startsWith("@gd:")) {
      const sec = item.p.slice(4);
      const label = sec === "trash" ? "Корзина" : sec === "starred" ? "Избранное" : sec === "shared" ? "Доступные мне" : "Общие диски";
      setDrawer(false);
      setTabs((ts) => ts.map((t, i) => (i === active ? { ...t, src: { kind: "gdrive", folder: "root", section: sec, name: label, stack: [{ id: "root", name: label }] } } : t)));
    }
    else { setDrawer(false); setTabPath(item.p); }
  };
  const [webdavs, setWebdavs] = useState([]);
  const [wdForm, setWdForm] = useState(null);
  const [wd, setWd] = useState(null);
  useEffect(() => { Apps.webdavGetAccounts().then((r) => { try { setWebdavs(JSON.parse(r.json || "[]")); } catch {} }).catch(() => {}); }, []);
  const saveWebdav = async () => { const f = wdForm; if (!f || !f.url) { setWdForm(null); return; } const list = [...webdavs, { name: (f.name || f.url).trim(), url: f.url.trim().replace(/\/?$/, "/"), user: (f.user || "").trim(), pass: f.pass || "" }]; setWebdavs(list); setWdForm(null); try { await Apps.webdavSetAccounts({ json: JSON.stringify(list) }); } catch {} };
  const delWebdav = async (i) => { const list = webdavs.filter((_, j) => j !== i); setWebdavs(list); try { await Apps.webdavSetAccounts({ json: JSON.stringify(list) }); } catch {} };
  const openWebdav = (acc) => { setDrawer(false); setTabs((ts) => ts.map((t, i) => (i === active ? { ...t, src: { kind: "webdav", acc, url: acc.url, name: acc.name, stack: [{ url: acc.url, name: acc.name }] } } : t))); };
  const wdEnter = async (e) => { if (e.type === "directory") { try { const r = await Apps.webdavList({ url: e.url, user: wd.acc.user, pass: wd.acc.pass }); setWd((v) => ({ ...v, stack: [...v.stack, { url: e.url, name: e.name }], entries: r.files || [] })); } catch (er) { showToast("Ошибка: " + (er?.message || "")); } } else { showToast("Загрузка…"); try { await Apps.webdavGet({ url: e.url, user: wd.acc.user, pass: wd.acc.pass, name: e.name }); showToast("Скачано → Download/" + e.name); } catch (er) { showToast("Ошибка: " + (er?.message || "")); } } };
  const wdBack = async () => { if (!wd) return; if (wd.stack.length <= 1) { setWd(null); return; } const st = wd.stack.slice(0, -1); const top = st[st.length - 1]; try { const r = await Apps.webdavList({ url: top.url, user: wd.acc.user, pass: wd.acc.pass }); setWd({ ...wd, stack: st, entries: r.files || [] }); } catch {} };
  const [gdIn, setGdIn] = useState(false);
  const [gdQuota, setGdQuota] = useState(null);      // сколько занято на Диске
  useEffect(() => {
    if (!gdIn) { setGdQuota(null); return; }
    Apps.gdriveQuota().then(setGdQuota).catch(() => {});
  }, [gdIn]);
  const [volumes, setVolumes] = useState([]); // тома: внутренняя память, SD, USB
  const loadVolumes = React.useCallback(() => {
    Apps.storageVolumes().then((r) => setVolumes((r && r.volumes) || [])).catch(() => setVolumes([]));
  }, []);
  useEffect(() => { loadVolumes(); }, [loadVolumes]);
  // флешку могли воткнуть при открытом приложении — обновляем список при возврате
  useEffect(() => { let h; CapApp.addListener("resume", loadVolumes).then((l) => (h = l)); return () => { h && h.remove(); }; }, [loadVolumes]);
  const [gd, setGd] = useState(null);
  const b64url = (buf) => btoa(String.fromCharCode.apply(null, new Uint8Array(buf))).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
  const googleLogin = async () => {
    setDrawer(false);
    const verifier = b64url(crypto.getRandomValues(new Uint8Array(32)));
    const chal = b64url(await crypto.subtle.digest("SHA-256", new TextEncoder().encode(verifier)));
    localStorage.setItem("gd_verifier", verifier);
    const url = "https://accounts.google.com/o/oauth2/v2/auth?client_id=" + encodeURIComponent("589335091963-6n9ss077f7htshue4vd288eb2t2jduhb.apps.googleusercontent.com") + "&redirect_uri=" + encodeURIComponent("com.googleusercontent.apps.589335091963-6n9ss077f7htshue4vd288eb2t2jduhb:/oauth") + "&response_type=code&scope=" + encodeURIComponent("https://www.googleapis.com/auth/drive") + "&code_challenge=" + chal + "&code_challenge_method=S256&access_type=offline&prompt=consent";
    try { await Apps.openExternalUrl({ url }); } catch { showToast("Не открыть браузер"); }
  };
  useEffect(() => {
    const consume = async () => { try { const r = await Apps.oauthConsume(); if (r.code) { const v = localStorage.getItem("gd_verifier") || ""; await Apps.gdriveToken({ code: r.code, verifier: v }); localStorage.removeItem("gd_verifier"); setGdIn(true); showToast("Google Drive подключён"); } } catch (e) { if (e?.message) showToast("Google: " + e.message); } };
    Apps.gdriveLoggedIn().then((r) => setGdIn(!!r.yes)).catch(() => {});
    consume();
    const h = CapApp.addListener("resume", consume);
    return () => { h.then((x) => x.remove()).catch(() => {}); };
  }, []);
  const openGDrive = () => { setDrawer(false); setTabs((ts) => ts.map((t, i) => (i === active ? { ...t, src: { kind: "gdrive", folder: "root", name: "Google Drive", stack: [{ id: "root", name: "Google Drive" }] } } : t))); };
  const gdEnter = async (e) => { if (e.type === "directory") { try { const r = await Apps.gdriveList({ folder: e.id }); setGd((v) => ({ ...v, stack: [...v.stack, { id: e.id, name: e.name }], entries: r.files || [] })); } catch (er) { showToast("Ошибка: " + (er?.message || "")); } } else { showToast("Загрузка…"); try { await Apps.gdriveGet({ id: e.id, name: e.name, mime: e.mime || "" }); showToast("Скачано → Download/" + e.name); } catch (er) { showToast("Ошибка: " + (er?.message || "")); } } };
  const gdBack = async () => { if (!gd) return; if (gd.stack.length <= 1) { setGd(null); return; } const st = gd.stack.slice(0, -1); const top = st[st.length - 1]; try { const r = await Apps.gdriveList({ folder: top.id }); setGd({ ...gd, stack: st, entries: r.files || [] }); } catch {} };
  const [settings, setSettings] = useState(false);
  const [settingsPage, setSettingsPage] = useState(null); // null=список, "theme"/"fonts"/"sort"/"icons"
  const [iconDB, setIconDB] = useState(() => loadMap(ICONKEY));
  const saveIconDB = (db) => { setIconDB(db); saveMap(ICONKEY, db); };
  const [iconPick, setIconPick] = useState(null);   // { folder, name } — выбираем картинку для иконки папки
  const [iconApps, setIconApps] = useState(null);  // { folder, name, list, q } — выбор иконки из приложения
  const [appPick, setAppPick] = useState(null);    // { file, list, q } — открыть файл любым приложением
  const allAppsCache = useRef(null);
  const startAppPick = async (file) => {
    setSheet(null);
    setAppPick({ file, list: allAppsCache.current, q: "" });
    if (allAppsCache.current) return;
    try {
      const r = await Apps.appList({ iconSize: 144 });
      const list = ((r && r.apps) || []).sort((a, b) => nameCmp(a.label || a.pkg, b.label || b.pkg));
      allAppsCache.current = list;
      setAppPick((m) => (m ? { ...m, list } : m));
    } catch { setAppPick(null); showToast("Не удалось получить список приложений"); }
  };
  const openWithApp = async (app) => {
    const f = appPick && appPick.file;
    setAppPick(null);
    if (!f) return;
    try { await Apps.open({ uri: f.uri, mime: mimeOf(f.name), packageName: app.pkg, ...playArgs(f) }); }
    catch (e) { showToast("Приложение не открыло файл"); }
  };
  // спрашиваем, откуда брать иконку
  const askIconSource = (folderPath, name) => { setSelMenu(false); exitSel(); setSheet({ kind: "iconSrc", folder: folderPath, name }); };
  const startIconPick = (folderPath, name) => {
    setSheet(null); leaveSearch(); setQuery(null);
    setIconPick({ folder: folderPath, name, back: path });      // куда вернуться после выбора
    setTabs((ts) => ts.map((t, i) => (i === active ? { ...t, src: null, path: "" } : t)));   // начинаем с внутренней памяти
    showToast("Выберите картинку");
  };
  const startIconApps = async (folderPath, name) => {
    setSheet(null);
    setIconApps({ folder: folderPath, name, list: null, q: "" });
    try {
      const r = await Apps.appList({ iconSize: 192 });
      const list = ((r && r.apps) || []).sort((a, b) => nameCmp(a.label || a.pkg, b.label || b.pkg));
      setIconApps((m) => (m ? { ...m, list } : m));
    } catch (e) { setIconApps(null); showToast("Не удалось получить список приложений"); }
  };
  const applyIconFromApp = async (app) => {
    const target = iconApps;
    try {
      const im = new Image(); im.decoding = "async";
      await new Promise((res, rej) => { im.onload = res; im.onerror = () => rej(new Error("нет иконки")); im.src = cfs(app.icon); });
      const S2 = 192, w = im.naturalWidth, h = im.naturalHeight, side = Math.min(w, h);
      const c = document.createElement("canvas"); c.width = S2; c.height = S2;
      c.getContext("2d").drawImage(im, (w - side) / 2, (h - side) / 2, side, side, 0, 0, S2, S2);
      const db = { ...loadMap(ICONKEY) }; db[target.folder] = c.toDataURL("image/png"); saveIconDB(db);
      setIconApps(null);
      showToast("Иконка задана: " + (target.name || ""));
    } catch (e) { setIconApps(null); showToast("Ошибка: " + (e?.message || "")); }
  };
  // картинку ужимаем до 192 точек — иконке больше не нужно, а память бережём
  const applyIconFrom = async (e) => {
    const target = iconPick;
    try {
      const src = cfs(e.uri);
      const im = new Image(); im.decoding = "async";
      await new Promise((res, rej) => { im.onload = res; im.onerror = () => rej(new Error("не удалось прочитать картинку")); im.src = src; });
      const S2 = 192, w = im.naturalWidth, h = im.naturalHeight, side = Math.min(w, h);
      const c = document.createElement("canvas"); c.width = S2; c.height = S2;
      c.getContext("2d").drawImage(im, (w - side) / 2, (h - side) / 2, side, side, 0, 0, S2, S2);
      const data = c.toDataURL(/\.png$/i.test(e.name) ? "image/png" : "image/jpeg", 0.9);
      const db = { ...loadMap(ICONKEY) }; db[target.folder] = data; saveIconDB(db);
      setIconPick(null);
      if (target.back != null) setTabPath(target.back);          // возвращаемся туда, где меняли иконку
      showToast("Иконка задана: " + (target.name || baseName(target.folder) || "Storage"));
    } catch (err) { setIconPick(null); if (target.back != null) setTabPath(target.back); showToast("Ошибка: " + (err?.message || "")); }
  };
  const [thumbs, setThumbs] = useState({});
  const [pwPrompt, setPwPrompt] = useState(null); // { resolve, retry }
  const [pwVal, setPwVal] = useState("");
  const pwCacheRef = useRef({});
  const getCachedPw = (uri) => { const e = pwCacheRef.current[uri]; return e && e.exp > Date.now() ? e.pw : null; };
  const setCachedPw = (uri, pw) => { pwCacheRef.current[uri] = { pw, exp: Date.now() + 3600000 }; };
  const askPassword = (retry) => new Promise((resolve) => { setPwVal(""); setPwPrompt({ resolve, retry: !!retry }); });
  const resolvePassword = (val) => { setPwPrompt((p) => { if (p) p.resolve(val); return null; }); };
  const isImg = (n) => /\.(png|jpg|jpeg|webp|gif|bmp|avif|apng|heic|heif|hif|tif|tiff|jxl|tgs)$/i.test(n) || RAW_RE.test(n);
  const isPdf = (n) => /\.pdf$/i.test(n);
  const isAudio = (n) => EXT.audio.includes((n.split(".").pop() || "").toLowerCase());
  const isVid = (n) => EXT.video.includes((n.split(".").pop() || "").toLowerCase());
  const isFont = (n) => /\.(ttf|otf|woff2?|woff)$/i.test(n);
  const isSplitApk = (n) => /\.(apks|xapk|apkm|apkx)$/i.test(n);
  const isGzTar = (n) => /\.(tgz|tar|gz)$/i.test(n);
  const [fontView, setFontView] = useState(null);
  const [fontText, setFontText] = useState("");
  const openFontViewer = async (e) => {
    setFontText(""); setFontView({ name: e.name, loading: true });
    try {
      const r = await Filesystem.readFile({ path: e.uri });
      const ext = (e.name.split(".").pop() || "").toLowerCase();
      const fmt = ext === "otf" ? "opentype" : ext === "woff2" ? "woff2" : ext === "woff" ? "woff" : "truetype";
      const mime = ext === "otf" ? "font/otf" : ext === "woff2" ? "font/woff2" : ext === "woff" ? "font/woff" : "font/ttf";
      const fam = "fv_" + Date.now();
      const css = "@font-face{font-family:'" + fam + "';src:url(data:" + mime + ";base64," + r.data + ") format('" + fmt + "');}";
      setFontView({ name: e.name, family: fam, css });
    } catch (err) { setFontView(null); showToast("Не удалось открыть шрифт: " + (err?.message || "")); }
  };
  const cfs = (u) => { if (typeof u === "string" && /^https?:\/\//.test(u)) return u; try { return Capacitor.convertFileSrc(u); } catch { return u; } };
  const [tabsMenu, setTabsMenu] = useState(false);
  const [selMenu, setSelMenu] = useState(false);
  const [props, setProps] = useState(null);
  const [viewer, setViewer] = useState(null);       // { items:[entry], idx }
  const [viewerBar, setViewerBar] = useState(false); // видна ли панель
  const [dragX, setDragX] = useState(0);
  const [dragY, setDragY] = useState(0);
  const [zoom, setZoom] = useState(1);
  const [pan, setPan] = useState({ x: 0, y: 0 });
  const pinchRef = useRef(null);
  const [dragging, setDragging] = useState(false);
  const [viewerDel, setViewerDel] = useState(false);
  const vTouch = useRef(null);
  const [pdf, setPdf] = useState(null);       // { uri, name }
  const [pdfArr, setPdfArr] = useState([]);   // dataURL по страницам
  const [pdfN, setPdfN] = useState(0);
  const [pdfZoom, setPdfZoom] = useState(1);
  const pdfTok = useRef(0);
  const pdfPinch = useRef({ d0: 0, z0: 1 });
  const pdfDist = (t) => Math.hypot(t[0].clientX - t[1].clientX, t[0].clientY - t[1].clientY);
  // ---- поиск по тексту PDF: текст достаём библиотекой pdf.js, страницы по-прежнему рисует система ----
  const [pdfSearch, setPdfSearch] = useState(null); // { open, q, busy, hits:[{page, snippet, rects:[{l,t,w,h}]}], cur }
  const pdfDocRef = useRef(null);   // { uri, doc, textCache: {page: items} }
  const pdfPageRefs = useRef({});
  const closePdf = () => { pdfTok.current++; setPdf(null); setPdfArr([]); setPdfN(0); setPdfZoom(1); setPdfSearch(null); try { if (pdfDocRef.current && pdfDocRef.current.doc) pdfDocRef.current.doc.destroy(); } catch {} pdfDocRef.current = null; };
  const pdfLib = useRef(null);
  const pdfOpenDoc = async (uri) => {
    if (pdfDocRef.current && pdfDocRef.current.uri === uri) return pdfDocRef.current.doc;
    if (!pdfLib.current) { const lib = await import("pdfjs-dist/legacy/build/pdf.mjs"); lib.GlobalWorkerOptions.workerSrc = pdfWorkerUrl; pdfLib.current = lib; }
    const data = await readBytes(uri);
    const doc = await pdfLib.current.getDocument({ data, isEvalSupported: false }).promise;
    pdfDocRef.current = { uri, doc, textCache: {} };
    return doc;
  };
  const pdfRunSearch = async (qRaw) => {
    const q = (qRaw || "").trim().toLowerCase();
    if (!pdf || !q) { setPdfSearch((ps) => (ps ? { ...ps, hits: [], cur: -1, q: qRaw } : ps)); return; }
    setPdfSearch((ps) => ({ ...(ps || { open: true }), q: qRaw, busy: true }));
    const my = pdfTok.current;
    try {
      const doc = await pdfOpenDoc(pdf.uri);
      const hits = [];
      for (let p = 1; p <= doc.numPages; p++) {
        if (pdfTok.current !== my) return;
        const page = await doc.getPage(p);
        const vp = page.getViewport({ scale: 1 });
        const tc = await page.getTextContent();
        const items = tc.items.filter((it) => it.str != null);
        // сплошной текст страницы + карта «символ -> элемент»
        let text = ""; const map = [];
        for (let k = 0; k < items.length; k++) { const st = items[k].str; for (let c = 0; c < st.length; c++) map.push(k); text += st; if (items[k].hasEOL) { text += "\n"; map.push(k); } else { text += " "; map.push(k); } }
        const low = text.toLowerCase();
        let from = 0, found = 0;
        while (found < 200) {
          const at = low.indexOf(q, from); if (at < 0) break;
          const end = at + q.length; from = end;
          const rects = []; const seen = new Set();
          for (let c = at; c < end; c++) {
            const k = map[c]; if (k == null || seen.has(k)) continue; seen.add(k);
            const it = items[k]; const tx = it.transform || [1, 0, 0, 1, 0, 0];
            const x = tx[4], y = tx[5], w = it.width || 0, h = it.height || Math.abs(tx[3]) || 10;
            const r = vp.convertToViewportRectangle([x, y, x + w, y + h]);
            rects.push({ l: Math.min(r[0], r[2]) / vp.width, t: Math.min(r[1], r[3]) / vp.height, w: Math.abs(r[2] - r[0]) / vp.width, h: Math.abs(r[3] - r[1]) / vp.height });
          }
          const a = Math.max(0, at - 28), b = Math.min(text.length, end + 28);
          hits.push({ page: p, snippet: (a > 0 ? "…" : "") + text.slice(a, b).replace(/\s+/g, " ") + (b < text.length ? "…" : ""), rects });
          found++;
        }
        if (hits.length >= 500) break;
        if (p % 8 === 0) setPdfSearch((ps) => (ps ? { ...ps, hits: hits.slice(), cur: hits.length ? 0 : -1 } : ps));
      }
      if (pdfTok.current !== my) return;
      setPdfSearch((ps) => (ps ? { ...ps, busy: false, hits, cur: hits.length ? 0 : -1 } : ps));
      if (hits.length) pdfGoHit(hits[0]); else showToast("Ничего не найдено");
    } catch (e) { if (pdfTok.current === my) { setPdfSearch((ps) => (ps ? { ...ps, busy: false } : ps)); showToast("Поиск по PDF не удался: " + (e?.message || "")); } }
  };
  const pdfGoHit = (h) => { const el = h && pdfPageRefs.current[h.page - 1]; if (el) { try { el.scrollIntoView({ block: "center", behavior: "smooth" }); } catch { el.scrollIntoView(); } } };
  const pdfStep = (d) => { setPdfSearch((ps) => { if (!ps || !ps.hits.length) return ps; const cur = (ps.cur + d + ps.hits.length) % ps.hits.length; pdfGoHit(ps.hits[cur]); return { ...ps, cur }; }); };
  const openPdf = async (entry) => {
    const tok = ++pdfTok.current;
    setPdf({ uri: entry.uri, name: entry.name }); setPdfArr([]); setPdfN(0); setPdfZoom(1);
    const W = Math.min(Math.round((window.innerWidth || 400) * (window.devicePixelRatio || 2)), 1600);
    try {
      const first = await Apps.pdfPage({ uri: entry.uri, page: 0, width: W });
      if (pdfTok.current !== tok) return;
      const n = first.pages || 0; setPdfN(n);
      if (first.data) setPdfArr([first.data]);
      for (let p = 1; p < n; p++) {
        const r = await Apps.pdfPage({ uri: entry.uri, page: p, width: W });
        if (pdfTok.current !== tok) return;
        setPdfArr((a) => [...a, r.data]);
      }
    } catch (e) { if (pdfTok.current === tok) { showToast("Не удалось открыть PDF: " + (e?.message || "")); setPdf(null); } }
  };
  const pdfTouchStart = (e) => { if (e.touches.length === 2) { pdfPinch.current.d0 = pdfDist(e.touches); pdfPinch.current.z0 = pdfZoom; } };
  const pdfTouchMove = (e) => { if (e.touches.length === 2 && pdfPinch.current.d0 > 0) { e.preventDefault(); let z = pdfPinch.current.z0 * (pdfDist(e.touches) / pdfPinch.current.d0); z = Math.max(1, Math.min(4, z)); setPdfZoom(z); } };

  const AUTONEXTKEY = "fm_audio_autonext_v1";
  const [audioAuto, setAudioAuto] = useState(() => ls.get(AUTONEXTKEY) === "1");
  const [player, setPlayer] = useState(null);   // { idx, count, name, playing, pos, dur }
  const [playerMenu, setPlayerMenu] = useState(false);
  const playerList = useRef({ uris: [], names: [] });
  const openAudio = (entry) => {
    // файл из архива в списке папки не значится — тогда играем его одного
    let list = entries.filter((e) => e.type !== "directory" && isAudio(e.name));
    let idx = list.findIndex((e) => e.uri === entry.uri || e.name === entry.name);
    if (idx < 0) { list = [entry]; idx = 0; }
    playerList.current = { uris: list.map((e) => e.uri), names: list.map((e) => e.name) };
    Apps.audioOpen({ uris: playerList.current.uris, names: playerList.current.names, index: idx, autoNext: audioAuto }).catch((e) => showToast("Плеер: " + (e?.message || "")));
    setPlayer({ idx, count: list.length, name: entry.name, playing: true, pos: 0, dur: 0 }); setPlayerMenu(false);
  };
  const playerToggle = () => { Apps.audioToggle().catch(() => {}); setPlayer((p) => (p ? { ...p, playing: !p.playing } : p)); };
  const playerNext = () => { Apps.audioNext().catch(() => {}); };
  const playerPrev = () => { Apps.audioPrev().catch(() => {}); };
  const playerSeek = (ms) => { Apps.audioSeek({ ms }).catch(() => {}); setPlayer((p) => (p ? { ...p, pos: ms } : p)); };
  const playerClose = () => { Apps.audioClose().catch(() => {}); setPlayer(null); setPlayerMenu(false); };
  const playerSetAs = (type) => { const uri = playerList.current.uris[player ? player.idx : 0]; if (!uri) return; Apps.audioSetAs({ uri, type }).then(() => showToast(type === "alarm" ? "Установлено на будильник" : "Установлено на звонок")).catch((e) => { if ((e?.message || "").includes("write_settings")) showToast("Разрешите изменение системных настроек и повторите"); else showToast("Не удалось: " + (e?.message || "")); }); setPlayerMenu(false); };
  useEffect(() => {
    if (!player) return;
    let stop = false;
    const tick = async () => { try { const s = await Apps.audioState(); if (stop) return; if (!s.alive) { setPlayer(null); return; } setPlayer((p) => (p ? { ...p, idx: s.idx, count: s.count, name: s.name, playing: s.playing, pos: s.pos, dur: s.dur } : p)); } catch {} };
    const iv = setInterval(tick, 500); tick();
    return () => { stop = true; clearInterval(iv); };
  }, [!!player]);

  // Родной просмотрщик: рисует сам, поэтому не мерцает и не собирается кусками.
  const openViewer = async (entry) => {
    if (!entry.remote && isImg(entry.name)) {
      const imgs = (entries || []).filter((e) => e.type !== "directory" && !e.remote && isImg(e.name));
      let i = imgs.findIndex((e) => e.uri === entry.uri || e.name === entry.name);
      if (i < 0) { imgs.length = 0; imgs.push(entry); i = 0; }
      try {
        const r = await Apps.viewPhotos({ uris: imgs.map((e) => e.uri), index: i, debug: dbgOn });
        const act = r && r.action, p = r && r.uri;
        if (!act) { forceRef.current = true; refresh(); return; }
        const f = p ? { name: baseName(p), uri: p, type: "file" } : entry;
        if (act === "share") Apps.share({ uri: f.uri, mime: mimeOf(f.name) }).catch(() => {});
        else if (act === "edit") showOpenMenu(f, mimeOf(f.name), { edit: true });
        else if (act === "props") setProps(f);
        else if (act === "wallpaper") Apps.setWallpaper({ uri: f.uri }).catch(() => showToast("Не удалось"));
        else if (act === "deleted") showToast("Удалено");
        forceRef.current = true; refresh();
      } catch (e) { openViewerWeb(entry); }
      return;
    }
    openViewerWeb(entry);
  };
  const openViewerWeb = (entry) => {
    // файла из архива нет в списке папки — показываем его самого, иначе просмотрщик открывался пустым
    let items = entries.filter((e) => e.type !== "directory" && isImg(e.name));
    let idx = items.findIndex((e) => e.uri === entry.uri || e.name === entry.name);
    if (idx < 0) { items = [entry]; idx = 0; }
    setViewer({ items, idx }); setViewerBar(true); setDragX(0); setDragY(0); setZoom(1); setPan({ x: 0, y: 0 }); setViewerDel(false);
  };
  const viewerGo = (d) => { setZoom(1); setPan({ x: 0, y: 0 }); setViewer((v) => { if (!v) return v; const ni = v.idx + d; if (ni < 0 || ni >= v.items.length) return v; return { ...v, idx: ni }; }); };
  const viewerCur = viewer && viewer.items[viewer.idx];
  // ---- жесты просмотрщика: щипок, перетаскивание, листание, закрытие вниз ----
  const stageRef = useRef(null), vbgRef = useRef(null);
  const [vFast, setVFast] = useState({});            // экранные варианты снимков: рисуются сразу
  const vFastRef = useRef({}); vFastRef.current = vFast;
  const fsOn = useRef(false);                        // полноэкранный режим включали мы
  const [vReady, setVReady] = useState({});          // какие снимки уже показаны целиком
  const V_GAP = 16;
  const gz = useRef({ scale: 1, tx: 0, ty: 0, dragX: 0, dragY: 0, mode: "none", pts: new Map(), lastTap: 0, sx: 0, sy: 0, st0: 0, bTx: 0, bTy: 0, sScale: 1, sDist: 0, sMidX: 0, sMidY: 0, slideFrom: 0 });
  const vApply = (anim) => {
    const g = gz.current, st = stageRef.current;
    if (st) {
      st.style.transition = anim ? "transform .2s cubic-bezier(.2,.8,.3,1)" : "none";
      st.style.transform = "translate3d(" + (g.tx + g.dragX) + "px," + (g.ty + g.dragY) + "px,0) scale(" + g.scale + ")";
    }
    if (vbgRef.current) vbgRef.current.style.opacity = String(Math.max(0, 1 - Math.abs(g.dragY) / 600));
  };
  const vDist = (a, b) => Math.hypot(a.x - b.x, a.y - b.y);
  const vClampPan = () => {
    const g = gz.current, w = window.innerWidth, h = window.innerHeight;
    const mx = (g.scale - 1) * w / 2, my = (g.scale - 1) * h / 2;
    g.tx = Math.max(-mx, Math.min(mx, g.tx));
    g.ty = Math.max(-my, Math.min(my, g.ty));
  };
  const vCloseAnim = () => {
    Apps.setFullscreen({ on: false }).catch(() => {});      // полосы вернутся под уходящим снимком
    const t2 = THEMES[theme] || THEMES.dark;
    Apps.setBars({ color: t2["--bg"], light: theme === "light" }).catch(() => {});
    fsOn.current = false;
    const st = stageRef.current;
    if (st) { st.style.transition = "transform .2s ease"; st.style.transform = "translateY(" + window.innerHeight + "px)"; }
    if (vbgRef.current) { vbgRef.current.style.transition = "opacity .2s"; vbgRef.current.style.opacity = "0"; }
    setTimeout(() => setViewer(null), 185);
  };
  const [vZoomed, setVZoomed] = useState(false);      // приблизили — показываем оригинал
  const vToggleZoom = (x, y) => {
    const g = gz.current;
    if (g.scale > 1) { g.scale = 1; g.tx = 0; g.ty = 0; }
    else { g.scale = 2.6; g.tx = (window.innerWidth / 2 - x) * (g.scale - 1); g.ty = (window.innerHeight / 2 - y) * (g.scale - 1); vClampPan(); }
    g.mode = g.scale > 1 ? "pan" : "none";
    setVZoomed(g.scale > 1.05);
    vApply(true);
  };
  const vStart = (e) => {
    const g = gz.current;
    for (const t of e.changedTouches) g.pts.set(t.identifier, { x: t.clientX, y: t.clientY });
    if (g.pts.size >= 2) {
      const [a, b] = [...g.pts.values()];
      g.mode = "pinch"; g.sDist = vDist(a, b) || 1; g.sScale = g.scale;
      g.sMidX = (a.x + b.x) / 2; g.sMidY = (a.y + b.y) / 2; g.bTx = g.tx; g.bTy = g.ty;
    } else {
      const t = e.changedTouches[0];
      g.sx = t.clientX; g.sy = t.clientY; g.st0 = Date.now();
      g.dragX = 0; g.dragY = 0; g.bTx = g.tx; g.bTy = g.ty;
      g.mode = g.scale > 1 ? "pan" : "undecided";
    }
  };
  const vMove = (e) => {
    const g = gz.current;
    if (e.cancelable) e.preventDefault();
    for (const t of e.changedTouches) if (g.pts.has(t.identifier)) g.pts.set(t.identifier, { x: t.clientX, y: t.clientY });
    if (g.mode === "pinch" && g.pts.size >= 2) {
      const [a, b] = [...g.pts.values()];
      g.scale = Math.max(1, Math.min(4, g.sScale * vDist(a, b) / g.sDist));
      g.tx = g.bTx + ((a.x + b.x) / 2 - g.sMidX);
      g.ty = g.bTy + ((a.y + b.y) / 2 - g.sMidY);
      vApply(false); return;
    }
    const t = e.changedTouches[0];
    const dx = t.clientX - g.sx, dy = t.clientY - g.sy;
    if (g.mode === "pan") { g.tx = g.bTx + dx; g.ty = g.bTy + dy; vApply(false); return; }
    if (g.mode === "undecided" && Math.hypot(dx, dy) > 10) g.mode = Math.abs(dx) > Math.abs(dy) ? "nav" : "close";
    if (g.mode === "nav") { g.dragX = dx; vApply(false); }
    else if (g.mode === "close") { g.dragY = Math.max(0, dy); g.dragX = dx * 0.3; vApply(false); }
  };
  const vEnd = (e) => {
    const g = gz.current;
    for (const t of e.changedTouches) g.pts.delete(t.identifier);
    if (g.mode === "pinch") {
      if (g.scale <= 1.02) { g.scale = 1; g.tx = 0; g.ty = 0; } else vClampPan();
      setVZoomed(g.scale > 1.05);
      vApply(true);
      if (g.pts.size === 1) { const t = [...g.pts.values()][0]; g.sx = t.x; g.sy = t.y; g.bTx = g.tx; g.bTy = g.ty; g.mode = "pan"; }
      else if (g.pts.size === 0) g.mode = g.scale > 1 ? "pan" : "none";
      return;
    }
    if (g.pts.size > 0) return;
    const dt = Date.now() - g.st0;
    if (g.mode === "undecided") {
      const now = Date.now();
      if (now - g.lastTap < 280) { g.lastTap = 0; vToggleZoom(g.sx, g.sy); }     // двойной тап — приблизить
      else { g.lastTap = now; setViewerBar((b) => !b); }                          // одиночный — спрятать панели
      g.mode = "none"; return;
    }
    if (g.mode === "close") {
      if (g.dragY > 110) vCloseAnim();
      else { g.dragY = 0; g.dragX = 0; vApply(true); }
      g.mode = "none"; return;
    }
    if (g.mode === "nav") {
      const TH = Math.min(60, window.innerWidth * 0.12), flick = dt < 260 && Math.abs(g.dragX) > 30;
      const W = window.innerWidth + V_GAP;
      let moved = false;
      if ((g.dragX < -TH || (flick && g.dragX < 0)) && viewer.idx < viewer.items.length - 1) { moved = true; g.slideFrom = g.dragX + W; viewerGo(1); }
      else if ((g.dragX > TH || (flick && g.dragX > 0)) && viewer.idx > 0) { moved = true; g.slideFrom = g.dragX - W; viewerGo(-1); }
      if (!moved) { g.dragX = 0; vApply(true); }
      g.mode = "none"; return;
    }
    if (g.mode === "pan") { vClampPan(); vApply(true); g.mode = g.scale > 1 ? "pan" : "none"; }
  };
  // смена кадра: новый доезжает от пальца, а не появляется скачком
  useLayoutEffect(() => {
    const g = gz.current, st = stageRef.current;
    g.scale = 1; g.tx = 0; g.ty = 0; g.dragY = 0; g.mode = "none"; g.pts.clear();
    setVZoomed(false);
    if (g.slideFrom) {
      g.dragX = g.slideFrom; g.slideFrom = 0;
      if (st) { st.style.transition = "none"; st.style.transform = "translate3d(" + g.dragX + "px,0,0)"; }
      requestAnimationFrame(() => {
        gz.current.dragX = 0;
        const el = stageRef.current;
        if (el) { el.style.transition = "transform .2s cubic-bezier(.2,.8,.3,1)"; el.style.transform = "translate3d(0,0,0)"; }
      });
    } else {
      g.dragX = 0;
      if (st) { st.style.transition = "none"; st.style.transform = ""; }
    }
    if (vbgRef.current) vbgRef.current.style.opacity = "1";
    // важно: следим за номером кадра, а не за ссылкой. Иначе подмена превью на готовый
    // снимок считалась переходом и кадр заново уезжал за край и возвращался.
  }, [viewer && viewer.idx, !!viewer]);
  // экранный вариант снимка: полноразмерный кадр браузер рисует кусками, этот появляется целиком
  useEffect(() => {
    if (!viewer || viewer.remote) return;
    let stop = false;
    (async () => {
      for (const d of [0, 1, -1]) {
        const m = viewer.items[viewer.idx + d];
        if (!m || !m.uri || !isImg(m.name) || vFastRef.current[m.uri] || stop) continue;
        try {
          const r = await Apps.viewImage({ uri: m.uri, size: 1440 });
          if (!stop && r && r.uri) setVFast((v) => ({ ...v, [m.uri]: r.uri }));
        } catch {}
      }
    })();
    return () => { stop = true; };
  }, [viewer && viewer.idx, !!viewer]);
  // соседи: ±1 держим в разметке, ±2 просто подтягиваем в кэш
  const vSlots = viewer ? [-1, 0, 1].map((d) => ({ d, m: viewer.items[viewer.idx + d] })).filter((x) => x.m) : [];
  useEffect(() => {
    if (!viewer) return;
    const warm = [];
    for (const d of [-2, 2]) {
      const m = viewer.items[viewer.idx + d];
      if (m && m.uri && isImg(m.name)) { const im = new Image(); im.decoding = "async"; im.src = cfs(m.uri); warm.push(im); }
    }
    return () => { for (const im of warm) im.src = ""; };
  }, [viewer && viewer.idx]);
  // просмотр на весь экран: системные полосы прячутся вместе с нашими
  useEffect(() => {
    if (viewer) { fsOn.current = true; Apps.setFullscreen({ on: true, showBars: viewerBar }).catch(() => {}); return; }
    // окно трогаем только если сами его меняли — иначе на старте сбивается вёрстка панелей
    if (!fsOn.current) return;
    fsOn.current = false;
    Apps.setFullscreen({ on: false }).catch(() => {});
    const t = THEMES[theme] || THEMES.dark;
    Apps.setBars({ color: t["--bg"], light: theme === "light" }).catch(() => {});
  }, [!!viewer, viewerBar]);
  // особые форматы: раскодированная картинка / анимация для текущего кадра просмотрщика
  const [vDec, setVDec] = useState(null); // { uri, kind: "img"|"lottie", src?, data?, loading?, err? }
  useEffect(() => {
    const e = viewerCur;
    if (!e) { setVDec(null); return; }
    const n = e.name;
    const special = !e.remote && (isRaw(n) || isHeic(n) || isTiff(n) || isJxl(n) || isTgs(n));
    if (!special) { setVDec(null); return; }
    let dead = false;
    setVDec({ uri: e.uri, loading: true });
    (async () => {
      try {
        let r;
        if (isRaw(n) || isHeic(n)) { const p = await Apps.imgPreview({ uri: e.uri }); if (!p || !p.path) throw new Error("нет встроенного превью"); r = { kind: "img", src: cfs(p.path) }; }
        else r = await decodeForView(e.uri, n);
        if (!dead) setVDec({ uri: e.uri, ...(r || {}) });
      } catch (err) { if (!dead) setVDec({ uri: e.uri, err: (err && err.message) || "не удалось раскодировать" }); }
    })();
    return () => { dead = true; };
  }, [viewerCur && viewerCur.uri]);
  const viewerDelete = async () => {
    if (!viewerCur) return; setViewerDel(false);
    try { await delTree(viewerCur); } catch {}
    setViewer((v) => { if (!v) return v; const items = v.items.filter((_, i) => i !== v.idx); if (items.length === 0) return null; return { items, idx: Math.min(v.idx, items.length - 1) }; });
    await refresh(); showToast("Удалено");
  };
  const [propCount, setPropCount] = useState(null);
  const [openMenu, setOpenMenu] = useState(null);
  // архив принадлежит вкладке: переключился — состояние сохранилось, вернулся — архив на месте
  const [arcTabs, setArcTabs] = useState({});           // { idВкладки: { view, path, sel } }
  const arcKey = (tabs[active] && tabs[active].id) != null ? String(tabs[active].id) : "0";
  const arcState = arcTabs[arcKey] || null;
  const arcView = arcState ? arcState.view : null;
  const arcPath = arcState ? arcState.path : "";
  const setArcView = (v) => setArcTabs((m) => {
    const cur = m[arcKey] || { view: null, path: "", sel: EMPTY_SET };
    const nv = typeof v === "function" ? v(cur.view) : v;
    const nm = { ...m };
    if (!nv) delete nm[arcKey]; else nm[arcKey] = { ...cur, view: nv };
    return nm;
  });
  const setArcPath = (p) => setArcTabs((m) => {
    const cur = m[arcKey]; if (!cur) return m;
    return { ...m, [arcKey]: { ...cur, path: typeof p === "function" ? p(cur.path) : p } };
  });
  // ZIP хранит плоский список путей — собираем из них уровень папок/файлов, как в обычном менеджере
  const arcLevel = React.useMemo(() => {
    const all = (arcView && arcView.entries) || [];
    const p = arcPath;
    const dirs = new Map(), files = [];
    for (const it of all) {
      const n = String(it.name || "").replace(/^\/+/, "");
      if (!n || !n.startsWith(p)) continue;
      const rest = n.slice(p.length);
      if (!rest) continue;
      const cut = rest.indexOf("/");
      if (cut >= 0) {
        const dn = rest.slice(0, cut); if (!dn) continue;
        const d = dirs.get(dn) || { name: dn, dir: true, count: 0, size: 0, prefix: p + dn + "/" };
        if (!(it.dir || rest.endsWith("/"))) { d.count++; d.size += it.size || 0; }
        dirs.set(dn, d);
      } else if (it.dir || rest.endsWith("/")) {
        const dn = rest.replace(/\/$/, "");
        if (dn && !dirs.has(dn)) dirs.set(dn, { name: dn, dir: true, count: 0, size: 0, prefix: p + dn + "/" });
      } else files.push({ ...it, label: rest });
    }
    const ds = [...dirs.values()].sort((a, b) => nameCmp(a.name, b.name));
    const fs = files.sort((a, b) => nameCmp(a.label, b.label));
    return [...ds, ...fs];
  }, [arcView && arcView.entries, arcPath]);
  const arcNamesUnder = (prefix) => ((arcView && arcView.entries) || []).filter((x) => String(x.name || "").replace(/^\/+/, "").startsWith(prefix) && !x.dir).map((x) => x.name);
  const [pendingExtract, setPendingExtract] = useState(null); // { uri, names|null, label }
  const [menuArmed, setMenuArmed] = useState(false);
  // то же самое для нижних окон: без этого палец, открывший окно, тут же жмёт его первую строку
  const [sheetArmed, setSheetArmed] = useState(false);
  useEffect(() => {
    if (!sheet) { setSheetArmed(false); return; }
    setSheetArmed(false);
    const t = setTimeout(() => setSheetArmed(true), 260);
    return () => clearTimeout(t);
  }, [sheet && sheet.kind, sheet && sheet.file && sheet.file.uri]);
  useEffect(() => { if (openMenu) { setMenuArmed(false); const t = setTimeout(() => setMenuArmed(true), 320); return () => clearTimeout(t); } setMenuArmed(false); }, [openMenu && openMenu.file]);
  const omSheetRef = useRef(null);
  useLayoutEffect(() => {
    if (!openMenu || !omSheetRef.current) return;
    const r = omSheetRef.current.getBoundingClientRect();
    const ox = (openMenu.originX != null ? openMenu.originX : window.innerWidth / 2) - r.left;
    const oy = (openMenu.originY != null ? openMenu.originY : r.top) - r.top;
    omSheetRef.current.style.transformOrigin = ox + "px " + oy + "px";
  }, [openMenu && openMenu.file]);
  const arcSel = (arcState && arcState.sel) || EMPTY_SET;
  const setArcSel = (v) => setArcTabs((m) => {
    const cur = m[arcKey]; if (!cur) return m;
    return { ...m, [arcKey]: { ...cur, sel: typeof v === "function" ? v(cur.sel) : v } };
  });
  // сколько выбранных лежит под каждой папкой текущего уровня — один проход по выбранным
  // Выделено «штук»: папка — одна единица, её содержимое отдельно не считается
  const arcUnits = React.useMemo(() => {
    const keys = [...arcSel];
    const dirs = keys.filter((k) => String(k).endsWith("/"));
    return keys.filter((k) => !dirs.some((d) => d !== k && String(k).startsWith(d)));
  }, [arcSel]);
  const arcSelUnder = React.useMemo(() => {
    const m = new Map();
    if (!arcSel.size) return m;
    for (const raw of arcSel) {
      const n = String(raw || "").replace(/^\/+/, "");
      if (!n.startsWith(arcPath)) continue;
      const rest = n.slice(arcPath.length);
      const cut = rest.indexOf("/");
      if (cut < 0) continue;
      if (rest.slice(cut) === "/") continue;            // это сама папка, а не файл в ней
      const key = arcPath + rest.slice(0, cut) + "/";
      m.set(key, (m.get(key) || 0) + 1);
    }
    return m;
  }, [arcSel, arcPath]);
  const arcLp = useRef(false), arcLpT = useRef(null), arcPX = useRef(0), arcPY = useRef(0);
  const arcListRef = useRef(null), arcSpacerRef = useRef(null);
  useLayoutEffect(() => {
    const el = arcListRef.current, sp = arcSpacerRef.current;
    if (!el || !sp || !arcView || !arcView.entries) return;
    sp.style.height = "0px";
    const ch = el.clientHeight;
    const wrap = sp.nextElementSibling;
    const kids = wrap ? wrap.children : [];
    let rowsH = 0, fourH = 0;
    if (kids.length) {
      const first = kids[0], last = kids[kids.length - 1];
      const bottom = last.getBoundingClientRect().bottom;
      rowsH = Math.max(0, bottom - first.getBoundingClientRect().top);
      const take = Math.min(4, kids.length);
      fourH = Math.max(0, bottom - kids[kids.length - take].getBoundingClientRect().top);
    }
    // запас снизу под плавающую панель — иначе последний элемент прячется под неё
    let navH = 0;
    if (navRef.current) { const nr = navRef.current.getBoundingClientRect(), lr = el.getBoundingClientRect(); navH = Math.max(0, lr.bottom - nr.top); }
    el.style.paddingBottom = navH + "px";
    const usable = el.clientHeight - navH;
    let pt = Math.max(0, usable - Math.min(rowsH, fourH));
    sp.style.height = pt + "px";
    el.scrollTop = rowsH >= usable ? pt : Math.max(0, el.scrollHeight - el.clientHeight);
    // доводка по факту, как в основном списке
    if (kids.length && rowsH < usable && navRef.current) {
      const delta = navRef.current.getBoundingClientRect().top - kids[kids.length - 1].getBoundingClientRect().bottom;
      if (Math.abs(delta) > 0.5) {
        pt = Math.max(0, pt + delta);
        sp.style.height = pt + "px";
        el.scrollTop = Math.max(0, el.scrollHeight - el.clientHeight);
      }
    }
    /* eslint-disable-next-line */
  }, [arcView && arcView.entries, arcPath]);
  const [shared, setShared] = useState([]);
  const [saveMode, setSaveMode] = useState(false);
  const [pickMode, setPickMode] = useState(null);       // { mime, multi } — нас позвали выбрать файл
  const checkShared = async () => {
    try {
      const r = await Apps.getShared();
      const files = r.files || [];
      if (r.mode === "pick") { setShared([]); setPickMode({ mime: r.pickMime || "*/*", multi: !!r.pickMulti }); return; }
      if (files.length === 0) { setShared([]); return; }
      if (r.mode === "open") { setShared([]); openSharedHere(); }
      else if (r.mode === "save") { setShared([]); setSaveMode(true); }
      else setShared(files);
    } catch {}
  };
  const openSharedHere = async () => {
    try {
      const t = await Apps.saveSharedTemp();
      setShared([]);
      if (t && t.uri) await showOpenMenu({ name: t.name, uri: t.uri, type: "file" }, mimeOf(t.name));
    } catch (e) { showToast("Не удалось открыть: " + (e?.message || "")); }
  };
  useEffect(() => { checkShared(); const h = CapApp.addListener("resume", checkShared); return () => { h.then((x) => x.remove()).catch(() => {}); }; }, []);
  const saveSharedHere = async () => {
    try { const u = await Filesystem.getUri({ path, directory: DIR }); const r = await Apps.saveShared({ dir: u.uri }); showToast("Сохранено: " + (r.saved || 0) + " в " + (baseName(path) || "Storage")); setShared([]); setSaveMode(false); refresh(); }
    catch (e) { showToast("Ошибка сохранения: " + (e?.message || "")); }
  };
  const dismissShared = async () => { try { await Apps.clearShared(); } catch {} setShared([]); };
  // «Копировать»/«Вырезать» из архива: файлы извлекаются во временную папку и кладутся в буфер,
  // вставка идёт обычным путём; при «вырезать» записи удаляются из архива после успешной вставки
  // Изменение архива: ZIP правим на месте, RAR/7z — пересобираем в ZIP рядом, как другие архиваторы
  const arcModify = async (opts) => {
    if (!arcView) return;
    const uri = arcView.uri, pw = getCachedPw(uri) || undefined;
    setProgress({ current: 0, total: 100, name: arcView.name, mode: "ext" });
    let sub = null;
    try { sub = await Apps.addListener("opProgress", (ev) => setProgress((p) => (p ? { ...p, current: ev.done, total: ev.total || 100, name: ev.name } : p))); } catch {}
    try {
      const st = await Apps.zipEditable({ uri, password: pw }).catch(() => ({ editable: false }));
      if (st.editable && st.kind === "7z") {
        // 7z меняем на месте: формат сохраняется, пересборка в ZIP не нужна
        await Apps.sevenModify({ uri, remove: opts.remove || null, renameFrom: opts.renameFrom || null, renameTo: opts.renameTo || null, password: pw });
        showToast("Готово");
        const r = await Apps.zipList({ uri, password: pw });
        setArcView((m) => (m ? { ...m, entries: (r.entries || []).map((x) => ({ name: x.name, size: x.size || 0, dir: !!x.dir })) } : m));
        setArcSel(new Set());
        try { sub && sub.remove(); } catch {}
        setProgress(null);
        return;
      }
      if (st.editable) {
        if (opts.remove) await Apps.zipDeleteEntries({ uri, entries: opts.remove, password: pw });
        if (opts.renameFrom) await Apps.zipRenameEntry({ uri, from: opts.renameFrom, to: opts.renameTo, password: pw });
        showToast("Готово");
        const r = await Apps.zipList({ uri, password: pw });
        setArcView((m) => (m ? { ...m, entries: (r.entries || []).map((x) => ({ name: x.name, size: x.size || 0, dir: !!x.dir })) } : m));
      } else {
        const res = await Apps.arcRebuild({ uri, remove: opts.remove || null, renameFrom: opts.renameFrom || null, renameTo: opts.renameTo || null, password: pw });
        showToast("Архив пересобран: " + res.name);
        setArcView(null);
        await refresh();
      }
      setArcSel(new Set());
    } catch (e) { showToast("Ошибка: " + (e?.message || "")); }
    finally { try { sub && sub.remove(); } catch {} setProgress(null); }
  };
  const arcDelete = (ev) => {
    if (!arcSel.size) return;
    const r = ev && ev.currentTarget ? ev.currentTarget.getBoundingClientRect() : { left: 180, width: 0, top: 400 };
    setConfirmDel({ arc: true, names: [...arcSel], cx: r.left + r.width / 2, top: r.top });
  };
  // Перенос/переименование записей внутри архива (папку разворачивает нативная часть)
  const arcMoveEntries = async (from, to) => {
    if (!arcView || !from.length) return;
    const pw = getCachedPw(arcView.uri) || undefined;
    setProgress({ current: 0, total: 100, name: arcView.name, mode: "ext" });
    let sub = null;
    try { sub = await Apps.addListener("opProgress", (ev) => setProgress((p) => (p ? { ...p, current: ev.done, total: ev.total || 100, name: ev.name } : p))); } catch {}
    try {
      await Apps.arcMove({ uri: arcView.uri, from, to, password: pw });
      const r = await Apps.zipList({ uri: arcView.uri, password: pw });
      setArcView((m) => (m ? { ...m, entries: (r.entries || []).map((x) => ({ name: x.name, size: x.size || 0, dir: !!x.dir })) } : m));
      setArcSel(new Set());
      showToast("Готово");
    } catch (e) { showToast("Ошибка: " + (e?.message || "")); }
    finally { try { sub && sub.remove(); } catch {} setProgress(null); }
  };
  const arcRename = () => {
    if (arcUnits.length !== 1) return;
    const raw = arcUnits[0];
    const isDir = String(raw).endsWith("/");
    const full = isDir ? String(raw).slice(0, -1) : String(raw);
    const base = full.split("/").pop();
    const sp = splitExt(base, isDir);
    setSheet({ kind: "arcRename", full: raw, base: sp.base, ext: sp.ext, editExt: false, isDir });
  };
  // Буфер из архива: запоминаем только имена записей. Архив остаётся открытым —
  // вставить можно и внутрь него (перенос между папками архива), и наружу (тогда файлы извлекаются).
  const arcGrab = (mode) => {
    if (!arcView || !arcSel.size) return;
    const names = [...arcSel];
    setArcSel(new Set());
    setClip((q) => [...(q || []), { id: Date.now() + Math.random(), mode, items: [], srcPath: "", arc: { uri: arcView.uri, name: arcView.name, prefix: arcPath, entries: names } }]);
    showToast((mode === "copy" ? "Копировать: " : "Вырезать: ") + names.length + " об.");
  };
  // Вставка внутри того же архива: записи переезжают в текущую папку архива
  const arcPasteInside = async (task) => {
    if (!arcView || !task || !task.arc) return;
    const pw = getCachedPw(arcView.uri) || undefined;
    const pre = task.arc.prefix || "";
    const from = [], to = [];
    // если выбрана папка, её содержимое перечислять не нужно — движок развернёт сам
    const dirKeys = task.arc.entries.filter((x) => String(x).endsWith("/"));
    const entries = task.arc.entries.filter((n) => !dirKeys.some((d) => d !== n && String(n).startsWith(d)));
    for (const n of entries) {
      const rel = n.startsWith(pre) ? n.slice(pre.length) : String(n).split("/").pop();
      const target = arcPath + rel;
      if (target === n) continue;                       // уже здесь
      if (String(n).endsWith("/") && arcPath.startsWith(n)) { showToast("Папку нельзя положить внутрь себя"); return; }
      from.push(n); to.push(target);
    }
    if (!from.length) { showToast("Уже в этой папке"); setClip((q) => (q || []).filter((t) => t.id !== task.id)); return; }
    setProgress({ current: 0, total: 100, name: arcView.name, mode: "ext" });
    let sub = null;
    try { sub = await Apps.addListener("opProgress", (ev) => setProgress((p) => (p ? { ...p, current: ev.done, total: ev.total || 100, name: ev.name } : p))); } catch {}
    try {
      if (task.mode === "copy") await Apps.arcCopyInside({ uri: arcView.uri, from, to, password: pw });
      else await Apps.arcMove({ uri: arcView.uri, from, to, password: pw });
      const r = await Apps.zipList({ uri: arcView.uri, password: pw });
      setArcView((m) => (m ? { ...m, entries: (r.entries || []).map((x) => ({ name: x.name, size: x.size || 0, dir: !!x.dir })) } : m));
      setClip((q) => (q || []).filter((t) => t.id !== task.id));
      showToast(task.mode === "copy" ? "Скопировано в архиве: " + from.length : "Перемещено в архиве: " + from.length);
    } catch (e) { showToast("Ошибка: " + (e?.message || "")); }
    finally { try { sub && sub.remove(); } catch {} setProgress(null); }
  };
  // Вставка наружу: сначала достаём записи во временную папку, дальше обычная вставка
  const arcMaterialize = async (task) => {
    const dirKeys = task.arc.entries.filter((x) => String(x).endsWith("/"));
    const names = task.arc.entries.filter((n) => !dirKeys.some((d) => d !== n && String(n).startsWith(d)));
    const tmpRel = "Download/.yevtmp/arc_" + Date.now();
    const destDir = await absPath(tmpRel);
    await Apps.zipExtractAll({ uri: task.arc.uri, dest: destDir, entries: names, password: getCachedPw(task.arc.uri) || undefined });
    // папка из архива остаётся папкой: кладём её целиком, а не вываливаем файлы по отдельности
    const items = [];
    for (const n of names) {
      const isDir = String(n).endsWith("/");
      const clean = isDir ? String(n).slice(0, -1) : String(n);
      const base = clean.split("/").pop();
      const u = await Filesystem.getUri({ path: tmpRel + "/" + clean, directory: DIR });
      items.push({ name: base, uri: u.uri, type: isDir ? "directory" : "file" });
    }
    return { ...task, mode: "copy", items, fromArc: task.mode === "cut" ? { uri: task.arc.uri, name: task.arc.name, entries: names } : null, arc: null };
  };
  const [allFiles, setAllFiles] = useState(true); // {file, mime, apps, useDefault, editHide}

  const cur = tabs[active], path = cur?.path || "";
  const srcRef = useRef(null); srcRef.current = (cur && cur.src) || null;
  const srcKey = cur && cur.src ? cur.src.kind + "|" + (cur.src.folder || cur.src.url || cur.src.id || "") : "";
  /* ===== Источники: единая абстракция. У каждого — флаги «что умею», по ним строятся меню и кнопки ===== */
  const CAPS = {
    local:  { write: true,  mkdir: true,  rename: true,  del: true,  copyFrom: true,  meta: true,  pins: true,  search: true,  share: true,  openExt: true, stream: false, watch: true },
    gdrive: { write: true,  mkdir: true,  rename: true,  del: true,  copyFrom: false, meta: false, pins: false, search: false, share: false, openExt: false, stream: true, watch: false },
    webdav: { write: false, mkdir: false, rename: false, del: false, copyFrom: false, meta: false, pins: false, search: false, share: false, openExt: false, stream: true, watch: false },
    search: { write: false, mkdir: false, rename: true,  del: true,  copyFrom: true,  meta: false, pins: false, search: true,  share: true,  openExt: true, stream: false, watch: false },
  };
  const provKind = (t) => (t && t.src ? t.src.kind : "local");
  const [roArea, setRoArea] = useState(false);           // системный раздел: писать туда нельзя
  const capsBase = CAPS[provKind(cur)] || CAPS.local;
  const caps = roArea ? { ...capsBase, write: false, mkdir: false, del: false, rename: false } : capsBase;
  const inSearch = !!(cur && cur.src && cur.src.kind === "search");
  // корень внутренней памяти в абсолютном виде — чтобы переводить абсолютные пути результатов поиска в пути вкладок
  const storageRoot = useRef("/storage/emulated/0");
  useEffect(() => { Filesystem.getUri({ path: "", directory: DIR }).then((u) => { const a = absOfUri(u.uri).replace(/\/$/, ""); if (a) storageRoot.current = a; }).catch(() => {}); }, []);
  const pathFromAbs = (abs) => { const r = storageRoot.current; if (abs === r) return ""; if (abs.startsWith(r + "/")) return abs.slice(r.length + 1); return "@abs:" + abs; };
  const relLabel = (abs) => { const r = storageRoot.current; if (!abs) return ""; if (abs === r) return "Storage"; if (abs.startsWith(r + "/")) return "Storage/" + abs.slice(r.length + 1); const v = volumes.find((x) => abs === x.path || abs.startsWith(x.path + "/")); if (v) return v.name + abs.slice(v.path.length); return abs; };
  /* ===== Поиск в два слоя: индекс Android отвечает сразу, обход диска досылает остальное пачками ===== */
  const searchResRef = useRef({});                 // id -> результаты
  const [searchLive, setSearchLive] = useState(null); // { id, total, running }
  const searchLiveRef = useRef(null); searchLiveRef.current = searchLive;
  const [searchOpts, setSearchOpts] = useState({ types: "all", minMb: "", maxMb: "", date: "any", hidden: false });
  const [searchPanel, setSearchPanel] = useState(false);
  const activeRef = useRef(active); activeRef.current = active;
  const tabsRef = useRef(tabs); tabsRef.current = tabs;
  const stopSearch = (id) => { if (!id) return; Apps.searchStop({ id }).catch(() => {}); setSearchLive((l) => (l && l.id === id ? { ...l, running: false } : l)); };
  const startDeepSearch = async (qText) => {
    const q0 = (qText != null ? qText : (query || "")).trim();
    const src = srcRef.current;
    if (src && src.kind !== "search") return;         // из облака и WebDAV поиска по диску нет
    if (src && src.kind === "search") stopSearch(src.id);
    const rootUri = src && src.kind === "search" ? src.rootUri : curUri;
    if (!rootUri) return;
    const back = src && src.kind === "search" ? src.back : { path };
    const id = "s" + Date.now().toString(36);
    searchResRef.current[id] = [];
    const rootAbs = absOfUri(rootUri);
    const label = "Поиск: " + (q0 || "*") + (searchOpts.types !== "all" ? " · " + (FILTERS.find((f) => f[0] === searchOpts.types) || ["", "папки"])[1].toLowerCase() : "");
    setTabs((ts) => ts.map((t, i) => (i === activeRef.current ? { ...t, src: { kind: "search", id, q: q0, rootUri, rootAbs, back, stack: [{ name: label }] } } : t)));
    setSearchLive({ id, total: 0, running: true });
    setEntries([]); setLoading(true);
    const now = Date.now(), day = 86400000;
    const from = searchOpts.date === "day" ? now - day : searchOpts.date === "week" ? now - 7 * day : searchOpts.date === "month" ? now - 31 * day : searchOpts.date === "year" ? now - 366 * day : -1;
    const mb = (v) => { const n = parseFloat(String(v).replace(",", ".")); return isNaN(n) || n < 0 ? -1 : Math.round(n * 1048576); };
    try {
      await Apps.searchStart({ id, query: q0, roots: [rootUri], types: searchOpts.types, minSize: mb(searchOpts.minMb), maxSize: mb(searchOpts.maxMb), from, to: -1, hidden: !!searchOpts.hidden });
    } catch (e) { showToast("Поиск не запустился: " + (e?.message || "")); setLoading(false); }
  };
  useEffect(() => {
    let h1, h2;
    Apps.addListener("searchFound", (ev) => {
      if (!ev || !ev.id) return;
      const arr = searchResRef.current[ev.id]; if (!arr) return;
      const items = ev.items || [];
      for (const it of items) arr.push(it);
      const t = tabsRef.current[activeRef.current];
      if (t && t.src && t.src.kind === "search" && t.src.id === ev.id) setEntries((prev) => (prev.length === arr.length - items.length ? [...prev, ...items] : arr.slice()));
      setSearchLive((l) => (l && l.id === ev.id ? { ...l, total: arr.length } : l));
    }).then((l) => (h1 = l));
    Apps.addListener("searchDone", (ev) => {
      if (!ev || !ev.id) return;
      setSearchLive((l) => (l && l.id === ev.id ? { ...l, running: false, total: (searchResRef.current[ev.id] || []).length } : l));
      const t = tabsRef.current[activeRef.current];
      if (t && t.src && t.src.kind === "search" && t.src.id === ev.id) { setLoading(false); if (!ev.cancelled) showToast("Найдено: " + ((searchResRef.current[ev.id] || []).length)); }
    }).then((l) => (h2 = l));
    return () => { h1 && h1.remove(); h2 && h2.remove(); };
  }, []);
  const leaveSearch = () => { const src = srcRef.current; if (src && src.kind === "search") { stopSearch(src.id); delete searchResRef.current[src.id]; } };
  const persist = (t) => { setTabs(t); saveTabs(t); };
  const toastT = useRef(null);
  const showToast = (m, ms) => { clearTimeout(toastT.current); setToast(m); toastT.current = setTimeout(() => setToast(null), ms || 1900); };
  const byName = (n) => entries.find((x) => x.name === n);
  const keyOf = (name) => join(path, name);
  const isHidden = (e) => meta.hidden.has(keyOf(e.name)) || e.name.startsWith(".");

  const applyMeta = (m) => { setMeta({ ...m }); saveMeta(m); };

  const reqRef = useRef(0);
  const forceRef = useRef(false);
  const LC_KEY = "fm_lcache_v1";
  const localCache = useRef(null);
  if (localCache.current === null) { try { localCache.current = JSON.parse(localStorage.getItem(LC_KEY) || "{}") || {}; } catch { localCache.current = {}; } }
  // кэш листингов держим в файле: localStorage мал (~5 МБ) и пишет синхронно, подвешивая прокрутку
  const lcLoaded = useRef(false);
  useEffect(() => {
    if (lcLoaded.current) return; lcLoaded.current = true;
    Apps.cacheGet({ key: LC_KEY }).then((r) => {
      if (!r || !r.data) return;
      try {
        const disk = JSON.parse(r.data) || {};
        localCache.current = { ...disk, ...(localCache.current || {}) };
        try { localStorage.removeItem(LC_KEY); } catch {} // переехали на диск
      } catch {}
    }).catch(() => {});
  }, []);
  const lcSaveT = useRef();
  const lcSave = () => {
    clearTimeout(lcSaveT.current);
    lcSaveT.current = setTimeout(() => {
      try {
        const keys = Object.keys(localCache.current);
        if (keys.length > 120) keys.slice(0, keys.length - 120).forEach((k) => delete localCache.current[k]);
        Apps.cacheSet({ key: LC_KEY, data: JSON.stringify(localCache.current) }).catch(() => {
          try { localStorage.setItem(LC_KEY, JSON.stringify(localCache.current)); } catch {}
        });
      } catch {}
    }, 800);
  };
  const GDC_KEY = "fm_gd_cache_v1", GDPT_KEY = "fm_gd_ptoken_v1";
  const gdCacheAll = () => { try { return JSON.parse(localStorage.getItem(GDC_KEY) || "{}"); } catch { return {}; } };
  const gdCacheGet = (fid) => gdCacheAll()[fid];
  const gdCacheSet = (fid, files) => { try { const a = gdCacheAll(); a[fid] = files; localStorage.setItem(GDC_KEY, JSON.stringify(a)); } catch {} };
  const gdCacheClear = () => { try { localStorage.removeItem(GDC_KEY); } catch {} };
  const list = useCallback(async () => {
    const my = ++reqRef.current;
    const src0 = srcRef.current;
    if (src0) {
      setError(null);
      if (src0.kind === "search") {
        const res = searchResRef.current[src0.id];
        if (!res) { setEntries([]); setLoading(false); switchingRef.current = false; return; }
        setEntries(res.slice());
        const live = searchLiveRef.current;
        setLoading(!!(live && live.id === src0.id && live.running));
        switchingRef.current = false; forceRef.current = false;
        return;
      }
      if (src0.kind === "gdrive") {
        const fid = src0.folder;
        const cached = gdCacheGet(fid);
        if (cached && !forceRef.current) { setEntries(cached); setLoading(false); switchingRef.current = false; return; }
        setEntries([]); setLoading(true);
        try {
          const r = await Apps.gdriveList({ folder: fid, section: src0.section || "" });
          const files = (r.files || []).map((f) => ({
            name: f.name, type: f.type, size: f.size, remote: "gdrive", uri: f.id, id: f.id,
            mime: f.mime, thumb: f.thumb, mtime: f.mtime || 0, md5: f.md5, shared: f.shared, starred: f.starred, shortcut: f.shortcut,
          }));
          if (my !== reqRef.current) return;
          setEntries(files); gdCacheSet(fid, files);
        }
        catch (e) {
          if (my !== reqRef.current) return;
          const msg = (e && e.message) || "Ошибка";
          // просроченный вход в Google — понятным языком, а не текстом ответа сервера
          if (/invalid_grant|invalid_token|unauthorized/i.test(msg)) { setError("Google Диск: вход устарел, войдите заново"); setGdIn(false); }
          else setError(msg);
          setEntries([]);
        }
        if (my === reqRef.current) { setLoading(false); switchingRef.current = false; forceRef.current = false; }
        return;
      }
      setEntries([]); setLoading(true);
      try { const r = await Apps.webdavList({ url: src0.url, user: src0.acc.user, pass: src0.acc.pass }); const files = (r.files || []).map((f) => ({ name: f.name, type: f.type, size: f.size, remote: "webdav", uri: f.url, url: f.url })); if (my !== reqRef.current) return; setEntries(files); }
      catch (e) { if (my !== reqRef.current) return; setError((e && e.message) || "Ошибка"); setEntries([]); }
      if (my === reqRef.current) { setLoading(false); switchingRef.current = false; forceRef.current = false; }
      return;
    }
    const cached = localCache.current[path];
    if (cached && !forceRef.current) {
      setError(null);                       // прошлая ошибка (например, от Диска) не должна висеть в обычной папке
      setEntries(cached); setLoading(false); switchingRef.current = false;
      try {
        const u = await uriForPath(path);
        if (my !== reqRef.current) return;
        setCurUri(u.uri);
        let files;
        try { const r = await Apps.list({ uri: u.uri }); files = r.files; } catch { return; }
        if (my !== reqRef.current) return;
        localCache.current[path] = files || []; lcSave();
        setEntries((prev) => { const a = JSON.stringify((prev || []).map((x) => x.name + x.size + x.mtime)); const b = JSON.stringify((files || []).map((x) => x.name + x.size + x.mtime)); return a === b ? prev : (files || []); });
      } catch {}
      return;
    }
    setLoading(true); setError(null);
    try {
      const u = await uriForPath(path);
      if (my !== reqRef.current) return;
      setCurUri(u.uri);
      let files;
      try { const r = await Apps.list({ uri: u.uri }); files = r.files; }
      catch (er) { showToast("Системное чтение недоступно: " + (er?.message || "ошибка плагина")); const r = await Filesystem.readdir({ path, directory: DIR }); files = r.files; }
      if (my !== reqRef.current) return;
      if (srcRef.current) return; // источник сменился, пока читали
      localCache.current[path] = files || []; lcSave();
      setEntries(files || []);
    } catch (e) { if (my !== reqRef.current) return; setError(e.message || "Нет доступа к хранилищу"); setEntries([]); }
    if (my === reqRef.current) { setLoading(false); switchingRef.current = false; forceRef.current = false; }
  }, [path]);
  useEffect(() => { const t = THEMES[theme] || THEMES.dark; Apps.setBars({ color: t["--bg"], light: theme === "light" }).catch(() => {}); }, [theme]);
  useEffect(() => { Filesystem.rmdir({ path: "Download/.yevtmp", directory: DIR, recursive: true }).catch(() => {}); }, []);
  useEffect(() => { Filesystem.requestPermissions().catch(() => {}); checkAccess(); }, []);
  const checkAccess = async () => { try { const r = await Apps.hasAllFiles(); setAllFiles(!!r.granted); } catch { setAllFiles(true); } };
  const listRef = useRef(null);
  const spacerRef = useRef(null);
  const visLen = useRef(0);
  const scrollPos = useRef({});
  const pathKeyRef = useRef("");
  const restoring = useRef(false);
  const navRef = useRef(null);
  pathKeyRef.current = active + "|" + path;
  // Окно списка: на экране живут только видимые строки плюс запас, остальное — пустые отступы нужной высоты
  const rowHRef = useRef({ d: 0, f: 0, s: 0, g: 0 });   // измеренные высоты строк по видам: папка, файл, результат поиска, ячейка галереи
  const geom = useRef({ virt: false, total: 0, last4: 0, offsets: null, spacer: 0 });
  const [winY, setWinY] = useState(0);
  const winYRef = useRef(0);
  const winRaf = useRef(0);
  const [hTick, setHTick] = useState(0);
  const scheduleWin = (y) => {
    winYRef.current = y;
    if (winRaf.current) return;
    winRaf.current = requestAnimationFrame(() => { winRaf.current = 0; setWinY(winYRef.current); });
  };
  // распорка сверху = пустая зона ровно в 4 строки, чтобы первые файлы доставались пальцем внизу.
  // высоты строк измеряются, а не берутся константой — иначе погрешность копится на каждой строке
  const measureRows = (sp) => {
    if (geom.current.virt) return { rowsH: geom.current.total, fourH: geom.current.last4, last: null, virt: true };
    const wrap = sp && sp.parentElement; if (!wrap) return { rowsH: 0, fourH: 0 };
    const rows = Array.from(wrap.children).filter(
      (k) => k !== sp && (sp.compareDocumentPosition(k) & Node.DOCUMENT_POSITION_FOLLOWING) && k.getBoundingClientRect().height > 0
    );
    if (!rows.length) return { rowsH: 0, fourH: 0, last: null };
    const bottom = rows[rows.length - 1].getBoundingClientRect().bottom;
    const rowsH = Math.max(0, bottom - rows[0].getBoundingClientRect().top);
    const take = Math.min(4, rows.length);
    const fourH = Math.max(0, bottom - rows[rows.length - take].getBoundingClientRect().top);
    return { rowsH, fourH, last: rows[rows.length - 1] };
  };
  const layoutList = useCallback(() => {
    const el = listRef.current, sp = spacerRef.current; if (!el || !sp) return;
    let navH = 72;
    if (navRef.current) { const nr = navRef.current.getBoundingClientRect(), lr = el.getBoundingClientRect(); navH = Math.max(0, lr.bottom - nr.top); }
    el.style.paddingBottom = navH + "px";
    sp.style.height = "0px"; // обнулить ПЕРЕД замером: старая распорка сталкивает строки за экран, и content-visibility отдаёт заготовку вместо реальной высоты
    const ch = el.clientHeight;
    const usable = ch - navH;
    const { rowsH, fourH, last, virt } = measureRows(sp);
    if (!last && !virt) { if (loading || switchingRef.current) return; sp.style.height = "0px"; el.scrollTop = 0; return; } // пустая папка: без распорки; во время загрузки/переключения кадр не трогаем
    let pt = Math.max(0, usable - Math.min(rowsH, fourH));
    sp.style.height = pt + "px";
    const short = rowsH < usable; // всё помещается на экран
    const saved = short ? null : scrollPos.current[active + "|" + path];
    restoring.current = true;
    if (saved != null) el.scrollTop = saved;
    else el.scrollTop = rowsH >= usable ? pt : Math.max(0, el.scrollHeight - ch);
    // доводка по факту: где реально оказался низ последнего файла — лечит любую погрешность замера.
    // для короткого списка выполняется всегда (сохранённый скролл там не используется)
    if (short && last && navRef.current) {
      const delta = navRef.current.getBoundingClientRect().top - last.getBoundingClientRect().bottom;
      if (Math.abs(delta) > 0.5) {
        pt = Math.max(0, pt + delta);
        sp.style.height = pt + "px";
        el.scrollTop = Math.max(0, el.scrollHeight - el.clientHeight);
      }
    }
    requestAnimationFrame(() => { requestAnimationFrame(() => { restoring.current = false; }); });
    /* eslint-disable-next-line */
  }, [active, path]);
  useLayoutEffect(() => { layoutList(); if (geom.current.virt && listRef.current) scheduleWin(listRef.current.scrollTop); }, [path, active, entries, query, clip, layoutList, hTick, viewMode]);
  // на старте геометрия панели (вырезы, безопасные зоны) доходит до финала не в первом кадре:
  // держим список скрытым до первого честного расчёта и пересчитываем по факту изменения панели
  const [listShown, setListShown] = useState(false);
  const [dropHover, setDropHover] = useState(null); // { kind: "row"|"tab", uri|idx } — куда сейчас тащат файлы
  useLayoutEffect(() => {
    if (listShown) return;
    // старт: ждём, пока панель перестанет менять геометрию, и показываем список
    // синхронно в том же кадре, где сделан финальный расчёт — без промежуточных отрисовок
    let stable = 0, prevH = -1, raf;
    const tick = () => {
      const h = navRef.current ? navRef.current.getBoundingClientRect().height : 0;
      if (Math.abs(h - prevH) < 0.5) stable++; else stable = 0;
      prevH = h;
      layoutList();
      if (stable >= 2) { setListShown(true); return; }
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    const t = setTimeout(() => { layoutList(); setListShown(true); }, 400); // предохранитель
    return () => { cancelAnimationFrame(raf); clearTimeout(t); };
    /* eslint-disable-next-line */
  }, [listShown]);
  useEffect(() => {
    let ro;
    if (typeof ResizeObserver !== "undefined" && navRef.current) { ro = new ResizeObserver(() => layoutList()); ro.observe(navRef.current); }
    const vv = window.visualViewport;
    const onVV = () => layoutList();
    if (vv) vv.addEventListener("resize", onVV);
    return () => { if (ro) ro.disconnect(); if (vv) vv.removeEventListener("resize", onVV); };
  }, [layoutList]);
  // клавиатура поднимает строку поиска, иначе она уезжает под нижнюю панель
  const [kbH, setKbH] = useState(0);
  useEffect(() => {
    const vv = window.visualViewport;
    if (!vv) return;
    const onVV = () => {
      const h = Math.max(0, Math.round((window.innerHeight || 0) - vv.height - vv.offsetTop));
      setKbH(h > 120 ? h : 0);
    };
    vv.addEventListener("resize", onVV); vv.addEventListener("scroll", onVV); onVV();
    return () => { vv.removeEventListener("resize", onVV); vv.removeEventListener("scroll", onVV); };
  }, []);
  const [fsBar, setFsBar] = useState(null); // { top, h, label } — ползунок быстрой прокрутки
  const fsHide = useRef();
  const fsDrag = useRef(false);
  const updateFs = (el) => {
    if (!el) return;
    const over = el.scrollHeight - el.clientHeight;
    if (over <= 0 || el.clientHeight <= 0 || over < el.clientHeight * 1.5) { setFsBar(null); return; } // короткие списки — ползунок не нужен
    const navH = parseFloat(el.style.paddingBottom) || 0;
    const track = el.clientHeight - navH - 16;
    const h = Math.max(48, track * (el.clientHeight / el.scrollHeight));
    const top = 8 + (track - h) * (el.scrollTop / over);
    setFsBar({ top, h, label: fsLabelAt(el) });
    clearTimeout(fsHide.current);
    if (!fsDrag.current) fsHide.current = setTimeout(() => setFsBar((b) => (b ? { ...b, idle: true } : null)), 1200);
  };
  const fsLabelAt = (el) => {
    if (geom.current.virt && geom.current.offsets) {
      const y = el.scrollTop - geom.current.spacer + 4, off = geom.current.offsets, names = geom.current.names || [];
      let lo = 0, hi = off.length - 1;
      while (lo < hi) { const mid = (lo + hi) >> 1; if (off[mid + 1] > y) hi = mid; else lo = mid + 1; }
      return names[lo] ? names[lo].slice(0, 1).toUpperCase() : "";
    }
    const wrap = spacerRef.current && spacerRef.current.parentElement; if (!wrap) return "";
    const rows = Array.from(wrap.children).filter((k) => k !== spacerRef.current && k.getBoundingClientRect().height > 0);
    const top = el.getBoundingClientRect().top + 4;
    for (const r of rows) { const b = r.getBoundingClientRect(); if (b.bottom > top) return (r.dataset && r.dataset.nm) ? r.dataset.nm.slice(0, 1).toUpperCase() : ""; }
    return "";
  };
  const fsFromY = (clientY) => {
    const el = listRef.current; if (!el) return;
    const navH = parseFloat(el.style.paddingBottom) || 0;
    const r = el.getBoundingClientRect();
    const track = el.clientHeight - navH - 16;
    const h = Math.max(48, track * (el.clientHeight / el.scrollHeight));
    const p = Math.min(1, Math.max(0, (clientY - r.top - 8 - h / 2) / Math.max(1, track - h)));
    el.scrollTop = p * (el.scrollHeight - el.clientHeight);
    updateFs(el);
  };
  const onListScroll = (e) => { const el = e.currentTarget; updateFs(el); if (geom.current.virt) scheduleWin(el.scrollTop); if (restoring.current) return; if (el.scrollHeight <= el.clientHeight + 1) return; scrollPos.current[pathKeyRef.current] = el.scrollTop; };
  useEffect(() => { winYRef.current = 0; setWinY(0); }, [path, active]);
  // после каждой отрисовки замеряем реальные высоты строк — от системного размера шрифта они меняются
  useLayoutEffect(() => {
    const el = listRef.current; if (!el) return;
    const H = rowHRef.current; let changed = false;
    for (const k of ["d", "f", "s", "g"]) {
      const n = el.querySelector('[data-kind="' + k + '"]'); if (!n) continue;
      const cs = getComputedStyle(n);
      const h = n.getBoundingClientRect().height + (parseFloat(cs.marginBottom) || 0) + (parseFloat(cs.marginTop) || 0) + (k === "g" ? 6 : 0);
      if (h >= 20 && Math.abs(h - H[k]) > 0.5) { H[k] = h; changed = true; } // нулевые замеры (скрытый список) не принимаем
    }
    if (changed) setHTick((t) => t + 1);
  });
  // Фоновая подгрузка превью: только видимые на экране строки, ограниченная нагрузка
  const slideRef = useRef(0);
  const seenKeys = useRef(new Set());
  const thumbQueue = useRef([]);
  const thumbRunning = useRef(0);
  const thumbWanted = useRef(new Set());
  const THUMB_CONCURRENCY = 3;
  const tkeyOf = (e) => e.uri + "|" + (e.mtime || 0) + "|" + (e.size || 0);
  const pumpThumbs = useCallback(() => {
    if (slideRef.current !== 0) return; // не грузим превью во время слайд-анимации — иначе дёргается
    while (thumbRunning.current < THUMB_CONCURRENCY && thumbQueue.current.length) {
      const it = thumbQueue.current.shift();
      if (thumbs[it.key] || !thumbWanted.current.has(it.key)) continue;
      thumbRunning.current++;
      thumbInFlight.current.add(it.key);
      const nm = (it.uri || "").split("/").pop() || "";
      (it.gd ? Apps.gdriveThumb({ id: it.gd.id, link: it.gd.link }) : Apps.thumb({ uri: it.uri, key: it.key, size: it.big ? 320 : 150 }))
        .then(async (r) => {
          if (r && r.thumb) { setThumbs((m) => ({ ...m, [it.key]: r.thumb })); return; }
          // система не смогла — пробуем раскодировать сами (TIFF, JPEG XL, AVIF, TGS)
          if (!it.gd && (isJsImg(nm) || isTgs(nm))) { try { const u = await decodeForThumb(it.uri, nm); if (u) setThumbs((m) => ({ ...m, [it.key]: u })); } catch {} }
        })
        .catch(() => {})
        .finally(() => { thumbRunning.current--; thumbInFlight.current.delete(it.key); setTimeout(pumpThumbs, 30); });
    }
  }, [thumbs]);
  const requestThumb = useCallback((uri, key, gd, big) => {
    const k = key || uri;
    if (!uri || thumbs[k] || thumbWanted.current.has(k)) return;
    thumbWanted.current.add(k);
    thumbQueue.current.push({ uri, key: k, gd: gd || null, big: !!big });
    pumpThumbs();
  }, [thumbs, pumpThumbs]);
  const thumbInFlight = useRef(new Set());
  const releaseThumb = useCallback((uri, key) => {
    const k = key || uri;
    thumbWanted.current.delete(k);
    // нативную часть дёргаем только если именно это превью сейчас считается,
    // иначе при прокрутке улетают сотни вызовов подряд и приложение застывает
    if (thumbInFlight.current.has(k)) Apps.thumbCancel({ key: k }).catch(() => {});
  }, []);
  useEffect(() => { slideRef.current = slide; if (slide === 0) pumpThumbs(); /* eslint-disable-next-line */ }, [slide]);
  // очистка кэша превью раз за сессию
  useEffect(() => { Apps.thumbSweep && Apps.thumbSweep().catch(() => {}); }, []);
  // при смене папки сбрасываем очередь желаемых (новые строки сами запросят)
  useEffect(() => { thumbQueue.current = []; thumbWanted.current = new Set(); }, [path, active]);
  const silentRefresh = useCallback(async () => {
    if (srcRef.current) return; // открыт Диск, WebDAV или результаты поиска — локальное обновление не к месту
    try {
      const u = await uriForPath(path);
      let files;
      try { const r = await Apps.list({ uri: u.uri }); files = r.files; } catch { return; }
      localCache.current[path] = files || []; lcSave();
      setEntries((prev) => { const a = JSON.stringify((prev || []).map((x) => x.name + x.size + x.mtime)); const b = JSON.stringify((files || []).map((x) => x.name + x.size + x.mtime)); return a === b ? prev : (files || []); });
    } catch {}
  }, [path]);
  const silentRefreshRef = useRef(silentRefresh); silentRefreshRef.current = silentRefresh;
  const curUriRef = useRef(""); curUriRef.current = curUri;
  const pathRef = useRef(path); pathRef.current = path;
  const absOfUri = (u) => { let p = (u || "").replace(/^file:\/\//, ""); try { p = decodeURIComponent(p); } catch {} return p; };
  // Точечное обновление списка: система присылает событие с именем файла, мы дочитываем только его.
  // События копятся 300 мс и применяются одной пачкой; лавина событий — обычная перечитка.
  const fsPend = useRef(new Map());
  const fsTimer = useRef();
  const flushFs = useCallback(async () => {
    const m = fsPend.current; fsPend.current = new Map();
    if (!m.size) return;
    if (srcRef.current) return;
    if (m.size > 150) { silentRefreshRef.current(); return; }
    const gone = [], stat = [];
    for (const [n, k] of m) (k === "gone" ? gone : stat).push(n);
    const uri = curUriRef.current, p = pathRef.current;
    let fresh = [];
    if (stat.length) { try { const r = await Apps.statMany({ uri, names: stat }); fresh = r.files || []; } catch { silentRefreshRef.current(); return; } }
    if (curUriRef.current !== uri) return; // уже ушли в другую папку
    const freshNames = new Set(fresh.map((f) => f.name));
    for (const n of stat) if (!freshNames.has(n)) gone.push(n);
    setEntries((prev) => {
      const by = new Map((prev || []).map((e) => [e.name, e]));
      let changed = false;
      for (const n of gone) if (by.delete(n)) changed = true;
      for (const f of fresh) { const old = by.get(f.name); if (!old || old.size !== f.size || old.mtime !== f.mtime || old.type !== f.type) changed = true; by.set(f.name, old ? { ...old, ...f } : f); }
      if (!changed) return prev;
      const next = [...by.values()];
      localCache.current[p] = next; lcSave();
      return next;
    });
  }, []);
  useEffect(() => {
    let h, t;
    const onChange = (ev) => {
      if (!ev || !ev.name || ev.ev === "self") { clearTimeout(t); t = setTimeout(() => silentRefreshRef.current(), 250); return; }
      fsPend.current.set(ev.name, ev.ev);
      clearTimeout(fsTimer.current); fsTimer.current = setTimeout(flushFs, 300);
    };
    Apps.addListener("fschange", onChange).then((l) => (h = l));
    return () => { clearTimeout(t); clearTimeout(fsTimer.current); h && h.remove(); };
  }, [flushFs]);
  useEffect(() => { fsPend.current = new Map(); if (curUri) Apps.watch({ uri: curUri }).catch(() => {}); }, [curUri]);
  // Число объектов, обложка и полный вес подпапок досчитываются в фоне и приходят событием
  useEffect(() => {
    let h;
    Apps.addListener("dirStats", (ev) => {
      if (!ev || !ev.dir) return;
      const cur = absOfUri(curUriRef.current).replace(/\/+$/, "");
      if (cur !== String(ev.dir).replace(/\/+$/, "")) return;
      const items = ev.items || [], sizes = ev.sizes || null;
      const byName = new Map(items.map((it) => [it.name, it]));
      if (!byName.size && !sizes) return;
      const p = pathRef.current;
      setEntries((prev) => {
        let changed = false;
        const next = (prev || []).map((e) => {
          if (e.type !== "directory") return e;
          let ne = e;
          const it = byName.get(e.name);
          if (it && (e.count !== it.count || (it.thumb || null) !== (e.thumb || null) || (it.bytes != null && e.bytes !== it.bytes))) {
            ne = { ...ne, count: it.count, thumb: it.thumb || undefined };
            if (it.bytes != null) ne.bytes = it.bytes;                 // вес папки посчитан обходом
            changed = true;
          }
          const sz = sizes && sizes[e.name];
          if (sz && (e.bytes !== sz.bytes || e.files !== sz.files)) { ne = { ...ne, bytes: sz.bytes, files: sz.files }; changed = true; }
          return ne;
        });
        if (!changed) return prev;
        localCache.current[p] = next; lcSave();
        return next;
      });
    }).then((l) => (h = l));
    return () => { h && h.remove(); };
  }, []);
  // заранее готовим превью для видимой части папки — иначе они появляются рывками при прокрутке
  useEffect(() => {
    if (!entries || !entries.length) return;
    const t = setTimeout(() => {
      const uris = entries
        .filter((e) => e.type !== "directory" && !e.remote && e.uri && (isImg(e.name) || isVid(e.name)))
        .slice(0, 60)
        .map((e) => e.uri);
      if (uris.length) Apps.warmThumbs({ uris }).catch(() => {});
    }, 250);
    return () => clearTimeout(t);
  }, [entries]);
  // пустой съёмный том без доступа — предлагаем дать доступ (чтение USB часто только через SAF)
  const safAskedRef = useRef(new Set());
  useEffect(() => {
    if (loading || !path.startsWith("@abs:") || entries.length > 0) return;
    const abs = path.slice(5);
    if (safAskedRef.current.has(abs)) return;
    Apps.safStatus({ path: abs }).then((st) => {
      if (st && st.needed && !st.granted) { safAskedRef.current.add(abs); setSafPrompt({ abs }); }
    }).catch(() => {});
  }, [loading, entries, path]);
  // изменения снаружи приложения (докачался файл, снято фото) — обновляемся сразу, а не по возврату
  useEffect(() => {
    let h, t;
    Apps.watchMedia().catch(() => {});
    const onMedia = () => { clearTimeout(t); t = setTimeout(silentRefresh, 400); };
    Apps.addListener("mediaChanged", onMedia).then((l) => (h = l));
    return () => { clearTimeout(t); h && h.remove(); };
  }, [silentRefresh]);
  useLayoutEffect(() => { switchingRef.current = true; list(); exitSel(); setQuery(null); const _k = active + "|" + path; setTimeout(() => seenKeys.current.add(_k), 350); /* eslint-disable-next-line */ }, [active, path, srcKey]);
  useEffect(() => { let h; CapApp.addListener("resume", () => list()).then((l) => (h = l)); return () => h && h.remove(); }, [list]);
  useEffect(() => {
    let cancelled = false;
    const t = setTimeout(async () => {
      for (const tb of tabs) {
        if (cancelled) break;
        if (tb.src) continue;
        const p = tb.path || "";
        if (localCache.current[p]) continue;
        try {
          const u = await Filesystem.getUri({ path: p, directory: DIR });
          if (cancelled) break;
          const r = await Apps.list({ uri: u.uri });
          if (cancelled) break;
          localCache.current[p] = r.files || []; lcSave();
        } catch {}
      }
    }, 900);
    return () => { cancelled = true; clearTimeout(t); };
    /* eslint-disable-next-line */
  }, []);
  useEffect(() => {
    const onVis = () => { if (document.visibilityState === "visible") { checkAccess(); list(); } };
    document.addEventListener("visibilitychange", onVis);
    window.addEventListener("focus", onVis);
    return () => { document.removeEventListener("visibilitychange", onVis); window.removeEventListener("focus", onVis); };
  }, [list]);
  useEffect(() => { ls.set(SORTKEY, sortMode); }, [sortMode]);
  useEffect(() => {
    if (!gdIn) return;
    let dead = false;
    const tok = localStorage.getItem(GDPT_KEY) || "";
    Apps.gdriveChanges({ token: tok }).then((r) => { if (dead || !r) return; if (r.token) localStorage.setItem(GDPT_KEY, r.token); if (r.changed) gdCacheClear(); }).catch(() => {});
    return () => { dead = true; };
  }, [gdIn]);
  const [propApkIcon, setPropApkIcon] = useState(null);
  useEffect(() => {
    setPropApkIcon(null);
    if (props && /\.apk$/i.test(props.name)) { Apps.apkInfo({ uri: props.uri }).then((info) => setPropApkIcon(info && info.icon || null)).catch(() => {}); }
  }, [props]);
  const [shz, setShz] = useState(null);
  const [perms, setPerms] = useState(null);        // что из разрешений уже выдано
  const loadPerms = React.useCallback(() => {
    Apps.permStatus().then(setPerms).catch(() => setPerms({}));
    Apps.pickerStatus().then((p) => setPerms((m) => ({ ...(m || {}), picker: p }))).catch(() => {});
  }, []);
  useEffect(() => {
    if (!settings || settingsPage !== "perms") return;
    loadPerms();
    const t = setInterval(loadPerms, 1500);        // вернулся из системных настроек — состояние обновится само
    return () => clearInterval(t);
  }, [settings, settingsPage, loadPerms]);
  // ---- Резервная копия настроек ----
  const [backupTabs, setBackupTabs] = useState(false);
  const [exportPick, setExportPick] = useState(null); // { payload } — режим выбора папки для сохранения настроек
  const exportSettings = (withTabs) => {
    try {
      const keys = withTabs ? [...BACKUP_KEYS, ...BACKUP_TABS_KEYS] : BACKUP_KEYS;
      const data = {};
      for (const k of [...new Set(keys)]) { const v = ls.get(k); if (v != null) data[k] = v; }
      const payload = JSON.stringify({ app: "YevFiles", kind: "settings", version: APP_VERSION, tabs: !!withTabs, data }, null, 2);
      setExportPick({ payload });
      setSettings(false); setSettingsPage(null); // уходим в файловый менеджер выбирать папку
    } catch (e) { showToast("Ошибка экспорта: " + (e?.message || "")); }
  };
  const doExportHere = async () => {
    const pk = exportPick; if (!pk) return;
    setExportPick(null);
    const name = "YevFiles_settings.json";
    try {
      if (path.startsWith("@abs:")) {
        const abs = path.slice(5);
        const st = await Apps.safStatus({ path: abs }).catch(() => ({}));
        if (st && st.needed) {
          if (!st.granted) { setSafPrompt({ abs }); setExportPick(pk); return; }
          // пишем во временный файл и копируем на носитель через SAF
          const tmp = "Download/.yevtmp/" + name;
          await Filesystem.writeFile({ path: tmp, data: pk.payload, directory: DIR, encoding: Encoding.UTF8, recursive: true });
          const tu = await Filesystem.getUri({ path: tmp, directory: DIR });
          await Apps.safCopyInto({ from: tu.uri, destDir: abs });
          try { await Filesystem.deleteFile({ path: tmp, directory: DIR }); } catch {}
          showToast("Сохранено на носитель"); refresh(); return;
        }
      }
      const rel = (path ? path + "/" : "") + name;
      await Filesystem.writeFile({ path: rel, data: pk.payload, directory: DIR, encoding: Encoding.UTF8, recursive: true });
      showToast("Сохранено: " + name); refresh();
    } catch (e) { showToast("Ошибка сохранения: " + (e?.message || "")); }
  };
  const importInputRef = useRef(null);
  const importSettings = async (file) => {
    try {
      const text = await file.text();
      const obj = JSON.parse(text);
      const data = obj && obj.data;
      if (!data || obj.kind !== "settings") { showToast("Это не файл настроек YevFiles"); return; }
      let n = 0;
      for (const k of Object.keys(data)) {
        if (![...BACKUP_KEYS, ...BACKUP_TABS_KEYS].includes(k)) continue; // чужие ключи игнорируем
        ls.set(k, data[k]); n++;
      }
      showToast("Импортировано настроек: " + n + ". Перезапуск…");
      setTimeout(() => { try { location.reload(); } catch {} }, 900);
    } catch (e) { showToast("Ошибка импорта: " + (e?.message || "")); }
  };
  const loadShz = React.useCallback(() => {
    Apps.shizukuStatus().then(setShz).catch(() => setShz({ state: "absent" }));
  }, []);
  useEffect(() => { loadShz(); }, [loadShz]);          // знаем состояние сразу: от него зависит пункт «Система»
  useEffect(() => {
    if (/\/Android\/(data|obb)/.test(absOfUri(curUri) || "")) loadShz();     // чтобы в самой папке было видно, что с доступом
  }, [curUri, loadShz]);
  useEffect(() => {
    if (!settings || settingsPage !== "perms") return;
    loadShz();
    const t = setInterval(loadShz, 1500); // состояние меняется снаружи — подхватываем сами
    return () => clearInterval(t);
  }, [settings, settingsPage, loadShz]);
  const [propMeta, setPropMeta] = useState(null);
  useEffect(() => {
    setPropMeta(null);
    if (!props || props.multi || props.type === "directory" || !props.uri) return;
    let dead = false;
    Apps.fileMeta({ uri: props.uri }).then((m) => { if (!dead && m && m.kind && m.kind !== "other") setPropMeta(m); }).catch(() => {});
    return () => { dead = true; };
  }, [props]);
  const [propSize, setPropSize] = useState(null);
  useEffect(() => {
    if (props && props.multi) {
      setPropCount(null); setPropSize(null);
      let dead = false;
      (async () => {
        let total = 0;
        for (const it of props.multi) {
          if (dead) return;
          if (it.type === "directory") {
            try { const c = sizeCache.get(it.uri); if (c && Date.now() - c.t < 60000) total += c.bytes; else { const r = await Apps.pathSize({ uri: it.uri }); sizeCache.set(it.uri, { bytes: r.bytes || 0, t: Date.now() }); total += r.bytes || 0; } } catch {}
          } else total += it.size || 0;
        }
        if (!dead) setPropSize(total);
      })();
      return () => { dead = true; };
    }
    if (!props || props.type !== "directory") { setPropCount(null); setPropSize(null); return; }
    (async () => { try { const { files } = await Filesystem.readdir({ path: props.uri }); setPropCount({ d: files.filter((f) => f.type === "directory").length, f: files.filter((f) => f.type !== "directory").length }); } catch { setPropCount(null); } })();
    setPropSize(null);
    (async () => { try { const c = sizeCache.get(props.uri); if (c && Date.now() - c.t < 60000) { setPropSize(c.bytes); return; } const r = await Apps.pathSize({ uri: props.uri }); sizeCache.set(props.uri, { bytes: r.bytes || 0, t: Date.now() }); setPropSize(r.bytes || 0); } catch { setPropSize(null); } })();
  }, [props]);

  const exitSel = () => { setSel(new Set()); setSelMode(false); setConfirmDel(null); setSelMenu(false); };
  // Уход по обычному пути всегда покидает удалённый источник: иначе вкладка остаётся
  // на Google Диске, хотя путь уже другой.
  const setTabPath = (p) => setTabs((ts) => ts.map((x, i) => (i === active ? { ...x, path: p, src: null } : x)));
  // подсветка «отсюда только что вышли»: для каждой папки помним имя, откуда вернулись
  const [cameFrom, setCameFrom] = useState({});
  // качающиеся прямо сейчас файлы в открытой папке: имя на диске -> { name, done, total, stalled }
  const [dls, setDls] = useState({});
  const dlCache = useRef({});          // что качалось в каждой папке — чтобы при возврате не мигало
  const NOTIFKEY = "fm_notifhint_v1";
  const notifAsked = useRef(false);
  const dlsRef = useRef(dls); dlsRef.current = dls;
  // строка загрузки появилась или ушла — пересчитываем раскладку, иначе на её месте остаётся пустота
  useLayoutEffect(() => { layoutList(); if (geom.current.virt && listRef.current) scheduleWin(listRef.current.scrollTop); }, [dls]);
  const entriesRef = useRef([]);
  useEffect(() => {
    let h;
    Apps.addListener("dlProgress", (ev) => {
      if (!ev || !ev.dir) return;
      if (absOfUri(curUriRef.current).replace(/\/+$/, "") !== String(ev.dir).replace(/\/+$/, "")) return;
      const m = {};
      for (const it of ev.items || []) {
        const rec = { name: it.name, done: it.done, total: it.total, stalled: !!it.stalled, paused: !!it.paused, virtual: !!it.virtual, extra: it.extra || null, at: Date.now() };
        m[it.file] = rec;
        if (it.name && it.name !== it.file) m[it.name] = rec;   // строка найдётся и по готовому имени
      }
      const dirKey = String(ev.dir).replace(/\/+$/, "");
      setDls((prev) => {
        // Загрузка закончилась: запись пропала, а настоящий файл в списке появится чуть позже.
        // Держим строку ещё две секунды, чтобы она просто стала обычной, без мигания и скачка.
        const now = Date.now();
        const out = { ...m };
        for (const [k, v] of Object.entries(prev || {})) {
          if (out[k]) continue;
          const gone = now - (v.at || 0);
          const arrived = (entriesRef.current || []).some((e) => e.name === (v.name || k));
          if (!arrived && gone < 2000) out[k] = v;                // ещё ждём появления файла
        }
        dlCache.current[dirKey] = { at: Date.now(), map: out };
        return JSON.stringify(prev) === JSON.stringify(out) ? prev : out;
      });
      // проценты берутся из шторки; если доступа нет — один раз подскажем, где включить
      const noTotal = Object.values(m).some((x) => !(x.total > 0));
      if (noTotal && !notifAsked.current && ls.get(NOTIFKEY) !== "1") {
        notifAsked.current = true;
        Apps.notifyAccess().then((r) => {
          if (r && r.granted) return;
          ls.set(NOTIFKEY, "1");
          setSheet({ kind: "notifHint" });
        }).catch(() => {});
      }
    }).then((l) => (h = l));
    return () => { h && h.remove(); };
  }, []);
  // следим только за открытой папкой, в архиве и на удалённых источниках — не следим
  useEffect(() => {
    if (srcRef.current || arcView || !curUri) { setDls({}); Apps.dlWatch({ uri: "" }).catch(() => {}); return; }
    // вернулись в папку — сразу показываем то, что там качалось, без мигания
    const key = absOfUri(curUri).replace(/\/+$/, "");
    const c = dlCache.current[key];
    setDls(c && Date.now() - c.at < 30000 ? c.map : {});
    Apps.dlWatch({ uri: curUri }).catch(() => {});
    return () => { Apps.dlWatch({ uri: "" }).catch(() => {}); };
  }, [curUri, arcView]);
  const markCameFrom = (parentPath, name) => setCameFrom((m) => {
    if (m[parentPath] === name) return m;
    const n = { ...m };
    if (name) n[parentPath] = name; else delete n[parentPath];
    return n;
  });
  // Крошки: путь разбит на сегменты, каждый — переход на свой уровень
  const crumbRef = useRef(null);
  const [crumbOver, setCrumbOver] = useState(false);
  const crumbs = React.useMemo(() => {
    const src = cur && cur.src;
    if (src) return (src.stack || []).map((x, i) => ({ name: x.name, i }));
    if (!path) return [];
    if (path.startsWith("@abs:")) {
      const raw = path.slice(5);
      const vol = volumes.find((v) => raw === v.path || raw.startsWith(v.path + "/"));
      const rest = vol ? raw.slice(vol.path.length).split("/").filter(Boolean) : raw.split("/").filter(Boolean);
      const head = { name: vol ? vol.name : "Хранилище", i: 0, abs: true };
      return [head, ...rest.map((name, k) => ({ name, i: k + 1, abs: true }))];
    }
    return path.split("/").filter(Boolean).map((name, i) => ({ name, i }));
  }, [cur && cur.src, path, volumes]);
  const goCrumb = (i) => {
    if (i === crumbs.length - 1) return; // уже здесь
    const src = srcRef.current;
    slideNav(-1);
    if (src) {
      const st = (src.stack || []).slice(0, i + 1), top = st[st.length - 1];
      if (!top) { setTabs((ts) => ts.map((t, k) => (k === active ? { ...t, src: null } : t))); return; }
      setTabs((ts) => ts.map((t, k) => (k === active ? { ...t, src: src.kind === "gdrive" ? { ...src, folder: top.id, stack: st } : { ...src, url: top.url, stack: st } } : t)));
      return;
    }
    if (path.startsWith("@abs:")) {
      const raw = path.slice(5);
      const vol = volumes.find((v) => raw === v.path || raw.startsWith(v.path + "/"));
      const base = vol ? vol.path : "";
      const rest = (vol ? raw.slice(vol.path.length) : raw).split("/").filter(Boolean);
      const sub = rest.slice(0, i).join("/"); // i=0 → корень тома
      const target = "@abs:" + base + (sub ? "/" + sub : "");
      markCameFrom(target, rest[i] || null);
      setTabPath(target);
      return;
    }
    const segs = path.split("/").filter(Boolean);
    const target = segs.slice(0, i + 1).join("/");
    markCameFrom(target, segs[i + 1] || null);
    setTabPath(target);
  };
  // лента сама доезжает до текущей папки
  useLayoutEffect(() => {
    const el = crumbRef.current; if (!el) return;
    el.scrollLeft = el.scrollWidth;
    setCrumbOver(el.scrollWidth > el.clientWidth + 1);
  }, [crumbs]);
  const goUp = () => {
    const src = srcRef.current;
    if (src) {
      slideNav(-1);
      if (src.kind === "search") { leaveSearch(); setQuery(null); setTabs((ts) => ts.map((t, i) => (i === active ? { ...t, src: null, path: src.back && src.back.path != null ? src.back.path : t.path } : t))); return; }
      if (src.stack.length <= 1) { setTabs((ts) => ts.map((t, i) => (i === active ? { ...t, src: null } : t))); return; }
      const st = src.stack.slice(0, -1), top = st[st.length - 1];
      setTabs((ts) => ts.map((t, i) => (i === active ? { ...t, src: src.kind === "gdrive" ? { ...src, folder: top.id, stack: st } : { ...src, url: top.url, stack: st } } : t)));
      return;
    }
    if (path) {
      slideNav(-1);
      // из корня тома-флешки уходим не в /storage, а обратно в шторку
      if (path.startsWith("@abs:")) {
        const raw = path.slice(5);
        const vol = volumes.find((v) => raw === v.path);
        if (vol) { setDrawer(true); return; }
      }
      const par = parent(path);
      markCameFrom(par, baseName(path));
      setTabPath(par);
    }
  };
  const closeTab = (i) => { if (tabs.length === 1) return; const tc = tabs[i]; if (tc && tc.src && tc.src.kind === "search") { stopSearch(tc.src.id); delete searchResRef.current[tc.src.id]; } const t = tabs.filter((_, idx) => idx !== i); persist(t); setActive(Math.max(0, Math.min(active, t.length - 1))); };

  const backRef = useRef(() => {});
  const backExit = useRef(0);
  backRef.current = () => {
    if (pwPrompt) { resolvePassword(null); return; }
    if (fontView) { setFontView(null); return; }
    if (resumeJob) { setResumeJob(null); jobSave(null); return; }
    if (exportPick) { setExportPick(null); return; }
    if (savePick) { restoreSavePick(); return; }
    if (pendingExtract) { setPendingExtract(null); return; }
    if (appPick) { setAppPick(null); return; }
    if (iconApps) { setIconApps(null); return; }
    if (iconPick) { const b = iconPick.back; setIconPick(null); if (b != null) setTabPath(b); return; }
    if (conflict) { resolveConflict("cancel", false); return; }
    if (settings) { if (settingsPage) { setSettingsPage(null); return; } setSettings(false); return; }
    if (headMenu) { if (headSub) { setHeadSub(null); return; } setHeadMenu(false); return; }
    if (createOpen) { setCreateSub(null); setCreateOpen(false); return; }
    if (selMenu) { setSelMenu(false); return; }
    // просмотрщики закрываются раньше архива — иначе «назад» из картинки закрывал бы весь архив
    if (pasteMenu) { setPasteMenu(false); return; }
    if (openMenu) { setOpenMenu(null); return; }
    if (props) { setProps(null); return; }
    if (pdf) { closePdf(); return; }
    if (player) { playerClose(); return; }
    if (viewerDel) { setViewerDel(false); return; }
    if (viewer) { setViewer(null); return; }
    if (sheet) { setSheet(null); return; }
    if (arcView && arcSel.size > 0) { setArcSel(new Set()); return; }
    if (arcView && arcPath) { setArcPath(arcPath.replace(/[^/]+\/$/, "")); return; }
    if (arcView) { markCameFrom(path, arcView.name); setArcView(null); return; }
    if (gd) { gdBack(); return; }
    if (wd) { wdBack(); return; }
    if (drawer) { setDrawer(false); return; }
    if (selMenu) { setSelMenu(false); return; }
    if (headMenu) { if (headSub) { setHeadSub(null); return; } setHeadMenu(false); return; }
    if (confirmDel) { setConfirmDel(null); return; }
    if (createOpen) { setCreateOpen(false); return; }
    if (query !== null) { setQuery(null); return; }
    if (selMode) { exitSel(); return; }
    { const t = tabs[active]; if (t && t.src) { goUp(); return; } const atStart = t && t.startup && (t.startupPath || "") === path; if (path && !atStart) { goUp(); return; } }
    const now = Date.now();
    if (now - backExit.current < 2000) { CapApp.exitApp(); }
    else { backExit.current = now; showToast("Нажмите «Назад» ещё раз для выхода"); }
  };
  useEffect(() => {
    let h;
    CapApp.addListener("backButton", () => backRef.current()).then((l) => (h = l));
    return () => { h && h.remove(); };
  }, []);

  const toggle = (name) => {
    if (dlsRef.current[name]) { showToast("Файл ещё качается"); return; } const n = new Set(sel); n.has(name) ? n.delete(name) : n.add(name); setSel(n); setSelMode(n.size > 0); };
  const selAllWant = useRef(false);
  const switchingRef = useRef(false);
  const selectAll = () => {
    if (arcView && arcView.entries) { setArcSel(new Set(arcView.entries.map((e) => (e.dir && !String(e.name).endsWith("/") ? e.name + "/" : e.name)))); return; }
    if (!loading && !switchingRef.current) {
      if (!visible.length) { showToast("Папка пуста"); return; }
      selAllWant.current = false; setSelMode(true);
      setSel(new Set(visible.filter((e) => !dlsRef.current[e.name]).map((e) => e.name)));   // качающиеся не берём
      return;
    }
    selAllWant.current = true; setSelMode(true);
  };

  // Очередь для плеера: все видео папки в том же порядке, что на экране, плюс имена и субтитры.
  // Так делает MiXplorer: плеер получает готовый список и играет следующий файл сам.
  const videoPlaylist = (e) => {
    if (!isVid(e.name)) return undefined;
    try {
      const vids = visibleRef.current.filter((x) => x.type !== "directory" && isVid(x.name) && !x.remote);
      if (vids.length < 2) return undefined;
      return { uris: vids.map((x) => x.uri), names: vids.map((x) => x.name), start: Math.max(0, vids.findIndex((x) => x.uri === e.uri)) };
    } catch { return undefined; }
  };
  // Субтитры рядом с видео: файл с тем же именем и другим расширением (name.ru.srt тоже подходит)
  const videoSubs = (e) => {
    try {
      if (!isVid(e.name)) return undefined;
      const base = e.name.replace(/\.[^.]+$/, "").toLowerCase();
      const subs = visibleRef.current.filter((x) => x.type !== "directory" && !x.remote && /\.(srt|ass|ssa|sub|vtt|smi|idx)$/i.test(x.name) && x.name.toLowerCase().startsWith(base));
      if (!subs.length) return undefined;
      return { uris: subs.map((x) => x.uri), names: subs.map((x) => x.name) };
    } catch { return undefined; }
  };
  const playArgs = (e) => {
    const pl = videoPlaylist(e), sb = videoSubs(e);
    const o = {};
    if (pl) { o.uris = pl.uris; o.names = pl.names; o.startIndex = pl.start; }
    if (sb) { o.subs = sb.uris; o.subNames = sb.names; }
    return o;
  };
  const openExternal = async (e) => {
    Apps.warmThumbs({ uris: [] }).catch(() => {}); // стоп фоновому прогреву: не мешать открытию
    const mime = mimeOf(e.name);
    const ext = (e.name.split(".").pop() || "").toLowerCase();
    // apk и архивы — всегда меню выбора (там есть «Открыть как архив»), без авто-привязки
    if (EXT.archive.includes(ext)) { await showOpenMenu(e, mime); return; }
    const cat = defaultOpenAs(e.name);
    const defs = loadMap(DEFKEY);
    const d = defs[cat] || defs[mime];
    // у видео и музыки плеер стартует сам — молча, без лишней надписи
    if (d) { if (!isVid(e.name) && !isAudio(e.name)) showToast("Открываю…"); try { const [pkg, act] = d.split("|"); await Apps.open({ uri: e.uri, mime, packageName: pkg, activityName: act, ...playArgs(e) }); return; } catch {} }
    // тип неизвестен — спрашиваем, чем считать файл
    if (cat === "*/*" && mime === "*/*") { setSheet({ kind: "openAs", file: e }); return; }
    await showOpenMenu(e, mime);
  };
  const appsCache = useRef({});   // список приложений на тип файла — чтобы меню открывалось мгновенно
  // Меню для файла из архива показываем мгновенно: извлекаем только когда выбрано действие.
  // У 7z ради одного файла распаковывается целый блок, поэтому ждать до меню нельзя.
  const arcTmp = useRef({});   // уже извлечённые файлы: повторное открытие мгновенное
  const arcResolve = async (f) => {
    if (!f || !f.arc) return f;
    const key = f.arc.uri + "|" + f.arc.entry;
    if (arcTmp.current[key]) return { ...f, uri: arcTmp.current[key] };
    const fname = f.name;
    setProgress({ current: 0, total: 100, name: fname, mode: "ext", bg: true });
    let psub = null;
    try { psub = await Apps.addListener("opProgress", (ev) => setProgress((p) => (p ? { ...p, current: ev.done, total: ev.total || 100, name: ev.name } : p))); } catch {}
    try {
      const destDir = await absPath("Download/.yevtmp");
      const run = (pw) => Apps.zipExtract({ uri: f.arc.uri, entry: f.arc.entry, dest: destDir + "/" + fname, password: pw || undefined, quiet: true });
      try { await run(getCachedPw(f.arc.uri)); }
      catch (err) {
        if (err && err.code === "UNSUPPORTED") { showToast(err.message || "Формат не поддерживается"); return null; }
        const enc = err && (err.code === "ENCRYPTED" || err.code === "BADPASS" || /ENCRYPTED|BADPASS|пароль/i.test(err.message || ""));
        if (!enc) throw err;
        let ok = false;
        for (let t = 0; t < 3 && !ok; t++) {
          const pw = await askPassword(t > 0);
          if (pw == null || pw === "") return null;
          try { await run(pw); setCachedPw(f.arc.uri, pw); ok = true; } catch { if (t === 2) { showToast("Неверный пароль"); return null; } }
        }
      }
      const u = await Filesystem.getUri({ path: "Download/.yevtmp/" + fname, directory: DIR });
      arcTmp.current[key] = u.uri;
      return { ...f, uri: u.uri };
    } catch (e) { showToast("Ошибка: " + (e?.message || "")); return null; }
    finally { try { psub && psub.remove(); } catch {} setProgress(null); }
  };
  const showOpenMenu = async (e, mime, opts) => {
    const edit = !!(opts && opts.edit);
    const split = !!(opts && opts.split);
    const cat = OPEN_AS.some(([m]) => m === mime) ? mime : defaultOpenAs(e.name);
    const ck = mime + "|" + (edit ? "e" : "v");
    let apps = split ? [] : (appsCache.current[ck] || []);
    // меню показываем сразу, список приложений дозагружаем и обновляем на месте
    setOpenMenu({ file: e, mime: cat, apps, useDefault: false, editHide: false, edit, split, asCat: !!(opts && opts.asCat), originX: pX.current, originY: pY.current });
    if (!split) {
      Apps.query({ uri: e.uri, mime, action: edit ? "edit" : "view" })
        .then((r) => {
          const list = (r.apps || []).filter((a) => a.packageName !== "leshugan.fm");
          appsCache.current[ck] = list;
          setOpenMenu((m) => (m && m.file === e ? { ...m, apps: list } : m));
        })
        .catch(() => {});
    }
    if (/\.(apk|apks|xapk|apkm|apkx)$/i.test(e.name)) { Apps.apkInfo({ uri: e.uri }).then((info) => setOpenMenu((m) => (m && m.file === e ? { ...m, apkInfo: info } : m))).catch(() => {}); }
  };
  const pickApp = async (app) => {
    let om = openMenu;
    if (om.file && om.file.arc) {
      const rf = await arcResolve(om.file);
      if (!rf) { setOpenMenu(null); return; }
      om = { ...om, file: rf };
      setOpenMenu(om);
    }
    if (om.editHide) {
      const hm = loadMap(HIDEKEY); const arr = new Set(hm[om.mime] || []);
      const id = app.packageName + "|" + app.activityName;
      arr.has(id) ? arr.delete(id) : arr.add(id);
      hm[om.mime] = [...arr]; saveMap(HIDEKEY, hm); setOpenMenu({ ...om }); return;
    }
    const defs = loadMap(DEFKEY);
    const openMime = om.asCat ? om.mime : mimeOf(om.file.name);
    if (om.edit) { setOpenMenu(null); try { await Apps.open({ uri: om.file.uri, mime: mimeOf(om.file.name), packageName: app.packageName, activityName: app.activityName, action: "edit" }); } catch (err) { showToast("Не удалось открыть: " + (err?.message || "")); } return; }
    const dkey = defaultOpenAs(om.file.name);
    if (om.useDefault) { defs[dkey] = app.packageName + "|" + app.activityName; saveMap(DEFKEY, defs); }
    else if (defs[dkey]) { delete defs[dkey]; saveMap(DEFKEY, defs); } // разовый выбор — сбросить прежнюю привязку
    setOpenMenu(null);
    try { await Apps.open({ uri: om.file.uri, mime: openMime, packageName: app.packageName, activityName: app.activityName, ...playArgs(om.file) }); }
    catch (err) { showToast("Не удалось открыть: " + (err?.message || "")); }
  };
  const reQueryAs = async (mime) => {
    const e = openMenu.file;
    setOpenMenu((m) => (m ? { ...m, mime, asCat: true, apps: null } : m));
    try { const { apps } = await Apps.query({ uri: e.uri, mime, action: "view" }); const fa = (apps || []).filter((a) => a.packageName !== "leshugan.fm"); setOpenMenu((m) => (m && m.file === e ? { ...m, apps: fa } : m)); }
    catch { setOpenMenu((m) => (m && m.file === e ? { ...m, apps: [] } : m)); }
  };
  const arcAnchor = useRef(null);
  const absPath = async (rel) => { const u = await Filesystem.getUri({ path: rel, directory: DIR }); let p = u.uri; if (p.startsWith("file://")) p = p.slice(7); try { p = decodeURIComponent(p); } catch {} return p; };
  const extractAllTo = async (uri, destRel, names) => {
    const destDir = await absPath(destRel);
    // проверка конфликтов имён с содержимым папки назначения
    try {
      const zl = await Apps.zipList({ uri, password: getCachedPw(uri) || undefined }); // список берётся из кэша, повторного разбора нет
      const dl = await Filesystem.readdir({ path: destDir }).catch(() => ({ files: [] }));
      const destNames = new Set((dl.files || []).map((f) => f.name));
      const wanted = names ? names : (zl.entries || []).map((x) => x.name);
      const tops = new Set(wanted.map((n) => String(n).split("/")[0]).filter(Boolean));
      const clash = [...tops].filter((n) => destNames.has(n));
      if (clash.length) {
        const action = await askConflict(clash.length === 1 ? clash[0] : clash.length + " объект(ов) совпадают");
        if (action === "cancel" || action === "skip") { showToast("Отменено"); return; }
        // overwrite/rename → извлекаем (нативно перезаписывает)
      }
    } catch {}
    let sub = null;
    try { sub = await Apps.addListener("opProgress", (ev) => setProgress({ current: ev.done, total: ev.total, name: ev.name, mode: "ext" })); } catch {}
    setProgress({ current: 0, total: (names ? names.length : 1), name: "", mode: "ext" });
    const doExtract = async (password) => Apps.zipExtractAll({ uri, dest: destDir, entries: names || undefined, password: password || undefined });
    try {
      await doExtract(getCachedPw(uri));
      showToast("Извлечено в " + (baseName(destRel) || "Storage"));
    } catch (e) {
      if (e && e.code === "UNSUPPORTED") { showToast(e.message || "Формат не поддерживается"); }
      const enc = e && (e.code === "ENCRYPTED" || e.code === "BADPASS" || /ENCRYPTED|BADPASS|пароль/i.test(e.message || ""));
      if (enc) {
        let ok = false;
        for (let t = 0; t < 3 && !ok; t++) {
          const pw = await askPassword(t > 0);
          if (pw == null || pw === "") { break; }
          try { await doExtract(pw); setCachedPw(uri, pw); showToast("Извлечено в " + (baseName(destRel) || "Storage")); ok = true; }
          catch (e2) { if (t === 2) showToast("Неверный пароль"); }
        }
      } else showToast("Ошибка: " + (e?.message || ""));
    }
    if (sub) try { sub.remove(); } catch {}
    setProgress(null); await refresh();
  };
  const startExtract = (uri, names, label) => { setOpenMenu(null); setArcView(null); setArcSel(new Set()); setPendingExtract({ uri, names: names || null, label: label || "архив" }); };
  const doExtractHere = async () => { const pe = pendingExtract; setPendingExtract(null); if (pe) await extractAllTo(pe.uri, path, pe.names); };
  const arcBase = (n) => n.replace(/\.[^.]+$/, "");
  const [dragId, setDragId] = useState(null);
  const dragRef = useRef(null);
  const suppressClick = useRef(false);
  const menuCat = (om) => { const f = om.file; const ext = (f.name.split(".").pop() || "").toLowerCase(); if (om.split) return "split"; if (/\.apk$/i.test(f.name)) return "apk"; if (EXT.archive.includes(ext)) return "archive"; if (isImg(f.name)) return "image"; return om.mime; };
  // ЕДИНЫЙ список: приложения (логическая категория) сверху по умолчанию, стоковые снизу; всё скрываемо/перемещаемо
  const buildStockItems = (om) => {
    const f = om.file; const ext = (f.name.split(".").pop() || "").toLowerCase();
    const isApkF = /\.apk$/i.test(f.name); const isArc = /\.(zip|jar|war|obb|rar|7z|tar|tgz|gz|bz2|xz|001|z01|r00)$/i.test(f.name) || /\.part\d+\.rar$/i.test(f.name) || /\.r\d\d$/i.test(f.name) || /\.z\d\d$/i.test(f.name); const items = [];
    const fm = mimeOf(f.name);
    const showApps = !om.split && ((fm !== "*/*" && fm !== "application/octet-stream") || (om.asCat && om.mime !== "*/*"));
    if (showApps) (om.apps || []).forEach((a) => items.push({ id: "app|" + a.packageName + "|" + a.activityName, label: a.label, icon: a.icon, color: TXT, onClick: () => pickApp(a) }));
    if (isImg(f.name)) items.push({ id: "viewer", label: "Открыть (просмотр)", d: I.img, size: 26, color: GOLD, onClick: () => { const defs = loadMap(DEFKEY); if (om.useDefault) defs[defaultOpenAs(f.name)] = "__viewer__"; else if (defs[defaultOpenAs(f.name)]) delete defs[defaultOpenAs(f.name)]; saveMap(DEFKEY, defs); setOpenMenu(null); (async () => { const rf = await arcResolve(f); if (rf) openViewer(rf); })(); } });
    if (isPdf(f.name)) items.push({ id: "pdfview", label: "PDF Читалка", d: I.pdf, size: 26, color: "#E0574F", onClick: () => { const defs = loadMap(DEFKEY); if (om.useDefault) defs[defaultOpenAs(f.name)] = "__pdf__"; else if (defs[defaultOpenAs(f.name)]) delete defs[defaultOpenAs(f.name)]; saveMap(DEFKEY, defs); setOpenMenu(null); (async () => { const rf = await arcResolve(f); if (rf) openPdf(rf); })(); } });
    if (isAudio(f.name)) items.push({ id: "player", label: "Воспроизвести", d: I.audio, size: 26, color: "#E36FB0", onClick: () => { const defs = loadMap(DEFKEY); if (om.useDefault) defs[defaultOpenAs(f.name)] = "__player__"; else if (defs[defaultOpenAs(f.name)]) delete defs[defaultOpenAs(f.name)]; saveMap(DEFKEY, defs); setOpenMenu(null); (async () => { const rf = await arcResolve(f); if (rf) openAudio(rf); })(); } });
    if (isApkF) {
      items.push({ id: "apk_archive", label: "Открыть как архив", d: I.folder, size: 26, color: GOLD, onClick: () => { (async () => { const rf = await arcResolve(f); if (rf) openArchive(rf); })(); } });
    }
    if (om.split) {
      items.push({ id: "split_install", label: "Установщик пакетов (split)", d: I.plus, size: 28, color: "#6FD3A8", onClick: () => { setOpenMenu(null); showToast("Установка пакета…"); Apps.installSplit({ uri: f.uri }).catch((er) => showToast("Ошибка: " + (er?.message || ""))); } });
      items.push({ id: "split_archive", label: "Открыть как архив", d: I.folder, size: 26, color: GOLD, onClick: () => openArchive(f) });
    }
    if (isArc || isGzTar(f.name)) {
      items.push({ id: "arc_open", label: "Открыть", d: I.folder, size: 26, color: GOLD, onClick: () => { (async () => { const rf = await arcResolve(f); if (rf) openArchive(rf); })(); } });
      items.push({ id: "arc_to", label: "Распаковать в…", d: I.dl, size: 22, color: TXT, onClick: () => startExtract(f.uri, null, f.name) });
      items.push({ id: "arc_folder", label: "Распаковать в папку «" + arcBase(f.name) + "»", d: I.folder, size: 22, color: TXT, onClick: () => { setOpenMenu(null); (async () => { const rf = await arcResolve(f); if (rf) extractAllTo(rf.uri, join(path, arcBase(f.name)), null); })(); } });
      items.push({ id: "arc_here", label: "Распаковать здесь", d: I.dl, size: 22, color: TXT, onClick: () => { setOpenMenu(null); (async () => { const rf = await arcResolve(f); if (rf) extractAllTo(rf.uri, path, null); })(); } });
    }
    return items;
  };
  const orderItems = (items, cat) => { const saved = loadMap(ORDERKEY)[cat] || []; const byId = {}; items.forEach((it) => (byId[it.id] = it)); const res = []; saved.forEach((id) => { if (byId[id]) { res.push(byId[id]); delete byId[id]; } }); items.forEach((it) => { if (byId[it.id]) res.push(it); }); return res; };
  const toggleHideItem = (cat, id) => { const m = loadMap(HIDEKEY); const arr = new Set(m[cat] || []); if (arr.has(id)) arr.delete(id); else arr.add(id); m[cat] = [...arr]; saveMap(HIDEKEY, m); setOpenMenu((o) => (o ? { ...o } : o)); };
  const menuDragStart = (idx, e, ordered) => {
    if (!openMenu || !openMenu.editHide) return;
    const id = ordered[idx] && ordered[idx].id; if (!id) return;
    const y0 = e.touches[0].clientY, x0 = e.touches[0].clientX;
    dragRef.current = { id, active: false, moved: false, y0, x0, order: ordered.map((x) => x.id), t: setTimeout(() => {
      const dt = dragRef.current; if (!dt || dt.moved) return; dt.active = true;
      const els = dt.order.map((i) => document.querySelector('[data-mid="' + i + '"]'));
      dt.slots = els.map((el) => { const r = el.getBoundingClientRect(); return { top: r.top, h: r.height, mid: r.top + r.height / 2 }; });
      dt.els = els; dt.startIndex = dt.order.indexOf(id); dt.curIndex = dt.startIndex; setDragId(id); buzz(12);
    }, 320) };
  };
  const menuDragMove = (e) => {
    const dt = dragRef.current; if (!dt) return;
    if (!dt.active) { const tt = e.touches[0]; if (Math.abs(tt.clientX - dt.x0) > 8 || Math.abs(tt.clientY - dt.y0) > 8) { dt.moved = true; if (dt.t) clearTimeout(dt.t); } return; }
    e.preventDefault(); const t = e.touches[0]; if (!dt.slots) return;
    const startSlot = dt.slots[dt.startIndex], self = dt.els[dt.startIndex];
    const dragY = t.clientY - dt.y0;
    if (self) { self.style.transition = "none"; self.style.transform = "translateY(" + dragY + "px)"; self.style.zIndex = "30"; self.style.position = "relative"; }
    const dragMid = startSlot.mid + dragY; let newIndex = dt.startIndex;
    for (let i = 0; i < dt.slots.length; i++) { if (i === dt.startIndex) continue; const s = dt.slots[i]; if (i < dt.startIndex && dragMid < s.mid) newIndex = Math.min(newIndex, i); else if (i > dt.startIndex && dragMid > s.mid) newIndex = Math.max(newIndex, i); }
    if (newIndex !== dt.curIndex) { dt.curIndex = newIndex; const dragH = startSlot.h; dt.order.forEach((id, i) => { if (i === dt.startIndex) return; const el = dt.els[i]; if (!el) return; let shift = 0; if (dt.startIndex < newIndex && i > dt.startIndex && i <= newIndex) shift = -dragH; else if (dt.startIndex > newIndex && i < dt.startIndex && i >= newIndex) shift = dragH; el.style.transition = "transform 200ms cubic-bezier(.22,1,.36,1)"; el.style.transform = shift ? "translateY(" + shift + "px)" : ""; }); }
  };
  const menuDragEnd = (cat) => {
    const dt = dragRef.current; dragRef.current = null;
    if (!dt) return; if (dt.t) clearTimeout(dt.t);
    if (!dt.active) return;
    (dt.els || []).forEach((el) => { if (el) { el.style.transition = ""; el.style.transform = ""; el.style.zIndex = ""; el.style.position = ""; } });
    suppressClick.current = true; setTimeout(() => (suppressClick.current = false), 60);
    const from = dt.startIndex, to = dt.curIndex; setDragId(null);
    if (from !== to) { const no = [...dt.order]; const [m] = no.splice(from, 1); no.splice(to, 0, m); const om = loadMap(ORDERKEY); om[cat] = no; saveMap(ORDERKEY, om); setOpenMenu((o) => (o ? { ...o } : o)); }
  };
  const openArchive = async (e) => {
    setOpenMenu(null);
    setArcPath("");
    setArcView({ name: e.name, uri: e.uri, entries: null });
    const mapEntries = (r) => (r.entries || []).map((x) => ({ name: x.name, size: x.size || 0, dir: !!x.dir })); // порядок задаётся при показе уровня
    try {
      const known = getCachedPw(e.uri);
      const r = await Apps.zipList({ uri: e.uri, password: known || undefined });
      let entries = mapEntries(r);
      // пароль нужен, если данные зашифрованы или скрыты сами имена (пустой список)
      if (r.encrypted && !(known && entries.length)) {
        const destDir = await absPath("Download/.yevtmp");
        let ok = false;
        for (let t = 0; t < 3 && !ok; t++) {
          const pw = await askPassword(t > 0);
          if (pw == null || pw === "") { setArcView(null); return; }
          try {
            const r2 = await Apps.zipList({ uri: e.uri, password: pw });
            const list = mapEntries(r2);
            if (!list.length) throw new Error("empty");            // имена не расшифровались — пароль не тот
            // проверяем пароль только на первом по порядку файле и только если он небольшой:
            // распаковка ради проверки не должна тормозить открытие
            const first = list[0];
            if (first && (first.size || 0) <= 4 * 1024 * 1024) {
              await Apps.zipExtract({ uri: e.uri, entry: first.name, dest: destDir + "/.pwtest", password: pw, quiet: true });
            }
            setCachedPw(e.uri, pw); entries = list; ok = true;
          } catch (er) { if (t === 2) { showToast("Неверный пароль"); setArcView(null); return; } }
        }
      }
      setArcView({ name: e.name, uri: e.uri, entries });
    } catch (err) { setArcView(null); showToast("Не удалось открыть архив: " + (err?.message || "")); }
  };
  const extractOpenMenu = async (entry) => {
    const fname = entry.name.split("/").pop();
    const fe = { name: fname, uri: "file:///" + encodeURIComponent(fname), type: "file", arc: { uri: arcView.uri, entry: entry.name } };
    await showOpenMenu(fe, mimeOf(fname) || "*/*");
  };
  const extractOpen = async (entry) => {
    setArcView((m) => (m ? { ...m, busy: null } : m));
    // подготовка файла к открытию идёт фоном: полоса под кнопкой темы, без уведомления в шторке
    setProgress({ current: 0, total: 100, name: entry.name.split("/").pop(), mode: "ext", bg: true, silent: true });
    let psub = null;
    try { psub = await Apps.addListener("opProgress", (ev) => setProgress((p) => (p ? { ...p, current: ev.done, total: ev.total || 100, name: ev.name } : p))); } catch {}
    const finish = () => { try { psub && psub.remove(); } catch {} setProgress(null); };
    try {
      const fname = entry.name.split("/").pop();
      const destDir = await absPath("Download/.yevtmp");
      const doOne = async (password) => Apps.zipExtract({ uri: arcView.uri, entry: entry.name, dest: destDir + "/" + fname, password: password || undefined, quiet: true });
      try { await doOne(getCachedPw(arcView.uri)); }
      catch (err) {
        if (err && err.code === "UNSUPPORTED") { finish(); showToast(err.message || "Формат не поддерживается"); setArcView((m) => (m ? { ...m, busy: null } : m)); return; }
        const enc = err && (err.code === "ENCRYPTED" || err.code === "BADPASS" || /ENCRYPTED|BADPASS|пароль/i.test(err.message || ""));
        if (!enc) throw err;
        let ok = false;
        for (let t = 0; t < 3 && !ok; t++) {
          const pw = await askPassword(t > 0);
          if (pw == null || pw === "") { finish(); setArcView((m) => (m ? { ...m, busy: null } : m)); return; }
          try { await doOne(pw); setCachedPw(arcView.uri, pw); ok = true; } catch (e2) { if (t === 2) { finish(); showToast("Неверный пароль"); setArcView((m) => (m ? { ...m, busy: null } : m)); return; } }
        }
      }
      const u = await Filesystem.getUri({ path: "Download/.yevtmp/" + fname, directory: DIR });
      finish();
      setArcView((m) => (m ? { ...m, busy: null } : m)); // архив остаётся открытым, как папка
      const fe = { name: fname, uri: u.uri, type: "file" };
      // наше меню выбора: встроенные просмотрщики + список приложений, как в самом менеджере
      await showOpenMenu(fe, mimeOf(fname) || "*/*");
    } catch (err) { setArcView((m) => (m ? { ...m, busy: null } : m)); showToast("Не удалось открыть: " + (err?.message || "")); }
  };
  const resetDefault = () => { const defs = loadMap(DEFKEY); const f = openMenu.file; delete defs[openMenu.mime]; delete defs[mimeOf(f.name)]; delete defs[defaultOpenAs(f.name)]; saveMap(DEFKEY, defs); showToast("Привязка сброшена"); };
  const remoteEnter = (e) => {
    const src = srcRef.current; if (!src) return;
    if (e.type === "directory") {
      setSlide(1); setTimeout(() => setSlide(0), 300);
      setTabs((ts) => ts.map((t, i) => (i === active ? { ...t, src: src.kind === "gdrive" ? { ...src, section: "", folder: e.id, stack: [...src.stack, { id: e.id, name: e.name }] } : { ...src, url: e.url, stack: [...src.stack, { url: e.url, name: e.name }] } } : t)));
    } else {
      setSheet({ kind: "remote", file: e, src });
    }
  };

  /**
   * Просмотр фото прямо с Диска: файл не качается целиком, картинка идёт потоком
   * через свой локальный адрес, поэтому листать можно всю папку.
   */
  const gdBigCache = useRef({});     // крупное превью Диска — показываем сразу
  const gdFileCache = useRef({});    // скачанный снимок — подменяем, когда готов
  const openRemoteGallery = (e) => {
    const imgs = (entries || []).filter((x) => x.type !== "directory" && isImg(x.name));
    let idx = imgs.findIndex((x) => x.id === e.id);
    if (idx < 0) idx = 0;
    const items = imgs.map((x) => ({
      name: x.name, type: "file", gdId: x.id, gdLink: x.thumb, size: x.size,
      uri: gdFileCache.current[x.id] || "", preview: gdBigCache.current[x.id] || null,
    }));
    setViewer({ items, idx, remote: true });
    setViewerBar(true); setDragX(0); setDragY(0); setZoom(1); setPan({ x: 0, y: 0 }); setViewerDel(false);
  };
  // текущий кадр: сперва крупное превью с Диска, следом настоящий файл
  useEffect(() => {
    if (!viewer || !viewer.remote) return;
    let stop = false;
    const put = (i, patch) => setViewer((v) => (v && v.remote ? { ...v, items: v.items.map((x, k) => (k === i ? { ...x, ...patch } : x)) } : v));
    (async () => {
      for (const d of [0, 1, -1]) {
        const i = viewer.idx + d;
        const it = viewer.items[i];
        if (!it || !it.gdId || stop) continue;
        if (!it.preview && it.gdLink) {
          try {
            const r = await Apps.gdriveThumb({ id: it.gdId, link: it.gdLink, size: 1600 });
            if (!stop && r && r.thumb) { gdBigCache.current[it.gdId] = r.thumb; put(i, { preview: r.thumb }); }
          } catch {}
        }
        if (!it.uri && d === 0) {
          try {
            const r = await Apps.gdriveGet({ id: it.gdId, name: it.name, mime: mimeOf(it.name) || "", dest: "temp" });
            const u = r.uri || ("file://" + r.path);
            if (!stop) { gdFileCache.current[it.gdId] = u; put(i, { uri: u }); }
          } catch {}
        }
      }
    })();
    return () => { stop = true; };
  }, [viewer && viewer.idx, viewer && viewer.remote]);
  const remoteTempOpen = async (e, src) => {
    setSheet(null);
    // видно, сколько уже скачано, а не просто «Загрузка…»
    setProgress({ current: 0, total: Math.max(1, e.size || 1), name: e.name, mode: "copy", sub: "с Диска" });
    let sub = null;
    try { sub = await Apps.addListener("gdProgress", (ev) => setProgress((p) => (p ? { ...p, current: ev.done, total: ev.total > 0 ? ev.total : (e.size || 1), name: ev.name } : p))); } catch {}
    const done = () => { try { sub && sub.remove(); } catch {} setProgress(null); };
    const p = src.kind === "gdrive"
      ? Apps.gdriveGet({ id: e.id, name: e.name, mime: e.mime || "", dest: "temp" })
      : Apps.webdavGet({ url: e.url, user: src.acc.user, pass: src.acc.pass, name: e.name, dest: "temp" });
    p.then((r) => {
      done();
      const uri = r.uri || ("file://" + r.path);
      const te = { name: e.name, uri, type: "file" };
      const ext = (e.name.split(".").pop() || "").toLowerCase();
      if (isImg(e.name)) { setViewer({ items: [te], idx: 0 }); setViewerBar(true); setDragX(0); setDragY(0); setZoom(1); setPan({ x: 0, y: 0 }); setViewerDel(false); }
      else if (isPdf(e.name)) openPdf(te);
      else if (isAudio(e.name)) { playerList.current = { uris: [uri], names: [e.name] }; Apps.audioOpen({ uris: [uri], names: [e.name], index: 0, autoNext: false }).catch((er) => showToast("Плеер: " + (er?.message || ""))); setPlayer({ idx: 0, count: 1, name: e.name, playing: true, pos: 0, dur: 0 }); setPlayerMenu(false); }
      // apk и архивы — через меню «Открыть с помощью», как и в обычной папке
      else if (/\.(apk|apks|xapk|apkm|apkx)$/i.test(e.name) || EXT.archive.includes(ext)) showOpenMenu(te, mimeOf(e.name));
      else Apps.open({ uri, mime: mimeOf(e.name) || "*/*" }).catch((er) => showToast("Открытие: " + (er?.message || "")));
    }).catch((er) => { done(); showToast("Ошибка: " + (er?.message || "")); });
  };

  const [savePick, setSavePick] = useState(null); // { file, src, prevSrc } — выбор папки для облачного файла
  const saveTo = (file, src) => { setSheet(null); setSavePick({ file, src, prevSrc: src }); setTabs((ts) => ts.map((t, i) => (i === active ? { ...t, src: null } : t))); };
  const restoreSavePick = () => { const sp = savePick; setSavePick(null); if (sp) setTabs((ts) => ts.map((t, i) => (i === active ? { ...t, src: sp.prevSrc } : t))); };
  const doSavePickHere = async () => {
    const sp = savePick; if (!sp) return;
    const e = sp.file, src = sp.src;
    try {
      showToast("Загрузка…");
      const r = src.kind === "gdrive"
        ? await Apps.gdriveGet({ id: e.id, name: e.name, mime: e.mime || "", dest: "temp" })
        : await Apps.webdavGet({ url: e.url, user: src.acc.user, pass: src.acc.pass, name: e.name, dest: "temp" });
      const fromUri = r.uri || ("file://" + r.path);
      if (path.startsWith("@abs:")) {
        const abs = path.slice(5);
        const st = await Apps.safStatus({ path: abs }).catch(() => ({}));
        if (st && st.needed) {
          if (!st.granted) { setSafPrompt({ abs }); return; } // выбор папки не сбрасываем — можно повторить
          await Apps.safCopyInto({ from: fromUri, destDir: abs });
          showToast("Сохранено: " + e.name); restoreSavePick(); refresh(); return;
        }
      }
      await Filesystem.copy({ from: fromUri, to: targetUri(e.name) });
      showToast("Сохранено: " + e.name); restoreSavePick(); refresh();
    } catch (er) { showToast("Ошибка: " + (er?.message || "")); }
  };
  // Видео и музыка из облака проигрываются потоком: плеер стартует сразу, файл целиком не качается
  const remoteStream = async (e, src) => {
    setSheet(null);
    try {

      const mime = mimeOf(e.name) || "video/*";
      const r = src.kind === "gdrive"
        ? await Apps.streamGdrive({ id: e.id, mime, size: String(e.size || 0) })
        : await Apps.streamWebdav({ url: e.url, user: src.acc.user, pass: src.acc.pass, mime, size: String(e.size || 0) });
      await Apps.openUrl({ url: r.url, mime });
    } catch (er) { showToast("Ошибка: " + (er?.message || "")); }
  };
  const remoteDownload = (e, src) => {
    setSheet(null); showToast("Загрузка…");
    const done = () => showToast("Скачано → Download/" + e.name), fail = (er) => showToast("Ошибка: " + (er?.message || ""));
    if (src.kind === "gdrive") Apps.gdriveGet({ id: e.id, name: e.name, mime: e.mime || "" }).then(done).catch(fail);
    else Apps.webdavGet({ url: e.url, user: src.acc.user, pass: src.acc.pass, name: e.name }).then(done).catch(fail);
  };
  const open = (e, ev) => {
    if (dlsRef.current[e.name]) { showToast("Файл ещё качается"); return; }
    if (pickMode && e.type !== "directory" && !selMode) {
      Apps.pickResult({ uris: [e.uri] }).catch(() => showToast("Не удалось отдать файл"));
      return;
    }
    if (iconPick && e.type !== "directory") {
      if (!isImg(e.name) || e.remote) { showToast("Нужна картинка"); return; }
      applyIconFrom(e); return;
    }
    if (selMode) { toggle(e.name); return; }
    if (e.remote) { remoteEnter(e); return; }
    if (e.type === "directory") {
      if (e.dir) { const abs = absOfUri(e.uri); leaveSearch(); slideNav(1); setTabs((ts) => ts.map((t, i) => (i === active ? { ...t, src: null, path: pathFromAbs(abs) } : t))); return; }
      markCameFrom(path, null); slideNav(1); setTabPath(join(path, e.name)); return;
    }
    arcAnchor.current = ev && ev.currentTarget ? ev.currentTarget.getBoundingClientRect().top : null;
    const ext = (e.name.split(".").pop() || "").toLowerCase();
    if (isFont(e.name)) { openFontViewer(e); return; }
    if (isSplitApk(e.name)) { showOpenMenu(e, "application/octet-stream", { split: true }); return; }
    if (isImg(e.name)) {
      const mime = mimeOf(e.name), cat = defaultOpenAs(e.name), defs = loadMap(DEFKEY), d = defs[cat] || defs[mime];
      if (d === "__viewer__") { openViewer(e); return; }
      if (d) { const [pkg, act] = d.split("|"); Apps.open({ uri: e.uri, mime, packageName: pkg, activityName: act, ...playArgs(e) }).catch(() => showOpenMenu(e, mime)); return; }
      showOpenMenu(e, mime); return;
    }
    if (isPdf(e.name)) {
      const mime = mimeOf(e.name), cat = defaultOpenAs(e.name), defs = loadMap(DEFKEY), d = defs[cat] || defs[mime];
      if (d === "__pdf__") { openPdf(e); return; }
      if (d) { const [pkg, act] = d.split("|"); Apps.open({ uri: e.uri, mime, packageName: pkg, activityName: act, ...playArgs(e) }).catch(() => showOpenMenu(e, mime)); return; }
      showOpenMenu(e, mime); return;
    }
    if (isAudio(e.name)) {
      const mime = mimeOf(e.name), cat = defaultOpenAs(e.name), defs = loadMap(DEFKEY), d = defs[cat] || defs[mime];
      if (d === "__player__") { openAudio(e); return; }
      if (d) { const [pkg, act] = d.split("|"); Apps.open({ uri: e.uri, mime, packageName: pkg, activityName: act, ...playArgs(e) }).catch(() => showOpenMenu(e, mime)); return; }
      showOpenMenu(e, mime); return;
    }
    if (EXT.archive.includes(ext)) { showOpenMenu(e, mimeOf(e.name)); return; }
    openExternal(e);
  };

  const addTab = () => { const id = Date.now(); const t = [...tabs, { id, path: "" }]; persist(t); setActive(t.length - 1); };
  const switchTab = (dir) => { const ni = active + dir; if (ni < 0 || ni >= tabs.length) return; setSlide(dir); setActive(ni); setTimeout(() => setSlide(0), 300); };
  const sx = useRef(0), sy = useRef(0), swiped = useRef(false);
  const onTS = (e) => { sx.current = e.touches[0].clientX; sy.current = e.touches[0].clientY; swiped.current = false; };
  const onTM = (e) => { const dx = e.touches[0].clientX - sx.current, dy = e.touches[0].clientY - sy.current; if (!swiped.current && Math.abs(dx) > 45 && Math.abs(dx) > Math.abs(dy) * 1.3) { swiped.current = true; switchTab(dx > 0 ? -1 : 1); } };
  const tabRefs = useRef([]);
  const [tabDragId, setTabDragId] = useState(null);
  const tabDrag = useRef({ pid: null, from: -1, to: -1, startX: 0, startY: 0, rects: [], gap: 6, active: false });
  const clearTabDrag = () => { tabRefs.current.forEach((el) => { if (el) el.style.transform = ""; }); };
  const beginTabDrag = () => {
    const d = tabDrag.current;
    d.rects = tabRefs.current.map((el) => (el ? el.getBoundingClientRect() : null));
    d.active = true; d.to = d.from; buzz(12); setTabDragId(tabs[d.from].id);
    try { const el = tabRefs.current[d.from]; el && el.setPointerCapture(d.pid); } catch {}
  };
  const tabHoldT = useRef();
  const tabsScrollRef = useRef(null);
  useEffect(() => {
    const cont = tabsScrollRef.current, el = tabRefs.current[active];
    if (!cont || !el) return;
    const cw = cont.clientWidth, left = el.offsetLeft - cont.offsetLeft, w = el.offsetWidth;
    if (w >= cw) cont.scrollTo({ left, behavior: "smooth" });                       // шире окна — прижать к левому краю
    else if (left < cont.scrollLeft) cont.scrollTo({ left: left - 8, behavior: "smooth" });
    else if (left + w > cont.scrollLeft + cw) cont.scrollTo({ left: left + w - cw + 8, behavior: "smooth" });
  }, [active, tabs.length]);
  const onTabDown = (ev, i) => {
    const d = tabDrag.current;
    d.pid = ev.pointerId; d.from = i; d.to = i; d.startX = ev.clientX; d.startY = ev.clientY; d.active = false;
    clearTimeout(tabHoldT.current);
    // перенос — по долгому удержанию (450мс × 2.5), чтобы не конфликтовать с прокруткой панели
    tabHoldT.current = setTimeout(() => { if (d.from >= 0 && !d.active) { buzz(15); beginTabDrag(); } }, 1125);
  };
  const onTabMove = (ev) => {
    const d = tabDrag.current; if (d.from < 0) return;
    if (!d.active) {
      const adx = Math.abs(ev.clientX - d.startX), ady = Math.abs(ev.clientY - d.startY);
      if (adx > 8 || ady > 8) { clearTimeout(tabHoldT.current); d.from = -1; } // палец поехал — это прокрутка
      return;
    }
    ev.preventDefault();
    const rf = d.rects[d.from]; if (!rf) return;
    const dx = ev.clientX - d.startX;
    const fingerX = rf.left + rf.width / 2 + dx;
    let count = 0;
    for (let j = 0; j < d.rects.length; j++) { const r = d.rects[j]; if (!r || j === d.from) continue; if (r.left + r.width / 2 < fingerX) count++; }
    let to = count; if (to < 0) to = 0; if (to > d.rects.length - 1) to = d.rects.length - 1;
    d.to = to;
    const span = rf.width + d.gap;
    for (let j = 0; j < d.rects.length; j++) {
      const el = tabRefs.current[j]; if (!el) continue;
      if (j === d.from) { el.style.transform = "translateX(" + dx + "px)"; continue; }
      let t = 0;
      if (d.from < to && j > d.from && j <= to) t = -span;
      else if (to < d.from && j >= to && j < d.from) t = span;
      el.style.transform = t ? "translateX(" + t + "px)" : "translateX(0)";
    }
  };
  const onTabUp = (i) => {
    clearTimeout(tabHoldT.current);
    const d = tabDrag.current;
    try { if (d.pid != null && tabRefs.current[d.from]) tabRefs.current[d.from].releasePointerCapture(d.pid); } catch {}
    if (d.active) {
      const from = d.from, to = d.to;
      d.active = false; d.from = -1; clearTabDrag(); setTabDragId(null);
      if (to !== from && to >= 0) { setTabs((arr) => { const a = [...arr]; const [m] = a.splice(from, 1); a.splice(to, 0, m); saveTabs(a); return a; }); setActive(to); }
      return;
    }
    d.from = -1; clearTabDrag(); setTabDragId(null);
    const dir = i > active ? 1 : i < active ? -1 : 0; if (dir) { setSlide(dir); setTimeout(() => setSlide(0), 300); }
    setActive(i);
  };
  const onTabCancel = () => { clearTimeout(tabHoldT.current); const d = tabDrag.current; d.active = false; d.from = -1; clearTabDrag(); setTabDragId(null); };

  const saveAllTabs = () => { setTabsMenu(false); const t = tabs.map((x) => ({ ...x, saved: true })); persist(t); showToast("Вкладки сохранены"); };
  const startupHere = () => { setTabsMenu(false); const t = tabs.map((x, i) => ({ ...x, startup: i === active, startupPath: i === active ? path : x.startupPath, saved: i === active ? true : x.saved })); persist(t); showToast("Запуск при открытии: " + (path ? baseName(path) : "Storage")); };
  const resetTabs = () => { setTabsMenu(false); setTabs((arr) => { const t = arr.map((x) => ({ ...x, saved: false, startup: false })); saveTabs(t); return t; }); showToast("Вкладки сброшены"); };

  /* операции через .uri */
  const refresh = () => { forceRef.current = true; list(); };
  const targetUri = (name) => (curUri ? curUri + "/" + name : null);
  // Создание внутри архива: папка или пустой файл ложатся в текущую папку архива
  const arcCreateEntry = async (rawName, isDir) => {
    if (!arcView) return;
    const pw = getCachedPw(arcView.uri) || undefined;
    const name = arcPath + rawName + (isDir ? "/" : "");
    setProgress({ current: 0, total: 100, name: arcView.name, mode: "ext" });
    let sub = null;
    try { sub = await Apps.addListener("opProgress", (ev) => setProgress((p) => (p ? { ...p, current: ev.done, total: ev.total || 100, name: ev.name } : p))); } catch {}
    try {
      await Apps.arcCreate({ uri: arcView.uri, name, password: pw });
      const r = await Apps.zipList({ uri: arcView.uri, password: pw });
      setArcView((m) => (m ? { ...m, entries: (r.entries || []).map((x) => ({ name: x.name, size: x.size || 0, dir: !!x.dir })) } : m));
      showToast(isDir ? "Папка создана в архиве" : "Файл создан в архиве");
    } catch (e) { showToast("Ошибка: " + (e?.message || "")); }
    finally { try { sub && sub.remove(); } catch {} setProgress(null); }
  };
  const doCreateFolder = async (name) => {
    setSheet(null); if (!name) return;
    if (arcView) { await arcCreateEntry(name, true); return; }
    const src = srcRef.current;
    if (src && src.kind === "gdrive") {
      try { await Apps.gdriveMkdir({ folder: src.folder || "root", name }); refresh(); }
      catch (e) {
        const msg = (e?.message || "");
        if (/insufficient|scope|PERMISSION_DENIED|403/i.test(msg)) {
          try { await Apps.gdriveLogout(); } catch {}
          setGdIn(false);
          showToast("Нужен полный доступ к Google Drive — подключитесь заново");
        } else showToast("Ошибка: " + msg);
      }
      return;
    }
    if (src) { showToast("Создание папок недоступно здесь"); return; }
    if (path.startsWith("@abs:")) {
      const abs = path.slice(5);
      try {
        const st = await Apps.safStatus({ path: abs });
        if (st && st.needed) {
          if (!st.granted) { setSafPrompt({ abs }); return; }
          await Apps.safMkdir({ destDir: abs, name }); refresh(); return;
        }
      } catch {}
    }
    try { await Filesystem.mkdir({ path: targetUri(name) }); refresh(); } catch (e) { showToast("Ошибка: " + e.message); }
  };
  const doCreateTxt = async (name) => { setSheet(null); if (!name) return; if (!/\.txt$/i.test(name)) name += ".txt"; if (arcView) { await arcCreateEntry(name, false); return; } try { await Filesystem.writeFile({ path: targetUri(name), data: "", encoding: Encoding.UTF8 }); refresh(); } catch (e) { showToast("Ошибка: " + e.message); } };
  const doCreateNomedia = async () => { try { await Filesystem.writeFile({ path: targetUri(".nomedia"), data: "", encoding: Encoding.UTF8 }); refresh(); showToast("Создан .nomedia"); } catch (e) { showToast("Ошибка: " + e.message); } };
  const doCreateDotFile = async (nm) => { if (arcView) { await arcCreateEntry(nm, false); return; } try { await Filesystem.writeFile({ path: targetUri(nm), data: "", encoding: Encoding.UTF8 }); refresh(); showToast("Создан " + nm); } catch (e) { showToast("Ошибка: " + e.message); } };
  const doRename = async (oldName, newName) => {
    setSheet(null); if (!newName || newName === oldName) return; const e = byName(oldName); if (!e) return;
    try {
      if (e.remote === "gdrive") {                              // на Диске переименование — один запрос
        await Apps.gdriveMove({ id: e.id, name: newName });
        exitSel(); forceRef.current = true; refresh(); return;
      }
      if (e.dir) {
        // результат поиска: переименовываем в его настоящей папке и правим сам результат
        const to = "file://" + e.dir + "/" + newName;
        await Filesystem.rename({ from: e.uri, to });
        const src = srcRef.current; const arr = src && searchResRef.current[src.id];
        if (arr) { const k = arr.findIndex((x) => x.uri === e.uri); if (k >= 0) arr[k] = { ...arr[k], name: newName, uri: to }; }
        exitSel(); refresh(); return;
      }
      await Filesystem.rename({ from: e.uri, to: targetUri(newName) }); exitSel(); refresh();
    } catch (er) { showToast("Ошибка: " + er.message); }
  };
  const doArchive = async (base) => { setSheet(null); const nm = (base || "archive").trim().replace(/\.zip$/i, "") + ".zip"; const uris = [...sel].map((n) => (byName(n) || {}).uri).filter(Boolean); if (!uris.length) return; let sub; try { sub = await Apps.addListener("opProgress", (ev) => setZipProg(Math.max(0, Math.min(100, ev.done)))); } catch {} setZipProg(0); showToast("Архивирование…"); try { await Apps.zipCreate({ dir: curUri, name: nm, uris }); showToast("Готово: " + nm); exitSel(); refresh(); } catch (e) { showToast("Ошибка: " + (e?.message || "")); } if (sub) { try { sub.remove(); } catch {} } setZipProg(null); };
  const delTree = async (e) => {
    if (e.remote === "gdrive") { await Apps.gdriveDelete({ id: e.id || e.uri }); return; }
    try { const r = await Apps.deletePath({ uri: e.uri }); if (r && r.ok) return; } catch {}
    try { const r = await Apps.delete({ uri: e.uri }); if (r && r.deleted) return; } catch {}
    // фолбэк
    if (e.type === "directory") {
      try { const { files } = await Apps.list({ uri: e.uri }); for (const f of files) await delTree(f); } catch {}
      await Filesystem.rmdir({ path: e.uri, recursive: true });
    } else await Filesystem.deleteFile({ path: e.uri });
  };
  const doDelete = async () => {
    const items = [...sel].map(byName).filter(Boolean); setConfirmDel(null);
    // обычные файлы удаляет движок: очередь, пауза, отмена, уведомление и счётчики — как у копирования
    const local = items.filter((e) => !e.remote && !e.dir && e.uri && !String(e.uri).startsWith("content://"));
    if (local.length === items.length && items.length && !srcRef.current) {
      try {
        const r = await Apps.xferStart({ mode: "delete", dest: "", items: items.map((e) => ({ uri: e.uri, name: e.name, type: e.type })) });
        if (r && r.id) xferMeta.current[r.id] = { destPath: path };
        exitSel();
        return;
      } catch (err) { showToast("Ошибка: " + (err?.message || "")); }
    }
    cancelRef.current = false; let ok = 0, fail = 0;
    setProgress({ current: 0, total: items.length, name: "", mode: "del" });
    let dsub = null;
    try { dsub = await Apps.addListener("opProgress", (ev) => { setProgress((p) => (p ? { ...p, sub: { done: ev.done, total: ev.total, name: ev.name } } : p)); }); } catch {}
    for (let i = 0; i < items.length; i++) {
      if (cancelRef.current) break;
      const e = items[i];
      setProgress((p) => ({ ...(p || {}), current: i, total: items.length, name: e.name, mode: "del", sub: null }));
      try { await delTree(e); ok++; } catch { fail++; }
      setProgress((p) => ({ ...(p || {}), current: i + 1, total: items.length, mode: "del" }));
    }
    try { dsub && dsub.remove(); } catch {}
    setProgress(null); Apps.cancelNotify().catch(() => {});
    { const src = srcRef.current; const arr = src && src.kind === "search" && searchResRef.current[src.id]; if (arr) { const gone = new Set(items.map((x) => x.uri)); searchResRef.current[src.id] = arr.filter((x) => !gone.has(x.uri)); } }
    exitSel(); await refresh();
    showToast(cancelRef.current ? "Отменено" : fail ? "Не удалено: " + fail + (ok ? ", удалено: " + ok : "") : "Удалено: " + ok);
  };
  const visibleRef = useRef([]);
  const cutSet = React.useMemo(() => {
    const st = new Set();
    for (const t of (clip || [])) if (t.mode !== "copy") for (const it of t.items) st.add(it.uri);
    return st;
  }, [clip]);
  const grab = (mode) => {
    const items = [...sel].map((n) => { const e = byName(n); return e ? { name: n, uri: e.uri, type: e.type, remote: e.remote, id: e.id } : null; }).filter(Boolean);
    if (!items.length) return;
    const gdFrom = srcRef.current && srcRef.current.kind === "gdrive" ? (srcRef.current.folder || "root") : null;
    setClip((q) => [...(q || []), { id: Date.now() + Math.random(), mode, items, srcPath: path, gdFrom }]);
    exitSel();
    showToast((mode === "copy" ? "Копировать: " : "Вырезать: ") + items.length + " об.");
  };
  const runTask = async (task) => {
    for (const it of task.items) {
      const to = targetUri(it.name);
      if (!to || it.uri === to) continue;
      if (it.type === "directory" && curUri && curUri === it.uri) continue;
      try {
        if (task.mode === "copy") {
          if (it.type === "directory") await Apps.copyTree({ from: it.uri, to });
          else await Filesystem.copy({ from: it.uri, to });
        } else await Filesystem.rename({ from: it.uri, to });
      } catch (e) { showToast(it.name + ": " + e.message); }
    }
  };
  const [opErr, setOpErr] = useState(null); // { name, msg, resolve }
  const [safPrompt, setSafPrompt] = useState(null); // { abs } — просьба дать доступ к флешке
  // Незавершённые задания лежат на диске у движка: при старте предлагаем продолжить с места обрыва
  const [resumeJob, setResumeJob] = useState(null); // { jobs: [...] }
  const jobSave = () => {};
  useEffect(() => {
    try { ls.del("fm_job_v1"); } catch {}
    Apps.jobsList().then((r) => { const jobs = (r && r.jobs) || []; if (jobs.length) setResumeJob({ jobs }); }).catch(() => {});
  }, []);
  // ---- события движка копирования ----
  const xferArc = useRef({});     // id задания -> задачи «вырезать из архива», которые надо доделать после успеха
  const xferMeta = useRef({});    // id задания -> { destPath }
  useEffect(() => {
    let h1, h2;
    const apply = (ev) => {
      if (!ev || !ev.id) return;
      const st = ev.state;
      if (st === "done" || st === "cancelled" || st === "error") {
        setProgress((p) => (p && p.native && p.id === ev.id ? null : p));
        const meta = xferMeta.current[ev.id]; delete xferMeta.current[ev.id];
        const arcTasks = xferArc.current[ev.id]; delete xferArc.current[ev.id];
        if (st === "done") {
          if (arcTasks && arcTasks.length) finishArcCut(arcTasks);
          const failed = ev.failed || 0, skipped = ev.skipped || 0;
          if (ev.mode === "delete") showToast(failed ? "Удалено с ошибками: " + failed : "Удалено");
          else showToast(failed ? "Готово, с ошибками: " + failed : "Готово" + (skipped ? " (пропущено: " + skipped + ")" : ""));
        } else if (st === "cancelled") showToast("Отменено");
        else showToast("Ошибка: " + (ev.error || ""));
        if (!meta || meta.destPath === pathRef.current) silentRefreshRef.current();
        return;
      }
      if (st === "queued") { setProgress((p) => (p && p.native && p.id !== ev.id ? { ...p, queued: ev.queued || 0 } : (p && p.native ? { ...p, queued: ev.queued || 0 } : { bg: false, native: true, id: ev.id, mode: ev.mode === "move" ? "cut" : "copy", name: "", state: "queued", bytesDone: 0, bytesTotal: 0, filesDone: 0, filesTotal: 0, speed: 0, eta: -1, queued: ev.queued || 0, current: 0, total: 0 }))); return; }
      setProgress((p) => ({
        ...(p && p.native && p.id === ev.id ? p : { bg: false }),
        native: true, id: ev.id, mode: ev.mode === "move" ? "cut" : ev.mode === "delete" ? "del" : "copy",
        name: ev.name || (p && p.name) || "", state: st, paused: !!ev.paused,
        bytesDone: ev.bytesDone || 0, bytesTotal: ev.bytesTotal || 0,
        filesDone: ev.filesDone || 0, filesTotal: ev.filesTotal || 0,
        speed: ev.speed || 0, eta: ev.eta == null ? -1 : ev.eta, queued: ev.queued || 0,
        failed: ev.failed || 0, skipped: ev.skipped || 0,
        srcPath: ev.srcPath || (p ? p.srcPath : null), destPath: ev.destPath || (p ? p.destPath : null),
        startedAt: (p && p.native && p.id === ev.id && p.startedAt) || Date.now(),
        current: ev.filesDone || 0, total: ev.filesTotal || 0,
      }));
    };
    Apps.addListener("xfer", apply).then((l) => (h1 = l));
    Apps.addListener("xferAsk", (q) => {
      if (!q) return;
      if (q.kind === "space") setSpaceAsk({ need: q.need, free: q.free, path: q.name });
      else if (q.kind === "conflict") setConflict({ name: q.name, isDir: !!q.isDir, native: true, srcSize: q.srcSize, dstSize: q.dstSize, srcMtime: q.srcMtime, dstMtime: q.dstMtime, srcPath: q.srcPath, dstPath: q.dstPath, same: !!q.same, canResume: !!q.canResume, num: q.num, mode: q.mode });
      else setOpErr({ name: q.name, msg: q.msg || "не удалось", native: true });
    }).then((l) => (h2 = l));
    // приложение перезапустилось, а задание ещё идёт — подхватываем его состояние и открытый вопрос
    Apps.xferState().then((st) => {
      if (st && st.job) apply(st.job);
      if (st && st.ask) {
        const q = st.ask;
        if (q.kind === "space") setSpaceAsk({ need: q.need, free: q.free, path: q.name });
        else if (q.kind === "conflict") setConflict({ name: q.name, isDir: !!q.isDir, native: true, srcSize: q.srcSize, dstSize: q.dstSize, srcMtime: q.srcMtime, dstMtime: q.dstMtime, srcPath: q.srcPath, dstPath: q.dstPath, same: !!q.same, canResume: !!q.canResume, num: q.num, mode: q.mode });
        else setOpErr({ name: q.name, msg: q.msg || "не удалось", native: true });
      }
    }).catch(() => {});
    return () => { h1 && h1.remove(); h2 && h2.remove(); };
  }, []);
  const opErrAll = useRef(null);
  const askOpErr = (name, msg) => new Promise((resolve) => setOpErr({ name, msg, resolve }));
  const resolveOpErr = (action, all) => { if (all) opErrAll.current = action; setOpErr((c) => { if (c && c.native) Apps.xferResolve({ action, all: !!all }).catch(() => {}); else if (c) c.resolve(action); return null; }); };
  const [conflict, setConflict] = useState(null); // { name, resolve }
  const [conflictApplyAll, setConflictApplyAll] = useState(false);
  const [conflictDiffOnly, setConflictDiffOnly] = useState(false);   // «только если различаются»
  const DBGKEY = "fm_debug_v1";
  const [dbgOn, setDbgOn] = useState(() => ls.get(DBGKEY) === "1");   // показывать числа поверх просмотрщика
  const DIRSIZEKEY = "fm_dirsize_v1";
  const [dirSizes, setDirSizes] = useState(() => ls.get(DIRSIZEKEY) === "1");   // вес папок — по умолчанию выключен
  useEffect(() => { Apps.dirSizes({ on: dirSizes }).catch(() => {}); }, []);
  const [progMore, setProgMore] = useState(false);                   // раскрыт ли раздел «Подробности» в окне хода работы
  const [conflictAllFiles, setConflictAllFiles] = useState(false);   // ответ ко всем файлам
  const [conflictAllDirs, setConflictAllDirs] = useState(false);     // ответ ко всем папкам
  const [spaceAsk, setSpaceAsk] = useState(null);                    // не хватает места на приёмнике
  const [jobsView, setJobsView] = useState(null);                    // список заданий движка
  const openJobs = async () => {
    try { const r = await Apps.xferJobs(); setJobsView((r && r.jobs) || []); }
    catch { showToast("Список задач недоступен"); }
  };
  const conflictAll = useRef(null);
  const askConflict = (name, isDir) => new Promise((resolve) => setConflict({ name, isDir, resolve }));
  const conflictRef = useRef(null); conflictRef.current = conflict;
  const resolveConflict = (action, all, newName) => {
    const c0 = conflictRef.current;
    const isDir = !!(c0 && c0.isDir);
    // «Запомнить» у папки — про папки, у файла — про файлы. Вопрос по файлам внутри задаётся отдельно.
    const allDirs = all && isDir;
    const allFiles = all && !isDir;
    if (all) conflictAll.current = action;
    setConflict((c) => {
      if (c && c.native) {
        const map = { rename: "keepBoth", skip: "skip", merge: "merge", replaceDir: "replaceDir", overwrite: "overwrite", overwriteDiff: "overwriteDiff", resume: "resume", cancel: "cancel" };
        Apps.xferResolve({ action: map[action] || "cancel", allFiles, allDirs, newName: newName || undefined }).catch(() => {});
      } else if (c) c.resolve(action === "overwriteDiff" ? "overwrite" : action === "replaceDir" ? "overwrite" : action);
      return null;
    });
    setConflictApplyAll(false); setConflictDiffOnly(false); setConflictAllFiles(false); setConflictAllDirs(false);
  };
  const freeName = (name, taken) => {
    const dot = name.lastIndexOf("."); const base = dot > 0 ? name.slice(0, dot) : name; const ext = dot > 0 ? name.slice(dot) : "";
    const names = taken || new Set(entries.map((e) => e.name));
    let i = 1, cand; do { cand = base + " (" + i + ")" + ext; i++; } while (names.has(cand));
    return cand;
  };
  // «вырезать» из архива: после удачной вставки убираем записи из самого архива
  const finishArcCut = async (tasks) => {
    for (const t of tasks) {
      if (!t || !t.fromArc) continue;
      const apw = getCachedPw(t.fromArc.uri) || undefined;
      try {
        const st = await Apps.zipEditable({ uri: t.fromArc.uri, password: apw }).catch(() => ({ editable: false }));
        if (st.editable && st.kind === "7z") await Apps.sevenModify({ uri: t.fromArc.uri, remove: t.fromArc.entries, password: apw });
        else if (st.editable) await Apps.zipDeleteEntries({ uri: t.fromArc.uri, entries: t.fromArc.entries, password: apw });
        else { await Apps.arcRebuild({ uri: t.fromArc.uri, remove: t.fromArc.entries, password: apw }); showToast("Архив пересобран"); }
        showToast("Удалено из архива: " + t.fromArc.entries.length);
      } catch { showToast("Этот архив изменить нельзя — файлы скопированы"); }
    }
  };
  // Вставка: всё задание целиком уходит в нативный движок (просчёт объёма, конвейер, контрольные точки,
  // вопросы про конфликты и ошибки). Интерфейс только показывает ход работы.
  const runQueue = async (queue0, destPathOverride) => {
    let queue = queue0;
    // приёмник — Google Диск: отправляем туда напрямую, с показом хода
    if (srcRef.current && srcRef.current.kind === "gdrive" && destPathOverride == null) {
      const folder = srcRef.current.folder || "root";
      // взято на самом Диске — переносим или копируем силами Диска, без скачивания
      const inner = (queue0 || []).filter((t) => t.gdFrom);
      if (inner.length) {
        setClip(null);
        let ok = 0, bad = 0;
        for (const t of inner) {
          for (const it of t.items) {
            try {
              if (t.mode === "copy") await Apps.gdriveCopy({ id: it.id || it.uri, folder });
              else await Apps.gdriveMove({ id: it.id || it.uri, addParent: folder, removeParent: t.gdFrom });
              ok++;
            } catch (e) { bad++; }
          }
        }
        showToast(bad ? ("Готово: " + ok + ", с ошибками: " + bad) : ("Готово: " + ok));
        try { const r = await Apps.gdriveList({ folder }); setGd((v) => (v ? { ...v, entries: r.files || [] } : v)); } catch {}
        forceRef.current = true; refresh();
        return;
      }
      const items = [];
      for (const t of queue0 || []) for (const it of t.items || []) if (it.type !== "directory" && !it.remote) items.push(it);
      if (!items.length) { showToast("На Диск можно отправлять только файлы"); return; }
      setClip(null);
      let sub = null;
      try { sub = await Apps.addListener("gdProgress", (ev) => setProgress((p) => (p ? { ...p, name: ev.name, current: ev.done, total: ev.total || 1 } : p))); } catch {}
      let ok = 0, bad = 0;
      for (let i = 0; i < items.length; i++) {
        const it = items[i];
        setProgress({ current: 0, total: 1, name: it.name, mode: "copy", sub: (i + 1) + " из " + items.length });
        try { await Apps.gdrivePut({ uri: it.uri, folder, name: it.name, mime: mimeOf(it.name) }); ok++; }
        catch (e) { bad++; showToast("Не отправился: " + it.name); }
      }
      try { sub && sub.remove(); } catch {}
      setProgress(null);
      showToast(bad ? ("Отправлено: " + ok + ", с ошибками: " + bad) : ("Отправлено на Диск: " + ok));
      try { const r = await Apps.gdriveList({ folder }); setGd((v) => (v ? { ...v, entries: r.files || [] } : v)); } catch {}
      return;
    }
    const destPath = destPathOverride != null ? destPathOverride : path;
    let destUri;
    try { destUri = destPathOverride != null ? (await uriForPath(destPathOverride)).uri : curUri; } catch { destUri = null; }
    if (!destUri) { showToast("Папка-приёмник недоступна"); return; }
    // задачи из архива: сначала достаём записи во временную папку
    const prepared = [];
    for (const t of queue) {
      if (t && t.arc) {
        try {
          setProgress({ current: 0, total: 100, name: t.arc.name, mode: "ext" });
          prepared.push(await arcMaterialize(t));
          setProgress(null);
        } catch (e) { setProgress(null); showToast("Не удалось извлечь: " + (e?.message || "")); }
      } else prepared.push(t);
    }
    queue = prepared;
    const all = [];
    for (const t of queue) for (const it of t.items) all.push({ it, mode: t.mode === "copy" ? "copy" : "move" });
    const destAbs = absOfUri(destUri);
    const plan = all.filter(({ it }) => !(it.type === "directory" && absOfUri(it.uri) === destAbs));
    if (!plan.length) { showToast("Нечего вставлять"); return; }
    // приёмник на съёмном носителе (флешка/SD) требует системного доступа
    if (destPath.startsWith("@abs:")) {
      const abs = destPath.slice(5);
      try {
        const st = await Apps.safStatus({ path: abs });
        if (st && st.needed && !st.granted) { setSafPrompt({ abs }); return; }
      } catch {}
    }
    conflictAll.current = null; setConflictApplyAll(false); opErrAll.current = null;
    const arcTasks = queue.filter((t) => t && t.fromArc);
    for (const mode of ["copy", "move"]) {
      const items = plan.filter((x) => x.mode === mode).map(({ it }) => ({ uri: it.uri, name: it.name, type: it.type }));
      if (!items.length) continue;
      try {
        const r = await Apps.xferStart({ mode, dest: destUri, items, fileRule: "ask", dirRule: "ask" });
        if (r && r.id) {
          xferMeta.current[r.id] = { destPath };
          if (mode === "copy" && arcTasks.length) xferArc.current[r.id] = arcTasks;
          setProgress((p) => (p ? p : { native: true, id: r.id, mode: mode === "move" ? "cut" : "copy", name: "", state: "scan", bytesDone: 0, bytesTotal: 0, filesDone: 0, filesTotal: 0, speed: 0, eta: -1, current: 0, total: 0 }));
        }
      } catch (e) { showToast("Ошибка: " + (e?.message || "")); }
    }
  };
  const pasteAll = async () => { const q = clip || []; setPasteMenu(false); setClip(null); await runQueue(q); };
  const pasteOne = async (task) => { setPasteMenu(false); setClip((q) => (q || []).filter((t) => t.id !== task.id)); await runQueue([task]); };
  const dropTask = (id) => setClip((q) => { const n = (q || []).filter((t) => t.id !== id); return n.length ? n : null; });

  /* три точки тулбара: скрыть / закрепить */
  const metaToggle = (which) => {
    const m = loadMeta();
    for (const n of sel) { const k = keyOf(n);
      if (which === "hidden") { m.hidden.has(k) ? m.hidden.delete(k) : m.hidden.add(k); }
      if (which === "top") { m.pinBot.delete(k); m.pinTop.has(k) ? m.pinTop.delete(k) : m.pinTop.add(k); }
      if (which === "bot") { m.pinTop.delete(k); m.pinBot.has(k) ? m.pinBot.delete(k) : m.pinBot.add(k); }
      if (which === "unpin") { m.pinTop.delete(k); m.pinBot.delete(k); }
    }
    applyMeta(m); setSelMenu(false); exitSel();
    showToast(which === "hidden" ? "Готово" : which === "unpin" ? "Откреплено" : "Закреплено");
  };

  const copyPath = async (p) => { try { await navigator.clipboard.writeText(p); showToast("Путь скопирован"); } catch { showToast("Не удалось скопировать"); } };

  /* отображаемый список: фильтр скрытых -> поиск -> сортировка -> папки сверху -> пины */
    const effSort = effSortFor(path);
const cmp = (a, b) => {
    if (effSort === "az") return nameCmp(a.name, b.name);
    if (effSort === "za") return nameCmp(b.name, a.name);
    if (effSort === "sizeA") return ((a.size || 0) - (b.size || 0)) || nameCmp(a.name, b.name);
    if (effSort === "sizeD") return ((b.size || 0) - (a.size || 0)) || nameCmp(a.name, b.name);
    if (effSort === "dateN") return ((b.mtime || 0) - (a.mtime || 0)) || nameCmp(a.name, b.name);
    if (effSort === "dateO") return ((a.mtime || 0) - (b.mtime || 0)) || nameCmp(a.name, b.name);
    return nameCmp(a.name, b.name);
  };
  let visible = entries.filter((e) => (showHidden || !isHidden(e)) && matchFilter(e));
  // Качающийся файл система от нас прячет, пока браузер не закончит — добавляем его строкой сами
  {
    const have = new Set(visible.map((e) => e.name));
    for (const [file, d] of Object.entries(dls)) {
      const shown = d.name || file;
      if (!d.virtual || have.has(shown) || have.has(file)) continue;
      have.add(shown);
      visible = visible.concat([{ name: shown, type: "file", size: d.done || 0, mtime: Date.now(), uri: (curUri || "") + "/" + encodeURIComponent(file) }]);
    }
  }
  const dq = useDeferredValue((query || "").toLowerCase());
  if (dq) visible = visible.filter((e) => e.name.toLowerCase().includes(dq));
  const isRemote = !!(cur && cur.src);
  const isSysFolder = (e) => !isRemote && path === "" && e.type === "directory" && REAL_SYS.has(e.name.toLowerCase());
  const rank = (e) => (isRemote ? 0 : meta.pinTop.has(keyOf(e.name)) ? -1 : meta.pinBot.has(keyOf(e.name)) ? 1 : 0);
  visible = [...visible].sort((a, b) => {
    // 1) закреплённые сверху/снизу
    const ra = rank(a), rb = rank(b);
    if (ra !== rb) return ra - rb;
    const ad = a.type === "directory", bd = b.type === "directory";
    // 2) системные папки сверху (только локально), НЕ затирая выбранную сортировку остального
    if (sysTop && !isRemote) {
      const sa = isSysFolder(a) ? 0 : 1, sb = isSysFolder(b) ? 0 : 1;
      if (sa !== sb) return sa - sb;
      if (sa === 0 && sb === 0) return nameCmp(a.name, b.name); // сами системные папки — по алфавиту
    }
    // 3) папки выше файлов
    if (ad !== bd) return ad ? -1 : 1;
    // 4) выбранная сортировка
    return cmp(a, b);
  });
  // «Открыть с помощью» для нескольких видео/аудио: строим плейлист в текущем порядке —
  // внешний плеер получает ровно эти файлы и ровно в этой последовательности
  const openSelPlaylist = async () => {
    try {
      const chosen = new Set(sel);
      const list = visible.filter((e) => chosen.has(e.name) && e.type !== "directory" && (isVid(e.name) || isAudio(e.name)));
      if (list.length < 2) return;
      const toPath = (u) => { let pp = (u || "").replace(/^file:\/\//, ""); try { pp = decodeURIComponent(pp); } catch {} return pp; };
      const body = "#EXTM3U\n" + list.map((e) => "#EXTINF:-1," + e.name + "\n" + toPath(e.uri)).join("\n") + "\n";
      const rel = "Download/.yevtmp/playlist.m3u";
      await Filesystem.writeFile({ path: rel, data: body, directory: DIR, encoding: Encoding.UTF8, recursive: true });
      const u = await Filesystem.getUri({ path: rel, directory: DIR });
      setSel(new Set());
      // меню приложений — как при тапе по одному видео/аудио; открываем им плейлист
      const first = list[0];
      await showOpenMenu({ name: first.name, uri: u.uri, type: "file" }, mimeOf(first.name));
    } catch (e) { showToast("Ошибка: " + (e?.message || "")); }
  };
  visibleRef.current = visible;
  entriesRef.current = entries;

  useEffect(() => {
    if (selAllWant.current && !loading) {
      selAllWant.current = false;
      if (visible.length) { setSelMode(true); setSel(new Set(visible.map((e) => e.name))); }
      else setSelMode(false);
    }
  }, [loading, entries]);

  const lpTimer = useRef(), lpFired = useRef(false), moved = useRef(false), pX = useRef(0), pY = useRef(0);
  const selAnchor = useRef(null), visOrder = useRef([]), icoTimer = useRef(), icoFired = useRef(false);
  const selectRange = (toName) => {
    const list = visOrder.current;
    const to = list.indexOf(toName); if (to < 0) return;
    let from = selAnchor.current != null ? list.indexOf(selAnchor.current) : -1;
    if (from < 0) from = 0;
    const [a, b] = from <= to ? [from, to] : [to, from];
    const n = new Set(sel);
    for (let i = a; i <= b; i++) n.add(list[i]);
    setSel(n); setSelMode(n.size > 0); buzz(15);
  };
  const icoDown = (ev, e) => {
    ev.stopPropagation(); icoFired.current = false;
    pX.current = ev.clientX; pY.current = ev.clientY;
    clearTimeout(icoTimer.current);
    icoTimer.current = setTimeout(() => { icoFired.current = true; selectRange(e.name); }, 450);
  };
  const icoUp = (ev, e) => {
    ev.stopPropagation(); clearTimeout(lpTimer.current); clearTimeout(icoTimer.current);
    if (icoFired.current) { icoFired.current = false; return; }
    selAnchor.current = e.name; toggle(e.name);
  };
  /* ===== Перетаскивание файлов (как у MiXplorer): в режиме выделения удерживаем выделенный элемент и тащим
     на папку в списке или на вкладку; вкладка под пальцем через полсекунды сама открывается ===== */
  const [fileDrag, setFileDrag] = useState(null);   // { count, x, y }
  const fdRef = useRef(null);                        // { items, srcPath, x, y }
  const fdHoverT = useRef(); const fdRaf = useRef(0); const fdScrollRaf = useRef(0);
  const [dropMenu, setDropMenu] = useState(null);   // { x, y, destPath, label, items, srcPath }
  const fdHit = (x, y) => {
    let el = document.elementFromPoint(x, y);
    while (el && el !== document.body) {
      if (el.dataset) {
        if (el.dataset.tabIdx != null) return { kind: "tab", idx: Number(el.dataset.tabIdx) };
        if (el.dataset.dir === "1" && el.dataset.uri) return { kind: "row", uri: el.dataset.uri, name: el.dataset.nm };
      }
      el = el.parentElement;
    }
    return null;
  };
  const fdEnd = (commit) => {
    const d = fdRef.current; fdRef.current = null;
    clearTimeout(fdHoverT.current); cancelAnimationFrame(fdRaf.current); cancelAnimationFrame(fdScrollRaf.current);
    document.removeEventListener("pointermove", fdMove); document.removeEventListener("pointerup", fdUp); document.removeEventListener("pointercancel", fdCancel);
    document.removeEventListener("touchmove", fdBlock);
    setFileDrag(null);
    const hov = dropHoverRef.current; setDropHover(null);
    if (!commit || !d || !hov) return;
    let destPath = null, label = "";
    if (hov.kind === "tab") {
      const t = tabsRef.current[hov.idx]; if (!t) return;
      if (t.src) { showToast("Сюда перетащить нельзя"); return; }
      if (hov.idx === activeRef.current) return;
      destPath = t.path || ""; label = t.path ? baseName(t.path) : "Storage";
    } else {
      if (d.items.some((it) => it.uri === hov.uri)) return;   // папку в саму себя
      const abs = absOfUri(hov.uri);
      destPath = pathFromAbs(abs); label = hov.name || baseName(abs);
    }
    if (destPath === d.srcPath) { showToast("Это та же папка"); return; }
    buzz(12);
    setDropMenu({ x: d.x, y: d.y, destPath, label, items: d.items, srcPath: d.srcPath });
  };
  const dropHoverRef = useRef(null);
  const fdSetHover = (h) => {
    const prev = dropHoverRef.current;
    const same = prev && h && prev.kind === h.kind && (h.kind === "tab" ? prev.idx === h.idx : prev.uri === h.uri);
    if (same) return;
    dropHoverRef.current = h; setDropHover(h);
    clearTimeout(fdHoverT.current);
    if (h && h.kind === "tab" && h.idx !== activeRef.current && !(tabsRef.current[h.idx] && tabsRef.current[h.idx].src)) {
      fdHoverT.current = setTimeout(() => { if (dropHoverRef.current === h) { setActive(h.idx); buzz(8); } }, 650);
    }
  };
  const fdMove = (ev) => {
    const d = fdRef.current; if (!d) return;
    d.x = ev.clientX; d.y = ev.clientY;
    if (!fdRaf.current) fdRaf.current = requestAnimationFrame(() => { fdRaf.current = 0; const dd = fdRef.current; if (!dd) return; setFileDrag((f) => (f ? { ...f, x: dd.x, y: dd.y } : f)); fdSetHover(fdHit(dd.x, dd.y)); });
  };
  const fdUp = () => fdEnd(true);
  const fdCancel = () => fdEnd(false);
  const fdBlock = (ev) => { if (fdRef.current) ev.preventDefault(); };
  const fdScrollLoop = () => {
    const d = fdRef.current, el = listRef.current; if (!d || !el) return;
    const r = el.getBoundingClientRect();
    if (d.y < r.top + 70) el.scrollTop -= 10; else if (d.y > r.bottom - 150) el.scrollTop += 10;
    fdScrollRaf.current = requestAnimationFrame(fdScrollLoop);
  };
  const fdStart = (ev, e) => {
    const items = [...sel].map((n) => byName(n)).filter((x) => x && !x.remote && !dlsRef.current[x.name]).map((x) => ({ name: x.name, uri: x.uri, type: x.type }));
    if (!items.length) return;
    fdRef.current = { items, srcPath: path, x: ev.clientX, y: ev.clientY };
    dropHoverRef.current = null;
    setFileDrag({ count: items.length, x: ev.clientX, y: ev.clientY, dir: items.length === 1 && items[0].type === "directory" });
    buzz(20);
    document.addEventListener("pointermove", fdMove); document.addEventListener("pointerup", fdUp); document.addEventListener("pointercancel", fdCancel);
    document.addEventListener("touchmove", fdBlock, { passive: false });
    fdScrollRaf.current = requestAnimationFrame(fdScrollLoop);
  };
  const rDown = (ev, e) => {
    lpFired.current = false; moved.current = false; pX.current = ev.clientX; pY.current = ev.clientY;
    if (dlsRef.current[e.name]) return;                    // качающийся файл не выделяем и не тащим
    const dragable = selMode && sel.has(e.name) && !e.remote && caps.copyFrom;
    lpTimer.current = setTimeout(() => { lpFired.current = true; if (dragable) { fdStart(ev, e); return; } buzz(15); selAnchor.current = e.name; toggle(e.name); }, 450);
  };
  const rMove = (ev) => { if (fdRef.current) return; if (Math.abs(ev.clientX - pX.current) > 10 || Math.abs(ev.clientY - pY.current) > 10) { moved.current = true; clearTimeout(lpTimer.current); clearTimeout(icoTimer.current); } };
  const rUp = (e, ev) => { clearTimeout(lpTimer.current); if (fdRef.current) return; if (lpFired.current || moved.current) return; open(e, ev); };

  const one = sel.size === 1 ? byName([...sel][0]) : null;

  return (
    <div style={{ ...S.app, ...(THEMES[theme] || THEMES.dark), fontFamily: fontCss }}>
      <style>{`html,body{background:${(THEMES[theme] || THEMES.dark)["--bg"]}}@import url('https://fonts.googleapis.com/css2?family=Comfortaa:wght@400;600;700&family=Roboto:wght@400;500;700&display=swap');`}</style>
      {/* ВКЛАДКИ + действия шапки */}
      <div style={S.tabsbar}>
        <div style={{ position: "relative", display: "flex", alignItems: "center", justifyContent: "center", height: "100%", padding: "0 16px" }}>
          <button style={{ ...S.hbtn }} onClick={() => setDrawer(true)}><Svg d={I.bars} size={20} /></button>
        </div>
        <div ref={tabsScrollRef} style={{ ...S.tabs, overflowX: tabDragId ? "visible" : "auto" }}>
          <div style={{ display: "flex", alignItems: "center", gap: 6, margin: "0 auto" }}>
          {tabs.map((t, i) => (
            <div key={t.id} ref={(el) => (tabRefs.current[i] = el)} data-tab-idx={i}
              onPointerDown={(ev) => onTabDown(ev, i)} onPointerMove={onTabMove} onPointerUp={() => onTabUp(i)} onPointerCancel={onTabCancel}
              style={{ ...S.tab, ...(i === active ? S.tabActive : {}), flexShrink: 0, touchAction: "pan-x", transition: t.id === tabDragId ? "none" : (tabDragId ? "transform .18s cubic-bezier(.2,.8,.2,1)" : "box-shadow .2s"), ...(t.id === tabDragId ? { zIndex: 6, position: "relative", boxShadow: "0 6px 16px rgba(0,0,0,.28)" } : (tabDragId ? { opacity: 0.6 } : {})), ...(dropHover && dropHover.kind === "tab" && dropHover.idx === i ? { background: ACC, color: "#fff", boxShadow: "0 0 0 2px " + ACC } : {}) }}>
              <span style={{ overflow: "hidden", textOverflow: "ellipsis", maxWidth: i === active ? 220 : 130 }}>{(arcTabs[String(t.id)] && arcTabs[String(t.id)].view) ? arcBase(arcTabs[String(t.id)].view.name) : (t.src ? t.src.stack[t.src.stack.length - 1].name : (t.path ? baseName(t.path) : "Storage"))}</span>
            </div>
          ))}
          </div>
        </div>
        <div style={{ position: "relative", display: "flex", alignItems: "center", height: "100%", padding: "0 16px" }}>
          <button style={S.hbtn} onClick={() => setHeadMenu((v) => !v)}><Svg d={I.dots} size={20} /></button>
          {headMenu && (
            <>
              <div style={{ ...S.overlay, zIndex: 1190 }} onClick={() => { setHeadMenu(false); setHeadSub(null); }} />
              <div ref={headSubRef} style={{ ...S.menu, zIndex: 1200, ...(headSub ? { position: "fixed", top: headSub.top, left: headSub.left, right: "auto", maxWidth: "calc(100vw - " + (headSub.left + 4) + "px)", maxHeight: "calc(100vh - " + Math.max(8, headSub.top + 8) + "px)", overflowY: "auto", transformOrigin: "top left" } : { top: 46, right: 4, transformOrigin: "top right" }), minWidth: 190 }}>
                {headSub ? (() => {
                  const conf = headSub.kind === "sort" ? { title: "Сортировка", list: SORTS, cur: effSortFor(path), pick: (k) => setSortAsk({ mode: k }) }
                    : headSub.kind === "view" ? { title: "Вид", list: [["list", "Подробная сетка"], ["gallery", "Галерея"]], cur: viewMode, pick: (k) => { setViewMode(k); ls.set(VIEWKEY, k); } }
                    : { title: "Фильтр", list: FILTERS, cur: typeFilter, pick: (k) => setTypeFilter(k) };
                  return (
                    <>
                      <div style={S.menuItem} onClick={(ev) => { ev.stopPropagation(); setHeadSub(null); }}><span style={{ display: "flex", width: 20, height: 20, alignItems: "center", justifyContent: "center", color: ACC }}><Svg d={I.back} size={16} /></span>{conf.title}</div>
                      <div style={{ height: 1, background: LINE }} />
                      {conf.list.map(([k, lbl], ix) => (
                        <React.Fragment key={k}>
                          {ix > 0 && <div style={{ height: 1, background: LINE }} />}
                          <div style={{ ...S.menuItem, whiteSpace: "normal", ...(conf.cur === k ? { color: ACC } : {}) }} onClick={() => { setHeadMenu(false); setHeadSub(null); conf.pick(k); }}>
                            {lbl}{conf.cur === k && <span style={{ marginLeft: "auto" }}>{"\u2713"}</span>}
                          </div>
                        </React.Fragment>
                      ))}
                    </>
                  );
                })() : (<>
                <div style={S.menuItem} onClick={() => { setHeadMenu(false); addTab(); }}>
                  <span style={{ color: ACC, display: "flex" }}><Svg d={I.plus} size={20} /></span>Новая вкладка
                </div>
                <div style={{ height: 1, background: LINE }} />
                <div style={S.menuItem} onClick={() => { setHeadMenu(false); saveAllTabs(); }}><span style={{ color: ACC, display: "flex" }}><Svg d={I.pin} size={20} /></span>Сохранить вкладки</div>
                <div style={{ height: 1, background: LINE }} />
                <div style={S.menuItem} onClick={() => { setHeadMenu(false); startupHere(); }}><span style={{ color: GOLD, display: "flex" }}><Svg d={I.home} size={20} /></span>Запуск при открытии</div>
                <div style={{ height: 1, background: LINE }} />
                <div style={S.menuItem} onClick={() => { setHeadMenu(false); resetTabs(); }}><span style={{ color: SUB, display: "flex" }}><Svg d={I.x} size={20} /></span>Сбросить вкладки</div>
                {tabs.length > 1 && <>
                  <div style={{ height: 1, background: LINE }} />
                  <div style={S.menuItem} onClick={() => { setHeadMenu(false); closeTab(active); }}><span style={{ color: RED, display: "flex" }}><Svg d={I.x} size={20} /></span>Закрыть вкладку</div>
                </>}
                <div style={{ height: 1, background: LINE }} />
                <div style={S.menuItem} onClick={(ev) => { ev.stopPropagation(); const r = ev.currentTarget.getBoundingClientRect(); setHeadSub({ kind: "sort", top: r.top, left: r.left }); }}>
                  <span style={{ color: ACC, display: "flex" }}><Svg d={I.sort} size={20} /></span>Сортировка
                </div>
                <div style={{ height: 1, background: LINE }} />
                <div style={S.menuItem} onClick={(ev) => { ev.stopPropagation(); const r = ev.currentTarget.getBoundingClientRect(); setHeadSub({ kind: "filter", top: r.top, left: r.left }); }}>
                  <span style={{ color: typeFilter !== "all" ? ACC : SUB, display: "flex" }}><Svg d={I.sort} size={20} /></span>Фильтр{typeFilter !== "all" ? " \u00b7 " + (FILTERS.find(([k]) => k === typeFilter) || [])[1] : ""}
                </div>
                <div style={{ height: 1, background: LINE }} />
                <div style={S.menuItem} onClick={(ev) => { ev.stopPropagation(); const r = ev.currentTarget.getBoundingClientRect(); setHeadSub({ kind: "view", top: r.top, left: r.left }); }}>
                  <span style={{ color: ACC, display: "flex" }}><Svg d={I.img} size={20} /></span>Вид
                </div>
                <div style={{ height: 1, background: LINE }} />
                <div style={S.menuItem} onClick={() => { setShowHidden((v) => !v); setHeadMenu(false); refresh(); }}>
                  <span style={{ color: showHidden ? ACC : SUB, display: "flex" }}><Svg d={showHidden ? I.eye : I.eyeOff} size={20} /></span>
                  Скрытые объекты
                  <span style={{ marginLeft: "auto", ...S.tgl, ...(showHidden ? S.tglOn : {}) }}><span style={{ ...S.knob, ...(showHidden ? S.knobOn : {}) }} /></span>
                </div>
                <div style={{ height: 1, background: LINE }} />
                <div style={S.menuItem} onClick={() => { setHeadMenu(false); setSettings(true); setSettingsPage(null); }}>
                  <span style={{ color: ACC, display: "flex" }}><Svg d={I.gear} size={20} /></span>Настройки
                </div>
                </>)}
              </div>
            </>
          )}
        </div>
      </div>

      {/* ПУТЬ */}
      <div style={S.crumb}>
        {(path || (cur && cur.src)) && (
          <span onClick={goUp} style={{ display: "inline-flex", alignItems: "center", color: ACC, flexShrink: 0, paddingRight: 4 }}><Svg d={I.back} size={18} /></span>
        )}
        <span ref={crumbRef} style={{ flex: 1, minWidth: 0, display: "flex", alignItems: "center", overflowX: "auto", overflowY: "hidden", whiteSpace: "nowrap", scrollbarWidth: "none", touchAction: "pan-x", WebkitOverflowScrolling: "touch", overscrollBehaviorX: "contain", WebkitMaskImage: crumbOver ? "linear-gradient(to right, transparent 0, #000 10px, #000 calc(100% - 14px), transparent 100%)" : "none", maskImage: crumbOver ? "linear-gradient(to right, transparent 0, #000 10px, #000 calc(100% - 14px), transparent 100%)" : "none" }}>
          {crumbs.length === 0 ? <span style={{ color: SUB }}>/storage</span>
            : crumbs.map((c, i) => (
              <React.Fragment key={i}>
                {i > 0 && <span style={{ color: SUB, opacity: 0.55, padding: "0 5px", flexShrink: 0 }}>/</span>}
                <span onClick={() => goCrumb(i)}
                  style={{ flexShrink: 0, color: i === crumbs.length - 1 ? ACC : SUB, fontWeight: i === crumbs.length - 1 ? 600 : 400, maxWidth: i === crumbs.length - 1 ? "none" : 140, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap", padding: "2px 0" }}>{c.name}</span>
              </React.Fragment>
            ))}
        </span>
        {themeBtn && (
          <button onClick={toggleTheme} aria-label="Тема"
            style={{ position: "fixed", right: 12, top: "calc(env(safe-area-inset-top) + 108px)", zIndex: 1210, width: 34, height: 34, borderRadius: 17, border: "1px solid rgba(255,255,255,.14)", background: BAR, color: ACC, display: "flex", alignItems: "center", justifyContent: "center", padding: 0, margin: 0, lineHeight: 0, boxShadow: "0 2px 8px rgba(0,0,0,.28)" }}>
            <Svg d={theme === "light" ? I.sun : I.moon} size={18} />
          </button>
        )}
        {(zipProg != null || progress) && (() => { const pv = zipProg != null ? zipProg : (progress && progress.total ? Math.round(((progress.current + (progress.sub && progress.sub.total ? progress.sub.done / progress.sub.total : 0)) / progress.total) * 100) : 0); return (
          <div style={{ position: "fixed", right: 9, top: "calc(env(safe-area-inset-top) + 148px)", zIndex: 1260, pointerEvents: "none" }}>
            <svg width="40" height="26" viewBox="0 0 40 26">
              <path d="M4 8 A16 16 0 0 0 36 8" fill="none" stroke="var(--chip)" strokeWidth="4" strokeLinecap="round" />
              <path d="M4 8 A16 16 0 0 0 36 8" fill="none" stroke={ACC} strokeWidth="4" strokeLinecap="round" strokeDasharray="50.27" strokeDashoffset={(50.27 * (1 - pv / 100)).toFixed(2)} style={{ transition: "stroke-dashoffset .2s linear" }} />
            </svg>
          </div>
        ); })()}
      </div>

      {shared.length > 0 && (
        <div style={{ position: "fixed", inset: 0, zIndex: 1300, background: "rgba(0,0,0,.5)", display: "flex", alignItems: "flex-end", justifyContent: "center" }} onClick={dismissShared}>
          <div onClick={(e) => e.stopPropagation()} style={{ width: "100%", background: BAR, borderRadius: "20px 20px 0 0", padding: "16px 16px calc(14px + env(safe-area-inset-bottom))", boxShadow: "0 -8px 30px rgba(0,0,0,.5)", animation: "dropGrow .2s cubic-bezier(.2,.9,.3,1.1)" }}>
            <div style={{ fontSize: 15, color: TXT, fontWeight: 600, marginBottom: 3 }}>Файл из другого приложения{shared.length > 1 ? " (" + shared.length + ")" : ""}</div>
            <div style={{ fontSize: 13, color: SUB, marginBottom: 12 }}>Что сделать с файлом?</div>
            <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
              <button onClick={() => { setShared([]); setSaveMode(true); }} style={{ display: "flex", alignItems: "center", gap: 10, padding: "12px 14px", borderRadius: 12, border: "1px solid " + LINE, background: ROW2, color: TXT, fontSize: 15 }}><span style={{ color: ACC, display: "flex" }}><Svg d={I.dl} size={20} /></span>Сохранить</button>
              <button onClick={openSharedHere} style={{ display: "flex", alignItems: "center", gap: 10, padding: "12px 14px", borderRadius: 12, border: "1px solid " + LINE, background: ROW2, color: TXT, fontSize: 15 }}><span style={{ color: ACC, display: "flex" }}><Svg d={I.folder} size={20} /></span>Открыть</button>
              <button onClick={dismissShared} style={{ padding: "10px 14px", borderRadius: 12, border: "none", background: "none", color: SUB, fontSize: 14 }}>Отмена</button>
            </div>
          </div>
        </div>
      )}
      {!allFiles && (
        <div style={S.accessBar}>
          <div style={{ flex: 1, fontSize: 13, lineHeight: 1.4 }}>Нет доступа ко всем файлам — архивы, PDF и APK не видны.</div>
          <button style={S.accessBtn} onClick={() => Apps.requestAllFiles().catch(() => {})}>Дать доступ</button>
        </div>
      )}
      {exportPick && (
        <>
          <div style={S.savePop}>
            <Svg d={I.dl} size={20} />
            <span style={{ flex: 1, fontSize: 13.5, lineHeight: 1.35 }}>Перейдите в папку для сохранения настроек и нажмите «Сохранить сюда»</span>
          </div>
          <div style={S.saveBar}>
            <button style={S.saveBtnCancel} onClick={() => setExportPick(null)}>Отмена</button>
            <button style={S.saveBtnSave} onClick={doExportHere}><Svg d={I.dl} size={16} /> Сохранить сюда</button>
          </div>
        </>
      )}
      {savePick && (
        <>
          <div style={S.savePop}>
            <Svg d={I.dl} size={20} />
            <span style={{ flex: 1, fontSize: 13.5, lineHeight: 1.35 }}>Перейдите в папку и нажмите «Сохранить сюда» — «{savePick.file.name}» скачается туда</span>
          </div>
          <div style={S.saveBar}>
            <button style={S.saveBtnCancel} onClick={restoreSavePick}>Отмена</button>
            <button style={S.saveBtnSave} onClick={doSavePickHere}><Svg d={I.dl} size={16} /> Сохранить сюда</button>
          </div>
        </>
      )}
      {appPick && (
        <div style={S.backdrop} onClick={() => setAppPick(null)}>
          <div style={{ ...S.sheet, padding: "14px 14px 24px", maxHeight: "82vh", display: "flex", flexDirection: "column" }} onClick={(e) => e.stopPropagation()}>
            <div style={{ color: TXT, fontSize: 17, fontWeight: 700 }}>Открыть в приложении</div>
            <div style={{ color: SUB, fontSize: 12.5, margin: "4px 0 10px", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{appPick.file.name}</div>
            <input autoFocus value={appPick.q} placeholder="Поиск приложения" onChange={(e) => setAppPick((m) => ({ ...m, q: e.target.value }))} style={{ ...S.searchInput, marginBottom: 10 }} />
            <div style={{ flex: 1, overflowY: "auto", margin: "0 -4px" }}>
              {!appPick.list && <div style={{ color: SUB, fontSize: 14, textAlign: "center", padding: "20px 0" }}>Собираю список…</div>}
              {appPick.list && appPick.list
                .filter((a) => !appPick.q || (a.label || "").toLowerCase().includes(appPick.q.toLowerCase()) || a.pkg.includes(appPick.q.toLowerCase()))
                .slice(0, 400)
                .map((a) => (
                  <div key={a.pkg} onClick={() => openWithApp(a)} style={{ display: "flex", alignItems: "center", gap: 12, padding: "9px 8px", borderRadius: 12 }}>
                    {a.icon ? <img src={cfs(a.icon)} alt="" style={{ width: 40, height: 40, borderRadius: 10, flexShrink: 0 }} />
                      : <span style={{ width: 40, height: 40, borderRadius: 10, background: ROW2, color: SUB, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}><Svg d={I.android} size={20} /></span>}
                    <div style={{ flex: 1, minWidth: 0 }}>
                      <div style={{ color: TXT, fontSize: 15, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{a.label}</div>
                      <div style={{ color: SUB, fontSize: 11.5, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{a.pkg}</div>
                    </div>
                  </div>
                ))}
            </div>
            <button onClick={() => setAppPick(null)} style={{ width: "100%", background: ROW2, border: "1px solid " + LINE, borderRadius: 14, color: TXT, fontSize: 15, fontWeight: 600, padding: "13px 0", marginTop: 10 }}>Отмена</button>
          </div>
        </div>
      )}
      {iconApps && (
        <div style={S.backdrop} onClick={() => setIconApps(null)}>
          <div style={{ ...S.sheet, padding: "14px 14px 24px", maxHeight: "82vh", display: "flex", flexDirection: "column" }} onClick={(e) => e.stopPropagation()}>
            <div style={{ color: TXT, fontSize: 17, fontWeight: 700, marginBottom: 10 }}>Иконка из приложения</div>
            <input autoFocus value={iconApps.q} placeholder="Поиск приложения" onChange={(e) => setIconApps((m) => ({ ...m, q: e.target.value }))} style={{ ...S.searchInput, marginBottom: 10 }} />
            <div style={{ flex: 1, overflowY: "auto", margin: "0 -4px" }}>
              {!iconApps.list && <div style={{ color: SUB, fontSize: 14, textAlign: "center", padding: "20px 0" }}>Собираю список…</div>}
              {iconApps.list && iconApps.list
                .filter((a) => !iconApps.q || (a.label || "").toLowerCase().includes(iconApps.q.toLowerCase()) || a.pkg.includes(iconApps.q.toLowerCase()))
                .slice(0, 400)
                .map((a) => (
                  <div key={a.pkg} onClick={() => applyIconFromApp(a)} style={{ display: "flex", alignItems: "center", gap: 12, padding: "9px 8px", borderRadius: 12 }}>
                    {a.icon ? <img src={cfs(a.icon)} alt="" style={{ width: 40, height: 40, borderRadius: 10, flexShrink: 0 }} />
                      : <span style={{ width: 40, height: 40, borderRadius: 10, background: ROW2, color: SUB, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}><Svg d={I.android} size={20} /></span>}
                    <div style={{ flex: 1, minWidth: 0 }}>
                      <div style={{ color: TXT, fontSize: 15, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{a.label}</div>
                      <div style={{ color: SUB, fontSize: 11.5, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{a.pkg}{a.sys ? " · системное" : ""}</div>
                    </div>
                  </div>
                ))}
            </div>
            <button onClick={() => setIconApps(null)} style={{ width: "100%", background: ROW2, border: "1px solid " + LINE, borderRadius: 14, color: TXT, fontSize: 15, fontWeight: 600, padding: "13px 0", marginTop: 10 }}>Отмена</button>
          </div>
        </div>
      )}
      {pickMode && (
        <>
          <div style={S.savePop}>
            <Svg d={I.check} size={20} />
            <span style={{ flex: 1, fontSize: 13.5, lineHeight: 1.35 }}>
              {pickMode.multi ? "Выберите файлы и нажмите «Отдать»" : "Нажмите на файл, чтобы отдать его приложению"}
            </span>
          </div>
          <div style={S.saveBar}>
            <button style={S.saveBtnCancel} onClick={() => { setPickMode(null); Apps.pickCancel().catch(() => {}); }}>Отмена</button>
            {pickMode.multi && (
              <button style={S.saveBtnOk} onClick={() => {
                const list = [...sel].map(byName).filter((x) => x && x.type !== "directory").map((x) => x.uri);
                if (!list.length) { showToast("Ничего не выбрано"); return; }
                Apps.pickResult({ uris: list }).catch(() => showToast("Не удалось отдать файлы"));
              }}>Отдать ({sel.size})</button>
            )}
          </div>
        </>
      )}
      {iconPick && (
        <>
          <div style={S.savePop}>
            <Svg d={I.img} size={20} />
            <span style={{ flex: 1, fontSize: 13.5, lineHeight: 1.35 }}>Иконка для «{iconPick.name}» — откройте папку с картинкой и нажмите на неё</span>
          </div>
          <div style={S.saveBar}>
            <button style={S.saveBtnCancel} onClick={() => { const b = iconPick.back; setIconPick(null); if (b != null) setTabPath(b); }}>Отмена</button>
            <button style={S.saveBtnCancel} onClick={() => { const db = { ...loadMap(ICONKEY) }; delete db[iconPick.folder]; saveIconDB(db); const b = iconPick.back; setIconPick(null); if (b != null) setTabPath(b); showToast("Иконка сброшена"); }}>Сбросить иконку</button>
          </div>
        </>
      )}
      {pendingExtract && (
        <>
          <div style={S.savePop}>
            <Svg d={I.dl} size={20} />
            <span style={{ flex: 1, fontSize: 13.5, lineHeight: 1.35 }}>Из «{pendingExtract.label}»{pendingExtract.names ? " (" + pendingExtract.names.length + ")" : ""} — перейдите в папку и нажмите «Извлечь сюда»</span>
          </div>
          <div style={S.saveBar}>
            <button style={S.saveBtnCancel} onClick={() => setPendingExtract(null)}>Отмена</button>
            <button style={S.saveBtnSave} onClick={doExtractHere}><Svg d={I.dl} size={16} /> Извлечь сюда</button>
          </div>
        </>
      )}
      {/* СПИСОК */}
      <main ref={listRef} style={S.list} onScroll={onListScroll} onTouchStart={onTS} onTouchMove={onTM}>
        {false && (
          <div style={S.accessBar}>
            <div style={{ flex: 1, fontSize: 13, lineHeight: 1.4 }}>Нет доступа ко всем файлам — архивы, PDF и APK не видны.</div>
            <button style={S.accessBtn} onClick={() => Apps.requestAllFiles().catch(() => {})}>Дать доступ</button>
          </div>
        )}
        <div key={active + "|" + path} style={{ ...S.slideWrap, marginTop: 0, visibility: listShown ? "visible" : "hidden", pointerEvents: slide ? "none" : "auto", animation: (slide && ((!(cur && cur.src) && localCache.current[path]) || seenKeys.current.has(active + "|" + path))) ? `fm-in-${slide > 0 ? "r" : "l"} .28s cubic-bezier(.22,.61,.36,1)` : "none" }}>
          {loading && null}
          {!loading && !error && !srcRef.current && visible.length === 0 && /\/Android\/(data|obb)/.test(absOfUri(curUri) || "") && (
            <div style={{ ...S.note, color: GOLD, lineHeight: 1.5 }}>
              Система прячет эту папку от приложений.
              <br /><span style={{ fontSize: 12 }}>Нужен Shizuku: включи его и выдай разрешение в «Настройки → Требуемые разрешения».</span>
              {shz && shz.detail && <><br /><span style={{ fontSize: 11, color: SUB, wordBreak: "break-word" }}>{shz.detail}</span></>}
              <br />
              <button onClick={async () => {
                const ok = shz && shz.state === "ok";
                if (!ok) { Apps.shizukuRequest().catch(() => {}); }
                await new Promise((r) => setTimeout(r, ok ? 100 : 900));
                forceRef.current = true; refresh();
                try {
                  const st = await Apps.shizukuStatus();
                  setShz(st);
                  if (ok) showToast(st && st.detail ? String(st.detail).slice(0, 120) : "Прочитал заново");
                  else showToast("Подтверди запрос в Shizuku");
                } catch { showToast("Не удалось спросить Shizuku"); }
              }}
                style={{ marginTop: 10, height: 40, padding: "0 18px", borderRadius: 12, border: "none", background: ACC, color: "#fff", fontSize: 14.5, fontWeight: 600 }}>
                {shz && shz.state === "ok" ? "Прочитать заново" : "Подключить Shizuku"}
              </button>
            </div>
          )}
          {error && !srcRef.current && (
            <div style={{ ...S.note, color: RED }}>{error}
              {/доступ|permission|denied|EACCES/i.test(error) ? <><br /><span style={{ fontSize: 12 }}>Разрешите «Доступ ко всем файлам» в настройках приложения.</span></> : null}
            </div>
          )}
          {error && srcRef.current && <div style={{ ...S.note, color: RED }}>{error}</div>}
          <div ref={spacerRef} style={{ height: 0 }} />
          {(() => {
            const renderRow = (e) => {
              const isSel = sel.has(e.name), hid = isHidden(e);
              const isDir = e.type === "directory";
              const sf = isDir ? SYS_FOLDERS[e.name.toLowerCase()] : null;
              const ic = isDir ? { d: (sf && sf.d) || I.folder, c: (sf && sf.c) || ACC, w: sf && sf.w } : fileIcon(e.name);
              const pinned = meta.pinTop.has(keyOf(e.name)) || meta.pinBot.has(keyOf(e.name));
              const wasHere = cameFrom[path] === e.name && !isSel;
              const dl = dls[e.name];                                   // файл ещё качается
              const dlPct = dl && dl.total > 0 ? Math.max(0, Math.min(100, Math.round((dl.done / dl.total) * 100))) : null;
              return (
                <div key={e.uri || e.name} data-nm={e.name} data-kind={isDir ? "d" : e.dir ? "s" : "f"} data-here={wasHere ? "1" : undefined} data-dir={isDir ? "1" : undefined} data-uri={isDir ? e.uri : undefined} data-dl={dl ? "1" : undefined} style={{ ...S.row, ...(visible.length <= 12 || geom.current.virt ? { contentVisibility: "visible" } : {}), ...(isDir ? S.rowDir : {}), ...(isSel ? S.rowSel : {}), ...(dropHover && dropHover.uri === e.uri ? S.rowDrop : {}), opacity: dl ? 0.45 : cutSet.has(e.uri) ? 0.35 : hid ? 0.5 : 1 }}
                  onPointerDown={(ev) => rDown(ev, e)} onPointerMove={rMove} onPointerUp={(ev) => rUp(e, ev)} onPointerCancel={() => clearTimeout(lpTimer.current)}>
                  <span style={{ ...S.iconWrap, color: ic.c, background: "var(--chip)", overflow: "hidden", position: "relative" }}
                    onPointerDown={(ev) => icoDown(ev, e)} onPointerMove={rMove} onPointerUp={(ev) => icoUp(ev, e)} onPointerCancel={() => clearTimeout(icoTimer.current)}>
                    {(isDir && iconDB[keyOf(e.name)]) ? <img src={iconDB[keyOf(e.name)]} alt="" style={S.iconImg} />
                      : (!isDir && (e.remote === "gdrive" ? !!e.thumb : !e.remote && (isImg(e.name) || isVid(e.name) || isPdf(e.name) || /\.apk$/i.test(e.name)))) ?
                          <ThumbIcon uri={e.uri} tkey={tkeyOf(e)} gd={e.remote === "gdrive" ? { id: e.id, link: e.thumb } : null} cached={thumbs[tkeyOf(e)]} request={requestThumb} release={releaseThumb}
                            fallback={/\.apk$/i.test(e.name) ? <Svg d={ic.d} size={24} /> : isPdf(e.name) ? <Svg d={ic.d} size={24} /> : <Svg d={ic.d} size={24} />} />
                      : (!isDir && EXT.archive.includes((e.name.split(".").pop() || "").toLowerCase())) ? <ArcBadge name={e.name} />
                      : <Svg d={ic.d} size={24} vw={ic.w} />}
                    {isDir && !iconDB[keyOf(e.name)] && e.appIcon ? <img src={cfs(e.appIcon)} alt="" style={{ ...S.folderThumb, right: 0, bottom: 0, width: 30, height: 30 }} /> : null}
                    {isDir && !iconDB[keyOf(e.name)] && !e.appIcon && e.thumb ? (
                      isVid(e.thumb)
                        ? <span style={{ ...S.folderThumb, overflow: "hidden", display: "flex" }}>
                            <ThumbIcon uri={e.thumb} tkey={"ft:" + e.thumb} cached={thumbs["ft:" + e.thumb]} request={requestThumb} release={releaseThumb} radius={6} fallback={<Svg d={I.video} size={14} />} />
                          </span>
                        : <img src={cfs(e.thumb)} alt="" loading="lazy" style={S.folderThumb} />
                    ) : null}
                  </span>
                  <span style={S.rowMid}>
                    <span style={{ ...S.name, fontWeight: isDir ? 600 : 400, display: "flex", alignItems: "flex-start", gap: 7, color: wasHere ? ACC : undefined, ...(dl && !dl.stalled ? { paddingRight: 38 } : {}) }}>
                      {/* имя в две строки, дальше многоточие */}
                      <span style={{ overflow: "hidden", display: "-webkit-box", WebkitBoxOrient: "vertical", WebkitLineClamp: 2, wordBreak: "break-word" }}>{dl ? dl.name : e.name}</span>
                      {/* отсюда только что вышли */}
                      {wasHere && <span style={S.hereDot} />}
                      {isDir && startupPath != null && join(path, e.name) === startupPath && <span style={{ color: GOLD, display: "flex", flexShrink: 0 }}><Svg d={I.home} size={15} /></span>}
                      {/* сколько объектов в папке — над её весом */}
                      {!dl && isDir && e.count != null && <><span style={{ flex: 1, minWidth: 6 }} /><span style={S.rowCount}>{"(" + e.count + ")"}</span></>}
                    </span>
                    {/* вторая строка: слева когда менялось, справа вес */}
                    <span style={{ ...S.rowDate, display: "flex", alignItems: "center", gap: 7, overflow: "hidden", whiteSpace: "nowrap" }}>
                      {dl ? (
                        <span style={{ color: dl.stalled ? RED : dl.paused ? SUB : ACC, overflow: "hidden", textOverflow: "ellipsis" }}>
                          {dl.stalled ? "не докачан" : dl.paused ? "на паузе" : (dl.extra || "качается")}
                        </span>
                      ) : (<>
                        {e.dir ? <span style={{ overflow: "hidden", textOverflow: "ellipsis" }}>{relLabel(e.dir)}</span> : null}
                        {e.mtime ? <span style={{ flexShrink: 0 }}>{fmtDate(e.mtime)}</span> : null}
                      </>)}
                      <span style={{ flex: 1, minWidth: 8 }} />
                      {dl && !dl.stalled ? (
                        <span style={{ ...S.rowNum, color: dl.paused ? SUB : ACC }}>
                          {fmtSizeShort(dl.done)}{dl.total > 0 ? " из " + fmtSizeShort(dl.total) : ""}
                        </span>
                      ) : null}
                      {!dl && isDir && dirSizes && e.bytes != null && e.bytes > 0 ? <span style={S.rowNum}>{fmtSizeShort(e.bytes)}</span> : null}
                      {!dl && !isDir ? <span style={S.rowNum}>{fmtSizeShort(e.size)}</span> : null}
                    </span>
                  </span>
                  {/* кольцо стоит поверх строки и не отнимает ширину — вес остаётся на своём месте */}
                  {dl && !dl.stalled && (
                    <span style={{ position: "absolute", right: 13, top: 9 }}><DlRing pct={dlPct} paused={dl.paused} /></span>
                  )}
                  {!dl && pinned && <span style={{ color: SUB, display: "flex", flexShrink: 0 }}><Svg d={meta.pinTop.has(keyOf(e.name)) ? I.pinT : I.pinB} size={14} /></span>}
                  {!isDir && <div style={S.rowLine} />}
                </div>
              );
            };
            const renderCell = (e) => {
              const isSel = sel.has(e.name), hid = isHidden(e);
              const isDir = e.type === "directory";
              const sf = isDir ? SYS_FOLDERS[e.name.toLowerCase()] : null;
              const ic = isDir ? { d: (sf && sf.d) || I.folder, c: (sf && sf.c) || ACC, w: sf && sf.w } : fileIcon(e.name);
              const thumb = !isDir && (e.remote === "gdrive" ? !!e.thumb : !e.remote && (isImg(e.name) || isVid(e.name) || isPdf(e.name) || /\.apk$/i.test(e.name)));
              return (
                <div key={e.uri || e.name} data-nm={e.name} data-kind="g" data-dir={isDir ? "1" : undefined} data-uri={isDir ? e.uri : undefined} onPointerDown={(ev) => rDown(ev, e)} onPointerMove={rMove} onPointerUp={(ev) => rUp(e, ev)} onPointerCancel={() => clearTimeout(lpTimer.current)}
                  style={{ display: "flex", flexDirection: "column", gap: 5, padding: 6, borderRadius: 12, background: dropHover && dropHover.uri === e.uri ? "var(--acc)" : isSel ? "var(--accbg)" : "transparent", opacity: cutSet.has(e.uri) ? 0.35 : hid ? 0.5 : 1 }}>
                  <div style={{ position: "relative", width: "100%", aspectRatio: "1 / 1", borderRadius: 10, overflow: "hidden", background: "var(--chip)", display: "flex", alignItems: "center", justifyContent: "center", color: ic.c }}>
                    {(isDir && iconDB[keyOf(e.name)]) ? <img src={iconDB[keyOf(e.name)]} alt="" style={{ width: "100%", height: "100%", objectFit: "cover" }} />
                      : thumb ? <ThumbIcon uri={e.uri} tkey={tkeyOf(e)} gd={e.remote === "gdrive" ? { id: e.id, link: e.thumb } : null} cached={thumbs[tkeyOf(e)]} request={requestThumb} release={releaseThumb} big fallback={<Svg d={ic.d} size={42} />} />
                      : isDir && e.thumb ? (
                        isVid(e.thumb)
                          ? <ThumbIcon uri={e.thumb} tkey={"ft:" + e.thumb} cached={thumbs["ft:" + e.thumb]} request={requestThumb} release={releaseThumb} fallback={<Svg d={ic.d} size={42} />} />
                          : <img src={cfs(e.thumb)} alt="" loading="lazy" style={{ width: "100%", height: "100%", objectFit: "cover", opacity: 0.9 }} />
                      )
                      : <Svg d={ic.d} size={42} vw={ic.w} />}
                  </div>
                  <div style={{ fontSize: 11.5, color: cameFrom[path] === e.name ? ACC : TXT, lineHeight: 1.25, maxHeight: 29, overflow: "hidden", wordBreak: "break-word", textAlign: "center", fontWeight: isDir ? 600 : 400 }}>{e.name}</div>
                </div>
              );
            };
            const firstFile = visible.findIndex((e) => e.type !== "directory");
            const startupPath = (tabs.find((t) => t.startup) || {}).startupPath;
            visLen.current = visible.length;
            visOrder.current = visible.map((x) => x.name);
            const H = rowHRef.current;
            const hd = H.d || 74, hf = H.f || 66, hs = H.s || 84, hg = H.g || 138;
            const gallery = viewMode === "gallery";
            const N = visible.length;
            const virt = N > 60;
            const el = listRef.current;
            const vh = (el && el.clientHeight > 0) ? el.clientHeight : (window.innerHeight || 800);
            const spH = geom.current.spacer = spacerRef.current ? spacerRef.current.offsetHeight : 0;
            if (!virt) {
              geom.current.virt = false; geom.current.offsets = null;
              if (gallery) return (
                <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 6, padding: "8px 10px 20px" }}>
                  {visible.map((e) => renderCell(e))}
                </div>
              );
              return visible.map((e) => (
                <React.Fragment key={e.uri || e.name}>
                  {renderRow(e)}
                </React.Fragment>
              ));
            }
            geom.current.virt = true;
            const y0 = winY - spH - vh, y1 = winY - spH + vh * 2;   // запас по экрану сверху и снизу
            if (gallery) {
              const rows = Math.ceil(N / 3);
              const total = 28 + rows * hg - 6;                      // отступы сетки 8 сверху и 20 снизу
              const r0 = Math.max(0, Math.floor(y0 / hg)), r1 = Math.min(rows, Math.ceil(y1 / hg) + 1);
              geom.current.total = total; geom.current.last4 = Math.min(rows, 2) * hg;
              geom.current.offsets = null;
              const names = []; for (let r = 0; r < rows; r++) names.push(visible[r * 3].name);
              geom.current.offsets = Array.from({ length: rows + 1 }, (_, r) => 8 + r * hg); geom.current.names = names;
              return (
                <div style={{ padding: "8px 10px 20px" }}>
                  <div style={{ height: r0 * hg }} />
                  <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 6 }}>
                    {visible.slice(r0 * 3, r1 * 3).map((e) => renderCell(e))}
                  </div>
                  <div style={{ height: Math.max(0, (rows - r1) * hg) }} />
                </div>
              );
            }
            const offsets = new Array(N + 1); const names = new Array(N);
            let acc = 0, start = -1, end = N;
            for (let i = 0; i < N; i++) {
              const e = visible[i]; names[i] = e.name;
              offsets[i] = acc;
              const h = e.type === "directory" ? hd : e.dir ? hs : hf;
              if (start < 0 && acc + h > y0) start = i;
              if (end === N && acc > y1) end = i;
              acc += h;
            }
            offsets[N] = acc;
            if (start < 0) start = N;
            let last4 = 0; for (let i = Math.max(0, N - 4); i < N; i++) last4 += offsets[i + 1] - offsets[i];
            geom.current.total = acc; geom.current.last4 = last4; geom.current.offsets = offsets; geom.current.names = names;
            return (
              <>
                <div style={{ height: offsets[start] }} />
                {visible.slice(start, end).map((e) => (
                  <React.Fragment key={e.uri || e.name}>
                    {renderRow(e)}
                  </React.Fragment>
                ))}
                <div style={{ height: Math.max(0, acc - offsets[end]) }} />
              </>
            );
          })()}
        </div>
      </main>
      {!loading && !error && visible.length === 0 && !arcView && (
        <div style={{ position: "absolute", left: 0, right: 0, top: "42%", textAlign: "center", color: SUB, pointerEvents: "none", zIndex: 2 }}>Пусто</div>
      )}
      {fsBar && (
        <div
          onPointerDown={(ev) => { ev.preventDefault(); fsDrag.current = true; ev.currentTarget.setPointerCapture(ev.pointerId); fsFromY(ev.clientY); }}
          onPointerMove={(ev) => { if (fsDrag.current) fsFromY(ev.clientY); }}
          onPointerUp={() => { fsDrag.current = false; updateFs(listRef.current); }}
          onPointerCancel={() => { fsDrag.current = false; }}
          style={{ position: "absolute", right: 0, top: fsBar.top, width: 34, height: fsBar.h, zIndex: 8, display: "flex", alignItems: "center", justifyContent: "flex-end", touchAction: "none", cursor: "grab" }}>
          {fsDrag.current && fsBar.label && (
            <span style={{ position: "absolute", right: 30, background: BAR, color: ACC, borderRadius: 12, padding: "6px 12px", fontSize: 18, fontWeight: 600, boxShadow: "var(--barsh)" }}>{fsBar.label}</span>
          )}
          <span style={{ width: fsDrag.current ? 6 : 4, height: "100%", marginRight: 4, borderRadius: 3, background: fsDrag.current ? ACC : "var(--sub)", opacity: fsDrag.current ? 1 : (fsBar.idle ? 0.25 : 0.55), transition: "opacity .25s, width .15s, background .15s" }} />
        </div>
      )}

      {/* ПОИСК */}
      {query !== null && (
        <div style={{ ...S.searchBar, bottom: "calc(" + (86 + kbH) + "px + env(safe-area-inset-bottom))", flexDirection: "column", alignItems: "stretch", gap: 6 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
            <input autoFocus value={query} placeholder={inSearch ? "Фильтр по результатам…" : "Поиск в папке…"} onChange={(e) => setQuery(e.target.value)} onKeyDown={(e) => { if (e.key === "Enter" && caps.search) { e.preventDefault(); startDeepSearch(); } }} style={S.searchInput} />
            {caps.search && <button style={{ ...S.searchClose, fontSize: 18, color: searchPanel ? ACC : SUB }} onClick={() => setSearchPanel((v) => !v)} aria-label="Условия поиска"><Svg d={I.sort} size={20} /></button>}
            <button style={S.searchClose} onClick={() => { setQuery(null); setSearchPanel(false); }}>×</button>
          </div>
          {caps.search && (
            <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
              <button onClick={() => startDeepSearch()} style={{ ...S.chip, background: ACC, color: "#fff", borderColor: ACC, fontWeight: 600 }}>{inSearch ? "Искать снова" : path || inSearch ? "Искать в подпапках" : "Искать везде"}</button>
              {inSearch && searchLive && (
                <span style={{ fontSize: 12, color: SUB, flex: 1, minWidth: 0, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
                  {searchLive.running ? "Ищу… найдено " + searchLive.total : "Найдено " + searchLive.total}
                  {searchLive.running ? <span onClick={() => stopSearch(searchLive.id)} style={{ color: RED, marginLeft: 8 }}>остановить</span> : null}
                </span>
              )}
              {!inSearch && <span style={{ fontSize: 11.5, color: SUB, flex: 1, minWidth: 0, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>маски * и ? · Enter — искать</span>}
            </div>
          )}
          {searchPanel && caps.search && (
            <div style={{ display: "flex", flexDirection: "column", gap: 6, paddingTop: 2 }}>
              <div style={{ display: "flex", gap: 6, overflowX: "auto", paddingBottom: 2 }}>
                {[...FILTERS, ["dir", "Папки"]].map(([k, lbl]) => (
                  <button key={k} onClick={() => setSearchOpts((o) => ({ ...o, types: k }))} style={{ ...S.chip, ...(searchOpts.types === k ? { background: "var(--accbg)", color: ACC, borderColor: ACC } : {}) }}>{lbl}</button>
                ))}
              </div>
              <div style={{ display: "flex", gap: 6, overflowX: "auto", paddingBottom: 2 }}>
                {[["any", "Любая дата"], ["day", "За день"], ["week", "За неделю"], ["month", "За месяц"], ["year", "За год"]].map(([k, lbl]) => (
                  <button key={k} onClick={() => setSearchOpts((o) => ({ ...o, date: k }))} style={{ ...S.chip, ...(searchOpts.date === k ? { background: "var(--accbg)", color: ACC, borderColor: ACC } : {}) }}>{lbl}</button>
                ))}
              </div>
              <div style={{ display: "flex", gap: 6, alignItems: "center" }}>
                <span style={{ fontSize: 12, color: SUB, flexShrink: 0 }}>Размер, МБ:</span>
                <input value={searchOpts.minMb} onChange={(e) => setSearchOpts((o) => ({ ...o, minMb: e.target.value }))} placeholder="от" inputMode="decimal" style={{ ...S.searchInput, padding: "6px 10px", fontSize: 13, width: 70, flex: "none" }} />
                <input value={searchOpts.maxMb} onChange={(e) => setSearchOpts((o) => ({ ...o, maxMb: e.target.value }))} placeholder="до" inputMode="decimal" style={{ ...S.searchInput, padding: "6px 10px", fontSize: 13, width: 70, flex: "none" }} />
                <span onClick={() => setSearchOpts((o) => ({ ...o, hidden: !o.hidden }))} style={{ display: "flex", alignItems: "center", gap: 6, color: SUB, fontSize: 12, marginLeft: "auto" }}>
                  <span style={{ ...S.cbox, width: 18, height: 18, ...(searchOpts.hidden ? S.cboxOn : {}) }}>{searchOpts.hidden ? <Svg d={I.check} size={11} /> : null}</span>Скрытые
                </span>
              </div>
            </div>
          )}
        </div>
      )}

      {/* НИЖНЯЯ ПАНЕЛЬ (плавает над списком — контент уходит под неё) */}
      <div ref={navRef} style={{ position: "absolute", left: 0, right: 0, bottom: 0, zIndex: 60, pointerEvents: "none", transform: "translateZ(0)", background: arcView ? BG : "transparent" }}>
       <div style={{ pointerEvents: "auto" }}>
      {arcView && arcSel.size > 0 ? (
        <nav style={{ ...S.bottom, justifyContent: "flex-start" }}>
          <div style={{ width: 38, display: "flex", alignItems: "center", justifyContent: "flex-end", paddingRight: 2, flexShrink: 0 }}>
            <div style={S.selCount}>
              <span key={arcUnits.length} style={{ fontSize: 13, fontWeight: 700, color: "#fff", lineHeight: 1, display: "block", textAlign: "center", animation: "pulse .3s cubic-bezier(.2,.9,.3,1.3)" }}>{arcUnits.length}</span>
            </div>
          </div>
          <div style={{ flex: 1, overflow: "hidden", display: "flex" }}>
            <div style={{ display: "flex", overflowX: "auto", overflowY: "hidden", flex: 1, justifyContent: "flex-start", paddingBottom: 20, marginBottom: -20 }}>
              {/* набор кнопок как вне архива: «Вырезать» и «Копир.» сами извлекают выбранное */}
              <Btn onClick={() => setArcSel(new Set())} icon={I.x} label="Отмена" flexNone />
              <Btn onClick={() => arcGrab("cut")} icon={I.cut} label="Вырезать" flexNone />
              <Btn onClick={() => arcGrab("copy")} icon={I.copy} label="Копир." flexNone />
              <Btn onClick={(ev) => arcDelete(ev)} icon={I.trash} label="Удалить" red flexNone />
              <Btn onClick={arcRename} icon={I.rename} label="Имя" flexNone disabled={arcUnits.length !== 1} />
            </div>
          </div>
        </nav>
      ) : arcView && (clip || []).some((t) => t.arc && t.arc.uri === arcView.uri) ? (
        <nav style={S.bottom}>
          {(() => {
            const task = (clip || []).filter((t) => t.arc && t.arc.uri === arcView.uri).slice(-1)[0];
            return (<>
              <Zone><Btn onClick={() => dropTask(task.id)} icon={I.x} label="Отмена" red /></Zone>
              <Zone><Btn onClick={() => setArcSel(new Set(arcView.entries ? arcView.entries.map((e) => (e.dir && !String(e.name).endsWith("/") ? e.name + "/" : e.name)) : []))} icon={I.selectAll} label="Все" /></Zone>
              <Zone><Btn onClick={() => arcPasteInside(task)} icon={I.paste} label={"Вставить (" + task.arc.entries.length + ")"} /></Zone>
            </>);
          })()}
        </nav>
      ) : selMode ? (
        <nav style={{ ...S.bottom, justifyContent: "flex-start" }}>
          <div style={{ width: 38, display: "flex", alignItems: "center", justifyContent: "flex-end", paddingRight: 2, flexShrink: 0 }}>
            <div style={S.selCount}>
              <span key={sel.size} style={{ fontSize: 13, fontWeight: 700, color: "#fff", lineHeight: 1, display: "block", textAlign: "center", animation: "pulse .3s cubic-bezier(.2,.9,.3,1.3)" }}>{sel.size}</span>
            </div>
          </div>
          <div style={{ flex: 1, overflow: "hidden", display: "flex" }}>
            <div style={{ display: "flex", overflowX: "auto", overflowY: "hidden", flex: 1, justifyContent: "flex-start", paddingBottom: 20, marginBottom: -20 }}>
            <Btn onClick={exitSel} icon={I.x} label="Отмена" flexNone />
            <Btn onClick={() => setProps(sel.size === 1 ? one : { multi: [...sel].map((n) => byName(n)).filter(Boolean) })} icon={I.info} label="Свойства" flexNone disabled={sel.size < 1} />
            {caps.copyFrom && <Btn onClick={() => grab("cut")} icon={I.cut} label="Вырезать" flexNone />}
            {caps.copyFrom && <Btn onClick={() => grab("copy")} icon={I.copy} label="Копир." flexNone />}
            {caps.del && <Btn onClick={(ev) => { const t = ev.currentTarget; const r = t.getBoundingClientRect(); const p = t.previousElementSibling; const cr = p ? p.getBoundingClientRect() : r; setConfirmDel({ cx: cr.left + cr.width / 2, top: r.top }); }} icon={I.trash} label="Удалить" red flexNone />}
            {caps.rename && <Btn onClick={() => { const e = one; const sp = splitExt(e.name, e.type === "directory"); setSheet({ kind: "rename", old: e.name, base: sp.base, ext: sp.ext, editExt: false }); }} icon={I.rename} label="Имя" flexNone disabled={sel.size !== 1} />}
            <Btn onClick={() => setSelMenu((v) => !v)} icon={I.dots} label="Ещё" flexNone />
          </div>
          </div>
        </nav>
      ) : (
        <nav style={S.bottom}>
          <Zone><Btn onClick={() => setQuery(query === null ? "" : null)} icon={I.search} label="Поиск" /></Zone>
          <Zone>{clip && clip.length > 0 ? <Btn onClick={() => setClip(null)} icon={I.x} label="Отмена" red /> : saveMode ? <Btn onClick={() => { setSaveMode(false); dismissShared(); }} icon={I.x} label="Отмена" red /> : null}</Zone>
          <Zone><Btn onClick={selectAll} icon={I.selectAll} label="Все" /></Zone>
          <Zone>{clip && clip.length > 0 && caps.write ? <Btn onClick={() => (clip.length === 1 ? pasteAll() : setPasteMenu((v) => !v))} icon={I.paste} label={"Вставить (" + clip.length + ")"} /> : saveMode && caps.write ? <Btn onClick={saveSharedHere} icon={I.paste} label="Вставить" /> : null}</Zone>
          <Zone>{(caps.mkdir || caps.write) ? <Btn onClick={() => setCreateOpen((v) => !v)} icon={I.plus} label="Создать" /> : null}</Zone>
        </nav>
      )}
       </div>
      </div>

      {/* МЕНЮ «СОЗДАТЬ» (поверх тулбара) */}
      {createOpen && (
        <>
          <div style={{ position: "fixed", inset: 0, zIndex: 1190 }} onClick={() => { setCreateOpen(false); setCreateSub(null); }} />
          <div style={{ ...S.menu, position: "fixed", right: 8, bottom: "calc(62px + env(safe-area-inset-bottom))", zIndex: 1200, minWidth: 150, transformOrigin: "bottom right" }}>
            {createSub === "dot" ? (
              <>
                <div style={S.createItem} onClick={() => { setCreateSub(null); setCreateOpen(false); doCreateDotFile(".nomedia"); }}>
                  <div>.nomedia<div style={{ fontSize: 10.5, color: SUB, marginTop: 2 }}>(скроет все медиа + в подпапках)</div></div>
                </div>
                <div style={{ height: 1, background: LINE }} />
                <div style={S.createItem} onClick={() => { setCreateSub(null); setCreateOpen(false); doCreateDotFile(".nofolder"); }}>
                  <div>.nofolder<div style={{ fontSize: 10.5, color: SUB, marginTop: 2 }}>(скроет медиа от YevGallery только в этой, папке без подпапок)</div></div>
                </div>
                <div style={{ height: 1, background: LINE }} />

                <div style={{ height: 1, background: LINE }} />
                <div style={{ ...S.createItem, color: SUB }} onClick={() => setCreateSub(null)}>‹ Назад</div>
              </>
            ) : (
              <>
                <div style={S.createItem} onClick={() => setCreateSub("dot")}>.CreateFile ›</div>
                <div style={{ height: 1, background: LINE }} />
                <div style={S.createItem} onClick={() => { setCreateOpen(false); setSheet({ kind: "folder", val: "" }); }}>Папка</div>
                <div style={{ height: 1, background: LINE }} />
                <div style={S.createItem} onClick={() => { setCreateOpen(false); setSheet({ kind: "txt", val: "" }); }}>TXT</div>
              </>
            )}
          </div>
        </>
      )}

      {/* МЕНЮ «ЕЩЁ» выделения (поверх тулбара) */}
      {selMenu && (
        <>
          <div style={{ position: "fixed", inset: 0, zIndex: 1190 }} onClick={() => setSelMenu(false)} />
          <div style={{ ...S.menu, position: "fixed", right: 8, bottom: "calc(56px + env(safe-area-inset-bottom))", zIndex: 1200, transformOrigin: "bottom right" }}>
            {one && one.dir && (
              <>
                <div style={S.menuItem} onClick={() => { const abs = one.dir; setSelMenu(false); exitSel(); leaveSearch(); setQuery(null); setTabs((ts) => ts.map((t, i) => (i === active ? { ...t, src: null, path: pathFromAbs(abs) } : t))); }}>
                  <span style={{ color: ACC, display: "flex" }}><Svg d={I.folder} size={20} /></span>Открыть папку файла
                </div>
                <div style={{ height: 1, background: LINE }} />
              </>
            )}
            {one && one.type === "directory" && (
              <>
                <div style={S.menuItem} onClick={() => askIconSource(one.dir ? absOfUri(one.uri) : join(path, one.name), one.name)}>
                  <span style={{ color: GOLD, display: "flex" }}><Svg d={I.img} size={20} /></span>Изменить иконку
                </div>
                <div style={{ height: 1, background: LINE }} />
              </>
            )}
            {one && one.type === "directory" && !one.dir && (
              <>
                <div style={S.menuItem} onClick={() => { const t = [...tabs, { id: Date.now(), path: keyOf(one.name) }]; persist(t); setSelMenu(false); exitSel(); setActive(t.length - 1); }}>
                  <span style={{ color: ACC, display: "flex" }}><Svg d={I.folder} size={20} /></span>Открыть во вкладке
                </div>
                <div style={{ height: 1, background: LINE }} />
              </>
            )}
            {(() => {
              const dirs = [...sel].map(byName).filter((e) => e && e.type === "directory" && !e.remote);
              if (!dirs.length) return null;
              return (<>
                <div style={S.menuItem} onClick={() => { setSelMenu(false); addBookmark(); }}>
                  <span style={{ color: GOLD, display: "flex" }}><Svg d={I.star} size={20} /></span>В закладки
                </div>
                <div style={{ height: 1, background: LINE }} />
              </>);
            })()}
            {(() => {
              const items = visibleRef.current.filter((x) => sel.has(x.name) && x.type !== "directory" && !x.remote);
              const media = items.length > 1 && items.every((x) => isVid(x.name) || isAudio(x.name) || isImg(x.name));
              if (!media) return null;
              const mime = items.every((x) => isVid(x.name)) ? "video/*" : items.every((x) => isAudio(x.name)) ? "audio/*" : items.every((x) => isImg(x.name)) ? "image/*" : "*/*";
              return (
                <>
                  <div style={S.menuItem} onClick={() => { setSelMenu(false); const uris = items.map((x) => x.uri); Apps.open({ uri: uris[0], mime, uris, chooser: true }).catch((err) => showToast("Не удалось открыть: " + (err?.message || ""))); exitSel(); }}>
                    <span style={{ color: ACC, display: "flex" }}><Svg d={I.open} size={20} /></span>Открыть с помощью
                  </div>
                  <div style={{ height: 1, background: LINE }} />
                </>
              );
            })()}
            {caps.meta && (() => { const allHid = [...sel].every((n) => meta.hidden.has(keyOf(n))); return (
              <div style={S.menuItem} onClick={() => metaToggle("hidden")}>
                <span style={{ color: SUB, display: "flex" }}><Svg d={allHid ? I.eye : I.eyeOff} size={20} /></span>{allHid ? "Показать" : "Скрыть"}
              </div>
            ); })()}
            {caps.pins && <div style={{ height: 1, background: LINE }} />}
            {caps.pins && (() => {
              const pinnedNow = [...sel].every((n) => meta.pinTop.has(keyOf(n)) || meta.pinBot.has(keyOf(n)));
              if (pinnedNow) return <div style={S.menuItem} onClick={() => metaToggle("unpin")}><span style={{ color: ACC, display: "flex" }}><Svg d={I.x} size={20} /></span>Открепить</div>;
              return (<>
                <div style={S.menuItem} onClick={() => metaToggle("top")}><span style={{ color: ACC, display: "flex" }}><Svg d={I.pinT} size={20} /></span>Закрепить сверху</div>
                <div style={{ height: 1, background: LINE }} />
                <div style={S.menuItem} onClick={() => metaToggle("bot")}><span style={{ color: ACC, display: "flex" }}><Svg d={I.pinB} size={20} /></span>Закрепить снизу</div>
              </>);
            })()}
            {one && one.type !== "directory" && (
              <>
                <div style={{ height: 1, background: LINE }} />
                <div style={S.menuItem} onClick={() => { setSelMenu(false); const e = one; exitSel(); showOpenMenu(e, mimeOf(e.name)); }}><span style={{ color: TXT, display: "flex" }}><Svg d={I.dots} size={20} /></span>Открыть с помощью</div>
              </>
            )}
            {one && /\.apk$/i.test(one.name) && (
              <>
                <div style={{ height: 1, background: LINE }} />
                <div style={S.menuItem} onClick={() => { setSelMenu(false); Apps.installApk({ uri: one.uri }).catch((er) => showToast("Ошибка: " + (er?.message || ""))); }}><span style={{ color: "#6FD3A8", display: "flex" }}><Svg d={I.plus} size={20} /></span>Установить</div>
                <div style={{ height: 1, background: LINE }} />
                <div style={S.menuItem} onClick={() => { setSelMenu(false); Apps.uninstall({ uri: one.uri }).catch((er) => showToast("Ошибка: " + (er?.message || ""))); }}><span style={{ color: RED, display: "flex" }}><Svg d={I.trash} size={20} /></span>Деинсталлировать</div>
              </>
            )}
            {(() => {
              const items = [...sel].map(byName).filter(Boolean);
              const allMedia = items.length >= 2 && items.every((e) => e.type !== "directory" && (isVid(e.name) || isAudio(e.name)));
              if (!allMedia) return null;
              return (<>
                <div style={{ height: 1, background: LINE }} />
                <div style={S.menuItem} onClick={() => { setSelMenu(false); openSelPlaylist(); }}><span style={{ color: ACC, display: "flex" }}><Svg d={I.play} size={20} /></span>Открыть</div>
              </>);
            })()}            <div style={{ height: 1, background: LINE }} />
            <div style={S.menuItem} onClick={() => { setSelMenu(false); const b = sel.size === 1 ? splitExt([...sel][0], (byName([...sel][0]) || {}).type === "directory").base : "archive"; setSheet({ kind: "archive", val: b }); }}><span style={{ color: GOLD, display: "flex" }}><Svg d={I.dl} size={20} /></span>Архивировать (.zip)</div>
          </div>
        </>
      )}
      {sheet && (
        <div style={{ ...S.backdrop, ...(sheet.conflict || sheet.kind === "bmName" ? { zIndex: 1600 } : {}), pointerEvents: sheetArmed ? "auto" : "none" }} onPointerUp={() => setSheet(null)}>
          <div style={{ ...S.sheet, pointerEvents: sheetArmed ? "auto" : "none" }} onPointerDown={(e) => e.stopPropagation()} onPointerUp={(e) => e.stopPropagation()} onClick={(e) => e.stopPropagation()}>
            {sheet.kind === "folder" && <SheetInput title="Новая папка" value={sheet.val} placeholder="Имя папки" onChange={(v) => setSheet({ ...sheet, val: v })} onCancel={() => setSheet(null)} onOk={() => doCreateFolder(sheet.val.trim())} okText="Создать" />}
            {sheet.kind === "txt" && <SheetInput title="Новый TXT-файл" value={sheet.val} placeholder="Имя файла" onChange={(v) => setSheet({ ...sheet, val: v })} onCancel={() => setSheet(null)} onOk={() => doCreateTxt(sheet.val.trim())} okText="Создать" />}
            {sheet.kind === "archive" && <SheetInput title="Архивировать в .zip" value={sheet.val} placeholder="Имя архива" onChange={(v) => setSheet({ ...sheet, val: v })} onCancel={() => setSheet(null)} onOk={() => doArchive(sheet.val.trim())} okText="Создать" />}
            {sheet.kind === "openAs" && (() => {
              const f = sheet.file;
              const items = [
                ["Другое приложение", I.android, null],
                ["Изображение", I.img, "image/*"],
                ["Аудио", I.music, "audio/*"],
                ["Видео", I.video, "video/*"],
                ["Текст", I.rename, "text/plain"],
                ["Архив", I.zip, "arc"],
              ];
              return (
                <>
                  <div style={S.sheetTitle}>Чем открыть?</div>
                  <div style={{ color: SUB, fontSize: 12.5, marginBottom: 12, wordBreak: "break-word" }}>{f.name}</div>
                  <div style={{ display: "flex", flexDirection: "column", gap: 8, marginBottom: 12 }}>
                    {items.map(([label, ic, mm]) => (
                      <div key={label} onClick={() => {
                        setSheet(null);
                        if (mm === "arc") { openArchive(f); return; }
                        if (!mm) { startAppPick(f); return; }
                        showOpenMenu(f, mm, { asCat: true });
                      }} style={{ display: "flex", alignItems: "center", gap: 12, padding: "12px 14px", borderRadius: 14, background: ROW2, border: "1px solid " + LINE }}>
                        <span style={{ color: ACC, display: "flex" }}><Svg d={ic} size={21} /></span>
                        <span style={{ color: TXT, fontSize: 15.5 }}>{label}</span>
                      </div>
                    ))}
                  </div>
                  <button style={S.sheetGhost} onClick={() => setSheet(null)}>Отмена</button>
                </>
              );
            })()}
            {sheet.kind === "iconSrc" && (
              <>
                <div style={S.sheetTitle}>Иконка для «{sheet.name}»</div>
                <div style={{ display: "flex", flexDirection: "column", gap: 8, marginBottom: 12 }}>
                  <div onClick={() => startIconPick(sheet.folder, sheet.name)} style={{ display: "flex", alignItems: "center", gap: 12, padding: "13px 14px", borderRadius: 14, background: ROW2, border: "1px solid " + LINE }}>
                    <span style={{ color: ACC, display: "flex" }}><Svg d={I.img} size={22} /></span>
                    <div style={{ flex: 1 }}><div style={{ color: TXT, fontSize: 16, fontWeight: 600 }}>Из файла</div><div style={{ color: SUB, fontSize: 12.5, marginTop: 2 }}>выбрать картинку в памяти телефона</div></div>
                  </div>
                  <div onClick={() => startIconApps(sheet.folder, sheet.name)} style={{ display: "flex", alignItems: "center", gap: 12, padding: "13px 14px", borderRadius: 14, background: ROW2, border: "1px solid " + LINE }}>
                    <span style={{ color: ACC, display: "flex" }}><Svg d={I.android} size={22} /></span>
                    <div style={{ flex: 1 }}><div style={{ color: TXT, fontSize: 16, fontWeight: 600 }}>Из приложения</div><div style={{ color: SUB, fontSize: 12.5, marginTop: 2 }}>взять значок установленного приложения</div></div>
                  </div>
                </div>
                <div style={{ display: "flex", gap: 10 }}>
                  <button style={S.sheetGhost} onClick={() => setSheet(null)}>Отмена</button>
                  <button style={{ ...S.sheetGhost, color: RED }} onClick={() => { const db = { ...loadMap(ICONKEY) }; delete db[sheet.folder]; saveIconDB(db); setSheet(null); showToast("Иконка сброшена"); }}>Сбросить</button>
                </div>
              </>
            )}
            {sheet.kind === "notifHint" && (
              <>
                <div style={S.sheetTitle}>Показывать проценты загрузки?</div>
                <div style={{ color: SUB, fontSize: 13.5, lineHeight: 1.5, marginBottom: 14 }}>
                  Сколько всего весит качающийся файл, знает только браузер — он пишет это в своём уведомлении.
                  Разрешите приложению читать уведомления если хотите видеть файл, что качается в папке сразу с прогрессом скачивания.
                </div>
                <div style={{ display: "flex", gap: 10 }}>
                  <button style={S.sheetGhost} onClick={() => setSheet(null)}>Не надо</button>
                  <button style={S.sheetOk} onClick={() => { setSheet(null); Apps.notifyAccessOpen().catch(() => showToast("Не удалось открыть настройки")); }}>Открыть настройки</button>
                </div>
              </>
            )}
            {sheet.kind === "bmName" && <SheetInput title="Имя закладки" value={sheet.val} placeholder="Как назвать" onChange={(v) => setSheet({ ...sheet, val: v })} onCancel={() => setSheet(null)}
              onOk={() => { const nm = (sheet.val || "").trim(); const id = sheet.id; setSheet(null); if (!nm) return; saveBookmarks(bookmarks.map((b) => (b.id === id ? { ...b, name: nm } : b))); }} okText="Готово" />}
            {sheet.kind === "rename" && (
              <>
                <div style={S.sheetTitle}>{sheet.conflict ? "Новое имя" : "Переименовать"}</div>
                <input autoFocus onFocus={(ev) => ev.target.select()} key={sheet.editExt ? "ext" : "base"} value={sheet.editExt ? sheet.ext : sheet.base} placeholder={sheet.editExt ? "расширение" : "имя"}
                  onChange={(e) => setSheet({ ...sheet, [sheet.editExt ? "ext" : "base"]: e.target.value })} style={S.sheetField} />
                <div style={{ display: "flex", gap: 10 }}>
                  <button style={S.sheetGhost} onClick={() => setSheet({ ...sheet, editExt: !sheet.editExt })}>{sheet.editExt ? "Имя" : "Расширение"}</button>
                  <button style={S.sheetGhost} onClick={() => setSheet(null)}>Отмена</button>
                  <button style={S.sheetOk} onClick={() => {
                    const nn = sheet.base.trim() + (sheet.ext.trim() ? "." + sheet.ext.trim() : "");
                    if (sheet.conflict) { setSheet(null); resolveConflict("rename", false, nn); return; }
                    doRename(sheet.old, nn);
                  }}>ОК</button>
                </div>
              </>
            )}
            {sheet.kind === "arcRename" && (
              <>
                <div style={S.sheetTitle}>Переименовать в архиве</div>
                <input autoFocus onFocus={(ev) => ev.target.select()} value={sheet.base} onChange={(ev) => setSheet({ ...sheet, base: ev.target.value })}
                  style={{ width: "100%", boxSizing: "border-box", background: ROW2, border: "1px solid " + LINE, borderRadius: 12, color: TXT, fontSize: 15, padding: "12px 14px", marginBottom: 12 }} />
                <div style={{ display: "flex", gap: 8 }}>
                  <button onClick={() => {
                    const sh = sheet; setSheet(null);
                    const nm = sh.base + (sh.ext ? "." + sh.ext : "");
                    if (sh.isDir) {
                      // папка: переносим её содержимое под новое имя
                      const from = sh.full;                                  // «Data/»
                      const parent = from.replace(/[^/]+\/$/, "");
                      const to = parent + nm + "/";
                      if (to !== from) arcMoveEntries([from], [to]);
                      return;
                    }
                    const to = sh.full.replace(/[^/]+$/, "") + nm;
                    if (to !== sh.full) arcModify({ renameFrom: sh.full, renameTo: to });
                  }}
                    style={{ flex: 1, height: 44, borderRadius: 12, border: "none", background: ACC, color: "#fff", fontSize: 15, fontWeight: 600 }}>Переименовать</button>
                  <button onClick={() => setSheet(null)} style={{ flex: 1, height: 44, borderRadius: 12, border: "1px solid " + LINE, background: ROW2, color: TXT, fontSize: 15 }}>Отмена</button>
                </div>
              </>
            )}
            {sheet.kind === "filter" && (
              <>
                <div style={S.sheetTitle}>Фильтр</div>
                {FILTERS.map(([k, lbl]) => (
                  <div key={k} style={{ ...S.sortRow, ...(typeFilter === k ? { color: ACC } : {}) }} onClick={() => { setTypeFilter(k); setSheet(null); }}>
                    {lbl}{typeFilter === k && <span style={{ marginLeft: "auto" }}>✓</span>}
                  </div>
                ))}
              </>
            )}
            {sheet.kind === "view" && (
              <>
                <div style={S.sheetTitle}>Вид</div>
                {[["list", "Подробная сетка"], ["gallery", "Галерея"]].map(([k, lbl]) => (
                  <div key={k} style={{ ...S.sortRow, ...(viewMode === k ? { color: ACC } : {}) }} onClick={() => { setViewMode(k); ls.set(VIEWKEY, k); setSheet(null); }}>
                    {lbl}{viewMode === k && <span style={{ marginLeft: "auto" }}>✓</span>}
                  </div>
                ))}
              </>
            )}
            {sheet.kind === "sort" && (
              <>
                <div style={S.sheetTitle}>Сортировка</div>
                {SORTS.map(([k, lbl]) => (
                  <div key={k} style={{ ...S.sortRow, ...(effSortFor(path) === k ? { color: ACC } : {}) }} onClick={() => { setSheet(null); setSortAsk({ mode: k }); }}>
                    {lbl}{effSortFor(path) === k && <span style={{ marginLeft: "auto" }}>✓</span>}
                  </div>
                ))}
              </>
            )}
            {sheet.kind === "remote" && (
              <>
                <div style={{ ...S.sheetTitle, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{sheet.file.name}</div>
                {isImg(sheet.file.name) && sheet.src.kind === "gdrive" && (
                  <div style={S.sortRow} onClick={() => { const f = sheet.file, sr = sheet.src; setSheet(null); openRemoteGallery(f, sr); }}>Открыть сразу, без загрузки</div>
                )}
                {(isVid(sheet.file.name) || isAudio(sheet.file.name)) && (
                  <div style={S.sortRow} onClick={() => remoteStream(sheet.file, sheet.src)}>Смотреть без загрузки</div>
                )}
                <div style={S.sortRow} onClick={() => remoteTempOpen(sheet.file, sheet.src)}>Скачать и открыть</div>
                <div style={S.sortRow} onClick={() => saveTo(sheet.file, sheet.src)}>Сохранить в…</div>
                <div style={S.sortRow} onClick={() => remoteDownload(sheet.file, sheet.src)}>Сохранить в Download</div>
                {sheet.src.kind === "gdrive" && (
                  <div style={{ ...S.sortRow, color: SUB, fontSize: 14 }} onClick={async () => {
                    const f = sheet.file; setSheet(null);
                    try {
                      const r = await Apps.streamGdrive({ id: f.id, mime: mimeOf(f.name) || "*/*", size: String(f.size || 0) });
                      await Apps.copyText({ text: r.url });
                      showToast("Прямая ссылка скопирована");
                    } catch (er) { showToast("Ошибка: " + (er?.message || "")); }
                  }}>Скопировать прямую ссылку</div>
                )}
              </>
            )}
          </div>
        </div>
      )}
      {/* ПРОСМОТРЩИК ИЗОБРАЖЕНИЙ */}
      {player && (
        <div style={{ position: "fixed", left: 8, right: 8, bottom: "calc(78px + env(safe-area-inset-bottom))", zIndex: 70, background: BAR, borderRadius: 20, padding: "10px 12px 10px", boxShadow: "var(--barsh)" }}>
          <div style={{ display: "flex", alignItems: "center", gap: 6, marginBottom: 6 }}>
            <span style={{ flex: 1, minWidth: 0, color: TXT, fontSize: 13.5, fontWeight: 600, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{player.name}</span>
            <div style={{ position: "relative", flexShrink: 0 }}>
              <button onClick={() => setPlayerMenu((v) => !v)} aria-label="Меню" style={{ background: ROW2, border: "1px solid " + LINE, borderRadius: 11, color: ACC, display: "flex", alignItems: "center", justifyContent: "center", width: 32, height: 32 }}><Svg d={I.dots} size={20} /></button>
              {playerMenu && (
                <div style={{ position: "absolute", right: 0, bottom: "calc(100% + 6px)", background: BAR, borderRadius: 14, overflow: "hidden", minWidth: 210, boxShadow: "var(--barsh)", zIndex: 5 }}>
                  <div style={S.menuItem} onClick={() => playerSetAs("ringtone")}><span style={{ color: ACC, display: "flex" }}><Svg d={I.bell} size={20} /></span>Установить на звонок</div>
                </div>
              )}
            </div>
            <button onClick={playerClose} aria-label="Закрыть" style={{ background: ROW2, border: "1px solid " + LINE, borderRadius: 14, color: RED, display: "flex", alignItems: "center", justifyContent: "center", width: 46, height: 42, flexShrink: 0 }}><Svg d={I.x} size={26} /></button>
          </div>
          <input type="range" min={0} max={player.dur || 0} value={Math.min(player.pos || 0, player.dur || 0)} onChange={(e) => playerSeek(Number(e.target.value))} style={{ width: "100%", accentColor: ACC, height: 7, borderRadius: 4, margin: 0 }} />
          <div style={{ display: "flex", justifyContent: "space-between", fontSize: 11, color: SUB, marginTop: 3 }}><span>{fmtTime(player.pos)}</span><span>{fmtTime(player.dur)}</span></div>
          <div style={{ display: "flex", alignItems: "center", justifyContent: "center", gap: 30, marginTop: 4 }}>
            <button onClick={playerPrev} aria-label="Назад" style={{ background: ROW2, border: "1px solid " + LINE, borderRadius: 16, color: TXT, display: "flex", alignItems: "center", justifyContent: "center", width: 50, height: 44 }}><Svg d={I.prev} size={26} /></button>
            <button onClick={playerToggle} aria-label="Плей/Пауза" style={{ background: ACC, border: "none", color: "#fff", display: "flex", alignItems: "center", justifyContent: "center", width: 56, height: 56, borderRadius: 28 }}><Svg d={player.playing ? I.pause : I.play} size={27} /></button>
            <button onClick={playerNext} aria-label="Вперёд" style={{ background: ROW2, border: "1px solid " + LINE, borderRadius: 16, color: TXT, display: "flex", alignItems: "center", justifyContent: "center", width: 50, height: 44 }}><Svg d={I.next} size={26} /></button>
          </div>
        </div>
      )}
      {drawer && (
        <div style={{ position: "fixed", inset: 0, zIndex: 1500 }}>
          <div onClick={() => { setDrawer(false); setPlusMenu(false); setDSwipeId(null); }} style={{ position: "absolute", inset: 0, background: "rgba(0,0,0,.5)" }} />
          <div style={{ position: "absolute", left: 0, top: 0, bottom: 0, width: "82%", maxWidth: 330, background: BAR, borderRight: "1px solid " + LINE, boxShadow: "6px 0 26px rgba(0,0,0,.5)", display: "flex", flexDirection: "column", animation: "drawerIn .24s cubic-bezier(.2,.8,.3,1)" }}>
            <div style={{ flex: 1, minHeight: "env(safe-area-inset-top)" }} />
            <div style={{ overflow: "auto", touchAction: dDragId ? "none" : "auto" }}>
              {(() => {
                const avail = [
                  ...webdavs.map((a) => ({ id: "wd:" + a.url, kind: "wd", a })),
                  ...(gdIn ? [{ id: "gd", kind: "gd" }] : []),
                  ...bookmarks.map((b) => ({ id: b.id, kind: "st", n: b.name, sub: b.path.replace(/^\/storage\/emulated\/0\/?/, "") || b.path, d: I.star, c: "#E3B14F", p: pathFromAbs(b.path), bm: b })),
                  ...(shz && shz.state === "ok" ? [{ id: "sysroot", kind: "st", n: "Система", sub: "корень телефона", d: I.chipIc, c: "#9AA7B4", p: "@abs:/", canHide: true }] : []),
                  { id: "data", kind: "st", n: "Data", sub: "data", d: I.android, c: "#8FB84A", p: "Android/data", canHide: true },
                  { id: "obb", kind: "st", n: "OBB", sub: "obb", d: I.android, c: "#E3B14F", p: "Android/obb", canHide: true },
                  ...volumes.map((v, i) => ({
                    id: v.primary ? "storage" : ("vol:" + v.path),
                    kind: "st",
                    n: v.primary ? "Storage" : v.name,
                    sub: v.path,
                    d: I.folder,
                    c: v.primary ? "#4FC3D9" : (v.removable ? "#E58A4F" : "#7F9FD9"),
                    p: v.primary ? "" : "@abs:" + v.path,
                    removable: v.removable,
                  })),
                ];
                const shown = avail.filter((it) => !drawerHidden.includes(it.id));
                const byId = {}; shown.forEach((it) => (byId[it.id] = it));
                const ordered = drawerOrder.filter((id) => byId[id]).map((id) => byId[id]);
                const rest = shown.filter((it) => !drawerOrder.includes(it.id));
                const rendered = [...rest, ...ordered];
                dRenderedRef.current = rendered;
                return rendered.map((it) => (
                  <div key={it.id} ref={(el) => (dItemRefs.current[it.id] = el)}
                    onPointerDown={(ev) => dDown(ev, it.id)} onPointerMove={dMove} onPointerUp={() => dUp(it)} onPointerCancel={() => { clearTimeout(dLp.current); dLpFired.current = false; dDragIdRef.current = null; clearDDrag(); setDDragId(null); }}
                    style={{ position: "relative", overflow: "hidden", display: "flex", alignItems: "center", gap: 12, padding: "12px 14px", borderTop: "1px solid " + LINE, background: dSwipeId === it.id ? ROW2 : dDragId === it.id ? ROW2 : "transparent", opacity: dDragId && dDragId !== it.id ? 0.6 : 1, boxShadow: dDragId === it.id ? "0 6px 18px rgba(0,0,0,.5)" : "none", touchAction: "none", transition: dDragId === it.id ? "none" : (dDragId ? "transform .18s cubic-bezier(.2,.8,.2,1)" : "none"), ...(dDragId === it.id ? { zIndex: 3 } : {}) }}>
                    {(it.bm || it.canHide) && dSwipeId === it.id && (
                      <div style={{ position: "absolute", left: 8, top: 0, bottom: 0, display: "flex", alignItems: "center", gap: 7, zIndex: 2 }}>
                        <button onPointerDown={(ev) => ev.stopPropagation()} onPointerUp={(ev) => ev.stopPropagation()}
                          onClick={(ev) => { ev.stopPropagation(); setDSwipeId(null); if (it.bm) saveBookmarks(bookmarks.filter((b) => b.id !== it.id)); else hideDrawerItem(it.id); }}
                          aria-label="Убрать" style={{ width: 32, height: 32, borderRadius: 16, background: "rgba(224,82,82,.16)", border: "1px solid rgba(224,82,82,.5)", color: RED, display: "flex", alignItems: "center", justifyContent: "center" }}><Svg d={I.x} size={16} /></button>
                        {it.bm && (
                          <button onPointerDown={(ev) => ev.stopPropagation()} onPointerUp={(ev) => ev.stopPropagation()}
                            onClick={(ev) => { ev.stopPropagation(); setDSwipeId(null); setDrawer(false); setSheet({ kind: "bmName", id: it.id, val: it.n }); }}
                            aria-label="Переименовать" style={{ width: 32, height: 32, borderRadius: 16, background: "var(--accbg)", border: "1px solid " + ACC, color: ACC, display: "flex", alignItems: "center", justifyContent: "center" }}><Svg d={I.rename} size={15} /></button>
                        )}
                      </div>
                    )}
                    <div style={{ display: "flex", alignItems: "center", gap: 12, flex: 1, minWidth: 0, transform: dSwipeId === it.id ? "translateX(" + (it.bm ? 80 : 42) + "px)" : "none", transition: "transform .18s cubic-bezier(.2,.8,.2,1)" }}>
                    {it.kind === "wd" && <>
                      <span style={{ width: 40, height: 40, borderRadius: 20, background: "#5AA9E622", color: "#5AA9E6", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}><Svg d={I.dl} size={22} /></span>
                      <div style={{ minWidth: 0, flex: 1 }}><div style={{ color: TXT, fontSize: 16, fontWeight: 600, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{it.a.name}</div><div style={{ color: SUB, fontSize: 12 }}>WebDAV</div></div>
                      <button onPointerDown={(ev) => ev.stopPropagation()} onClick={(ev) => { ev.stopPropagation(); delWebdav(webdavs.indexOf(it.a)); }} aria-label="Удалить" style={{ background: "none", border: "none", color: RED, display: "flex", padding: 6, flexShrink: 0 }}><Svg d={I.x} size={18} /></button>
                    </>}
                    {it.kind === "gd" && <>
                      <span style={{ width: 40, height: 40, borderRadius: 20, background: "var(--accbg)", color: ACC, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}><Svg d={I.gdrive} size={24} /></span>
                      <div style={{ minWidth: 0, flex: 1 }}><div style={{ color: TXT, fontSize: 16, fontWeight: 600 }}>Google Drive</div><div style={{ color: SUB, fontSize: 12 }}>{gdQuota && gdQuota.total > 0 ? "Занято " + fmtSizeShort(gdQuota.used) + " из " + fmtSizeShort(gdQuota.total) : "Подключён"}</div></div>
                      <button onPointerDown={(ev) => ev.stopPropagation()} onClick={(ev) => { ev.stopPropagation(); Apps.gdriveLogout().catch(() => {}); setGdIn(false); }} aria-label="Выйти" style={{ background: "none", border: "none", color: RED, display: "flex", padding: 6, flexShrink: 0 }}><Svg d={I.x} size={18} /></button>
                    </>}
                    {it.kind === "st" && <>
                      <span style={{ width: 40, height: 40, borderRadius: 20, background: it.c + "22", color: it.c, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}><Svg d={it.d} size={22} /></span>
                      <div style={{ minWidth: 0, flex: 1 }}><div style={{ color: TXT, fontSize: 16, fontWeight: 600, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{it.n}</div><div style={{ color: SUB, fontSize: 12, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{it.sub}</div></div>
                    </>}
                    </div>
                  </div>
                ));
              })()}
            </div>
            <div style={{ position: "relative", display: "flex", alignItems: "center", padding: "10px 12px calc(12px + env(safe-area-inset-bottom))", borderTop: "1px solid " + LINE }}>
              <span style={{ flex: 1, fontSize: 18, fontWeight: 700, color: TXT, paddingLeft: 6 }}>YevFiles</span>
              {drawerHidden.length > 0 && (
                <button onClick={() => { showAllDrawerItems(); showToast("Скрытые пункты возвращены"); }} aria-label="Вернуть скрытые пункты"
                  style={{ width: 34, height: 34, borderRadius: 17, background: ROW2, border: "1px solid " + LINE, color: SUB, display: "flex", alignItems: "center", justifyContent: "center", marginRight: 8 }}><Svg d={I.refresh} size={17} /></button>
              )}
              <button onClick={() => setPlusMenu((v) => !v)} aria-label="Добавить" style={{ width: 34, height: 34, borderRadius: 17, background: ROW2, border: "1px solid " + LINE, color: ACC, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}><Svg d={I.plus} size={22} /></button>
              {plusMenu && (
                <div style={{ position: "absolute", right: 10, bottom: "calc(100% + 4px)", background: BAR, borderRadius: 12, overflow: "hidden", minWidth: 190, boxShadow: "var(--barsh)" }}>
                  {!gdIn && <div style={S.menuItem} onClick={() => { setPlusMenu(false); googleLogin(); }}><span style={{ background: "var(--accbg)", color: ACC, borderRadius: 8, display: "flex", padding: 4 }}><Svg d={I.gdrive} size={18} /></span>Google Drive</div>}
                  <div style={S.menuItem} onClick={() => { setPlusMenu(false); setDrawer(false); setWdForm({ name: "", url: "", user: "", pass: "" }); }}><span style={{ color: "#5AA9E6", display: "flex" }}><Svg d={I.dl} size={20} /></span>WebDAV</div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
      {wdForm && (
        <div style={{ position: "fixed", inset: 0, zIndex: 1600, background: "rgba(0,0,0,.55)", display: "flex", alignItems: "center", justifyContent: "center", padding: 20 }} onClick={() => setWdForm(null)}>
          <div onClick={(e) => e.stopPropagation()} style={{ width: "100%", maxWidth: 360, background: BAR, borderRadius: 18, padding: 18, boxShadow: "0 12px 40px rgba(0,0,0,.5)" }}>
            <div style={{ fontSize: 16, fontWeight: 700, color: TXT, marginBottom: 14 }}>WebDAV</div>
            {[["name", "Название"], ["url", "https://…/dav/"], ["user", "Логин"], ["pass", "Пароль"]].map(([k, ph]) => (
              <input key={k} value={wdForm[k]} placeholder={ph} type={k === "pass" ? "password" : "text"} autoCapitalize="none" autoCorrect="off" onChange={(e) => setWdForm((f) => ({ ...f, [k]: e.target.value }))}
                style={{ width: "100%", boxSizing: "border-box", marginBottom: 10, padding: "11px 12px", borderRadius: 10, border: "1px solid " + LINE, background: ROW2, color: TXT, fontSize: 15, outline: "none" }} />
            ))}
            <div style={{ display: "flex", gap: 10, marginTop: 4 }}>
              <button onClick={() => setWdForm(null)} style={{ ...S.sheetGhost, flex: 1, borderColor: LINE }}>Отмена</button>
              <button onClick={saveWebdav} style={{ flex: 1, padding: 11, borderRadius: 10, border: "none", background: ACC, color: "#fff", fontSize: 15, fontWeight: 600 }}>Сохранить</button>
            </div>
          </div>
        </div>
      )}
      {gd && (
        <div style={{ position: "fixed", inset: 0, zIndex: 1450, background: BG, display: "flex", flexDirection: "column" }}>
          <div style={{ display: "flex", alignItems: "center", gap: 8, padding: "calc(10px + env(safe-area-inset-top)) 12px 10px", background: BAR }}>
            <button onClick={gdBack} style={{ background: "none", border: "none", color: ACC, display: "flex", padding: 4 }}><Svg d={I.back} size={22} /></button>
            <span style={{ flex: 1, minWidth: 0, color: TXT, fontWeight: 600, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{gd.stack[gd.stack.length - 1].name}</span>
            <button onClick={() => setGd(null)} style={{ background: "none", border: "none", color: RED, display: "flex", padding: 4 }}><Svg d={I.x} size={22} /></button>
          </div>
          <div style={{ flex: 1, overflow: "auto" }}>
            {gd.entries.length === 0 && <div style={S.note}>Пусто</div>}
            {gd.entries.map((e, i) => (
              <div key={i} onClick={() => gdEnter(e)} style={{ ...S.row, ...(e.type === "directory" ? S.rowDir : {}) }}>
                <span style={{ ...S.iconWrap, color: e.type === "directory" ? ACC : GOLD }}><Svg d={e.type === "directory" ? I.folder : fileIcon(e.name).d} size={24} /></span>
                <span style={S.rowMid}><span style={{ ...S.name, fontWeight: e.type === "directory" ? 600 : 400 }}>{e.name}</span></span>
                <span style={S.rowSize}>{e.type === "directory" ? "" : fmtSizeShort(e.size)}</span>
              </div>
            ))}
          </div>
          <div style={{ padding: "8px 12px calc(8px + env(safe-area-inset-bottom))", background: BAR, fontSize: 12, color: SUB, textAlign: "center" }}>Тап по файлу — скачать в Download</div>
        </div>
      )}
      {wd && (
        <div style={{ position: "fixed", inset: 0, zIndex: 1450, background: BG, display: "flex", flexDirection: "column" }}>
          <div style={{ display: "flex", alignItems: "center", gap: 8, padding: "calc(10px + env(safe-area-inset-top)) 12px 10px", background: BAR }}>
            <button onClick={wdBack} style={{ background: "none", border: "none", color: ACC, display: "flex", padding: 4 }}><Svg d={I.back} size={22} /></button>
            <span style={{ flex: 1, minWidth: 0, color: TXT, fontWeight: 600, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{wd.stack[wd.stack.length - 1].name}</span>
            <button onClick={() => setWd(null)} style={{ background: "none", border: "none", color: RED, display: "flex", padding: 4 }}><Svg d={I.x} size={22} /></button>
          </div>
          <div style={{ flex: 1, overflow: "auto" }}>
            {wd.entries.length === 0 && <div style={S.note}>Пусто</div>}
            {wd.entries.map((e, i) => (
              <div key={i} onClick={() => wdEnter(e)} style={{ ...S.row, ...(e.type === "directory" ? S.rowDir : {}) }}>
                <span style={{ ...S.iconWrap, color: e.type === "directory" ? ACC : GOLD }}><Svg d={e.type === "directory" ? I.folder : fileIcon(e.name).d} size={24} /></span>
                <span style={S.rowMid}><span style={{ ...S.name, fontWeight: e.type === "directory" ? 600 : 400 }}>{e.name}</span></span>
                <span style={S.rowSize}>{e.type === "directory" ? "" : fmtSizeShort(e.size)}</span>
              </div>
            ))}
          </div>
          <div style={{ padding: "8px 12px calc(8px + env(safe-area-inset-bottom))", background: BAR, fontSize: 12, color: SUB, textAlign: "center" }}>Тап по файлу — скачать в Download</div>
        </div>
      )}
      {pdf && (
        <div style={{ position: "fixed", inset: 0, zIndex: 1400, background: "#111", display: "flex", flexDirection: "column" }}>
          <div onTouchStart={pdfTouchStart} onTouchMove={pdfTouchMove} style={{ flex: 1, overflow: "auto", background: "#2b2b2b", WebkitOverflowScrolling: "touch", touchAction: "pan-x pan-y", paddingTop: "env(safe-area-inset-top)" }}>
            <div style={{ width: (pdfZoom * 100) + "%", margin: "0 auto", padding: "10px 0 24px", display: "flex", flexDirection: "column", alignItems: "center", gap: 10 }}>
              {pdfArr.map((src, i) => {
                const hs = pdfSearch && pdfSearch.hits ? pdfSearch.hits.filter((h) => h.page === i + 1) : [];
                const curHit = pdfSearch && pdfSearch.cur >= 0 ? pdfSearch.hits[pdfSearch.cur] : null;
                return (
                  <div key={i} ref={(el) => (pdfPageRefs.current[i] = el)} style={{ position: "relative", width: "100%" }}>
                    <img src={src} alt={"p" + i} style={{ width: "100%", display: "block", background: "#fff" }} />
                    {hs.map((h, k) => h.rects.map((r, j) => (
                      <div key={k + "_" + j} style={{ position: "absolute", left: (r.l * 100) + "%", top: (r.t * 100) + "%", width: Math.max(0.3, r.w * 100) + "%", height: Math.max(0.5, r.h * 100) + "%", background: h === curHit ? "rgba(255,140,0,.55)" : "rgba(255,230,0,.4)", borderRadius: 2, pointerEvents: "none", boxShadow: h === curHit ? "0 0 0 2px rgba(255,140,0,.9)" : "none" }} />
                    )))}
                  </div>
                );
              })}
              {(pdfN === 0 || pdfArr.length < pdfN) && <div style={{ color: "#bbb", fontSize: 13, padding: 20 }}>{pdfN === 0 ? "Открываю PDF…" : "Загрузка " + pdfArr.length + "/" + pdfN}</div>}
            </div>
          </div>
          {pdfSearch && pdfSearch.open && (
            <div style={{ display: "flex", flexDirection: "column", gap: 6, padding: "8px 10px 4px", background: "rgba(0,0,0,.65)" }}>
              <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
                <input autoFocus value={pdfSearch.q || ""} placeholder="Найти в тексте…" onChange={(e) => setPdfSearch((ps) => ({ ...ps, q: e.target.value }))} onKeyDown={(e) => { if (e.key === "Enter") { e.preventDefault(); pdfRunSearch(pdfSearch.q); } }} style={{ ...S.searchInput, flex: 1, minWidth: 0 }} />
                <button onClick={() => pdfRunSearch(pdfSearch.q)} style={{ ...S.chip, background: ACC, color: "#fff", borderColor: ACC }}>{pdfSearch.busy ? "…" : "Найти"}</button>
                <button onClick={() => pdfStep(-1)} disabled={!pdfSearch.hits || !pdfSearch.hits.length} style={{ background: "none", border: "none", color: "#fff", display: "flex", padding: 6 }}><span style={{ display: "flex", transform: "rotate(90deg)" }}><Svg d={I.chev} size={20} /></span></button>
                <button onClick={() => pdfStep(1)} disabled={!pdfSearch.hits || !pdfSearch.hits.length} style={{ background: "none", border: "none", color: "#fff", display: "flex", padding: 6 }}><span style={{ display: "flex", transform: "rotate(-90deg)" }}><Svg d={I.chev} size={20} /></span></button>
              </div>
              {pdfSearch.hits && pdfSearch.hits.length > 0 && pdfSearch.cur >= 0 && (
                <div style={{ color: "#ddd", fontSize: 12, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
                  {pdfSearch.cur + 1}/{pdfSearch.hits.length} · стр. {pdfSearch.hits[pdfSearch.cur].page}: {pdfSearch.hits[pdfSearch.cur].snippet}
                </div>
              )}
            </div>
          )}
          <div style={{ display: "flex", alignItems: "center", gap: 8, padding: "8px 8px calc(8px + env(safe-area-inset-bottom)) 14px", background: "rgba(0,0,0,.65)" }}>
            <span style={{ flex: 1, minWidth: 0, color: "#fff", fontSize: 14, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{pdf.name}</span>
            <span style={{ color: "rgba(255,255,255,.7)", fontSize: 13, flexShrink: 0 }}>{pdfN ? pdfArr.length + "/" + pdfN : "…"}</span>
            <button onClick={() => setPdfSearch((ps) => (ps && ps.open ? { ...ps, open: false } : { ...(ps || { q: "", hits: [], cur: -1 }), open: true }))} aria-label="Поиск по тексту" style={{ background: "none", border: "none", color: pdfSearch && pdfSearch.open ? ACC : "#fff", display: "flex", padding: 6, flexShrink: 0 }}><Svg d={I.search} size={22} /></button>
            <button onClick={closePdf} aria-label="Закрыть" style={{ background: "none", border: "none", color: "#fff", display: "flex", padding: 6, flexShrink: 0 }}><Svg d={I.x} size={24} /></button>
          </div>
        </div>
      )}
      {viewer && viewerCur && (
        <div ref={vbgRef} style={{ position: "fixed", inset: 0, zIndex: 1300, background: "#000", touchAction: "none", overflow: "hidden" }}>
          <div style={{ position: "absolute", inset: 0, display: "flex", alignItems: "center", justifyContent: "center" }}
            {...(viewerCur && isVid(viewerCur.name) ? {} : { onTouchStart: vStart, onTouchMove: vMove, onTouchEnd: vEnd, onTouchCancel: vEnd })}>
            <div ref={stageRef} style={{ position: "relative", width: "100%", height: "100%", willChange: "transform" }}>
              {vSlots.map(({ d, m }) => {
                const cur = d === 0;
                const nm = m.name || "";
                const special = !m.remote && (isRaw(nm) || isHeic(nm) || isTiff(nm) || isJxl(nm) || isTgs(nm));
                const dec = cur && vDec && vDec.uri === m.uri ? vDec : null;
                const th = thumbs[tkeyOf(m)];
                return (
                  <div key={m.uri || nm} style={{ position: "absolute", inset: 0, transform: "translate3d(calc(" + (d * 100) + "% + " + (d * V_GAP) + "px),0,0)", display: "flex", alignItems: "center", justifyContent: "center" }}>
                    {/* под полным кадром лежит превью; уходит, как только сам снимок показан */}
                    {m.preview && !vReady[m.uri || m.gdId] && <img src={m.preview} alt="" aria-hidden="true" draggable={false}
                      style={{ position: "absolute", inset: 0, width: "100%", height: "100%", objectFit: "contain", pointerEvents: "none" }} />}
                    {special && cur && (!dec || dec.loading) && <div style={{ position: "absolute", color: "#bbb", fontSize: 13 }}>Открываю…</div>}
                    {dec && dec.err && <div style={{ position: "absolute", color: "#f88", fontSize: 13, padding: 20, textAlign: "center" }}>{dec.err}</div>}
                    {isVid(nm)
                      ? (cur ? <video key={m.uri} src={cfs(m.uri)} controls autoPlay playsInline style={{ maxWidth: "100%", maxHeight: "100%" }} /> : null)
                      : dec && dec.kind === "lottie" && dec.data
                      ? <LottieView data={dec.data} style={{ width: "100%", height: "100%" }} />
                      : (!special || (dec && dec.src)) && m.uri
                        ? (<>
                            {/* нижний слой — то, что уже готово; он никогда не меняется на лету */}
                            <img key={"b" + (m.uri || nm)} src={dec && dec.src ? dec.src : (vFast[m.uri] ? cfs(vFast[m.uri]) : cfs(m.uri))} alt={nm} draggable={false} decoding="async"
                              onLoad={() => setVReady((r) => (r[m.uri || m.gdId] ? r : { ...r, [m.uri || m.gdId]: true }))}
                              style={{ position: "absolute", inset: 0, width: "100%", height: "100%", objectFit: "contain", pointerEvents: "none", userSelect: "none" }} />
                            {/* оригинал появляется поверх только при приближении и только когда загрузился */}
                            {cur && vZoomed && vFast[m.uri] && (
                              <img key={"f" + (m.uri || nm)} src={cfs(m.uri)} alt="" draggable={false} decoding="async"
                                onLoad={(ev) => { ev.currentTarget.style.opacity = "1"; }}
                                style={{ position: "absolute", inset: 0, width: "100%", height: "100%", objectFit: "contain", pointerEvents: "none", opacity: 0, transition: "opacity .12s" }} />
                            )}
                          </>)
                        : null}
                  </div>
                );
              })}
            </div>
          </div>

          {/* заголовок сверху: имя + счётчик + крестик справа */}
          <div style={{ position: "absolute", top: 0, left: 0, right: 0, paddingTop: "env(safe-area-inset-top)", background: "linear-gradient(to bottom, rgba(0,0,0,.75), transparent)", transform: viewerBar ? "translateY(0)" : "translateY(-110%)", transition: "transform .2s ease", pointerEvents: viewerBar ? "auto" : "none" }}>
            <div style={{ display: "flex", alignItems: "center", gap: 10, padding: "12px 14px 16px" }}>
              <span style={{ flex: 1, minWidth: 0, color: "#fff", fontSize: 14, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{viewerCur.name}</span>
              <span style={{ color: "rgba(255,255,255,.7)", fontSize: 13, flexShrink: 0 }}>{viewer.idx + 1}/{viewer.items.length}</span>
            </div>
          </div>

          {/* тулбар снизу: справа-налево — удалить, свойства, поделиться, редактировать */}
          <div style={{ position: "absolute", bottom: 0, left: 0, right: 0, paddingBottom: "env(safe-area-inset-bottom)", background: "linear-gradient(to top, rgba(0,0,0,.8), transparent)", transform: viewerBar ? "translateY(0)" : "translateY(110%)", transition: "transform .2s ease", pointerEvents: viewerBar ? "auto" : "none" }}>
            <div style={{ display: "flex", justifyContent: "space-around", alignItems: "center", padding: "16px 10px 14px" }}>
              {[
                [I.img, "Обои", () => Apps.setWallpaper({ uri: viewerCur.uri }).catch(() => showToast("Не удалось")), false],
                [I.info, "Свойства", () => setProps(viewerCur), false],
                [I.share, "Поделиться", () => Apps.share({ uri: viewerCur.uri, mime: mimeOf(viewerCur.name) }).catch(() => {}), false],
                [I.rename, "Изменить", () => showOpenMenu(viewerCur, mimeOf(viewerCur.name), { edit: true }), false],
                [I.trash, "Удалить", () => setViewerDel(true), true],
              ].map(([ic, lbl, fn, red], i) => (
                <span key={i} onClick={fn} style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 4, color: red ? "#FF6B6B" : "#fff", minWidth: 50 }}>
                  <Svg d={ic} size={22} /><span style={{ fontSize: 10.5 }}>{lbl}</span>
                </span>
              ))}
            </div>
          </div>

          {/* подтверждение удаления в просмотрщике */}
          {viewerDel && (
            <div style={{ position: "fixed", inset: 0, zIndex: 1360, background: "rgba(0,0,0,.6)", display: "flex", alignItems: "center", justifyContent: "center" }} onClick={() => setViewerDel(false)}>
              <div onClick={(e) => e.stopPropagation()} style={{ background: BAR, borderRadius: 16, padding: 18, width: "78%", maxWidth: 320, boxShadow: "0 18px 48px rgba(0,0,0,.6)" }}>
                <div style={{ color: TXT, fontSize: 15, marginBottom: 4 }}>Удалить файл?</div>
                <div style={{ color: SUB, fontSize: 13, marginBottom: 16, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{viewerCur.name}</div>
                <div style={{ display: "flex", gap: 10, justifyContent: "flex-end" }}>
                  <button onClick={() => setViewerDel(false)} style={{ background: ROW2, border: "1px solid " + LINE, borderRadius: 10, color: SUB, fontSize: 14, padding: "9px 20px" }}>Нет</button>
                  <button onClick={viewerDelete} style={{ background: RED, border: "none", borderRadius: 10, color: "#fff", fontSize: 14, fontWeight: 700, padding: "9px 20px" }}>Да</button>
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {props && (
        <div style={S.backdrop} onClick={() => setProps(null)}>
          <div style={S.sheet} onClick={(e) => e.stopPropagation()}>
            {props.multi ? (
              <>
                <div style={S.sheetTitle}>Выбрано: {props.multi.length}</div>
                <Prop k="Папок" v={String(props.multi.filter((x) => x.type === "directory").length)} />
                <Prop k="Файлов" v={String(props.multi.filter((x) => x.type !== "directory").length)} />
                <Prop k="Общий вес" v={propSize == null ? "подсчёт…" : fmtSize(propSize)} />
                <div style={{ maxHeight: 180, overflowY: "auto", marginTop: 10, borderTop: "1px solid " + LINE, paddingTop: 8 }}>
                  {props.multi.map((x) => (
                    <div key={x.uri || x.name} style={{ display: "flex", justifyContent: "space-between", gap: 10, padding: "4px 0", fontSize: 12, color: SUB }}>
                      <span style={{ overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{x.name}</span>
                      <span style={{ flexShrink: 0 }}>{x.type === "directory" ? "папка" : fmtSize(x.size)}</span>
                    </div>
                  ))}
                </div>
                <button style={{ ...S.sheetGhost, width: "100%", marginTop: 14 }} onClick={() => setProps(null)}>Закрыть</button>
              </>
            ) : (
              <>
            <div style={S.sheetTitle}>{propApkIcon && <img src={propApkIcon} alt="" style={{ width: 28, height: 28, borderRadius: 7, verticalAlign: "middle", marginRight: 10 }} />}{props.name}</div>
            <Prop k="Путь (нажмите, чтобы скопировать)" v={path ? "/" + keyOf(props.name) : "/" + props.name} onClick={() => copyPath(props.uri)} link />
            {props.type === "directory" && <Prop k="Содержимое" v={propCount ? propCount.d + " папок, " + propCount.f + " файлов" : "…"} />}
            <Prop k="Вес" v={props.type === "directory" ? (propSize == null ? "подсчёт…" : fmtSize(propSize)) : fmtSize(props.size)} />
            <Prop k="Изменено" v={ago(props.mtime)} />
            <Prop k="Тип" v={props.type === "directory" ? "Папка" : (props.name.includes(".") ? props.name.split(".").pop().toUpperCase() : "Файл")} />
            {propMeta && propMeta.w > 0 && <Prop k="Разрешение" v={propMeta.w + " × " + propMeta.h} />}
            {propMeta && propMeta.duration && <Prop k="Длительность" v={propMeta.duration} />}
            {propMeta && propMeta.bitrate && <Prop k="Битрейт" v={propMeta.bitrate} />}
            {propMeta && propMeta.codec && <Prop k="Кодек" v={propMeta.codec} />}
            {propMeta && propMeta.fps && <Prop k="Кадров/с" v={propMeta.fps} />}
            {propMeta && propMeta.title && <Prop k="Название" v={propMeta.title} />}
            {propMeta && propMeta.artist && <Prop k="Исполнитель" v={propMeta.artist} />}
            {propMeta && propMeta.album && <Prop k="Альбом" v={propMeta.album} />}
            {propMeta && propMeta.year && <Prop k="Год" v={propMeta.year} />}
            {propMeta && propMeta.camera && <Prop k="Камера" v={propMeta.camera} />}
            {propMeta && propMeta.lens && <Prop k="Объектив" v={propMeta.lens} />}
            {propMeta && (propMeta.aperture || propMeta.exposure || propMeta.iso) &&
              <Prop k="Съёмка" v={[propMeta.aperture, propMeta.exposure, propMeta.iso, propMeta.focal].filter(Boolean).join("  ·  ")} />}
            {propMeta && propMeta.taken && <Prop k="Снято" v={propMeta.taken} />}
            {propMeta && propMeta.gps && <Prop k="Координаты" v={propMeta.gps} />}
            <Prop k="Скрытый" v={isHidden(props) ? "Да" : "Нет"} />
            <button style={{ ...S.sheetGhost, width: "100%", marginTop: 14 }} onClick={() => setProps(null)}>Закрыть</button>
              </>
            )}
          </div>
        </div>
      )}

      {/* ЗАПРОС ПАРОЛЯ АРХИВА */}
      {pwPrompt && (
        <div style={{ position: "fixed", inset: 0, zIndex: 1460, background: "rgba(0,0,0,.55)", display: "flex", alignItems: "flex-end", justifyContent: "center" }} onClick={() => resolvePassword(null)}>
          <div onClick={(e) => e.stopPropagation()} style={{ width: "100%", maxWidth: 460, background: BAR, borderTopLeftRadius: 18, borderTopRightRadius: 18, padding: "16px 16px calc(env(safe-area-inset-bottom) + 16px)", boxShadow: "0 -8px 32px rgba(0,0,0,.5)" }}>
            <div style={{ color: TXT, fontSize: 15, fontWeight: 600, marginBottom: 4 }}>Архив защищён паролем</div>
            {pwPrompt.retry && <div style={{ color: RED, fontSize: 12, marginBottom: 8 }}>Неверный пароль, попробуйте ещё раз</div>}
            <input value={pwVal} onChange={(e) => setPwVal(e.target.value)} type="password" autoFocus placeholder="Пароль"
              style={{ width: "100%", boxSizing: "border-box", background: BG, border: "1px solid " + LINE, borderRadius: 12, color: TXT, fontSize: 15, padding: "12px 14px", marginBottom: 12, outline: "none" }} />
            <div style={{ display: "flex", gap: 8 }}>
              <button onClick={() => resolvePassword(null)} style={{ flex: 1, background: ROW2, border: "1px solid " + LINE, borderRadius: 10, color: SUB, fontSize: 14, padding: "11px 0" }}>Отмена</button>
              <button onClick={() => resolvePassword(pwVal)} style={{ flex: 1, background: ACC, border: "none", borderRadius: 10, color: "#fff", fontSize: 14, fontWeight: 600, padding: "11px 0" }}>Ок</button>
            </div>
          </div>
        </div>
      )}

      {/* ВЬЮВЕР ШРИФТОВ */}
      {fontView && (
        <div style={{ position: "fixed", inset: 0, zIndex: 1350, background: BG, display: "flex", flexDirection: "column" }}>
          {fontView.css && <style>{fontView.css}</style>}
          <div style={{ display: "flex", alignItems: "center", gap: 10, padding: "calc(env(safe-area-inset-top) + 10px) 14px 10px", borderBottom: "1px solid " + LINE }}>
            <button onClick={() => setFontView(null)} style={{ background: "transparent", border: "none", color: ACC, padding: 4, display: "flex" }}><Svg d={I.back} size={24} /></button>
            <div style={{ flex: 1, minWidth: 0, color: TXT, fontSize: 15, fontWeight: 600, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{fontView.name}</div>
          </div>
          {fontView.loading ? (
            <div style={{ flex: 1, display: "flex", alignItems: "center", justifyContent: "center", color: SUB }}>Загрузка…</div>
          ) : (
            <>
              <div style={{ flex: 1, overflowY: "auto", padding: 16 }}>
                {fontText.trim() && [40, 28, 20].map((sz) => (
                  <div key={"c" + sz} style={{ fontFamily: "'" + fontView.family + "'", fontSize: sz, color: TXT, lineHeight: 1.35, marginBottom: 14, wordBreak: "break-word" }}>{fontText}</div>
                ))}
                {[
                  ["Русский", "Съешь же ещё этих мягких французских булок да выпей чаю."],
                  ["English", "The quick brown fox jumps over the lazy dog."],
                ].map(([lbl, txt]) => (
                  <div key={lbl} style={{ marginBottom: 20 }}>
                    <div style={{ color: SUB, fontSize: 11, textTransform: "uppercase", letterSpacing: 1, marginBottom: 6 }}>{lbl}</div>
                    {[34, 24, 18, 14].map((sz) => (
                      <div key={lbl + sz} style={{ fontFamily: "'" + fontView.family + "'", fontSize: sz, color: TXT, lineHeight: 1.4, marginBottom: 8, wordBreak: "break-word" }}>{txt}</div>
                    ))}
                  </div>
                ))}
                <div style={{ fontFamily: "'" + fontView.family + "'", fontSize: 26, color: TXT, marginBottom: 8 }}>ABCDEFGHIJKLMNOPQRSTUVWXYZ</div>
                <div style={{ fontFamily: "'" + fontView.family + "'", fontSize: 26, color: TXT, marginBottom: 8 }}>abcdefghijklmnopqrstuvwxyz</div>
                <div style={{ fontFamily: "'" + fontView.family + "'", fontSize: 26, color: TXT, marginBottom: 8 }}>АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯ</div>
                <div style={{ fontFamily: "'" + fontView.family + "'", fontSize: 26, color: TXT, marginBottom: 20 }}>0123456789</div>
              </div>
              <div style={{ padding: "10px 14px calc(env(safe-area-inset-bottom) + 12px)", borderTop: "1px solid " + LINE, background: BAR }}>
                <input value={fontText} onChange={(e) => setFontText(e.target.value)} placeholder="Введите свой текст…"
                  style={{ width: "100%", boxSizing: "border-box", background: BG, border: "1px solid " + LINE, borderRadius: 12, color: TXT, fontSize: 15, padding: "12px 14px", outline: "none" }} />
              </div>
            </>
          )}
        </div>
      )}

      {/* КОНФЛИКТ ИМЁН ПРИ ВСТАВКЕ — компактно, внизу */}
      {sortAsk && (
        <>
          <div style={{ position: "fixed", inset: 0, zIndex: 1449, background: "rgba(0,0,0,.35)" }} onClick={() => setSortAsk(null)} />
          <div style={{ position: "fixed", zIndex: 1450, left: 10, right: 10, bottom: "calc(84px + env(safe-area-inset-bottom))", background: BAR, borderRadius: 16, padding: 14, boxShadow: "var(--barsh)" }}>
            <div style={{ color: TXT, fontSize: 15, fontWeight: 600, marginBottom: 6 }}>Подпапки сортировать тоже?</div>
            <div style={{ color: SUB, fontSize: 12.5, lineHeight: 1.5, marginBottom: 12 }}>«Да» — к этой папке и всем её подпапкам. «Нет» — только к этой папке.</div>
            <div style={{ display: "flex", gap: 8 }}>
              <button onClick={() => { const k = sortAsk.mode; setSortAsk(null); const m = {}; for (const kk in sortMap) { const raw = kk.startsWith("sub://") ? kk.slice(6) : kk; if (raw === path || raw.startsWith(path ? path + "/" : "")) continue; m[kk] = sortMap[kk]; } m["sub://" + path] = k; setSortMap(m); ls.set("fm_sortmap_v1", JSON.stringify(m)); }}
                style={{ flex: 1, height: 44, borderRadius: 12, border: "none", background: ACC, color: "#fff", fontSize: 14, fontWeight: 600 }}>Да</button>
              <button onClick={() => { const k = sortAsk.mode; setSortAsk(null); const m = { ...sortMap, [path]: k }; setSortMap(m); ls.set("fm_sortmap_v1", JSON.stringify(m)); }}
                style={{ flex: 1, height: 44, borderRadius: 12, border: "1px solid " + LINE, background: ROW2, color: TXT, fontSize: 14 }}>Нет</button>
            </div>
          </div>
        </>
      )}
      {resumeJob && (
        <>
          <div style={{ position: "fixed", inset: 0, zIndex: 1449, background: "rgba(0,0,0,.35)" }} onClick={() => setResumeJob(null)} />
          <div style={{ position: "fixed", zIndex: 1450, left: 10, right: 10, bottom: "calc(84px + env(safe-area-inset-bottom))", background: BAR, borderRadius: 16, padding: 14, boxShadow: "var(--barsh)" }}>
            <div style={{ color: TXT, fontSize: 15, fontWeight: 600, marginBottom: 6 }}>{resumeJob.jobs.length > 1 ? "Незавершённые операции" : "Незавершённая операция"}</div>
            <div style={{ color: SUB, fontSize: 12.5, lineHeight: 1.5, marginBottom: 12 }}>
              {resumeJob.jobs.map((j) => (
                <div key={j.id} style={{ marginBottom: 4 }}>
                  {j.mode === "move" ? "Перемещение" : "Копирование"}: {j.items} об. в «{baseName(absOfUri(j.dest)) || "Storage"}»
                  {j.bytesTotal > 0 ? " — сделано " + Math.round((j.bytesDone || 0) * 100 / j.bytesTotal) + "%" : ""}
                  {j.error ? <span style={{ color: RED }}> · {j.error}</span> : null}
                </div>
              ))}
              Продолжить с места обрыва?
            </div>
            <div style={{ display: "flex", gap: 8 }}>
              <button onClick={async () => { const j = resumeJob; setResumeJob(null); for (const x of j.jobs) { xferMeta.current[x.id] = { destPath: null }; try { await Apps.jobResume({ id: x.id }); } catch {} } }}
                style={{ flex: 1, height: 44, borderRadius: 12, border: "none", background: ACC, color: "#fff", fontSize: 14, fontWeight: 600 }}>Продолжить</button>
              <button onClick={async () => { const j = resumeJob; setResumeJob(null); for (const x of j.jobs) { try { await Apps.jobForget({ id: x.id }); } catch {} } }} style={{ flex: 1, height: 44, borderRadius: 12, border: "1px solid " + LINE, background: ROW2, color: TXT, fontSize: 14 }}>Забыть</button>
            </div>
          </div>
        </>
      )}
      {safPrompt && (
        <>
          <div style={{ position: "fixed", inset: 0, zIndex: 1449, background: "rgba(0,0,0,.35)" }} onClick={() => setSafPrompt(null)} />
          <div style={{ position: "fixed", zIndex: 1450, left: 10, right: 10, bottom: "calc(84px + env(safe-area-inset-bottom))", background: BAR, borderRadius: 16, padding: 14, boxShadow: "var(--barsh)" }}>
            <div style={{ color: TXT, fontSize: 15, fontWeight: 600, marginBottom: 6 }}>Доступ к флешке</div>
            <div style={{ color: SUB, fontSize: 12.5, lineHeight: 1.5, marginBottom: 12 }}>
              Android даёт работать со съёмными носителями только через системный выбор папки. Нажмите «Разрешить», в открывшемся окне выберите этот накопитель и подтвердите — после этого просмотр и копирование заработают.
            </div>
            <div style={{ display: "flex", gap: 8 }}>
              <button onClick={async () => { const abs = safPrompt.abs; setSafPrompt(null); try { await Apps.safRequest({ path: abs }); showToast("Доступ выдан"); loadVolumes(); refresh(); } catch (e) { showToast("Ошибка: " + (e?.message || "")); } }}
                style={{ flex: 1, height: 44, borderRadius: 12, border: "none", background: ACC, color: "#fff", fontSize: 14, fontWeight: 600 }}>Разрешить</button>
              <button onClick={() => setSafPrompt(null)} style={{ flex: 1, height: 44, borderRadius: 12, border: "1px solid " + LINE, background: ROW2, color: TXT, fontSize: 14 }}>Отмена</button>
            </div>
          </div>
        </>
      )}
      {opErr && (
        <>
          <div style={{ position: "fixed", inset: 0, zIndex: 1449 }} />
          <div style={{ position: "fixed", zIndex: 1450, left: 10, right: 10, bottom: "calc(84px + env(safe-area-inset-bottom))", background: BAR, borderRadius: 16, padding: 12, boxShadow: "var(--barsh)" }}>
            <div style={{ color: RED, fontSize: 13, marginBottom: 2 }}>Не удалось обработать:</div>
            <div style={{ color: TXT, fontSize: 12, marginBottom: 4, wordBreak: "break-all" }}>{opErr.name}</div>
            <div style={{ color: SUB, fontSize: 11.5, marginBottom: 10, wordBreak: "break-all" }}>{opErr.msg}</div>
            <div style={{ display: "flex", gap: 6 }}>
              <button onClick={() => resolveOpErr("retry", false)} style={{ flex: 1, background: ACC, border: "none", borderRadius: 9, color: "#fff", fontSize: 13, fontWeight: 600, padding: "10px 0" }}>Повторить</button>
              <button onClick={() => resolveOpErr("skip", false)} style={{ flex: 1, background: ROW2, border: "1px solid " + LINE, borderRadius: 9, color: TXT, fontSize: 13, padding: "10px 0" }}>Пропустить</button>
              <button onClick={() => resolveOpErr("skip", true)} style={{ flex: 1, background: ROW2, border: "1px solid " + LINE, borderRadius: 9, color: TXT, fontSize: 13, padding: "10px 0" }}>Пропустить все</button>
            </div>
            <div style={{ display: "flex", justifyContent: "flex-end", marginTop: 8 }}>
              <button onClick={() => resolveOpErr("cancel", false)} style={{ background: "transparent", border: "none", color: SUB, fontSize: 12, padding: "4px 6px" }}>Отменить всё</button>
            </div>
          </div>
        </>
      )}
      {jobsView && (
        <div style={S.backdrop} onClick={() => setJobsView(null)}>
          <div style={{ ...S.sheet, padding: "16px 16px 28px" }} onClick={(e) => e.stopPropagation()}>
            <div style={{ color: TXT, fontSize: 18, fontWeight: 700, marginBottom: 12 }}>Задачи</div>
            {!jobsView.length && <div style={{ color: SUB, fontSize: 14, padding: "18px 0", textAlign: "center" }}>Ничего не выполняется</div>}
            {jobsView.map((jb) => {
              const lab = jb.mode === "delete" ? "Удаление" : jb.mode === "move" ? "Перемещение" : "Копирование";
              const p = jb.bytesTotal > 0 ? Math.min(100, Math.round(jb.bytesDone * 100 / jb.bytesTotal)) : 0;
              return (
                <div key={jb.id} style={{ padding: "11px 12px", borderRadius: 14, background: ROW2, border: "1px solid " + (jb.active ? ACC : LINE), marginBottom: 8 }}>
                  <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                    <span style={{ color: jb.active ? ACC : SUB, display: "flex" }}><Svg d={jb.mode === "delete" ? I.trash : jb.mode === "move" ? I.cut : I.copy} size={20} /></span>
                    <div style={{ flex: 1, minWidth: 0 }}>
                      <div style={{ color: TXT, fontSize: 15, fontWeight: 600 }}>{lab}{jb.items ? " · " + jb.items + " об." : ""}</div>
                      <div style={{ color: SUB, fontSize: 12, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
                        {jb.active ? (jb.name || "…") : "в очереди"}{jb.destPath ? " → " + String(jb.destPath).replace(/^\/storage\/emulated\/0/, "Внутренняя память") : ""}
                      </div>
                    </div>
                    {jb.active ? <span style={{ color: TXT, fontSize: 15, fontWeight: 700 }}>{p}%</span> : null}
                    <button onClick={async () => { await Apps.xferCancel({ id: jb.id }).catch(() => {}); openJobs(); }} aria-label="Отменить"
                      style={{ background: "transparent", border: "none", color: RED, display: "flex", padding: 6 }}><Svg d={I.x} size={20} /></button>
                  </div>
                  {jb.active && (
                    <div style={{ height: 6, background: BAR, borderRadius: 3, overflow: "hidden", marginTop: 8 }}>
                      <div style={{ height: "100%", width: p + "%", background: ACC }} />
                    </div>
                  )}
                </div>
              );
            })}
            <button onClick={() => setJobsView(null)} style={{ width: "100%", background: ROW2, border: "1px solid " + LINE, borderRadius: 14, color: TXT, fontSize: 15, fontWeight: 600, padding: "13px 0", marginTop: 12 }}>Закрыть</button>
          </div>
        </div>
      )}
      {spaceAsk && (
        <>
          <div style={{ position: "fixed", inset: 0, zIndex: 1449, background: "rgba(0,0,0,.45)" }} />
          <div style={{ position: "fixed", zIndex: 1450, left: 8, right: 8, maxWidth: 400, margin: "0 auto", bottom: "calc(84px + env(safe-area-inset-bottom))", background: BAR, borderRadius: 20, padding: 14, boxShadow: "0 -8px 30px rgba(0,0,0,.35)", border: "1px solid " + LINE }}>
            <div style={{ display: "flex", alignItems: "center", gap: 11, marginBottom: 10 }}>
              <span style={{ color: RED, display: "flex", flexShrink: 0 }}><Svg d={I.info} size={26} /></span>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ color: TXT, fontSize: 17, fontWeight: 700 }}>Не хватает места</div>
                <div style={{ color: SUB, fontSize: 13, marginTop: 3 }}>нужно {fmtSizeShort(spaceAsk.need)}, свободно {fmtSizeShort(spaceAsk.free)}</div>
              </div>
            </div>
            <div style={{ color: SUB, fontSize: 13, marginBottom: 12, wordBreak: "break-all" }}>{(spaceAsk.path || "").replace(/^\/storage\/emulated\/0/, "Внутренняя память")}</div>
            <div style={{ display: "flex", gap: 10 }}>
              <button onClick={() => { setSpaceAsk(null); Apps.xferResolve({ action: "cancel" }).catch(() => {}); }}
                style={{ flex: 1, background: ROW2, border: "1px solid " + LINE, borderRadius: 14, color: TXT, fontSize: 15, fontWeight: 600, padding: "13px 0" }}>Отменить</button>
              <button onClick={() => { setSpaceAsk(null); Apps.xferResolve({ action: "continue" }).catch(() => {}); }}
                style={{ flex: 1, background: "rgba(224,82,82,.13)", border: "1px solid rgba(224,82,82,.5)", borderRadius: 14, color: RED, fontSize: 15, fontWeight: 700, padding: "13px 0" }}>Всё равно копировать</button>
            </div>
          </div>
        </>
      )}
      {conflict && (() => {
        const c = conflict;
        const dirOf = (p) => { const x = (p || "").replace(/\/+$/, ""); const i = x.lastIndexOf("/"); return i > 0 ? x.slice(0, i) : x; };
        const pretty = (p) => (p || "").replace(/^file:\/\//, "").replace(/^\/storage\/emulated\/0/, "Внутренняя память");
        const hasInfo = c.native && c.dstSize != null;
        const newer = hasInfo && !c.isDir ? (c.srcMtime > c.dstMtime + 2000 ? "новее" : c.srcMtime + 2000 < c.dstMtime ? "старее" : null) : null;
        const bigger = hasInfo && !c.isDir ? (c.srcSize > c.dstSize ? "больше" : c.srcSize < c.dstSize ? "меньше" : null) : null;
        const Row = ({ title, desc, tone, icon, onClick, right }) => (
          <div onClick={onClick} style={{
            display: "flex", alignItems: "center", gap: 12, padding: "13px 14px", borderRadius: 14, marginBottom: 8,
            background: tone === "danger" ? "rgba(224,82,82,.13)" : tone === "acc" ? "var(--accbg)" : ROW2,
            border: "1px solid " + (tone === "danger" ? "rgba(224,82,82,.5)" : tone === "acc" ? ACC : LINE),
          }}>
            <span style={{ display: "flex", flexShrink: 0, color: tone === "danger" ? RED : tone === "acc" ? ACC : SUB }}><Svg d={icon} size={22} /></span>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ color: tone === "danger" ? RED : TXT, fontSize: 16, fontWeight: 700, lineHeight: 1.2 }}>{title}</div>
              {desc ? <div style={{ color: SUB, fontSize: 13, marginTop: 3, lineHeight: 1.3 }}>{desc}</div> : null}
            </div>
            {right || null}
          </div>
        );
        return (
        <>
          <div style={{ position: "fixed", inset: 0, zIndex: 1449, background: "rgba(0,0,0,.45)" }} />
          <div style={{ position: "fixed", zIndex: 1450, left: 8, right: 8, maxWidth: 400, margin: "0 auto", bottom: "calc(84px + env(safe-area-inset-bottom))", background: BAR, borderRadius: 20, padding: 14, boxShadow: "0 -8px 30px rgba(0,0,0,.35)", border: "1px solid " + LINE, maxHeight: "78vh", overflowY: "auto" }}>
            {/* что спрашиваем */}
            <div style={{ display: "flex", alignItems: "center", gap: 11, marginBottom: 12 }}>
              <span style={{ color: ACC, display: "flex", flexShrink: 0 }}><Svg d={c.isDir ? I.folder : I.file} size={26} /></span>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ color: TXT, fontSize: 17, fontWeight: 700, lineHeight: 1.2, wordBreak: "break-word" }}>{c.name}</div>
                <div style={{ color: SUB, fontSize: 13, marginTop: 3 }}>
                  {c.isDir ? "Папка уже существует" : "Файл уже существует"}{c.num > 1 ? " · " + c.num + "-й по счёту" : ""}
                </div>
              </div>
            </div>

            {hasInfo && !c.isDir && (
              <div style={{ background: ROW2, borderRadius: 14, padding: "11px 13px", marginBottom: 10, border: "1px solid " + LINE }}>
                {c.same && (
                  <div style={{ display: "flex", alignItems: "center", gap: 7, color: ACC, fontSize: 14, fontWeight: 700, marginBottom: 9 }}>
                    <Svg d={I.check} size={17} />Файлы одинаковые
                  </div>
                )}
                <div style={{ color: SUB, fontSize: 12, textTransform: "uppercase", letterSpacing: 0.4, marginBottom: 2 }}>Новый</div>
                <div style={{ color: TXT, fontSize: 15, fontWeight: 600 }}>
                  {fmtSizeShort(c.srcSize)} · {fmtDate(c.srcMtime)}
                  {newer || bigger ? <span style={{ color: ACC, fontWeight: 700 }}>{"  " + [newer, bigger].filter(Boolean).join(", ")}</span> : null}
                </div>
                {c.srcPath ? <div style={{ color: SUB, fontSize: 12.5, marginTop: 2, wordBreak: "break-all" }}>{pretty(dirOf(c.srcPath))}</div> : null}
                <div style={{ height: 1, background: LINE, margin: "10px 0" }} />
                <div style={{ color: SUB, fontSize: 12, textTransform: "uppercase", letterSpacing: 0.4, marginBottom: 2 }}>Будет заменён</div>
                <div style={{ color: TXT, fontSize: 15, fontWeight: 600 }}>{fmtSizeShort(c.dstSize)} · {fmtDate(c.dstMtime)}</div>
                {c.dstPath ? <div style={{ color: SUB, fontSize: 12.5, marginTop: 2, wordBreak: "break-all" }}>{pretty(c.dstPath)}</div> : null}
              </div>
            )}
            {hasInfo && c.isDir && c.dstPath && (
              <div style={{ background: ROW2, borderRadius: 14, padding: "11px 13px", marginBottom: 10, border: "1px solid " + LINE }}>
                <div style={{ color: SUB, fontSize: 12, textTransform: "uppercase", letterSpacing: 0.4, marginBottom: 2 }}>Существующая папка</div>
                <div style={{ color: TXT, fontSize: 13.5, wordBreak: "break-all" }}>{pretty(c.dstPath)}</div>
              </div>
            )}

            {/* действия */}
            {!c.isDir && (
              <Row title="Заменить" tone="danger" icon={I.refresh}
                desc={conflictDiffOnly ? "одинаковые пропустить, заменить только отличающиеся" : "существующий файл будет перезаписан"}
                onClick={() => resolveConflict(conflictDiffOnly ? "overwriteDiff" : "overwrite", conflictApplyAll)}
                right={<span onClick={(e) => { e.stopPropagation(); setConflictDiffOnly((v) => !v); }} style={{ display: "flex", alignItems: "center", gap: 7, color: conflictDiffOnly ? ACC : SUB, fontSize: 13, flexShrink: 0, maxWidth: 104, lineHeight: 1.2 }}>
                  <span style={{ ...S.cbox, ...(conflictDiffOnly ? S.cboxOn : {}) }}>{conflictDiffOnly ? <Svg d={I.check} size={13} /> : null}</span>
                  если различаются
                </span>} />
            )}
            {c.isDir && (
              <>
                <Row title="Объединить" tone="acc" icon={I.folder} desc="файлы добавятся в существующую папку, лишнее останется" onClick={() => resolveConflict("merge", conflictApplyAll)} />
                <Row title="Заменить папку" tone="danger" icon={I.refresh} desc="существующая папка удаляется целиком вместе с лишними файлами" onClick={() => resolveConflict("replaceDir", conflictApplyAll)} />
              </>
            )}
            {c.canResume && !c.isDir && (
              <Row title="Дописать" tone="acc" icon={I.dl} desc="продолжить с места обрыва, уже скопированное не трогать" onClick={() => resolveConflict("resume", false)} />
            )}
            <Row title="Пропустить" icon={I.x} desc={c.isDir ? "не трогать эту папку" : "не трогать этот файл"} onClick={() => resolveConflict("skip", conflictApplyAll)} />
            <Row title="Сохранить оба" icon={I.copy} desc="новый получит имя с номером" onClick={() => resolveConflict("rename", conflictApplyAll)} />
            <Row title="Новое имя" icon={I.rename} desc="задать своё имя" onClick={() => {
              const sp = splitExt(c.name, c.isDir);
              setSheet({ kind: "rename", conflict: true, old: c.name, base: sp.base, ext: sp.ext, editExt: false });
            }} />

            <div style={{ marginTop: 10, paddingTop: 10, borderTop: "1px solid " + LINE }}>
              {/* один флажок: для папки помнит ответ по папкам, для файла — по файлам */}
              <div onClick={() => { const v = !conflictApplyAll; setConflictApplyAll(v); setConflictAllDirs(v && c.isDir); setConflictAllFiles(v && !c.isDir); }}
                style={{ display: "flex", alignItems: "center", gap: 9, color: conflictApplyAll ? ACC : SUB, fontSize: 14 }}>
                <span style={{ ...S.cbox, ...(conflictApplyAll ? S.cboxOn : {}) }}>{conflictApplyAll ? <Svg d={I.check} size={13} /> : null}</span>
                Запомнить
              </div>
              <div style={{ display: "flex", justifyContent: "flex-end", marginTop: 10 }}>
                <button onClick={() => resolveConflict("cancel", false)} style={{ background: "transparent", border: "1px solid " + LINE, borderRadius: 10, color: RED, fontSize: 14, fontWeight: 600, padding: "8px 14px" }}>Прервать</button>
              </div>
            </div>
          </div>
        </>
        );
      })()}

      {/* ПОДТВЕРЖДЕНИЕ УДАЛЕНИЯ — над кнопкой «Удалить» */}
      {confirmDel && (
        <>
          <div style={{ position: "fixed", inset: 0, zIndex: 1290 }} onClick={() => setConfirmDel(null)} />
          <div style={{ position: "fixed", zIndex: 1300, left: Math.max(90, Math.min(confirmDel.cx, window.innerWidth - 90)), transform: "translateX(-50%)", top: confirmDel.top - 92, minWidth: 180, background: BAR, borderRadius: 14, padding: 10, boxShadow: "var(--barsh)", animation: "popCenter .15s ease" }}>
            <div style={{ color: TXT, fontSize: 14, fontWeight: 600, textAlign: "center", marginBottom: delInfo && delInfo.bytes > 0 ? 8 : 10 }}>
              Удалить {confirmDel.arc ? confirmDel.names.length : (delInfo ? delInfo.items : [...sel].length)}?
            </div>
            {delInfo && delInfo.bytes > 0 && (
              <div style={{ textAlign: "center", marginBottom: 10 }}>
                <span style={{ display: "inline-block", background: "rgba(224,82,82,.15)", color: "#E88", fontSize: 12, fontWeight: 600, padding: "3px 11px", borderRadius: 999 }}>{fmtSizeShort(delInfo.bytes)}</span>
              </div>
            )}
            {!delInfo && !confirmDel.arc && (<div style={{ color: SUB, fontSize: 12, textAlign: "center", marginBottom: 10 }}>подсчёт…</div>)}
            {confirmDel.arc && (<div style={{ color: SUB, fontSize: 12, textAlign: "center", marginBottom: 10 }}>из архива</div>)}
            <div style={{ display: "flex", gap: 8, justifyContent: "center" }}>
              <button onClick={() => { if (confirmDel.arc) { const nm = confirmDel.names; setConfirmDel(null); arcModify({ remove: nm }); } else doDelete(); }} style={{ background: RED, border: "none", borderRadius: 8, color: "#fff", fontSize: 14, fontWeight: 700, padding: "8px 20px" }}>Да</button>
              <button onClick={() => setConfirmDel(null)} style={{ background: ROW2, border: "1px solid " + LINE, borderRadius: 8, color: SUB, fontSize: 14, padding: "8px 20px" }}>Нет</button>
            </div>
          </div>
        </>
      )}

      {/* ПРОСМОТР АРХИВА — как папка */}
      {arcView && (
        <div style={S.arcScreen}>
          <div style={{ ...S.crumb, borderBottom: "none" }}>
            <span onClick={() => (arcPath ? setArcPath(arcPath.replace(/[^/]+\/$/, "")) : (markCameFrom(path, arcView.name), setArcView(null)))} style={{ display: "inline-flex", alignItems: "center", gap: 6, color: ACC, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}><Svg d={I.back} size={18} /> {arcView.name + (arcPath ? " / " + arcPath.replace(/\/$/, "") : "")}</span>
          </div>
          {arcView.busy && <div style={{ position: "absolute", top: 50, left: 0, right: 0, zIndex: 5, padding: "8px 16px", color: GOLD, fontSize: 13, textAlign: "center", pointerEvents: "none", textShadow: "0 1px 4px rgba(0,0,0,.6)" }}>{arcView.busy}</div>}
          {arcView.entries == null ? (
            <div style={{ flex: 1, display: "flex", alignItems: "center", justifyContent: "center", color: SUB }}>Открываю архив…</div>
          ) : (
          <div ref={arcListRef} onTouchStart={onTS} onTouchMove={onTM} style={{ flex: 1, overflowY: "auto", display: "flex", flexDirection: "column" }}>
            <div ref={arcSpacerRef} style={{ height: 0, flexShrink: 0 }} />
            <div style={{ flexShrink: 0 }}>
              {arcLevel.map((it, i) => {
                const isDir = !!it.dir;
                const label = isDir ? it.name : (it.label || it.name);
                const ic = isDir ? { d: I.folder, c: ACC } : fileIcon(label);
                const asel = isDir ? (arcSel.has(it.prefix) || (it.count > 0 && arcSelUnder.get(it.prefix) === it.count)) : arcSel.has(it.name);
                const tog = () => {
                  const selNames = isDir ? [it.prefix, ...arcNamesUnder(it.prefix)] : [it.name];
                  setArcSel((prev) => {
                    const n = new Set(prev);
                    const on = isDir ? (n.has(it.prefix) || (it.count > 0 && selNames.slice(1).every((x) => n.has(x)))) : n.has(it.name);
                    if (on) selNames.forEach((x) => n.delete(x)); else selNames.forEach((x) => n.add(x));
                    return n;
                  });
                };
                return (
                  <div key={i}
                    onClick={() => {
                      if (arcLp.current) { arcLp.current = false; return; }   // это был долгий тап, он уже сработал
                      if (arcSel.size > 0) tog();
                      else if (isDir) setArcPath(it.prefix);
                      else extractOpenMenu(it);
                    }}
                    onPointerDown={(ev) => { arcLp.current = false; arcPX.current = ev.clientX; arcPY.current = ev.clientY; clearTimeout(arcLpT.current); arcLpT.current = setTimeout(() => { arcLp.current = true; buzz(15); tog(); }, 400); }}
                    onPointerUp={() => clearTimeout(arcLpT.current)}
                    onPointerMove={(ev) => { if (Math.abs(ev.clientX - arcPX.current) > 10 || Math.abs(ev.clientY - arcPY.current) > 10) clearTimeout(arcLpT.current); }}
                    onPointerCancel={() => clearTimeout(arcLpT.current)}
                    style={{ ...S.row, ...(arcLevel.length <= 12 ? { contentVisibility: "visible" } : {}), ...(asel ? { background: "var(--accbg)" } : {}) }}>
                    <span style={{ ...S.iconWrap, color: ic.c, background: asel ? "transparent" : "var(--chip)" }}
                      onClick={(ev) => { ev.stopPropagation(); tog(); }}>
                      {asel ? <span style={S.cbk}><Svg d={I.check} size={14} /></span>
                        : isDir ? <Svg d={I.folder} size={24} />
                        : /\.apk$/i.test(label) ? <Svg d={ic.d} size={24} />
                        : (EXT.archive.includes((label.split(".").pop() || "").toLowerCase())) ? <ArcBadge name={label} />
                        : <Svg d={ic.d} size={24} />}
                    </span>
                    <span style={S.rowMid}>
                      <span style={S.name}>{label}</span>
                      <span style={S.rowDate}>{isDir ? (it.count + " " + plural(it.count, "объект", "объекта", "объектов")) : "в архиве"}</span>
                    </span>
                    <span style={S.rowSize}>{fmtSizeShort(it.size)}</span>
                    <div style={S.rowLine} />
                  </div>
                );
              })}
            </div>
          </div>
          )}
        </div>
      )}

      {/* МЕНЮ ОТКРЫТИЯ ФАЙЛА */}
      {openMenu && (() => {
        return (
          <div style={{ ...S.backdrop, pointerEvents: menuArmed ? "auto" : "none" }} onClick={() => setOpenMenu(null)}>
            <div ref={omSheetRef} style={{ ...S.sheet, animation: "growSheet .26s cubic-bezier(.2,.8,.3,1.05)" }} onClick={(e) => e.stopPropagation()}>
              {/\.(apk|apks|xapk|apkm|apkx)$/i.test(openMenu.file.name) && openMenu.apkInfo && (
                <div style={{ padding: "10px 12px", margin: "0 0 12px", background: ROW2, borderRadius: 12, fontSize: 13, lineHeight: 1.7, color: SUB }}>
                  <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 4 }}>
                    {openMenu.apkInfo.icon && <img src={openMenu.apkInfo.icon} alt="" style={{ width: 40, height: 40, borderRadius: 9, flexShrink: 0 }} />}
                    <div style={{ minWidth: 0 }}>
                      {openMenu.apkInfo.label && <div style={{ color: TXT, fontWeight: 600, fontSize: 15 }}>{openMenu.apkInfo.label}</div>}
                      {openMenu.apkInfo.package && <div style={{ color: "#7FB4E6", wordBreak: "break-all", fontSize: 12 }}>{openMenu.apkInfo.package}</div>}
                    </div>
                  </div>
                  {openMenu.apkInfo.versionName && <div>Версия: <span style={{ color: TXT }}>{openMenu.apkInfo.versionName} ({openMenu.apkInfo.versionCode})</span>{openMenu.apkInfo.installed && openMenu.apkInfo.installedVersionCode != null && Number(openMenu.apkInfo.versionCode) > Number(openMenu.apkInfo.installedVersionCode) && <span style={{ color: "#5FCF80", fontWeight: 700 }}> (новее)</span>}</div>}
                  {openMenu.apkInfo.installed && <div>Установлено: <span style={{ color: GOLD }}>{openMenu.apkInfo.installedVersionName || "—"}</span></div>}
                  {openMenu.apkInfo.installed && openMenu.apkInfo.sigMatch === true && <div style={{ color: "#5FCF80" }}>Подпись совпадает — установится поверх</div>}
                  {openMenu.apkInfo.installed && openMenu.apkInfo.sigMatch === false && <div style={{ color: RED, fontWeight: 600 }}>Подпись отличается — поверх НЕ установится</div>}
                  {openMenu.apkInfo.installed && openMenu.apkInfo.sigMatch === false && openMenu.apkInfo.package && (
                    <div onClick={() => { const f = openMenu.file, p = openMenu.apkInfo.package; setOpenMenu(null); Apps.apkReinstall({ uri: f.uri, package: p }).catch((er) => showToast("Ошибка: " + (er?.message || ""))); }}
                      style={{ marginTop: 8, padding: "10px 12px", borderRadius: 10, background: "var(--accbg)", color: ACC, fontWeight: 600, fontSize: 14, display: "flex", alignItems: "center", justifyContent: "center", gap: 8 }}>
                      <Svg d={I.plus} size={18} /> Деинсталировать и установить
                    </div>
                  )}
                  {!openMenu.apkInfo.installed && openMenu.apkInfo.sig && <div style={{ color: SUB, fontSize: 11, wordBreak: "break-all" }}>Подпись: {openMenu.apkInfo.sig.slice(0, 24)}…</div>}
                  <div>Целевая ОС: <span style={{ color: TXT }}>SDK {openMenu.apkInfo.targetSdk}</span></div>
                  {openMenu.apkInfo.minSdk != null && <div>Минимальная ОС: <span style={{ color: TXT }}>SDK {openMenu.apkInfo.minSdk}</span></div>}
                </div>
              )}
              <div style={{ display: "flex", alignItems: "center", marginBottom: 14 }}>
                <div style={{ ...S.sheetTitle, marginBottom: 0, flex: 1, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{openMenu.file.name}</div>
                <button style={{ ...S.iconBtn, color: openMenu.editHide ? ACC : SUB }} onClick={() => setOpenMenu({ ...openMenu, editHide: !openMenu.editHide })}><Svg d={I.rename} size={20} /></button>
              </div>
              {!openMenu.editHide && !openMenu.edit && (
                <>
                  <div onClick={() => setOpenMenu({ ...openMenu, showCats: !openMenu.showCats })} style={{ ...S.appRow, color: SUB }}>
                    <span style={{ width: 38, display: "flex", justifyContent: "center" }}><Svg d={I.chev} size={22} /></span>
                    <span style={{ flex: 1, fontSize: 15 }}>Открыть как…</span>
                  </div>
                  {openMenu.showCats && (
                    <div style={{ display: "flex", gap: 6, overflowX: "auto", margin: "2px 0 12px", paddingBottom: 2 }}>
                      {OPEN_AS.map(([m, lbl]) => (
                        <button key={m} onClick={() => reQueryAs(m)}
                          style={{ ...S.chip, ...(openMenu.asCat && openMenu.mime === m ? S.chipOn : {}) }}>{lbl}</button>
                      ))}
                    </div>
                  )}
                </>
              )}
              {openMenu.editHide && <div style={{ fontSize: 12, color: GOLD, marginBottom: 10 }}>Глаз — скрыть/показать. Кнопки перетаскиваются (удержание). Тап по приложению — скрыть/показать.</div>}
              <div style={{ maxHeight: "52vh", overflowY: dragId ? "hidden" : "auto" }} onTouchMove={menuDragMove} onTouchEnd={() => menuDragEnd(menuCat(openMenu))} onTouchCancel={() => menuDragEnd(menuCat(openMenu))}>
                {(() => {
                  const cat = menuCat(openMenu);
                  const sh = new Set(loadMap(HIDEKEY)[cat] || []);
                  const stock = orderItems(buildStockItems(openMenu), cat);
                  const vis = openMenu.editHide ? stock : stock.filter((it) => !sh.has(it.id));
                  return vis.map((it, idx) => {
                    const isHid = sh.has(it.id);
                    return (
                      <div key={it.id} data-mid={it.id}
                        onTouchStart={(e) => menuDragStart(idx, e, vis)}
                        onClick={() => { if (suppressClick.current) return; if (openMenu.editHide) toggleHideItem(cat, it.id); else it.onClick(); }}
                        style={{ ...S.appRow, color: it.color || TXT, opacity: isHid ? 0.4 : 1, background: dragId === it.id ? ROW2 : "transparent" }}>
                        {it.icon ? <img src={it.icon} alt="" style={{ width: 38, height: 38, borderRadius: 9 }} />
                          : <span style={{ width: 38, display: "flex", justifyContent: "center" }}><Svg d={it.d} size={it.size || 26} /></span>}
                        <span style={{ flex: 1, fontSize: 15 }}>{it.label}</span>
                        {openMenu.editHide && <span style={{ color: isHid ? SUB : ACC, display: "flex", marginRight: 8 }}><Svg d={isHid ? I.eyeOff : I.eye} size={20} /></span>}
                        {openMenu.editHide && <span style={{ color: SUB, display: "flex" }}><Svg d={I.drag} size={20} /></span>}
                      </div>
                    );
                  });
                })()}
              </div>
              {openMenu.apps == null && (() => { const fm = mimeOf(openMenu.file.name); return !openMenu.split && ((fm !== "*/*" && fm !== "application/octet-stream") || (openMenu.asCat && openMenu.mime !== "*/*")); })() && (
                <div style={{ color: SUB, padding: 16, textAlign: "center" }}>Загрузка приложений…</div>
              )}
              {!openMenu.editHide && !openMenu.edit && !openMenu.split && !/\.apk$/i.test(openMenu.file.name) && (
                <div style={{ display: "flex", alignItems: "center", gap: 10, padding: "10px 2px 2px" }}>
                  <div onClick={() => setOpenMenu({ ...openMenu, useDefault: !openMenu.useDefault })}
                    style={{ display: "flex", alignItems: "center", gap: 10, flex: 1, cursor: "pointer" }}>
                    <span style={{ ...S.cbox, ...(openMenu.useDefault ? S.cboxOn : {}) }}>{openMenu.useDefault ? "✓" : ""}</span>
                    <span style={{ fontSize: 14 }}>Использовать по умолчанию</span>
                  </div>
                  <button style={{ ...S.sheetGhost, color: RED, borderColor: LINE, padding: "8px 18px", flexShrink: 0 }} onClick={resetDefault}>Сбросить</button>
                </div>
              )}
            </div>
          </div>
        );
      })()}

      {/* НАСТРОЙКИ */}
      {settings && (
        <div style={S.settingsScreen}>
          <div style={S.crumb}>
            <span onClick={() => { if (settingsPage) setSettingsPage(null); else setSettings(false); }} style={{ display: "inline-flex", alignItems: "center", gap: 6, color: ACC }}>
              <Svg d={I.back} size={18} /> {settingsPage === "theme" ? "Тема" : settingsPage === "fonts" ? "Шрифты" : settingsPage === "sort" ? "Сортировка" : settingsPage === "icons" ? "Иконки папок" : settingsPage === "player" ? "Плеер" : settingsPage === "perms" ? "Требуемые разрешения" : settingsPage === "backup" ? "Резервная копия" : settingsPage === "debug" ? "Отладка" : settingsPage === "dirsize" ? "Размер папок" : settingsPage === "anim" ? "Анимации" : "Настройки"}
            </span>
          </div>
          <div style={{ flex: 1, overflowY: "auto", padding: "8px 14px calc(20px + env(safe-area-inset-bottom))" }}>
            {settingsPage === null && (
              <>
                {[["theme", I.sun, "Тема"], ["fonts", I.rename, "Шрифты"], ["sort", I.sort, "Сортировка"], ["icons", I.folder, "Иконки папок"], ["perms", I.info, "Требуемые разрешения"], ["backup", I.dl, "Резервная копия"], ["dirsize", I.info, "Размер папок"], ["debug", I.info, "Отладка"], ["anim", I.sun, "Анимации"], ["player", I.audio, "Плеер"]].map(([pg, ic, lbl]) => (
                  <div key={pg} style={S.menuItem} onClick={() => setSettingsPage(pg)}>
                    <span style={{ color: ACC, display: "flex" }}><Svg d={ic} size={20} /></span>
                    <span style={{ flex: 1 }}>{lbl}</span>
                    <span style={{ color: SUB, display: "flex", transform: "rotate(180deg)" }}><Svg d={I.back} size={18} /></span>
                  </div>
                ))}
                <div style={{ color: SUB, fontSize: 11, textAlign: "center", marginTop: 18 }}>Версия {APP_VERSION}</div>
              </>
            )}
            {settingsPage === "debug" && (
              <>
                <div style={{ color: SUB, fontSize: 12.5, lineHeight: 1.5, padding: "10px 2px 14px" }}>
                  Нужна, только когда что-то ведёт себя странно. Поверх просмотрщика снимков появятся числа: размеры экрана и сцены, где сцена стоит на экране, отступы под системные полосы и положение самого кадра. Сделай снимок экрана в тот момент, когда видно проблему, и пришли — по этим числам сразу видно, что не так.
                </div>
                <div style={{ display: "flex", alignItems: "center", padding: "12px 2px" }} onClick={() => { const v = !dbgOn; setDbgOn(v); ls.set(DBGKEY, v ? "1" : "0"); }}>
                  <div style={{ flex: 1 }}>
                    <div style={{ color: TXT, fontSize: 15 }}>Показывать числа в просмотрщике</div>
                    <div style={{ color: SUB, fontSize: 12 }}>Обновляются при скрытии и показе панелей</div>
                  </div>
                  <span style={{ ...S.tgl, ...(dbgOn ? S.tglOn : {}) }}><span style={{ ...S.knob, ...(dbgOn ? S.knobOn : {}) }} /></span>
                </div>
              </>
            )}
            {settingsPage === "dirsize" && (
              <>
                <div style={{ color: SUB, fontSize: 12.5, lineHeight: 1.5, padding: "10px 2px 14px" }}>
                  Чтобы узнать вес папки, её содержимое нужно один раз обойти — система готового числа не хранит.
                  Дальше вес держится в памяти приложения и правится на разницу при добавлении и удалении файлов, без повторных обходов.
                  Первый заход в большую папку может занять несколько секунд.
                </div>
                <div style={{ display: "flex", alignItems: "center", padding: "12px 2px" }} onClick={() => { const v = !dirSizes; setDirSizes(v); ls.set(DIRSIZEKEY, v ? "1" : "0"); Apps.dirSizes({ on: v }).catch(() => {}); if (v) refresh(); }}>
                  <div style={{ flex: 1 }}>
                    <div style={{ color: TXT, fontSize: 15 }}>Показывать вес папок</div>
                    <div style={{ color: SUB, fontSize: 12 }}>Под именем папки появится её общий вес</div>
                  </div>
                  <span style={{ ...S.tgl, ...(dirSizes ? S.tglOn : {}) }}><span style={{ ...S.knob, ...(dirSizes ? S.knobOn : {}) }} /></span>
                </div>
              </>
            )}
            {settingsPage === "anim" && (
              <>
                <div style={{ display: "flex", alignItems: "center", padding: "12px 2px" }} onClick={() => { const v = !animFolders; setAnimFolders(v); ls.set("fm_anim_folders_v1", v ? "1" : "0"); }}>
                  <div style={{ flex: 1 }}>
                    <div style={{ color: TXT, fontSize: 15 }}>Открытие папок</div>
                    <div style={{ color: SUB, fontSize: 12 }}>Скольжение списка при входе и выходе из папки</div>
                  </div>
                  <span style={{ ...S.tgl, ...(animFolders ? S.tglOn : {}) }}><span style={{ ...S.knob, ...(animFolders ? S.knobOn : {}) }} /></span>
                </div>
              </>
            )}
            {settingsPage === "backup" && (
              <>
                <div style={{ color: SUB, fontSize: 12.5, lineHeight: 1.5, padding: "10px 2px 14px" }}>
                  Сохраняет темы, сортировку, иконки папок, привязки открытия, порядок меню и прочие настройки в файл. Кэши и вход в аккаунты не сохраняются.
                </div>
                <div style={{ display: "flex", alignItems: "center", padding: "10px 2px" }} onClick={() => setBackupTabs((v) => !v)}>
                  <div style={{ flex: 1 }}>
                    <div style={{ color: TXT, fontSize: 15 }}>Сохранить вкладки</div>
                    <div style={{ color: SUB, fontSize: 12 }}>Открытые вкладки и стартовую папку</div>
                  </div>
                  <span style={{ ...S.tgl, ...(backupTabs ? S.tglOn : {}) }}><span style={{ ...S.knob, ...(backupTabs ? S.knobOn : {}) }} /></span>
                </div>
                <button onClick={() => exportSettings(backupTabs)}
                  style={{ width: "100%", height: 46, borderRadius: 14, border: "none", background: ACC, color: "#fff", fontSize: 15, fontWeight: 600, marginTop: 12 }}>Экспортировать</button>
                <button onClick={() => importInputRef.current && importInputRef.current.click()}
                  style={{ width: "100%", height: 46, borderRadius: 14, border: "1px solid " + LINE, background: ROW2, color: TXT, fontSize: 15, marginTop: 10 }}>Импортировать из файла</button>
                <input ref={importInputRef} type="file" accept="application/json,.json" style={{ display: "none" }}
                  onChange={(e) => { const f = e.target.files && e.target.files[0]; if (f) importSettings(f); e.target.value = ""; }} />
              </>
            )}
            {settingsPage === "perms" && (() => {
              const st = (shz && shz.state) || "absent";
              const P = perms || {};
              const Row = ({ ok, title, desc, btn, onBtn, warn }) => (
                <div style={{ padding: "12px 2px", borderBottom: "1px solid " + LINE }}>
                  <div style={{ display: "flex", alignItems: "center", gap: 9 }}>
                    <span style={{ width: 10, height: 10, borderRadius: 5, background: ok ? ACC : warn ? GOLD : SUB, flexShrink: 0 }} />
                    <span style={{ flex: 1, color: TXT, fontSize: 15, fontWeight: 600 }}>{title}</span>
                    <span style={{ color: ok ? ACC : SUB, fontSize: 12.5 }}>{ok ? "выдано" : "не выдано"}</span>
                  </div>
                  <div style={{ color: SUB, fontSize: 12.5, lineHeight: 1.5, margin: "6px 0 0", paddingLeft: 19 }}>{desc}</div>
                  {btn && (
                    <button onClick={onBtn} style={{ width: "100%", height: 42, borderRadius: 12, marginTop: 10, border: ok ? "1px solid " + LINE : "none", background: ok ? ROW2 : ACC, color: ok ? TXT : "#fff", fontSize: 14.5, fontWeight: 600 }}>{btn}</button>
                  )}
                </div>
              );
              return (
                <>
                  <div style={{ color: SUB, fontSize: 12.5, lineHeight: 1.5, padding: "8px 2px 10px" }}>
                    Здесь собрано всё, что менеджер может попросить у системы. Ничего из этого не обязательно — без разрешения просто не работает та часть, ради которой оно нужно. Если раньше отказал, нажми кнопку и выдай заново.
                  </div>

                  <Row ok={!!P.files} title="Доступ ко всем файлам"
                    desc="Без него видна только часть памяти: не открываются чужие папки, архивы, APK и файлы приложений. Это главное разрешение менеджера."
                    btn={P.files ? "Открыть настройки" : "Дать доступ"}
                    onBtn={() => { Apps.requestAllFiles().catch(() => {}); setTimeout(loadPerms, 800); }} />

                  <Row ok={!!P.dataTree} title="Доступ к Android/data"
                    desc="Сохранения и файлы игр. Попробуй выдать через системное окно: если оно откроется на нужной папке — нажми «Использовать эту папку». На свежих версиях Android система эту папку в окне не показывает вовсе — тогда работает только Shizuku."
                    btn="Выдать доступ"
                    onBtn={() => { Apps.safRestricted({ what: "data" }).then(() => { loadPerms(); refresh(); }).catch(() => showToast("Система не дала доступ")); }} />

                  <Row ok={!!P.obbTree} title="Доступ к Android/obb"
                    desc="Дополнительные файлы игр — те, что качаются отдельно от установки. Выдаётся так же, отдельным окном."
                    btn="Выдать доступ"
                    onBtn={() => { Apps.safRestricted({ what: "obb" }).then(() => { loadPerms(); refresh(); }).catch(() => showToast("Система не дала доступ")); }} />

                  <Row ok={!!P.saf} title="Доступ к флешке или карте памяти"
                    desc="Android отдаёт съёмные носители только через своё окно выбора папки. Выдаётся один раз для каждого носителя, при первой записи на него."
                    btn="Выбрать носитель"
                    onBtn={() => { setSettings(false); setDrawer(true); showToast("Выберите носитель в шторке"); }} />

                  <Row ok={!!P.notif} title="Уведомления приложения"
                    desc="Нужно, чтобы показывать ход копирования, распаковки и удаления, когда приложение свёрнуто."
                    btn="Открыть настройки уведомлений"
                    onBtn={() => { Apps.permOpen({ what: "notif" }).catch(() => {}); setTimeout(loadPerms, 800); }} />

                  <Row ok={!!P.listener} title="Чтение уведомлений"
                    desc="Из уведомления браузера берутся проценты и общий размер файла, который качается в открытую папку. Без него у качающегося файла просто крутится кольцо."
                    btn="Открыть список доступа"
                    onBtn={() => { Apps.permOpen({ what: "listener" }).catch(() => {}); setTimeout(loadPerms, 800); }} />

                  <Row ok={!!(P.picker && P.picker.registered)} title="Выбор файла для других приложений"
                    desc={P.picker && P.picker.registered
                      ? ("Система знает нас как приложение для выбора файла: " + (P.picker.components || "") + ". Если в чужом окне нас не видно — открой в нём пункт «Прочее» или «Другое приложение»: свои списки браузеры собирают сами.")
                      : ("Система нас в этой роли не числит — значит фильтр не попал в сборку. Всего таких приложений в системе: " + ((P.picker && P.picker.total) || 0) + ".")}
                    btn={null} onBtn={() => {}} />

                  <Row ok={!!P.install} title="Установка приложений"
                    desc="Нужно, чтобы ставить APK прямо из менеджера. Без него система будет отказывать при установке."
                    btn="Открыть настройки"
                    onBtn={() => { Apps.permOpen({ what: "install" }).catch(() => {}); setTimeout(loadPerms, 800); }} />

                  <Row ok={st === "ok"} warn={st === "denied" || st === "stopped" || st === "binding"} title="Расширенный доступ (Shizuku)"
                    desc={st === "ok" ? "Работает: папки Android/data и Android/obb открываются как обычные, туда можно копировать."
                      : st === "binding" ? ("Разрешение выдано, но наша служба внутри Shizuku ещё не поднялась." + (shz && shz.err ? " Причина: " + shz.err : " Нажми «Подключить»."))
                      : st === "denied" ? "Shizuku запущен, но менеджеру не разрешил. Нажми «Разрешить» и подтверди запрос в окне Shizuku."
                      : st === "stopped" ? "Shizuku установлен, но служба не поднята. Запусти Shizuku — после перезагрузки телефона это нужно делать заново."
                      : st === "old" ? "Работает начиная с Android 6.0. На твоей версии менеджер работает как обычно."
                      : "Отдельное приложение, которое даёт доступ к закрытым папкам Android/data и Android/obb. Без него они не открываются — это ограничение системы, а не менеджера."}
                    btn={st === "denied" ? "Разрешить" : st === "absent" ? "Открыть страницу Shizuku" : st === "binding" ? "Подключить" : st === "stopped" ? "Проверить снова" : null}
                    onBtn={() => {
                      if (st === "denied") { Apps.shizukuRequest().catch(() => {}); setTimeout(loadShz, 800); }
                      else if (st === "absent") Apps.openUrl({ url: "https://shizuku.rikka.app/" }).catch(() => {});
                      else loadShz();
                    }} />

                  {shz && shz.detail && (
                    <div style={{ color: SUB, fontSize: 11, lineHeight: 1.5, marginTop: 12, padding: "10px 12px", background: ROW2, borderRadius: 12, wordBreak: "break-word" }}>
                      Состояние Shizuku: {shz.detail}
                    </div>
                  )}
                  <div style={{ color: SUB, fontSize: 11.5, lineHeight: 1.5, marginTop: 14 }}>
                    Состояние обновляется само — вернувшись из системных настроек, ничего нажимать не нужно.
                  </div>
                </>
              );
            })()}
            {settingsPage === "theme" && (
              <>
                <div style={{ display: "flex", gap: 8, marginBottom: 6 }}>
                  {[["dark", "Тёмная"], ["light", "Светлая"]].map(([t, lbl]) => (
                    <button key={t} onClick={() => { setTheme(t); ls.set("fm_theme_v1", t); }}
                      style={{ flex: 1, height: 44, borderRadius: 14, fontSize: 14, fontWeight: 600, background: theme === t ? "var(--accbg)" : "transparent", border: "1px solid " + (theme === t ? ACC : LINE), color: theme === t ? ACC : TXT }}>{lbl}</button>
                  ))}
                </div>
                <div style={S.menuItem} onClick={() => { const v = !themeBtn; setThemeBtn(v); ls.set("fm_themebtn_v1", v ? "1" : "0"); }}>
                  <span style={{ color: themeBtn ? ACC : SUB, display: "flex" }}><Svg d={theme === "dark" ? I.sun : I.moon} size={20} /></span>
                  Кнопка темы в шапке
                  <span style={{ marginLeft: "auto", ...S.tgl, ...(themeBtn ? S.tglOn : {}) }}><span style={{ ...S.knob, ...(themeBtn ? S.knobOn : {}) }} /></span>
                </div>
              </>
            )}
            {settingsPage === "fonts" && (
              <>
                {allFonts.map((f) => (
                  <div key={f.id} style={{ ...S.menuItem, justifyContent: "flex-start" }}>
                    <span onClick={() => saveFonts({ ...fonts, sel: f.id })} style={{ flex: 1, display: "flex", alignItems: "center", gap: 10 }}>
                      <span style={{ width: 22, color: fonts.sel === f.id ? ACC : "transparent", display: "flex" }}><Svg d={I.check} size={18} /></span>
                      <span style={{ fontFamily: f.css, fontSize: 15 }}>{f.name}</span>
                    </span>
                    {f.id !== "sys" && <span onClick={() => removeFont(f.id)} style={{ color: RED, display: "flex", padding: 4 }}><Svg d={I.trash} size={18} /></span>}
                  </div>
                ))}
                <input ref={fontFileRef} type="file" accept=".ttf,.otf,.woff,.woff2" onChange={onFontFile} style={{ display: "none" }} />
                <div style={S.menuItem} onClick={() => fontFileRef.current && fontFileRef.current.click()}>
                  <span style={{ color: ACC, display: "flex" }}><Svg d={I.plus} size={20} /></span>
                  Добавить шрифт (TTF/OTF)
                </div>
              </>
            )}
            {settingsPage === "sort" && (
              <div style={S.menuItem} onClick={() => { const v = !sysTop; setSysTop(v); ls.set("fm_systop_v2", v ? "1" : "0"); }}>
                <span style={{ color: sysTop ? ACC : SUB, display: "flex" }}><Svg d={I.folder} size={20} /></span>
                Системные папки всегда сверху
                <span style={{ marginLeft: "auto", ...S.tgl, ...(sysTop ? S.tglOn : {}) }}><span style={{ ...S.knob, ...(sysTop ? S.knobOn : {}) }} /></span>
              </div>
            )}
            {settingsPage === "player" && (
              <>
                <div style={S.menuItem} onClick={() => { const v = !audioAuto; setAudioAuto(v); ls.set(AUTONEXTKEY, v ? "1" : "0"); Apps.audioConfig({ autoNext: v }).catch(() => {}); }}>
                  <span style={{ color: audioAuto ? ACC : SUB, display: "flex" }}><Svg d={I.next} size={20} /></span>
                  Автопереход к следующему треку
                  <span style={{ marginLeft: "auto", ...S.tgl, ...(audioAuto ? S.tglOn : {}) }}><span style={{ ...S.knob, ...(audioAuto ? S.knobOn : {}) }} /></span>
                </div>
                <div style={{ color: SUB, fontSize: 12, lineHeight: 1.5, marginTop: 10 }}>Зацикливания нет. При выключенной опции после трека воспроизведение останавливается.</div>
              </>
            )}
            {settingsPage === "icons" && (
              <>
                <div style={{ color: SUB, fontSize: 12, lineHeight: 1.5, marginBottom: 12 }}>
                  Иконка папки меняется в меню самой папки: выделите её и выберите «Изменить иконку». Здесь можно вернуть папке обычный вид — крестик справа сбрасывает иконку на стандартную.
                </div>
                {Object.keys(iconDB).length === 0 && <div style={{ color: SUB, padding: 16, textAlign: "center" }}>Пока нет изменённых иконок</div>}
                {Object.keys(iconDB).map((k) => (
                  <div key={k} style={{ display: "flex", alignItems: "center", gap: 12, padding: "9px 2px", borderBottom: "1px solid " + LINE }}>
                    <img src={iconDB[k]} alt="" style={{ width: 40, height: 40, borderRadius: 11, objectFit: "cover", flexShrink: 0 }} />
                    <span style={{ flex: 1, minWidth: 0 }}>
                      <span style={{ fontSize: 14, display: "block", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{baseName(k) || "Storage"}</span>
                      <span style={{ fontSize: 11, color: SUB, wordBreak: "break-all", display: "block" }}>{"Internal/" + (k || "")}</span>
                    </span>
                    <span onClick={() => { const db = { ...iconDB }; delete db[k]; saveIconDB(db); }} style={{ color: RED, display: "flex", padding: 6 }}><Svg d={I.trash} size={18} /></span>
                  </div>
                ))}
              </>
            )}
          </div>
        </div>
      )}

      {/* МЕНЮ ЗАДАЧ БУФЕРА */}
      {pasteMenu && clip && clip.length > 0 && (
        <div style={S.backdrop} onClick={() => setPasteMenu(false)}>
          <div style={S.sheet} onClick={(e) => e.stopPropagation()}>
            <div style={{ ...S.sheetTitle }}>Буфер ({clip.length})</div>
            <div style={{ maxHeight: "50vh", overflowY: "auto" }}>
              {clip.slice().reverse().map((t, idx) => (
                <div key={t.id} style={{ display: "flex", alignItems: "center", gap: 12, padding: "11px 2px", borderBottom: "1px solid " + LINE }}>
                  <span style={{ color: t.mode === "cut" ? GOLD : "#6FD3A8", display: "flex" }}><Svg d={t.mode === "cut" ? I.cut : I.copy} size={20} /></span>
                  <span style={{ flex: 1, minWidth: 0 }}>
                    <span style={{ fontSize: 14, display: "block" }}>{clip.length - idx}. {t.arc ? (t.arc.entries.length === 1 ? String(t.arc.entries[0]).split("/").pop() : t.arc.entries.length + " объектов") : t.items.length === 1 ? t.items[0].name : t.items.length + " объектов"}</span>
                    <span style={{ fontSize: 12, color: SUB }}>{t.mode === "cut" ? "переместить" : "копировать"}{t.arc ? " · из архива " + t.arc.name : t.srcPath ? " · из " + (baseName(t.srcPath) || "Storage") : ""}</span>
                  </span>
                  <span onClick={() => dropTask(t.id)} style={{ color: SUB, display: "flex", padding: 4 }}><Svg d={I.x} size={18} /></span>
                </div>
              ))}
            </div>
            <button style={{ ...S.accessBtn, width: "100%", marginTop: 14, padding: "12px" }} onClick={pasteAll}>Всё сюда</button>
          </div>
        </div>
      )}

      {/* МЕНЮ ЗАДАЧ — конец */}
      {/* ПРОГРЕСС КОПИРОВАНИЯ */}
      {progress && !progress.bg && !conflict && !opErr && !spaceAsk && (() => {
        // процент: нативное задание — по байтам; старые операции — по элементам с учётом внутрифайлового прогресса
        const sub = progress.sub;
        const nat = !!progress.native;
        const pct = nat
          ? (progress.bytesTotal > 0 ? Math.min(100, Math.round(progress.bytesDone * 100 / progress.bytesTotal)) : (progress.filesTotal > 0 ? Math.round(progress.filesDone * 100 / progress.filesTotal) : 0))
          : (progress.total ? Math.round(((progress.current + (sub && sub.total ? sub.done / sub.total : 0)) / progress.total) * 100) : 0);
        const label = progress.mode === "del" ? "Удаление" : progress.mode === "cut" ? "Перемещение" : progress.mode === "ext" ? "Распаковка" : progress.mode === "zip" ? "Архивирование" : "Копирование";
        const icon = progress.mode === "del" ? I.trash : progress.mode === "cut" ? I.cut : progress.mode === "ext" || progress.mode === "zip" ? I.archive : I.copy;
        const stateTxt = nat ? (progress.state === "queued" ? "в очереди" : progress.state === "scan" ? "подсчёт объёма…" : progress.state === "ask" ? "ждёт ответа" : progress.paused ? "на паузе" : "") : "";
        const counter = nat ? (progress.filesTotal ? progress.filesDone + " из " + progress.filesTotal : "") : Math.min(progress.current + (sub ? 1 : 0), progress.total) + " из " + progress.total;
        const done = pct >= 100 && nat && progress.state !== "scan";
        const pretty = (p) => (p || "").replace(/^file:\/\//, "").replace(/^\/storage\/emulated\/0/, "Внутренняя память");
        const elapsed = progress.startedAt ? Math.max(0, Math.round((Date.now() - progress.startedAt) / 1000)) : 0;
        return (
        <div style={S.backdrop} onClick={(e) => e.stopPropagation()}>
          <div style={{ ...S.sheet, padding: "16px 16px 28px" }} onClick={(e) => e.stopPropagation()}>
            {/* заголовок */}
            <div style={{ display: "flex", alignItems: "center", gap: 11, marginBottom: 12 }}>
              <span style={{ color: done ? ACC : progress.paused ? SUB : ACC, display: "flex", flexShrink: 0 }}><Svg d={done ? I.check : icon} size={26} /></span>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ color: TXT, fontSize: 18, fontWeight: 700, lineHeight: 1.2 }}>{label}{counter ? " " + counter : ""}</div>
                {stateTxt ? <div style={{ color: progress.paused ? GOLD : SUB, fontSize: 13, marginTop: 3 }}>{stateTxt}</div> : null}
              </div>
              <div style={{ color: TXT, fontSize: 20, fontWeight: 700, flexShrink: 0 }}>{pct}%</div>
            </div>

            {/* полоса */}
            <div style={{ height: 12, background: ROW2, borderRadius: 6, overflow: "hidden", marginBottom: 12, border: "1px solid " + LINE }}>
              <div style={{ height: "100%", width: pct + "%", background: progress.paused ? SUB : ACC, transition: "width .2s", boxShadow: done ? "0 0 12px " + ACC : "none" }} />
            </div>

            {/* что копируется и с какой скоростью */}
            <div style={{ background: ROW2, borderRadius: 14, border: "1px solid " + LINE, padding: "11px 13px", marginBottom: 12 }}>
              <div style={{ color: TXT, fontSize: 15, fontWeight: 600, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
                {sub && sub.name ? sub.name : (progress.name || "…")}{sub && sub.total ? "  (" + sub.done + "/" + sub.total + ")" : ""}
              </div>
              {nat && progress.bytesTotal > 0 && (
                <div style={{ display: "flex", flexWrap: "wrap", gap: "4px 14px", marginTop: 7 }}>
                  <span style={{ color: TXT, fontSize: 14, fontWeight: 600 }}>{fmtSizeShort(progress.bytesDone)} <span style={{ color: SUB, fontWeight: 400 }}>из</span> {fmtSizeShort(progress.bytesTotal)}</span>
                  {progress.speed > 0 && !progress.paused ? <span style={{ color: ACC, fontSize: 14, fontWeight: 600 }}>{fmtSizeShort(progress.speed)}/с</span> : null}
                  {progress.eta >= 0 && progress.speed > 0 && !progress.paused ? <span style={{ color: SUB, fontSize: 14 }}>осталось {fmtTime(progress.eta * 1000)}</span> : null}
                  {elapsed > 2 ? <span style={{ color: SUB, fontSize: 14 }}>прошло {fmtTime(elapsed * 1000)}</span> : null}
                </div>
              )}
              {progress.queued > 0 ? <div onClick={openJobs} style={{ color: GOLD, fontSize: 13, marginTop: 6, textDecoration: "underline" }}>в очереди ещё заданий: {progress.queued} — показать</div> : null}
              {(progress.failed > 0 || progress.skipped > 0) ? (
                <div style={{ color: SUB, fontSize: 13, marginTop: 6 }}>
                  {progress.skipped > 0 ? "пропущено: " + progress.skipped : ""}{progress.skipped > 0 && progress.failed > 0 ? " · " : ""}{progress.failed > 0 ? <span style={{ color: RED }}>{"с ошибкой: " + progress.failed}</span> : null}
                </div>
              ) : null}
            </div>

            {/* откуда и куда */}
            {nat && (progress.srcPath || progress.destPath) && (
              <div style={{ marginBottom: 12 }}>
                <div onClick={() => setProgMore((v) => !v)} style={{ display: "flex", alignItems: "center", gap: 7, color: SUB, fontSize: 14 }}>
                  <span style={{ display: "flex", transform: progMore ? "rotate(180deg)" : "none", transition: "transform .15s" }}><Svg d={I.chev} size={18} /></span>
                  Подробности
                </div>
                {progMore && (
                  <div style={{ background: ROW2, borderRadius: 14, border: "1px solid " + LINE, padding: "11px 13px", marginTop: 8 }}>
                    <div style={{ color: SUB, fontSize: 12, textTransform: "uppercase", letterSpacing: 0.4 }}>Из</div>
                    <div style={{ color: TXT, fontSize: 13.5, wordBreak: "break-all", marginBottom: 8 }}>{pretty(progress.srcPath) || "—"}</div>
                    <div style={{ color: SUB, fontSize: 12, textTransform: "uppercase", letterSpacing: 0.4 }}>В</div>
                    <div style={{ color: TXT, fontSize: 13.5, wordBreak: "break-all" }}>{pretty(progress.destPath) || "—"}</div>
                  </div>
                )}
              </div>
            )}

            {/* кнопки */}
            <div style={{ display: "flex", gap: 10 }}>
              <button style={{ flex: 1, background: ROW2, border: "1px solid " + LINE, borderRadius: 14, color: TXT, fontSize: 15, fontWeight: 600, padding: "13px 0" }}
                onClick={() => { const pr = progress; setProgress((p) => ({ ...p, bg: true })); if (!pr.native) { const lbl = pr.mode === "del" ? "Удаление" : pr.mode === "cut" ? "Перемещение" : pr.mode === "ext" ? "Распаковка" : pr.mode === "zip" ? "Архивирование" : "Копирование"; Apps.opBegin({ title: lbl, text: pr.name || "" }).catch(() => {}); } }}>В фоне</button>
              {nat && progress.state !== "scan" && (
                <button style={{ flex: 1, background: progress.paused ? "var(--accbg)" : ROW2, border: "1px solid " + (progress.paused ? ACC : LINE), borderRadius: 14, color: progress.paused ? ACC : TXT, fontSize: 15, fontWeight: 600, padding: "13px 0" }}
                  onClick={() => Apps.xferPause({ on: !progress.paused }).catch(() => {})}>{progress.paused ? "Продолжить" : "Пауза"}</button>
              )}
              <button style={{ flex: 1, background: "rgba(224,82,82,.13)", border: "1px solid rgba(224,82,82,.5)", borderRadius: 14, color: RED, fontSize: 15, fontWeight: 700, padding: "13px 0" }}
                onClick={() => { if (nat) Apps.xferCancel({ id: progress.id }).catch(() => {}); else cancelRef.current = true; }}>Отменить</button>
            </div>
          </div>
        </div>
        );
      })()}
      {progress && progress.bg && !progress.native && (() => {
        const sub = progress.sub;
        const pct = progress.total ? Math.round(((progress.current + (sub && sub.total ? sub.done / sub.total : 0)) / progress.total) * 100) : 0;
        const label = progress.mode === "del" ? "Удаление" : progress.mode === "cut" ? "Перемещение" : progress.mode === "ext" ? "Распаковка" : progress.mode === "zip" ? "Архивирование" : "Копирование";
        if (!progress.silent) Apps.notifyProgress({ title: label, text: (sub && sub.name) || progress.name || "", progress: pct, max: 100 }).catch(() => {});
        return null; // прогресс живёт в шторке — внизу ничего не показываем
      })()}
      {progress && progress.bg && progress.native && (() => {
        const pctB = progress.bytesTotal > 0 ? Math.min(100, Math.round(progress.bytesDone * 100 / progress.bytesTotal)) : 0;
        return (
          <div onClick={() => setProgress((p) => ({ ...p, bg: false }))}
            style={{ position: "fixed", left: 12, right: 12, bottom: "calc(150px + env(safe-area-inset-bottom))", zIndex: 1100, background: BAR, borderRadius: 16, padding: "10px 13px", boxShadow: "var(--barsh)", border: "1px solid " + LINE }}>
            <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
              <span style={{ color: progress.paused ? SUB : ACC, display: "flex", flexShrink: 0 }}><Svg d={progress.mode === "cut" ? I.cut : I.copy} size={20} /></span>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontSize: 14, fontWeight: 600, color: TXT, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{progress.name || (progress.mode === "cut" ? "Перемещение" : "Копирование")}</div>
                <div style={{ fontSize: 12.5, color: SUB, marginTop: 1 }}>
                  {progress.filesTotal ? progress.filesDone + " из " + progress.filesTotal : ""}
                  {progress.speed > 0 && !progress.paused ? " · " + fmtSizeShort(progress.speed) + "/с" : (progress.paused ? " · на паузе" : "")}
                </div>
              </div>
              <span style={{ fontSize: 16, fontWeight: 700, color: TXT, flexShrink: 0 }}>{pctB}%</span>
            </div>
            <div style={{ height: 6, background: ROW2, borderRadius: 3, overflow: "hidden", marginTop: 8 }}>
              <div style={{ height: "100%", width: pctB + "%", background: progress.paused ? SUB : ACC, transition: "width .2s" }} />
            </div>
          </div>
        );
      })()}

      {fileDrag && (
        <div style={{ position: "fixed", left: 0, top: 0, zIndex: 1500, pointerEvents: "none", transform: "translate3d(" + (fileDrag.x - 26) + "px," + (fileDrag.y - 58) + "px,0)" }}>
          <div style={{ display: "flex", alignItems: "center", gap: 6, background: BAR, color: TXT, borderRadius: 14, padding: "8px 12px", boxShadow: "0 8px 24px rgba(0,0,0,.45)", border: "1px solid " + LINE }}>
            <span style={{ color: ACC, display: "flex" }}><Svg d={fileDrag.dir ? I.folder : I.copy} size={18} /></span>
            <span style={{ fontSize: 13, fontWeight: 600 }}>{fileDrag.count}</span>
          </div>
        </div>
      )}
      {dropMenu && (
        <>
          <div style={{ position: "fixed", inset: 0, zIndex: 1490 }} onClick={() => setDropMenu(null)} />
          <div style={{ ...S.menu, position: "fixed", zIndex: 1495, left: Math.max(8, Math.min(dropMenu.x - 90, (window.innerWidth || 360) - 200)), top: Math.max(8, Math.min(dropMenu.y - 20, (window.innerHeight || 700) - 170)), minWidth: 180, transformOrigin: "top left" }}>
            <div style={{ ...S.menuItem, color: SUB, fontSize: 12, pointerEvents: "none" }}>в «{dropMenu.label}»</div>
            <div style={S.menuItem} onClick={() => { const m = dropMenu; setDropMenu(null); exitSel(); runQueue([{ id: Date.now(), mode: "copy", items: m.items, srcPath: m.srcPath }], m.destPath); }}><span style={{ color: ACC, display: "flex" }}><Svg d={I.copy} size={20} /></span>Копировать сюда</div>
            <div style={S.menuItem} onClick={() => { const m = dropMenu; setDropMenu(null); exitSel(); runQueue([{ id: Date.now(), mode: "cut", items: m.items, srcPath: m.srcPath }], m.destPath); }}><span style={{ color: ACC, display: "flex" }}><Svg d={I.cut} size={20} /></span>Переместить сюда</div>
            <div style={{ ...S.menuItem, color: SUB }} onClick={() => setDropMenu(null)}><span style={{ display: "flex" }}><Svg d={I.x} size={20} /></span>Отмена</div>
          </div>
        </>
      )}
      {toast && <div style={S.toast}>{toast}</div>}

      <style>{`
        @keyframes fm-in-r{from{transform:translateX(100%)}to{transform:translateX(0)}}
        @keyframes fm-in-l{from{transform:translateX(-100%)}to{transform:translateX(0)}}
        @keyframes dropGrow{from{opacity:0;transform:scale(.88)}to{opacity:1;transform:scale(1)}}
        @keyframes growSheet{from{opacity:0;transform:scale(.35)}to{opacity:1;transform:scale(1)}}
        @keyframes drawerIn{from{transform:translateX(-100%)}to{transform:translateX(0)}}
        @keyframes sUp{from{transform:translateY(60px);opacity:0}to{transform:translateY(0);opacity:1}}
        @keyframes fS{from{opacity:0}to{opacity:1}}
        @keyframes dlspin{to{transform:rotate(360deg)}}
        @keyframes cbPop{0%{transform:scale(0);opacity:0}60%{transform:scale(1.25)}100%{transform:scale(1);opacity:1}}
        @keyframes pulse{0%{transform:scale(1)}40%{transform:scale(1.35)}100%{transform:scale(1)}}
        @keyframes toastUp{0%{transform:translateX(-50%) translateY(40px);opacity:0}65%{transform:translateX(-50%) translateY(-6px);opacity:1}100%{transform:translateX(-50%) translateY(0)}}
        @keyframes popCenter{from{opacity:0;transform:translateX(-50%) scale(.9)}to{opacity:1;transform:translateX(-50%) scale(1)}}
        *{box-sizing:border-box;-webkit-tap-highlight-color:transparent;-webkit-user-select:none;user-select:none}
        input{-webkit-user-select:text;user-select:text}
        body{margin:0}::-webkit-scrollbar{width:0;height:0}
        ::selection{background:var(--acc);color:#fff}input::selection,textarea::selection{background:var(--acc);color:#fff}
      `}</style>
    </div>
  );
}

const Zone = ({ children }) => <div style={{ flex: 1, display: "flex" }}>{children}</div>;
const Prop = ({ k, v, onClick, link }) => (
  <div onClick={onClick} style={{ padding: "10px 0", borderBottom: "1px solid " + LINE }}>
    <div style={{ fontSize: 12, color: SUB, marginBottom: 3 }}>{k}</div>
    <div style={{ fontSize: 14, color: link ? ACC : TXT, wordBreak: "break-all" }}>{v}</div>
  </div>
);
function SheetInput({ title, value, placeholder, onChange, onCancel, onOk, okText }) {
  return (
    <>
      <div style={S.sheetTitle}>{title}</div>
      <input autoFocus value={value} placeholder={placeholder} onChange={(e) => onChange(e.target.value)} onKeyDown={(e) => e.key === "Enter" && onOk()} style={S.sheetField} />
      <div style={{ display: "flex", gap: 10 }}>
        <button style={S.sheetGhost} onClick={onCancel}>Отмена</button>
        <button style={S.sheetOk} onClick={onOk}>{okText}</button>
      </div>
    </>
  );
}
function Btn({ onClick, icon, text, label, accent, red, flexNone, disabled }) {
  const color = disabled ? "#5c4d3e" : red ? RED : accent ? ACC : INK;
  return (
    <button onClick={disabled ? undefined : onClick} style={{ ...S.btn, flex: flexNone ? "none" : 1, minWidth: flexNone ? 52 : undefined, color }}>
      <span style={{ display: "flex", height: 28, alignItems: "center", fontSize: 22, fontWeight: 700 }}>{icon ? <Svg d={icon} size={25} /> : text}</span>
      {label ? <span style={S.btnLabel}>{label}</span> : null}
    </button>
  );
}

const S = {
  app: { position: "relative", display: "flex", flexDirection: "column", height: "100vh", background: BG, color: TXT, fontFamily: "system-ui,-apple-system,Roboto,sans-serif", overflow: "hidden" },
  tabsbar: { position: "relative", zIndex: 70, display: "flex", alignItems: "center", background: "var(--bar)", flexShrink: 0, height: 50, margin: "8px 8px 6px", borderRadius: 26, boxShadow: "var(--barsh)" },
  tabs: { display: "flex", overflowX: "auto", flex: 1, alignItems: "center", padding: "0 4px", height: "100%", scrollbarWidth: "none" },
  tab: { display: "flex", alignItems: "center", gap: 6, padding: "0 12px", height: 34, borderRadius: 17, fontSize: 13.5, color: SUB, whiteSpace: "nowrap", background: "var(--chip)", flexShrink: 0, border: "1px solid transparent" },
  tabActive: { color: ACC, background: "var(--accbg)", border: "1px solid " + ACC, fontWeight: 600, boxShadow: "0 0 0 1px var(--accbg), 0 2px 8px var(--accbg)" },
  tabX: { fontSize: 17, color: SUB, padding: "0 2px" },
  hbtn: { border: "none", background: "rgba(120,120,128,.16)", color: TXT, width: 34, height: 34, borderRadius: 17, flexShrink: 0, display: "flex", alignItems: "center", justifyContent: "center", padding: 0 },
  crumb: { position: "relative", zIndex: 6, height: 30, display: "flex", alignItems: "center", padding: "0 16px", fontSize: 12.5, background: "transparent", flexShrink: 0, overflow: "visible", whiteSpace: "nowrap" },
  list: { flex: 1, overflowY: "auto", overflowX: "hidden", display: "flex", flexDirection: "column" },
  slideWrap: { display: "flex", flexDirection: "column" },
  note: { color: SUB, textAlign: "center", padding: "60px 24px", lineHeight: 1.6 },
  row: { display: "flex", alignItems: "center", gap: 14, padding: "10px 14px", touchAction: "pan-y", position: "relative", contentVisibility: "auto", containIntrinsicSize: "0 68px" },
  rowLine: { position: "absolute", left: 72, right: 0, bottom: 0, height: 1, background: "var(--hair)" },
  sep: { height: 1, background: "var(--hair)", margin: "4px 0" },
  iconWrap: { width: 44, height: 44, borderRadius: 13, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 },
  iconImg: { width: "100%", height: "100%", objectFit: "cover", borderRadius: 13 },
  folderThumb: { position: "absolute", right: 0, bottom: 0, width: 28, height: 28, borderRadius: 8, objectFit: "cover", border: "2px solid " + BG, opacity: 0.95 },
  cbk: { width: 22, height: 22, borderRadius: 6, background: ACC, color: "#fff", display: "flex", alignItems: "center", justifyContent: "center", animation: "cbPop .26s cubic-bezier(.2,.9,.3,1.3)" },
  cbkOff: { width: 22, height: 22, borderRadius: 6, border: "2px solid " + ACC, background: "transparent" },
  rowMid: { flex: 1, minWidth: 0, display: "flex", flexDirection: "column", gap: 3 },
  rowDot: { color: "var(--sub)", opacity: 0.45, flexShrink: 0 },
  hereDot: { width: 7, height: 7, borderRadius: 4, background: "var(--acc)", flexShrink: 0, marginTop: 5, alignSelf: "flex-start" },
  rowDate: { fontSize: 12.5, color: SUB },
  rowSize: { fontSize: 11.5, color: "rgba(176,164,152,.5)", flexShrink: 0, marginLeft: 6 },
  rowNum: { fontSize: 13, color: "var(--sub)", fontWeight: 600, flexShrink: 0 },                 // вес — цветом даты
  rowCount: { fontSize: 12, color: "var(--sub)", fontWeight: 600, flexShrink: 0 },               // число объектов — чуть мельче
  rowDir: { background: "var(--chip)", borderRadius: 14, marginBottom: 6, boxShadow: "0 1px 3px rgba(0,0,0,.12)" },
  arcSelBar: { position: "absolute", left: "50%", transform: "translateX(-50%)", bottom: "calc(80px + env(safe-area-inset-bottom))", display: "flex", alignItems: "center", gap: 8, padding: "6px 8px 6px 14px", background: BAR, borderRadius: 22, boxShadow: "0 1px 0 rgba(255,255,255,.07) inset, 0 4px 12px rgba(0,0,0,.4), 0 18px 48px rgba(0,0,0,.62)", animation: "popCenter .2s cubic-bezier(.2,.9,.3,1.1)" },
  arcSelCancel: { background: "transparent", border: "none", borderRadius: 14, color: SUB, fontSize: 13, padding: "7px 12px" },
  arcSelGo: { display: "inline-flex", alignItems: "center", gap: 5, background: ACC, border: "none", borderRadius: 14, color: "#fff", fontWeight: 700, fontSize: 13, padding: "7px 14px" },
  arcScreen: { position: "fixed", top: 62, left: 0, right: 0, bottom: 0, zIndex: 40, background: BG, display: "flex", flexDirection: "column" },
  settingsScreen: { position: "fixed", inset: 0, zIndex: 1600, background: BG, display: "flex", flexDirection: "column", paddingTop: "env(safe-area-inset-top)" },
  cnt: { background: "var(--accbg)", color: GOLD, fontSize: 12, fontWeight: 700, padding: "2px 9px", borderRadius: 10, flexShrink: 0 },
  rowSel: { background: "var(--accbg)" },
  rowDrop: { background: "var(--acc)", color: "#fff", boxShadow: "0 0 0 2px var(--acc)" },
  name: { flex: 1, fontSize: 15, lineHeight: 1.25, overflow: "hidden", wordBreak: "break-word" },
  checkOn: { width: 26, height: 26, borderRadius: 13, background: ACC, color: "#fff", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 15 },
  searchBar: { position: "fixed", left: 10, right: 10, zIndex: 1450, display: "flex", alignItems: "center", background: BAR, padding: 8, gap: 8, borderRadius: 18, boxShadow: "var(--barsh)" },
  searchInput: { flex: 1, padding: "10px 12px", borderRadius: 8, border: "1px solid " + LINE, background: BAR, color: TXT, fontSize: 15, outline: "none" },
  searchClose: { border: "none", background: "transparent", color: SUB, fontSize: 24, width: 40 },
  bottom: { display: "flex", alignItems: "center", background: "var(--bar)", flexShrink: 0, borderRadius: 30, margin: "4px 8px calc(8px + env(safe-area-inset-bottom))", boxShadow: "var(--barsh)" },
  btn: { border: "none", background: "transparent", padding: "6px 6px 7px", display: "flex", flexDirection: "column", alignItems: "center", gap: 2 },
  selCount: { width: 26, height: 26, borderRadius: 13, background: ACC, display: "inline-flex", alignItems: "center", justifyContent: "center", flexShrink: 0, lineHeight: 0, boxShadow: "0 1px 3px rgba(0,0,0,.3), inset 0 1px 0 rgba(255,255,255,.25)" },
  btnLabel: { fontSize: 10, color: SUB, whiteSpace: "nowrap" },
  overlay: { position: "fixed", inset: 0, zIndex: 8 },
  menu: { position: "absolute", zIndex: 9, background: BAR, borderRadius: 14, overflow: "hidden", boxShadow: "var(--barsh)", minWidth: 200, animation: "dropGrow .2s cubic-bezier(.2,.9,.3,1.2)" },
  menuItem: { display: "flex", alignItems: "center", gap: 12, padding: "13px 14px", fontSize: 14, color: TXT, whiteSpace: "nowrap" },
  createItem: { padding: "14px 22px", fontSize: 15, color: TXT },
  ctxTitle: { padding: "10px 14px", fontSize: 12, color: SUB, borderBottom: "1px solid " + LINE, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap", maxWidth: 210 },
  tgl: { width: 38, height: 22, borderRadius: 11, background: "var(--tgloff)", position: "relative", flexShrink: 0, transition: "background .15s" },
  tglOn: { background: ACC },
  knob: { position: "absolute", top: 2, left: 2, width: 18, height: 18, borderRadius: 9, background: "#fff", transition: "left .15s" },
  knobOn: { left: 18 },
  backdrop: { position: "fixed", inset: 0, background: "rgba(0,0,0,.62)", display: "flex", alignItems: "flex-end", zIndex: 1400, backdropFilter: "blur(5px)", animation: "fS .2s ease" },
  sheet: { width: "100%", maxWidth: 420, margin: "0 auto", background: BAR, borderRadius: "22px 22px 0 0", padding: "20px 20px 36px", animation: "sUp .34s cubic-bezier(.2,.9,.3,1)", maxHeight: "88vh", overflowY: "auto", boxShadow: "0 -8px 30px rgba(0,0,0,.22), 0 -2px 8px rgba(0,0,0,.12)" },
  sheetTitle: { fontWeight: 700, fontSize: 17, marginBottom: 16 },
  sheetField: { width: "100%", background: ROW2, border: "1px solid " + LINE, borderRadius: 12, padding: "12px 14px", color: TXT, fontSize: 15, marginBottom: 16, outline: "none" },
  sheetGhost: { flex: 1, background: ROW2, border: "1px solid " + LINE, borderRadius: 12, padding: 13, color: SUB, fontSize: 14, cursor: "pointer" },
  sheetOk: { flex: 1, background: ACC, border: "none", borderRadius: 12, padding: 13, color: "#fff", fontSize: 14, fontWeight: 700, cursor: "pointer" },
  savePop: { position: "fixed", top: "calc(68px + env(safe-area-inset-top))", left: 10, right: 10, zIndex: 1260, display: "flex", alignItems: "center", gap: 10, padding: "12px 16px", background: BAR, color: TXT, borderRadius: 18, boxShadow: "var(--barsh)", animation: "dropGrow .22s cubic-bezier(.2,.9,.3,1.1)" },
  saveBar: { position: "fixed", left: 8, right: 8, bottom: "calc(8px + env(safe-area-inset-bottom))", zIndex: 1260, display: "flex", alignItems: "center", gap: 8, height: 56, padding: "0 10px", background: BAR, borderRadius: 26, boxShadow: "0 1px 0 rgba(255,255,255,.07) inset, 0 4px 12px rgba(0,0,0,.4), 0 18px 48px rgba(0,0,0,.62)", animation: "sUp .28s cubic-bezier(.2,.9,.3,1)" },
  saveBtnOpen: { flex: 1, display: "inline-flex", alignItems: "center", justifyContent: "center", gap: 6, height: 42, background: "transparent", border: "1px solid " + LINE, borderRadius: 16, color: TXT, fontWeight: 600, fontSize: 14 },
  saveBtnSave: { flex: 1, display: "inline-flex", alignItems: "center", justifyContent: "center", gap: 6, height: 42, background: "var(--accbg)", border: "1px solid " + ACC, borderRadius: 16, color: ACC, fontWeight: 600, fontSize: 14 },
  saveBtnCancel: { flex: 1, display: "inline-flex", alignItems: "center", justifyContent: "center", gap: 6, height: 42, background: "transparent", border: "1px solid " + LINE, borderRadius: 16, color: SUB, fontWeight: 600, fontSize: 14 },
  accessBar: { display: "flex", alignItems: "center", gap: 10, padding: "10px 14px", background: "var(--accbg)", borderBottom: "1px solid " + LINE },
  accessBtn: { flexShrink: 0, background: ACC, border: "none", borderRadius: 8, color: "#fff", fontSize: 13, fontWeight: 700, padding: "8px 14px" },
  sortRow: { padding: "13px 4px", fontSize: 15, color: TXT, borderBottom: "1px solid " + LINE, display: "flex", alignItems: "center" },
  iconBtn: { border: "none", background: "rgba(120,120,128,.16)", borderRadius: 12, width: 38, height: 38, display: "flex", alignItems: "center", justifyContent: "center" },
  chip: { flexShrink: 0, background: "rgba(120,120,128,.12)", border: "1px solid transparent", borderRadius: 15, padding: "7px 14px", color: SUB, fontSize: 13, whiteSpace: "nowrap" },
  chipOn: { background: ACC, borderColor: ACC, color: "#fff" },
  appRow: { display: "flex", alignItems: "center", gap: 14, padding: "10px 2px", borderBottom: "1px solid " + LINE },
  cbox: { width: 22, height: 22, borderRadius: 6, border: "2px solid " + SUB, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 13, color: "#fff", flexShrink: 0 },
  cboxOn: { background: ACC, borderColor: ACC },
  toast: { position: "fixed", left: "50%", bottom: 90, transform: "translateX(-50%)", pointerEvents: "none", background: "var(--bar)", color: TXT, padding: "10px 18px", borderRadius: 20, fontSize: 13, boxShadow: "var(--barsh)", zIndex: 1500, animation: "toastUp .34s cubic-bezier(.2,.9,.3,1)", maxWidth: "80%", textAlign: "center" },
};
