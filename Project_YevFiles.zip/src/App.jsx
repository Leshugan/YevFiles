import React, { useState, useEffect, useRef, useCallback, useLayoutEffect, useDeferredValue } from "react";
import { Filesystem, Directory, Encoding } from "@capacitor/filesystem";
import { App as CapApp } from "@capacitor/app";
import { registerPlugin, Capacitor } from "@capacitor/core";
const Apps = registerPlugin("Apps");

/* ===== YevFiles — leshugan.fm =====  стиль Notenger (шоколад) */

const BG = "var(--bg)", BAR = "var(--bar)", ROW2 = "var(--row2)", ACC = "var(--acc)";
const GOLD = "var(--gold)", RED = "var(--red)", TXT = "var(--txt)", SUB = "var(--sub)", LINE = "var(--line)", INK = "var(--ink)";
const THEMES = {
  dark:  { "--bg": "#1B130B", "--bar": "#2C2219", "--row2": "#332619", "--acc": "#EF6C00", "--accbg": "rgba(239,108,0,.18)", "--gold": "#F5A623", "--red": "#E05252", "--txt": "#F2EAE0", "--ink": "#E0D5C8", "--sub": "#B0A498", "--line": "#4A3A2A", "--chip": "rgba(255,255,255,.06)", "--hair": "rgba(255,255,255,.07)", "--tgloff": "#4A3A2A", "--barsh": "0 6px 18px rgba(0,0,0,.34), 0 1px 4px rgba(0,0,0,.26)" },
  light: { "--bg": "#EEF1F4", "--bar": "#FFFFFF", "--row2": "#E4E8EC", "--acc": "#2F80ED", "--accbg": "rgba(47,128,237,.14)", "--gold": "#2F80ED", "--red": "#D14343", "--txt": "#1E2329", "--ink": "#3D4754", "--sub": "#6B7280", "--line": "#D3D8DE", "--chip": "rgba(0,0,0,.05)", "--hair": "rgba(0,0,0,.08)", "--tgloff": "#C2C8D0", "--barsh": "0 8px 26px rgba(17,24,39,.14), 0 2px 6px rgba(17,24,39,.06)" },
};
const DIR = Directory.ExternalStorage;
const APP_VERSION = "1.003";
const TKEY = "fm_tabs_v1", SKEY = "fm_startup_v1", METAKEY = "fm_meta_v1", SORTKEY = "fm_sort_v1";
const DEFKEY = "fm_defaults_v1", HIDEKEY = "fm_hideapps_v1", ICONKEY = "fm_foldericons_v1", ORDERKEY = "fm_menuorder_v1";
// ключи настроек для резервной копии (кэши и токены НЕ включаем)
const BACKUP_KEYS = ["fm_theme_v1", "fm_themebtn_v1", "fm_fonts_v1", "fm_sort_v1", "fm_systop_v2", "fm_view_v1", "fm_defaults_v1", "fm_foldericons_v1", "fm_menuorder_v1", "fm_drawer_order_v1", "fm_hideapps_v1", "fm_meta_v1", "fm_startup_v1", "fm_audio_autonext_v1"];
const BACKUP_TABS_KEYS = ["fm_tabs_v1", "fm_startup_v1"];
const loadMap = (k) => { try { return JSON.parse(ls.get(k)) || {}; } catch { return {}; } };
const saveMap = (k, m) => ls.set(k, JSON.stringify(m));
const OPEN_AS = [["*/*", "Любой тип"], ["text/plain", "Текст"], ["image/*", "Изображение"], ["video/*", "Видео"], ["audio/*", "Аудио"], ["application/pdf", "PDF"]];

let mem = null;
const ls = { get: (k) => { try { return localStorage.getItem(k); } catch { return null; } },
  set: (k, v) => { try { localStorage.setItem(k, v); } catch {} },
  del: (k) => { try { localStorage.removeItem(k); } catch {} } };
function buildInitial() {
  const saved = loadTabs();
  const base = saved && saved.length ? saved : [{ id: 1, path: "" }];
  let active = base.findIndex((t) => t.startup);
  if (active < 0) active = 0;
  return { base, active };
}
const loadTabs = () => { try { return JSON.parse(ls.get(TKEY)); } catch { return mem; } };
const saveTabs = (t) => { const keep = t.filter((x) => x.saved); mem = keep; ls.set(TKEY, JSON.stringify(keep)); };
const loadMeta = () => { try { const m = JSON.parse(ls.get(METAKEY)) || {}; return { hidden: new Set(m.hidden || []), pinTop: new Set(m.pinTop || []), pinBot: new Set(m.pinBot || []) }; } catch { return { hidden: new Set(), pinTop: new Set(), pinBot: new Set() }; } };
const saveMeta = (m) => ls.set(METAKEY, JSON.stringify({ hidden: [...m.hidden], pinTop: [...m.pinTop], pinBot: [...m.pinBot] }));

const join = (a, b) => (a ? a + "/" + b : b);
const parent = (p) => (p.includes("/") ? p.slice(0, p.lastIndexOf("/")) : "");
const baseName = (p) => (p.includes("/") ? p.slice(p.lastIndexOf("/") + 1) : p);
const buzz = (ms) => { try { navigator.vibrate && navigator.vibrate(ms); } catch {} };
const splitExt = (name, isDir) => {
  if (isDir) return { base: name, ext: "" };
  const i = name.lastIndexOf(".");
  if (i <= 0) return { base: name, ext: "" };
  return { base: name.slice(0, i), ext: name.slice(i + 1) };
};
const fmtSize = (b) => { if (b == null) return "—"; const u = ["Б", "КБ", "МБ", "ГБ"]; let i = 0, n = b; while (n >= 1024 && i < 3) { n /= 1024; i++; } return (i ? n.toFixed(1) : n) + " " + u[i] + (i ? " (" + b.toLocaleString("ru") + " Б)" : ""); };
const fmtTime = (ms) => { if (!ms || ms < 0) return "0:00"; const s = Math.floor(ms / 1000); return Math.floor(s / 60) + ":" + String(s % 60).padStart(2, "0"); };
const fmtShort = (b) => { if (b == null) return ""; const u = ["Б", "КБ", "МБ", "ГБ"]; let i = 0, n = b; while (n >= 1024 && i < 3) { n /= 1024; i++; } return (i ? n.toFixed(1) : n) + " " + u[i]; };
const fmtSizeShort = (b) => { if (b == null) return ""; const u = ["Б", "КБ", "МБ", "ГБ"]; let i = 0, n = b; while (n >= 1024 && i < 3) { n /= 1024; i++; } return (i ? n.toFixed(1) : n) + " " + u[i]; };
const plural = (n, a, b, c) => { const m10 = n % 10, m100 = n % 100; if (m10 === 1 && m100 !== 11) return a; if (m10 >= 2 && m10 <= 4 && (m100 < 12 || m100 > 14)) return b; return c; };
const fmtDate = (ms) => {
  if (!ms) return "";
  const d = new Date(ms), diff = Date.now() - ms;
  if (diff < 60000) return "только что";
  if (diff < 3600000) { const m = Math.floor(diff / 60000); return m + " " + plural(m, "минуту", "минуты", "минут") + " назад"; }
  if (d.toDateString() === new Date().toDateString()) { const h = Math.floor(diff / 3600000); return h + " " + plural(h, "час", "часа", "часов") + " назад"; }
  return d.toLocaleDateString("ru") + " " + d.toLocaleTimeString("ru", { hour: "2-digit", minute: "2-digit" });
};
const ago = (ms) => { if (!ms) return "—"; const d = new Date(ms), diff = (Date.now() - ms) / 60000; const rel = diff < 1 ? "только что" : diff < 60 ? Math.floor(diff) + " мин назад" : diff < 1440 ? Math.floor(diff / 60) + " ч назад" : Math.floor(diff / 1440) + " дн назад"; const p = (n) => String(n).padStart(2, "0"); return `${p(d.getHours())}:${p(d.getMinutes())}, ${p(d.getDate())}.${p(d.getMonth() + 1)}.${String(d.getFullYear()).slice(2)} · ${rel}`; };

const MIME = {
  txt: "text/plain", md: "text/plain", markdown: "text/plain", log: "text/plain", ini: "text/plain", cfg: "text/plain", conf: "text/plain", csv: "text/csv", tsv: "text/tab-separated-values", html: "text/html", htm: "text/html", xhtml: "application/xhtml+xml", json: "text/plain", json5: "text/plain", xml: "text/xml", plist: "text/xml", yml: "text/plain", yaml: "text/plain", java: "text/plain", kt: "text/plain", kts: "text/plain", js: "text/plain", mjs: "text/plain", cjs: "text/plain", jsx: "text/plain", ts: "text/plain", tsx: "text/plain", vue: "text/plain", svelte: "text/plain", py: "text/plain", pyw: "text/plain", rb: "text/plain", php: "text/plain", c: "text/plain", h: "text/plain", hpp: "text/plain", cpp: "text/plain", cxx: "text/plain", cc: "text/plain", cs: "text/plain", go: "text/plain", rs: "text/plain", swift: "text/plain", m: "text/plain", mm: "text/plain", scala: "text/plain", dart: "text/plain", lua: "text/plain", pl: "text/plain", r: "text/plain", sh: "text/plain", bash: "text/plain", zsh: "text/plain", bat: "text/plain", cmd: "text/plain", ps1: "text/plain", gradle: "text/plain", properties: "text/plain", css: "text/css", scss: "text/plain", sass: "text/plain", less: "text/plain", sql: "text/plain", toml: "text/plain", env: "text/plain", gitignore: "text/plain", dockerfile: "text/plain", makefile: "text/plain", diff: "text/plain", patch: "text/plain", srt: "text/plain", vtt: "text/plain", ass: "text/plain", tex: "text/plain",
  pdf: "application/pdf", djvu: "image/vnd.djvu", djv: "image/vnd.djvu",
  doc: "application/msword", docx: "application/vnd.openxmlformats-officedocument.wordprocessingml.document", dot: "application/msword", odt: "application/vnd.oasis.opendocument.text", ott: "application/vnd.oasis.opendocument.text", rtf: "application/rtf",
  xls: "application/vnd.ms-excel", xlsx: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", ods: "application/vnd.oasis.opendocument.spreadsheet",
  ppt: "application/vnd.ms-powerpoint", pptx: "application/vnd.openxmlformats-officedocument.presentationml.presentation", odp: "application/vnd.oasis.opendocument.presentation",
  epub: "application/epub+zip", mobi: "application/x-mobipocket-ebook", azw: "application/vnd.amazon.ebook", azw3: "application/vnd.amazon.ebook", fb2: "application/x-fictionbook+xml",
  jpg: "image/jpeg", jpeg: "image/jpeg", jpe: "image/jpeg", jfif: "image/jpeg", png: "image/png", apng: "image/apng", gif: "image/gif", webp: "image/webp", bmp: "image/bmp", dib: "image/bmp", svg: "image/svg+xml", svgz: "image/svg+xml", ico: "image/x-icon", cur: "image/x-icon", tif: "image/tiff", tiff: "image/tiff", heic: "image/heic", heif: "image/heif", avif: "image/avif", jxl: "image/jxl", raw: "image/x-panasonic-raw", dng: "image/x-adobe-dng", cr2: "image/x-canon-cr2", nef: "image/x-nikon-nef", arw: "image/x-sony-arw", psd: "image/vnd.adobe.photoshop",
  mp4: "video/mp4", m4v: "video/x-m4v", mkv: "video/x-matroska", webm: "video/webm", avi: "video/x-msvideo", mov: "video/quicktime", qt: "video/quicktime", wmv: "video/x-ms-wmv", flv: "video/x-flv", f4v: "video/x-f4v", "3gp": "video/3gpp", "3g2": "video/3gpp2", mpg: "video/mpeg", mpeg: "video/mpeg", mpe: "video/mpeg", m2v: "video/mpeg", ts: "video/mp2t", m2ts: "video/mp2t", mts: "video/mp2t", vob: "video/dvd", ogv: "video/ogg", rm: "application/vnd.rn-realmedia", rmvb: "application/vnd.rn-realmedia-vbr", divx: "video/divx", asf: "video/x-ms-asf",
  mp3: "audio/mpeg", wav: "audio/wav", wave: "audio/wav", flac: "audio/flac", aac: "audio/aac", ogg: "audio/ogg", oga: "audio/ogg", opus: "audio/opus", m4a: "audio/mp4", m4b: "audio/mp4", wma: "audio/x-ms-wma", amr: "audio/amr", aiff: "audio/aiff", aif: "audio/aiff", ape: "audio/x-ape", ac3: "audio/ac3", dts: "audio/vnd.dts", mid: "audio/midi", midi: "audio/midi", mka: "audio/x-matroska", ra: "audio/x-realaudio", au: "audio/basic", weba: "audio/webm",
  zip: "application/zip", rar: "application/vnd.rar", "7z": "application/x-7z-compressed", tar: "application/x-tar", gz: "application/gzip", tgz: "application/gzip", bz2: "application/x-bzip2", tbz: "application/x-bzip2", tbz2: "application/x-bzip2", xz: "application/x-xz", txz: "application/x-xz", lz: "application/x-lzip", lzma: "application/x-lzma", zst: "application/zstd", z: "application/x-compress", cab: "application/vnd.ms-cab-compressed", arj: "application/x-arj", lha: "application/x-lzh", lzh: "application/x-lzh", ace: "application/x-ace-compressed", iso: "application/x-iso9660-image", img: "application/x-iso9660-image", dmg: "application/x-apple-diskimage", deb: "application/vnd.debian.binary-package", rpm: "application/x-rpm", jar: "application/java-archive", war: "application/java-archive", obb: "application/octet-stream",
  apk: "application/vnd.android.package-archive", apks: "application/octet-stream", xapk: "application/octet-stream", apkm: "application/octet-stream", aab: "application/octet-stream",
  ttf: "font/ttf", otf: "font/otf", woff: "font/woff", woff2: "font/woff2", eot: "application/vnd.ms-fontobject",
  apk_: "application/vnd.android.package-archive",
};
const mimeOf = (name) => MIME[(name.split(".").pop() || "").toLowerCase()] || "*/*";
const TEXT_EXT = new Set(["txt", "md", "log", "ini", "cfg", "conf", "yml", "yaml", "java", "kt", "kts", "js", "jsx", "ts", "tsx", "py", "c", "h", "cpp", "cc", "cs", "go", "rs", "rb", "php", "swift", "sh", "bat", "gradle", "properties", "css", "sql", "lua", "toml", "xml", "json", "html", "htm", "csv"]);
const defaultOpenAs = (name) => { const e = (name.split(".").pop() || "").toLowerCase(); const m = mimeOf(name); if (TEXT_EXT.has(e)) return "text/plain"; if (m.startsWith("image/")) return "image/*"; if (m.startsWith("video/")) return "video/*"; if (m.startsWith("audio/")) return "audio/*"; if (m === "application/pdf") return "application/pdf"; return "*/*"; };

const I = {
  back: <path d="M15 18l-6-6 6-6" />,
  search: <><circle cx="11" cy="11" r="7" /><path d="M21 21l-4-4" /></>,
  check: <path d="M5 12l4 4 10-11" />,
  dl: <><path d="M12 3v12" /><path d="M7 11l5 5 5-5" /><path d="M5 21h14" /></>,
  bell: <><path d="M18 8a6 6 0 0 0-12 0c0 7-3 9-3 9h18s-3-2-3-9" /><path d="M13.7 21a2 2 0 0 1-3.4 0" /></>,
  ring: <><path d="M8 14a4 4 0 0 1 8 0" /><path d="M12 3v3M5.6 6.6l2 2M18.4 6.6l-2 2" /><rect x="4" y="14" width="16" height="6" rx="2" /><path d="M10 17h4" /></>,
  alarm: <><circle cx="12" cy="13" r="8" /><path d="M12 9v4l2 2" /><path d="M5 3L2 6M19 3l3 3" /></>,
  mic: <><rect x="9" y="3" width="6" height="11" rx="3" /><path d="M5 11a7 7 0 0 0 14 0" /><path d="M12 18v3" /></>,
  cam: <><path d="M3 8a2 2 0 0 1 2-2h2l1.5-2h7L19 6h0a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z" /><circle cx="12" cy="12.5" r="3.5" /></>,
  android: <g stroke="none"><path d="M7 6 L5.6 4.2" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" fill="none" /><path d="M17 6 L18.4 4.2" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" fill="none" /><path d="M5.5 12a6.5 6.5 0 0 1 13 0z" fill="currentColor" /><rect x="6" y="12.4" width="12" height="7.2" rx="1.6" fill="currentColor" /><rect x="3" y="12.6" width="2.4" height="6.4" rx="1.2" fill="currentColor" /><rect x="18.6" y="12.6" width="2.4" height="6.4" rx="1.2" fill="currentColor" /><circle cx="9.6" cy="8.8" r=".85" fill="#0d0d0d" /><circle cx="14.4" cy="8.8" r=".85" fill="#0d0d0d" /></g>,
  doc2: <><path d="M6 2h9l5 5v15H6z" /><path d="M14 2v6h6" /><path d="M9 13h6M9 16h6" /></>,
  gamepad: <><path d="M7.5 7h9a4.5 4.5 0 0 1 4.4 3.6l1 5A2.6 2.6 0 0 1 18.4 18l-2-2.2a2 2 0 0 0-1.5-.7H9.1a2 2 0 0 0-1.5.7L5.6 18A2.6 2.6 0 0 1 2.1 15.6l1-5A4.5 4.5 0 0 1 7.5 7z" /><path d="M6.2 10.4v2.4M5 11.6h2.4" /><circle cx="15.4" cy="10.8" r=".8" fill="currentColor" /><circle cx="17.6" cy="12.6" r=".8" fill="currentColor" /></>,
  emuPad: <><rect x="3" y="8" width="18" height="9" rx="4.5" /><path d="M7 10.5v4M5 12.5h4" /><circle cx="16" cy="11" r=".8" fill="currentColor" /><circle cx="18.2" cy="13" r=".8" fill="currentColor" /><circle cx="13.8" cy="13" r=".8" fill="currentColor" /><circle cx="16" cy="15" r=".8" fill="currentColor" /></>,
  switchCon: <><path stroke="#5AA9E6" d="M11 4H7.5A3.5 3.5 0 0 0 4 7.5v9A3.5 3.5 0 0 0 7.5 20H11z" /><circle cx="7.5" cy="8.5" r="1.1" stroke="#5AA9E6" /><path stroke="#5AA9E6" d="M6.4 14.6h2.2" /><rect x="11" y="4" width="12" height="16" rx="1.2" stroke="#CFC6BA" /><path stroke="#E60012" d="M23 4h3.5A3.5 3.5 0 0 1 30 7.5v9A3.5 3.5 0 0 1 26.5 20H23z" /><circle cx="26.5" cy="14.6" r="1.1" stroke="#E60012" /><circle cx="26.5" cy="7.6" r=".55" fill="#E60012" stroke="#E60012" /><circle cx="27.9" cy="9" r=".55" fill="#E60012" stroke="#E60012" /><circle cx="25.1" cy="9" r=".55" fill="#E60012" stroke="#E60012" /><circle cx="26.5" cy="10.4" r=".55" fill="#E60012" stroke="#E60012" /></>,
  media: <><rect x="3" y="4" width="18" height="16" rx="3" /><path d="M10 9l5 3-5 3z" fill="currentColor" /></>,
  win: <><rect x="3" y="3" width="18" height="18" rx="2" /><path d="M12 3v18M3 12h18" /></>,
  fontA: <><path d="M5 19l5-13 5 13M7 14h6" /><path d="M17 19V9M17 9c2 0 3 1 3 2s-1 2-3 2" /></>,
  launcher: <><rect x="3" y="3" width="7" height="7" rx="1.5" /><rect x="14" y="3" width="7" height="7" rx="1.5" /><rect x="3" y="14" width="7" height="7" rx="1.5" /><rect x="14" y="14" width="7" height="7" rx="1.5" /></>,
  book: <><path d="M4 4h11a3 3 0 0 1 3 3v13H7a3 3 0 0 0-3 3z" /><path d="M4 4v16" /></>,
  bookOpen: <><path d="M12 6.8c-1.7-1.1-4.3-1.6-8-1.4v11.2c3.7-.2 6.3.3 8 1.4 1.7-1.1 4.3-1.6 8-1.4V5.4c-3.7-.2-6.3.3-8 1.4z" /><path d="M12 6.8v11.2" /></>,
  tool: <><path d="M14 7a4 4 0 0 1-5 5l-5 5 2 2 5-5a4 4 0 0 0 5-5z" /><path d="M14 7l3-3 3 3-3 3z" /></>,
  home: <><path d="M3 11l9-7 9 7" /><path d="M5 10v9a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-9" /><path d="M10 20v-6h4v6" /></>,
  selectAll: <><rect x="4" y="4" width="16" height="16" rx="4" /><path d="M8.5 12l2.5 2.5 4.5-5" /></>,
  chev: <path d="M6 9l6 6 6-6" />,
  bars: <path d="M4 6h16M4 12h16M4 18h16" />,
  gdrive: <g stroke="none" fill="currentColor"><path d="M7.7 20.5h9.9l-2.6-4.5H10.3z" opacity=".55" /><path d="M9.6 3.5L2 16.7l2.5 4.3 7.6-13.2z" /><path d="M14.4 3.5H9.6l7.6 13.2h4.8z" opacity=".8" /></g>,
  refresh: <><path d="M21 12a9 9 0 1 1-2.6-6.4" /><path d="M21 4v5h-5" /></>,
  plus: <><path d="M12 5v14" /><path d="M5 12h14" /></>,
  x: <><path d="M6 6l12 12" /><path d="M18 6L6 18" /></>,
  cut: <><circle cx="6" cy="6" r="3" /><circle cx="6" cy="18" r="3" /><path d="M20 4L8.5 15.5" /><path d="M20 20L8.5 8.5" /></>,
  copy: <><rect x="9" y="9" width="11" height="11" rx="2" /><path d="M5 15V5a2 2 0 0 1 2-2h8" /></>,
  trash: <><path d="M3 6h18" /><path d="M8 6V4h8v2" /><path d="M6 6l1 14h10l1-14" /></>,
  rename: <><path d="M12 20h9" /><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4z" /></>,
  paste: <><rect x="6" y="4" width="12" height="16" rx="2" /><path d="M9 4h6v3H9z" /></>,
  info: <><circle cx="12" cy="12" r="9" /><path d="M12 11v5M12 8h.01" /></>,
  share: <><circle cx="18" cy="5" r="3" /><circle cx="6" cy="12" r="3" /><circle cx="18" cy="19" r="3" /><path d="M8.6 13.5l6.8 4M15.4 6.5l-6.8 4" /></>,
  openext: <><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6" /><path d="M15 3h6v6" /><path d="M10 14L21 3" /></>,
  dots: <g fill="currentColor" stroke="none"><circle cx="12" cy="5" r="2" /><circle cx="12" cy="12" r="2" /><circle cx="12" cy="19" r="2" /></g>,
  sun: <><circle cx="12" cy="12" r="4.5" /><path d="M12 2v2M12 20v2M4.2 4.2l1.4 1.4M18.4 18.4l1.4 1.4M2 12h2M20 12h2M4.2 19.8l1.4-1.4M18.4 5.6l1.4-1.4" /></>,
  moon: <><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z" /></>,
  sort: <><path d="M7 4v16M7 20l-3-3M7 4l3 3" /><path d="M17 20V4M17 4l3 3M17 20l-3-3" /></>,
  gear: <><circle cx="12" cy="12" r="3" /><path d="M12 2v3M12 19v3M2 12h3M19 12h3M5 5l2 2M17 17l2 2M19 5l-2 2M7 17l-2 2" /></>,
  eye: <><path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7-10-7-10-7z" /><circle cx="12" cy="12" r="3" /></>,
  drag: <><path d="M4 8h16M4 12h16M4 16h16" /></>,
  eyeOff: <><path d="M3 3l18 18" /><path d="M10.6 10.6a3 3 0 0 0 4.2 4.2" /><path d="M9.9 5.1A9.7 9.7 0 0 1 12 5c6.5 0 10 7 10 7a16 16 0 0 1-3.2 3.9M6.2 6.2A16 16 0 0 0 2 12s3.5 7 10 7a9.7 9.7 0 0 0 3.1-.5" /></>,
  pinT: <><path d="M12 3v8M8 7l4-4 4 4" /><path d="M5 14h14M5 14v6h14v-6" /></>,
  pinB: <><path d="M12 21v-8M8 17l4 4 4-4" /><path d="M5 10h14M5 10V4h14v6" /></>,
  folder: <path d="M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z" />,
  file: <><path d="M6 2h9l5 5v15H6z" /><path d="M14 2v6h6" /></>,
  txt: <><path d="M6 2h9l5 5v15H6z" /><path d="M14 2v6h6" /><path d="M9 13h6M9 16h6M9 10h3" /></>,
  pdf: <><path d="M6 2h9l5 5v15H6z" /><path d="M14 2v6h6" /><path d="M9 12h6M9 15h6M9 18h3" /></>,
  apk: <g stroke="none"><path d="M7 6 L5.6 4.2" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" fill="none" /><path d="M17 6 L18.4 4.2" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" fill="none" /><path d="M5.5 12a6.5 6.5 0 0 1 13 0z" fill="currentColor" /><rect x="6" y="12.4" width="12" height="7.2" rx="1.6" fill="currentColor" /><rect x="3" y="12.6" width="2.4" height="6.4" rx="1.2" fill="currentColor" /><rect x="18.6" y="12.6" width="2.4" height="6.4" rx="1.2" fill="currentColor" /><circle cx="9.6" cy="8.8" r=".85" fill="#0d0d0d" /><circle cx="14.4" cy="8.8" r=".85" fill="#0d0d0d" /></g>,
  lnk: <><rect x="4" y="4" width="16" height="16" rx="2" /><path d="M9 15l6-6M10.5 9H15v4.5" /></>,
  img: <><rect x="3" y="3" width="18" height="18" rx="2" /><circle cx="8.5" cy="8.5" r="1.5" /><path d="M21 15l-5-5L5 21" /></>,
  video: <><rect x="2" y="5" width="14" height="14" rx="2" /><path d="M16 10l6-3v10l-6-3z" /></>,
  audio: <><path d="M9 18V5l10-2v13" /><circle cx="6" cy="18" r="3" /><circle cx="16" cy="16" r="3" /></>,
  play: <><path d="M8 5v14l11-7z" fill="currentColor" stroke="none" /></>,
  pause: <><rect x="6" y="5" width="4" height="14" rx="1" fill="currentColor" stroke="none" /><rect x="14" y="5" width="4" height="14" rx="1" fill="currentColor" stroke="none" /></>,
  prev: <><path d="M18 5v14l-9-7z" fill="currentColor" stroke="none" /><rect x="5" y="5" width="2.4" height="14" rx="1" fill="currentColor" stroke="none" /></>,
  next: <><path d="M6 5v14l9-7z" fill="currentColor" stroke="none" /><rect x="16.6" y="5" width="2.4" height="14" rx="1" fill="currentColor" stroke="none" /></>,
  archive: <><rect x="3" y="3" width="18" height="18" rx="2" /><path d="M12 3v18M9 7h6M9 11h6" /></>,
  code: <><path d="M8 9l-4 3 4 3" /><path d="M16 9l4 3-4 3" /></>,
  star: <path d="M12 3l2.9 5.9 6.5.9-4.7 4.6 1.1 6.5L12 18.8 6.2 21.8l1.1-6.5L2.6 10.7l6.5-.9z" />,
  pin: <><path d="M9 4h6l-1 7 4 3v2H6v-2l4-3z" /><path d="M12 16v4" /></>,
};
const Svg = ({ d, size = 24, vw }) => (
  <svg width={vw ? size * (vw / 24) : size} height={size} viewBox={"0 0 " + (vw || 24) + " 24"} fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">{d}</svg>
);
const ArcBadge = ({ name }) => {
  const ext = (name.split(".").pop() || "").toUpperCase();
  const c = ARCH_COLORS[ext.toLowerCase()] || "#E3B14F";
  return (
    <svg width="30" height="30" viewBox="0 0 24 24" fill="none">
      <rect x="3" y="3" width="18" height="18" rx="4" stroke={c} strokeWidth="2" fill="none" />
      <text x="12" y="15.5" textAnchor="middle" fontSize="7.5" fontWeight="700" fill={c} fontFamily="system-ui,sans-serif">{ext}</text>
    </svg>
  );
};
const ThumbIcon = ({ uri, tkey, gd, cached, request, release, fallback }) => {
  const ref = useRef(null);
  useEffect(() => {
    if (cached) return;
    const el = ref.current; if (!el) return;
    const io = new IntersectionObserver((ents) => {
      ents.forEach((en) => { if (en.isIntersecting) request(uri, tkey, gd); else release(uri, tkey); });
    }, { rootMargin: "800px 0px" }); // грузим заранее, ~11 строк за пределами экрана
    io.observe(el);
    return () => { io.disconnect(); release(uri, tkey); };
  }, [uri, tkey, cached]);
  if (cached) return <img src={cached} alt="" style={{ width: "100%", height: "100%", objectFit: "cover", borderRadius: 13, animation: "fS .18s ease" }} />;
  return <span ref={ref} style={{ display: "flex", alignItems: "center", justifyContent: "center", width: "100%", height: "100%" }}>{fallback}</span>;
};
const EXT = {
  img: ["jpg", "jpeg", "jpe", "jfif", "png", "apng", "gif", "webp", "bmp", "dib", "svg", "svgz", "ico", "cur", "tif", "tiff", "heic", "heif", "avif", "jxl", "psd", "raw", "dng", "cr2", "nef", "arw"],
  video: ["mp4", "m4v", "mkv", "webm", "avi", "mov", "qt", "wmv", "flv", "f4v", "3gp", "3g2", "mpg", "mpeg", "mpe", "m2v", "ts", "m2ts", "mts", "vob", "ogv", "rm", "rmvb", "divx", "asf"],
  audio: ["mp3", "wav", "wave", "flac", "aac", "ogg", "oga", "opus", "m4a", "m4b", "wma", "amr", "aiff", "aif", "ape", "ac3", "dts", "mid", "midi", "mka", "ra", "au", "weba"],
  archive: ["zip", "rar", "7z", "tar", "gz", "tgz", "bz2", "tbz", "tbz2", "xz", "txz", "lz", "lzma", "zst", "z", "cab", "arj", "lha", "lzh", "ace", "iso", "dmg", "deb", "rpm", "jar", "war", "apk", "obb", "001", "z01", "r00"],
  font: ["ttf", "otf", "woff", "woff2", "eot"],
  doc: ["doc", "docx", "dot", "odt", "ott", "rtf", "xls", "xlsx", "ods", "ppt", "pptx", "odp"],
  ebook: ["epub", "mobi", "azw", "azw3", "fb2", "djvu", "djv"],
  code: ["js", "mjs", "cjs", "jsx", "ts", "tsx", "vue", "json", "json5", "html", "htm", "css", "scss", "less", "xml", "py", "java", "kt", "kts", "c", "h", "hpp", "cpp", "cc", "cs", "go", "rs", "rb", "php", "swift", "dart", "lua", "sh", "bash", "bat", "ps1", "sql", "yml", "yaml", "toml", "gradle"],
};
const SYS_FOLDERS = {
  download: { d: I.dl, c: "#5AA9E6" }, downloads: { d: I.dl, c: "#5AA9E6" },
  music: { d: I.audio, c: "#E36FB0" }, ringtones: { d: I.ring, c: "#E3B14F" }, notifications: { d: I.bell, c: "#E3B14F" }, alarms: { d: I.alarm, c: "#E36F6F" },
  pictures: { d: I.img, c: "#6FD3A8" }, dcim: { d: I.cam, c: "#6FD3A8" }, screenshots: { d: I.img, c: "#6FD3A8" },
  movies: { d: I.video, c: "#A98BE0" }, video: { d: I.video, c: "#A98BE0" }, videos: { d: I.video, c: "#A98BE0" },
  podcasts: { d: I.mic, c: "#E3B14F" }, recordings: { d: I.mic, c: "#E3B14F" },
  documents: { d: I.doc2, c: "#5AA9E6" },
  android: { d: I.android, c: "#A4C639" }, data: { d: I.android, c: "#A4C639" }, obb: { d: I.android, c: "#A4C639" },
  apk: { d: I.apk, c: "#A4C639" },
  bannerhub: { d: I.img, c: "#E36FB0" }, fonts: { d: I.fontA, c: "#C9A227" }, books: { d: I.bookOpen, c: "#C98A4B" },
  games: { d: I.gamepad, c: "#A4C639" }, gamehub: { d: I.gamepad, c: "#A4C639" }, emu: { d: I.emuPad, c: "#A4C639" }, arcade: { d: I.emuPad, c: "#A4C639" }, mame: { d: I.emuPad, c: "#A4C639" },
  retroarch: { d: I.gamepad, c: "#7C5CFF" }, winlator: { d: I.win, c: "#5AA9E6" }, windows: { d: I.win, c: "#5AA9E6" },
  switch: { d: I.switchCon, c: "#5AA9E6", w: 34 }, "nintendo switch": { d: I.switchCon, c: "#5AA9E6", w: 34 }, nes: { d: I.gamepad, c: "#E05252" }, dandy: { d: I.gamepad, c: "#E05252" },
  media: { d: I.media, c: "#E0709A" },
  sega: { d: I.gamepad, c: "#3A7BD5" }, ps1: { d: I.gamepad, c: "#5AA9E6" }, ps2: { d: I.gamepad, c: "#5AA9E6" }, ps3: { d: I.gamepad, c: "#5AA9E6" }, psp: { d: I.gamepad, c: "#5AA9E6" }, vita3k: { d: I.gamepad, c: "#5AA9E6" },
  mt2: { d: I.tool, c: "#E3B14F" }, "mt manager": { d: I.tool, c: "#E3B14F" }, apkeditor: { d: I.tool, c: "#6FD3A8" },
  "smart launcher": { d: I.launcher, c: "#5AA9E6" }, smartlauncher: { d: I.launcher, c: "#5AA9E6" }, "mx player": { d: I.video, c: "#3A7BD5" }, mxplayer: { d: I.video, c: "#3A7BD5" },
};
// Настоящие системные папки — ТОЛЬКО для сортировки «сверху» (НЕ приложения)
const REAL_SYS = new Set(["android","alarms","audiobooks","dcim","documents","download","downloads","movies","music","notifications","pictures","podcasts","recordings","ringtones","screenshots","screenrecord","screenrecords","bluetooth","fonts","camera","data","media","obb","coloros","oppo","oneplus","heytap","realme","samsung","smartswitch","miui","xiaomi","huawei","vivo"]);
const COLL = new Intl.Collator("ru", { numeric: true, sensitivity: "base" });
const scriptRank = (n) => { const c = (n || " ").charCodeAt(0); if (c < 128) return 0; if (c >= 0x400 && c <= 0x4FF) return 1; return 2; };
const nameCmp = (a, b) => { const ra = scriptRank(a), rb = scriptRank(b); if (ra !== rb) return ra - rb; return COLL.compare(a || "", b || ""); };
const sizeCache = new Map();
const ARCH_COLORS = { zip: "#E3B14F", rar: "#9B59B6", "7z": "#5AA9E6", tar: "#6FD3A8", gz: "#6FD3A8", xz: "#6FD3A8", bz2: "#6FD3A8", jar: "#E0574F" };
const fileIcon = (name) => {
  const ext = (name.split(".").pop() || "").toLowerCase();
  if (ext === "pdf") return { d: I.pdf, c: "#E0574F" };
  if (ext === "apk") return { d: I.apk, c: "#6FD3A8" };
  if (["apks", "xapk", "apkm", "apkx"].includes(ext)) return { d: I.apk, c: "#A4C639" };
  if (["ttf", "otf", "woff", "woff2"].includes(ext)) return { d: I.txt, c: "#C9A0FF" };
  if (ext === "lnk") return { d: I.lnk, c: GOLD };
  if (["txt", "md", "log", "ini", "cfg"].includes(ext)) return { d: I.txt, c: "#9FD0FF" };
  if (EXT.img.includes(ext)) return { d: I.img, c: "#7FB3FF" };
  if (EXT.video.includes(ext)) return { d: I.video, c: "#C98BFF" };
  if (EXT.audio.includes(ext)) return { d: I.audio, c: "#FF9D6B" };
  if (EXT.archive.includes(ext)) return { d: I.archive, c: ARCH_COLORS[ext] || GOLD };
  if (EXT.code.includes(ext)) return { d: I.code, c: "#6FD3A8" };
  return { d: I.file, c: SUB };
};
const SORTS = [
  ["az", "Имя: А-Я / A-Z"], ["za", "Имя: Я-А / Z-A"],
  ["sizeD", "Размер: больше → меньше"], ["sizeA", "Размер: меньше → больше"],
  ["dateN", "Дата: новые сверху"], ["dateO", "Дата: старые сверху"],
];

export default function App() {
  const init0 = useRef(buildInitial());
  const [tabs, setTabs] = useState(init0.current.base);
  const [active, setActive] = useState(init0.current.active);
  const [entries, setEntries] = useState([]);
  const [curUri, setCurUri] = useState("");
  // путь тома-флешки помечается префиксом @abs: и ведёт на абсолютный file://,
  // обычные пути по-прежнему резолвятся относительно базовой директории
  const uriForPath = async (pth) => {
    if (pth && pth.startsWith("@abs:")) {
      let raw = pth.slice(5);
      const enc = raw.split("/").map((seg) => encodeURIComponent(seg)).join("/");
      return { uri: "file://" + enc };
    }
    return Filesystem.getUri({ path: pth, directory: DIR });
  };
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [sel, setSel] = useState(() => new Set());
  const [selMode, setSelMode] = useState(false);
  const [clip, setClip] = useState(null);
  const [pasteMenu, setPasteMenu] = useState(false);
  const [progress, setProgress] = useState(null);
  useEffect(() => { if (!progress) Apps.cancelNotify().catch(() => {}); }, [progress]);
  const [zipProg, setZipProg] = useState(null);
  const cancelRef = useRef(false);
  const [query, setQuery] = useState(null);
  const [createOpen, setCreateOpen] = useState(false);
  const [createSub, setCreateSub] = useState(null);
  const [confirmDel, setConfirmDel] = useState(false);
  const [delInfo, setDelInfo] = useState(null);
  useEffect(() => {
    if (!confirmDel) { setDelInfo(null); return; }
    const items = [...sel].map((n) => entries.find((x) => x.name === n)).filter(Boolean);
    let cancelled = false;
    (async () => {
      let bytes = 0, count = 0;
      for (const e of items) {
        if (e.type === "directory") { try { const r = await Apps.pathSize({ uri: e.uri }); bytes += r.bytes || 0; count += r.count || 0; } catch {} }
        else { bytes += e.size || 0; count += 1; }
      }
      if (!cancelled) setDelInfo({ items: items.length, bytes, count });
    })();
    return () => { cancelled = true; };
  }, [confirmDel]);
  const [sheet, setSheet] = useState(null);
  const [toast, setToast] = useState(null);
  const [slide, setSlide] = useState(0);
  const [meta, setMeta] = useState(loadMeta);
  const [showHidden, setShowHidden] = useState(false);
  const VIEWKEY = "fm_view_v1";
  const [viewMode, setViewMode] = useState(() => ls.get(VIEWKEY) || "list");
  const FILTERS = [["all", "Все"], ["img", "Изображения"], ["vid", "Видео"], ["aud", "Аудио"], ["doc", "Документы"], ["apk", "APK"]];
  const [typeFilter, setTypeFilter] = useState("all");
  const [headSub, setHeadSub] = useState(null); // подсписок в меню трёх точек: sort | view | filter
  const headSubRef = useRef(null);
  const matchFilter = (e) => {
    if (typeFilter === "all" || e.type === "directory") return true;
    const n = e.name;
    if (typeFilter === "img") return isImg(n);
    if (typeFilter === "vid") return isVid(n);
    if (typeFilter === "aud") return isAudio(n);
    if (typeFilter === "apk") return /\.(apk|aab|apks|apkm|xapk)$/i.test(n);
    if (typeFilter === "doc") {
      const ext = (n.split(".").pop() || "").toLowerCase();
      return EXT.doc.includes(ext) || EXT.ebook.includes(ext) || ["pdf", "txt", "md", "csv", "log", "json", "xml", "html", "htm"].includes(ext);
    }
    return true;
  };
  const [sortMap, setSortMap] = useState(() => { try { return JSON.parse(ls.get("fm_sortmap_v1")) || {}; } catch { return {}; } });
  const [sortAsk, setSortAsk] = useState(null); // { mode } — спросить область применения
  // приоритет: точное правило папки > правило ближайшего родителя-поддерева ("sub://путь") > глобальная
  const effSortFor = (p) => {
    const m = sortMap;
    if (typeof m[p] === "string") return m[p];
    let best = null, bestLen = -1;
    for (const k in m) {
      if (!k.startsWith("sub://")) continue;
      const base = k.slice(6);
      if (base === "" || p === base || p.startsWith(base + "/")) { if (base.length > bestLen) { bestLen = base.length; best = m[k]; } }
    }
    return best || sortMode;
  };
  const [sortMode, setSortMode] = useState(() => ls.get(SORTKEY) || "az");
  const [sysTop, setSysTop] = useState(() => ls.get("fm_systop_v2") === "1");
  const [animFolders, setAnimFolders] = useState(() => ls.get("fm_anim_folders_v1") !== "0");
  const slideNav = (dir) => { if (!animFolders) return; setSlide(dir); setTimeout(() => setSlide(0), 300); };
  const [theme, setTheme] = useState(() => ls.get("fm_theme_v1") || "dark");
  const [themeBtn, setThemeBtn] = useState(() => ls.get("fm_themebtn_v1") !== "0");
  const FONT_KEY = "fm_fonts_v1";
  const BUILTIN_FONTS = [
    { id: "sys", name: "По умолчанию", css: "'Noto Sans',sans-serif" },
    { id: "comfortaa", name: "Comfortaa", css: "'Comfortaa',cursive" },
    { id: "roboto", name: "Roboto", css: "'Roboto',sans-serif" },
    { id: "verdana", name: "Verdana", css: "Verdana,Geneva,sans-serif" },
  ];
  const loadFonts = () => { try { const r = ls.get(FONT_KEY); return r ? JSON.parse(r) : { sel: "sys", custom: [] }; } catch { return { sel: "sys", custom: [] }; } };
  const [fonts, setFonts] = useState(loadFonts);
  const saveFonts = (f) => { try { ls.set(FONT_KEY, JSON.stringify(f)); } catch {} setFonts(f); };
  const allFonts = [...BUILTIN_FONTS, ...(fonts.custom || [])];
  const fontCss = (() => { const f = allFonts.find((x) => x.id === fonts.sel); return f ? f.css : "'Noto Sans',sans-serif"; })();
  useEffect(() => {
    let css = "";
    (fonts.custom || []).forEach((f) => { if (f.dataUrl) css += `@font-face{font-family:'${f.id}';src:url('${f.dataUrl}');}`; });
    let st = document.getElementById("fm-custom-fonts"); if (!st) { st = document.createElement("style"); st.id = "fm-custom-fonts"; document.head.appendChild(st); } st.textContent = css;
  }, [fonts.custom]);
  const fontFileRef = useRef(null);
  const onFontFile = (e) => {
    const f = e.target.files && e.target.files[0]; if (!f) return;
    const r = new FileReader();
    r.onload = (ev) => {
      const id = "cf_" + Date.now().toString(36);
      const name = f.name.replace(/\.(ttf|otf|woff2?)$/i, "");
      const nf = { id, name, css: `'${id}',sans-serif`, dataUrl: ev.target.result };
      saveFonts({ ...fonts, custom: [...(fonts.custom || []), nf], sel: id });
      showToast("Шрифт добавлен: " + name);
    };
    r.readAsDataURL(f); e.target.value = "";
  };
  const removeFont = (id) => {
    if (id === "sys") return;
    const isCustom = (fonts.custom || []).some((f) => f.id === id);
    const next = { ...fonts, sel: fonts.sel === id ? "sys" : fonts.sel };
    if (isCustom) next.custom = (fonts.custom || []).filter((f) => f.id !== id);
    saveFonts(next); showToast("Шрифт удалён");
  };
  const toggleTheme = () => { const t = theme === "dark" ? "light" : "dark"; setTheme(t); ls.set("fm_theme_v1", t); };
  const [headMenu, setHeadMenu] = useState(false);
  const [drawer, setDrawer] = useState(false);
  const [plusMenu, setPlusMenu] = useState(false);
  const DORDERKEY = "fm_drawer_order_v1";
  const [drawerOrder, setDrawerOrder] = useState(() => { try { return JSON.parse(localStorage.getItem(DORDERKEY) || "[]"); } catch { return []; } });
  const [dDragId, setDDragId] = useState(null);
  const dItemRefs = useRef({});
  const dRenderedRef = useRef([]);
  const dLp = useRef(); const dMovedR = useRef(false); const dLpFired = useRef(false); const dStartY = useRef(0);
  const dRects = useRef([]); const dTo = useRef(-1); const dDragPid = useRef(null); const dDragIdRef = useRef(null);
  const clearDDrag = () => { Object.values(dItemRefs.current).forEach((el) => { if (el) el.style.transform = ""; }); };
  const persistDOrder = (list) => { const ids = list.map((x) => x.id); localStorage.setItem(DORDERKEY, JSON.stringify(ids)); setDrawerOrder(ids); };
  const dDown = (ev, id) => {
    dMovedR.current = false; dLpFired.current = false; dStartY.current = ev.clientY;
    const pid = ev.pointerId, tgt = ev.currentTarget;
    clearTimeout(dLp.current);
    dLp.current = setTimeout(() => {
      if (dMovedR.current) return;
      const list = dRenderedRef.current;
      dRects.current = list.map((it) => { const el = dItemRefs.current[it.id]; return el ? el.getBoundingClientRect() : null; });
      dLpFired.current = true; dDragPid.current = pid; dDragIdRef.current = id; dTo.current = list.findIndex((it) => it.id === id);
      setDDragId(id); buzz(15);
      try { tgt.setPointerCapture(pid); } catch {}
    }, 250);
  };
  const dMove = (ev) => {
    if (!dLpFired.current) { if (Math.abs(ev.clientY - dStartY.current) > 8) { dMovedR.current = true; clearTimeout(dLp.current); } return; }
    ev.preventDefault();
    const list = dRenderedRef.current;
    const from = list.findIndex((it) => it.id === dDragIdRef.current);
    const rf = dRects.current[from]; if (!rf) return;
    const dy = ev.clientY - dStartY.current;
    const fingerY = rf.top + rf.height / 2 + dy;
    let count = 0;
    for (let j = 0; j < dRects.current.length; j++) { const r = dRects.current[j]; if (!r || j === from) continue; if (r.top + r.height / 2 < fingerY) count++; }
    let to = count; if (to < 0) to = 0; if (to > list.length - 1) to = list.length - 1;
    dTo.current = to;
    const span = rf.height;
    for (let j = 0; j < list.length; j++) {
      const el = dItemRefs.current[list[j].id]; if (!el) continue;
      if (j === from) { el.style.transform = "translateY(" + dy + "px)"; continue; }
      let t = 0;
      if (from < to && j > from && j <= to) t = -span;
      else if (to < from && j >= to && j < from) t = span;
      el.style.transform = t ? "translateY(" + t + "px)" : "translateY(0)";
    }
  };
  const dUp = (item) => {
    clearTimeout(dLp.current);
    try { if (dDragPid.current != null) { const el = dItemRefs.current[dDragIdRef.current]; el && el.releasePointerCapture(dDragPid.current); } } catch {}
    if (dLpFired.current) {
      const list = dRenderedRef.current, from = list.findIndex((it) => it.id === dDragIdRef.current), to = dTo.current;
      dLpFired.current = false; dDragIdRef.current = null; clearDDrag(); setDDragId(null);
      if (from !== -1 && to !== -1 && from !== to) { const nl = [...list]; const [m] = nl.splice(from, 1); nl.splice(to, 0, m); persistDOrder(nl); }
      return;
    }
    if (dMovedR.current) return;
    if (item.kind === "wd") openWebdav(item.a); else if (item.kind === "gd") openGDrive(); else { setDrawer(false); setTabPath(item.p); }
  };
  const [webdavs, setWebdavs] = useState([]);
  const [wdForm, setWdForm] = useState(null);
  const [wd, setWd] = useState(null);
  useEffect(() => { Apps.webdavGetAccounts().then((r) => { try { setWebdavs(JSON.parse(r.json || "[]")); } catch {} }).catch(() => {}); }, []);
  const saveWebdav = async () => { const f = wdForm; if (!f || !f.url) { setWdForm(null); return; } const list = [...webdavs, { name: (f.name || f.url).trim(), url: f.url.trim().replace(/\/?$/, "/"), user: (f.user || "").trim(), pass: f.pass || "" }]; setWebdavs(list); setWdForm(null); try { await Apps.webdavSetAccounts({ json: JSON.stringify(list) }); } catch {} };
  const delWebdav = async (i) => { const list = webdavs.filter((_, j) => j !== i); setWebdavs(list); try { await Apps.webdavSetAccounts({ json: JSON.stringify(list) }); } catch {} };
  const openWebdav = (acc) => { setDrawer(false); setTabs((ts) => ts.map((t, i) => (i === active ? { ...t, src: { kind: "webdav", acc, url: acc.url, name: acc.name, stack: [{ url: acc.url, name: acc.name }] } } : t))); };
  const wdEnter = async (e) => { if (e.type === "directory") { try { const r = await Apps.webdavList({ url: e.url, user: wd.acc.user, pass: wd.acc.pass }); setWd((v) => ({ ...v, stack: [...v.stack, { url: e.url, name: e.name }], entries: r.files || [] })); } catch (er) { showToast("Ошибка: " + (er?.message || "")); } } else { showToast("Загрузка…"); try { await Apps.webdavGet({ url: e.url, user: wd.acc.user, pass: wd.acc.pass, name: e.name }); showToast("Скачано → Download/" + e.name); } catch (er) { showToast("Ошибка: " + (er?.message || "")); } } };
  const wdBack = async () => { if (!wd) return; if (wd.stack.length <= 1) { setWd(null); return; } const st = wd.stack.slice(0, -1); const top = st[st.length - 1]; try { const r = await Apps.webdavList({ url: top.url, user: wd.acc.user, pass: wd.acc.pass }); setWd({ ...wd, stack: st, entries: r.files || [] }); } catch {} };
  const [gdIn, setGdIn] = useState(false);
  const [volumes, setVolumes] = useState([]); // тома: внутренняя память, SD, USB
  const loadVolumes = React.useCallback(() => {
    Apps.storageVolumes().then((r) => setVolumes((r && r.volumes) || [])).catch(() => setVolumes([]));
  }, []);
  useEffect(() => { loadVolumes(); }, [loadVolumes]);
  // флешку могли воткнуть при открытом приложении — обновляем список при возврате
  useEffect(() => { let h; CapApp.addListener("resume", loadVolumes).then((l) => (h = l)); return () => { h && h.remove(); }; }, [loadVolumes]);
  const [gd, setGd] = useState(null);
  const b64url = (buf) => btoa(String.fromCharCode.apply(null, new Uint8Array(buf))).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
  const googleLogin = async () => {
    setDrawer(false);
    const verifier = b64url(crypto.getRandomValues(new Uint8Array(32)));
    const chal = b64url(await crypto.subtle.digest("SHA-256", new TextEncoder().encode(verifier)));
    localStorage.setItem("gd_verifier", verifier);
    const url = "https://accounts.google.com/o/oauth2/v2/auth?client_id=" + encodeURIComponent("589335091963-6n9ss077f7htshue4vd288eb2t2jduhb.apps.googleusercontent.com") + "&redirect_uri=" + encodeURIComponent("com.googleusercontent.apps.589335091963-6n9ss077f7htshue4vd288eb2t2jduhb:/oauth") + "&response_type=code&scope=" + encodeURIComponent("https://www.googleapis.com/auth/drive") + "&code_challenge=" + chal + "&code_challenge_method=S256&access_type=offline&prompt=consent";
    try { await Apps.openExternalUrl({ url }); } catch { showToast("Не открыть браузер"); }
  };
  useEffect(() => {
    const consume = async () => { try { const r = await Apps.oauthConsume(); if (r.code) { const v = localStorage.getItem("gd_verifier") || ""; await Apps.gdriveToken({ code: r.code, verifier: v }); localStorage.removeItem("gd_verifier"); setGdIn(true); showToast("Google Drive подключён"); } } catch (e) { if (e?.message) showToast("Google: " + e.message); } };
    Apps.gdriveLoggedIn().then((r) => setGdIn(!!r.yes)).catch(() => {});
    consume();
    const h = CapApp.addListener("resume", consume);
    return () => { h.then((x) => x.remove()).catch(() => {}); };
  }, []);
  const openGDrive = () => { setDrawer(false); setTabs((ts) => ts.map((t, i) => (i === active ? { ...t, src: { kind: "gdrive", folder: "root", name: "Google Drive", stack: [{ id: "root", name: "Google Drive" }] } } : t))); };
  const gdEnter = async (e) => { if (e.type === "directory") { try { const r = await Apps.gdriveList({ folder: e.id }); setGd((v) => ({ ...v, stack: [...v.stack, { id: e.id, name: e.name }], entries: r.files || [] })); } catch (er) { showToast("Ошибка: " + (er?.message || "")); } } else { showToast("Загрузка…"); try { await Apps.gdriveGet({ id: e.id, name: e.name, mime: e.mime || "" }); showToast("Скачано → Download/" + e.name); } catch (er) { showToast("Ошибка: " + (er?.message || "")); } } };
  const gdBack = async () => { if (!gd) return; if (gd.stack.length <= 1) { setGd(null); return; } const st = gd.stack.slice(0, -1); const top = st[st.length - 1]; try { const r = await Apps.gdriveList({ folder: top.id }); setGd({ ...gd, stack: st, entries: r.files || [] }); } catch {} };
  const [settings, setSettings] = useState(false);
  const [settingsPage, setSettingsPage] = useState(null); // null=список, "theme"/"fonts"/"sort"/"icons"
  const [iconDB, setIconDB] = useState(() => loadMap(ICONKEY));
  const saveIconDB = (db) => { setIconDB(db); saveMap(ICONKEY, db); };
  const [thumbs, setThumbs] = useState({});
  const [pwPrompt, setPwPrompt] = useState(null); // { resolve, retry }
  const [pwVal, setPwVal] = useState("");
  const pwCacheRef = useRef({});
  const getCachedPw = (uri) => { const e = pwCacheRef.current[uri]; return e && e.exp > Date.now() ? e.pw : null; };
  const setCachedPw = (uri, pw) => { pwCacheRef.current[uri] = { pw, exp: Date.now() + 3600000 }; };
  const askPassword = (retry) => new Promise((resolve) => { setPwVal(""); setPwPrompt({ resolve, retry: !!retry }); });
  const resolvePassword = (val) => { setPwPrompt((p) => { if (p) p.resolve(val); return null; }); };
  const isImg = (n) => /\.(png|jpg|jpeg|webp|gif|bmp)$/i.test(n);
  const isPdf = (n) => /\.pdf$/i.test(n);
  const isAudio = (n) => EXT.audio.includes((n.split(".").pop() || "").toLowerCase());
  const isVid = (n) => EXT.video.includes((n.split(".").pop() || "").toLowerCase());
  const isFont = (n) => /\.(ttf|otf|woff2?|woff)$/i.test(n);
  const isSplitApk = (n) => /\.(apks|xapk|apkm|apkx)$/i.test(n);
  const isGzTar = (n) => /\.(tgz|tar|gz)$/i.test(n);
  const [fontView, setFontView] = useState(null);
  const [fontText, setFontText] = useState("");
  const openFontViewer = async (e) => {
    setFontText(""); setFontView({ name: e.name, loading: true });
    try {
      const r = await Filesystem.readFile({ path: e.uri });
      const ext = (e.name.split(".").pop() || "").toLowerCase();
      const fmt = ext === "otf" ? "opentype" : ext === "woff2" ? "woff2" : ext === "woff" ? "woff" : "truetype";
      const mime = ext === "otf" ? "font/otf" : ext === "woff2" ? "font/woff2" : ext === "woff" ? "font/woff" : "font/ttf";
      const fam = "fv_" + Date.now();
      const css = "@font-face{font-family:'" + fam + "';src:url(data:" + mime + ";base64," + r.data + ") format('" + fmt + "');}";
      setFontView({ name: e.name, family: fam, css });
    } catch (err) { setFontView(null); showToast("Не удалось открыть шрифт: " + (err?.message || "")); }
  };
  const cfs = (u) => { try { return Capacitor.convertFileSrc(u); } catch { return u; } };
  const [tabsMenu, setTabsMenu] = useState(false);
  const [selMenu, setSelMenu] = useState(false);
  const [props, setProps] = useState(null);
  const [viewer, setViewer] = useState(null);       // { items:[entry], idx }
  const [viewerBar, setViewerBar] = useState(false); // видна ли панель
  const [dragX, setDragX] = useState(0);
  const [dragY, setDragY] = useState(0);
  const [zoom, setZoom] = useState(1);
  const [pan, setPan] = useState({ x: 0, y: 0 });
  const pinchRef = useRef(null);
  const [dragging, setDragging] = useState(false);
  const [viewerDel, setViewerDel] = useState(false);
  const vTouch = useRef(null);
  const [pdf, setPdf] = useState(null);       // { uri, name }
  const [pdfArr, setPdfArr] = useState([]);   // dataURL по страницам
  const [pdfN, setPdfN] = useState(0);
  const [pdfZoom, setPdfZoom] = useState(1);
  const pdfTok = useRef(0);
  const pdfPinch = useRef({ d0: 0, z0: 1 });
  const pdfDist = (t) => Math.hypot(t[0].clientX - t[1].clientX, t[0].clientY - t[1].clientY);
  const closePdf = () => { pdfTok.current++; setPdf(null); setPdfArr([]); setPdfN(0); setPdfZoom(1); };
  const openPdf = async (entry) => {
    const tok = ++pdfTok.current;
    setPdf({ uri: entry.uri, name: entry.name }); setPdfArr([]); setPdfN(0); setPdfZoom(1);
    const W = Math.min(Math.round((window.innerWidth || 400) * (window.devicePixelRatio || 2)), 1600);
    try {
      const first = await Apps.pdfPage({ uri: entry.uri, page: 0, width: W });
      if (pdfTok.current !== tok) return;
      const n = first.pages || 0; setPdfN(n);
      if (first.data) setPdfArr([first.data]);
      for (let p = 1; p < n; p++) {
        const r = await Apps.pdfPage({ uri: entry.uri, page: p, width: W });
        if (pdfTok.current !== tok) return;
        setPdfArr((a) => [...a, r.data]);
      }
    } catch (e) { if (pdfTok.current === tok) { showToast("Не удалось открыть PDF: " + (e?.message || "")); setPdf(null); } }
  };
  const pdfTouchStart = (e) => { if (e.touches.length === 2) { pdfPinch.current.d0 = pdfDist(e.touches); pdfPinch.current.z0 = pdfZoom; } };
  const pdfTouchMove = (e) => { if (e.touches.length === 2 && pdfPinch.current.d0 > 0) { e.preventDefault(); let z = pdfPinch.current.z0 * (pdfDist(e.touches) / pdfPinch.current.d0); z = Math.max(1, Math.min(4, z)); setPdfZoom(z); } };

  const AUTONEXTKEY = "fm_audio_autonext_v1";
  const [audioAuto, setAudioAuto] = useState(() => ls.get(AUTONEXTKEY) === "1");
  const [player, setPlayer] = useState(null);   // { idx, count, name, playing, pos, dur }
  const [playerMenu, setPlayerMenu] = useState(false);
  const playerList = useRef({ uris: [], names: [] });
  const openAudio = (entry) => {
    const list = entries.filter((e) => e.type !== "directory" && isAudio(e.name));
    const idx = Math.max(0, list.findIndex((e) => e.name === entry.name));
    playerList.current = { uris: list.map((e) => e.uri), names: list.map((e) => e.name) };
    Apps.audioOpen({ uris: playerList.current.uris, names: playerList.current.names, index: idx, autoNext: audioAuto }).catch((e) => showToast("Плеер: " + (e?.message || "")));
    setPlayer({ idx, count: list.length, name: entry.name, playing: true, pos: 0, dur: 0 }); setPlayerMenu(false);
  };
  const playerToggle = () => { Apps.audioToggle().catch(() => {}); setPlayer((p) => (p ? { ...p, playing: !p.playing } : p)); };
  const playerNext = () => { Apps.audioNext().catch(() => {}); };
  const playerPrev = () => { Apps.audioPrev().catch(() => {}); };
  const playerSeek = (ms) => { Apps.audioSeek({ ms }).catch(() => {}); setPlayer((p) => (p ? { ...p, pos: ms } : p)); };
  const playerClose = () => { Apps.audioClose().catch(() => {}); setPlayer(null); setPlayerMenu(false); };
  const playerSetAs = (type) => { const uri = playerList.current.uris[player ? player.idx : 0]; if (!uri) return; Apps.audioSetAs({ uri, type }).then(() => showToast(type === "alarm" ? "Установлено на будильник" : "Установлено на звонок")).catch((e) => { if ((e?.message || "").includes("write_settings")) showToast("Разрешите изменение системных настроек и повторите"); else showToast("Не удалось: " + (e?.message || "")); }); setPlayerMenu(false); };
  useEffect(() => {
    if (!player) return;
    let stop = false;
    const tick = async () => { try { const s = await Apps.audioState(); if (stop) return; if (!s.alive) { setPlayer(null); return; } setPlayer((p) => (p ? { ...p, idx: s.idx, count: s.count, name: s.name, playing: s.playing, pos: s.pos, dur: s.dur } : p)); } catch {} };
    const iv = setInterval(tick, 500); tick();
    return () => { stop = true; clearInterval(iv); };
  }, [!!player]);

  const openViewer = (entry) => {
    const items = entries.filter((e) => e.type !== "directory" && isImg(e.name));
    const idx = items.findIndex((e) => e.name === entry.name);
    setViewer({ items, idx: idx < 0 ? 0 : idx }); setViewerBar(true); setDragX(0); setDragY(0); setZoom(1); setPan({ x: 0, y: 0 }); setViewerDel(false);
  };
  const viewerGo = (d) => { setZoom(1); setPan({ x: 0, y: 0 }); setViewer((v) => { if (!v) return v; const ni = v.idx + d; if (ni < 0 || ni >= v.items.length) return v; return { ...v, idx: ni }; }); };
  const viewerCur = viewer && viewer.items[viewer.idx];
  const viewerDelete = async () => {
    if (!viewerCur) return; setViewerDel(false);
    try { await delTree(viewerCur); } catch {}
    setViewer((v) => { if (!v) return v; const items = v.items.filter((_, i) => i !== v.idx); if (items.length === 0) return null; return { items, idx: Math.min(v.idx, items.length - 1) }; });
    await refresh(); showToast("Удалено");
  };
  const [propCount, setPropCount] = useState(null);
  const [openMenu, setOpenMenu] = useState(null);
  const [arcView, setArcView] = useState(null);
  const [arcPath, setArcPath] = useState("");
  // ZIP хранит плоский список путей — собираем из них уровень папок/файлов, как в обычном менеджере
  const arcLevel = React.useMemo(() => {
    const all = (arcView && arcView.entries) || [];
    const p = arcPath;
    const dirs = new Map(), files = [];
    for (const it of all) {
      const n = String(it.name || "").replace(/^\/+/, "");
      if (!n || !n.startsWith(p)) continue;
      const rest = n.slice(p.length);
      if (!rest) continue;
      const cut = rest.indexOf("/");
      if (cut >= 0) {
        const dn = rest.slice(0, cut); if (!dn) continue;
        const d = dirs.get(dn) || { name: dn, dir: true, count: 0, size: 0, prefix: p + dn + "/" };
        if (!(it.dir || rest.endsWith("/"))) { d.count++; d.size += it.size || 0; }
        dirs.set(dn, d);
      } else if (it.dir || rest.endsWith("/")) {
        const dn = rest.replace(/\/$/, "");
        if (dn && !dirs.has(dn)) dirs.set(dn, { name: dn, dir: true, count: 0, size: 0, prefix: p + dn + "/" });
      } else files.push({ ...it, label: rest });
    }
    const ds = [...dirs.values()].sort((a, b) => nameCmp(a.name, b.name));
    const fs = files.sort((a, b) => nameCmp(a.label, b.label));
    return [...ds, ...fs];
  }, [arcView && arcView.entries, arcPath]);
  const arcNamesUnder = (prefix) => ((arcView && arcView.entries) || []).filter((x) => String(x.name || "").replace(/^\/+/, "").startsWith(prefix) && !x.dir).map((x) => x.name);
  const [pendingExtract, setPendingExtract] = useState(null); // { uri, names|null, label }
  const [menuArmed, setMenuArmed] = useState(false);
  useEffect(() => { if (openMenu) { setMenuArmed(false); const t = setTimeout(() => setMenuArmed(true), 320); return () => clearTimeout(t); } setMenuArmed(false); }, [openMenu && openMenu.file]);
  const omSheetRef = useRef(null);
  useLayoutEffect(() => {
    if (!openMenu || !omSheetRef.current) return;
    const r = omSheetRef.current.getBoundingClientRect();
    const ox = (openMenu.originX != null ? openMenu.originX : window.innerWidth / 2) - r.left;
    const oy = (openMenu.originY != null ? openMenu.originY : r.top) - r.top;
    omSheetRef.current.style.transformOrigin = ox + "px " + oy + "px";
  }, [openMenu && openMenu.file]);
  const arcTimes = useRef(null); // замер открытия архива: показывается, если открытие затянулось
  const [arcSel, setArcSel] = useState(new Set());
  // сколько выбранных лежит под каждой папкой текущего уровня — один проход по выбранным
  const arcSelUnder = React.useMemo(() => {
    const m = new Map();
    if (!arcSel.size) return m;
    for (const raw of arcSel) {
      const n = String(raw || "").replace(/^\/+/, "");
      if (!n.startsWith(arcPath)) continue;
      const rest = n.slice(arcPath.length);
      const cut = rest.indexOf("/");
      if (cut < 0) continue;
      const key = arcPath + rest.slice(0, cut) + "/";
      m.set(key, (m.get(key) || 0) + 1);
    }
    return m;
  }, [arcSel, arcPath]);
  const arcLp = useRef(false), arcLpT = useRef(null), arcPX = useRef(0), arcPY = useRef(0);
  const arcListRef = useRef(null), arcSpacerRef = useRef(null);
  useLayoutEffect(() => {
    const el = arcListRef.current, sp = arcSpacerRef.current;
    if (!el || !sp || !arcView || !arcView.entries) return;
    sp.style.height = "0px";
    const ch = el.clientHeight;
    const wrap = sp.nextElementSibling;
    const kids = wrap ? wrap.children : [];
    let rowsH = 0, fourH = 0;
    if (kids.length) {
      const first = kids[0], last = kids[kids.length - 1];
      const bottom = last.getBoundingClientRect().bottom;
      rowsH = Math.max(0, bottom - first.getBoundingClientRect().top);
      const take = Math.min(4, kids.length);
      fourH = Math.max(0, bottom - kids[kids.length - take].getBoundingClientRect().top);
    }
    // запас снизу под плавающую панель — иначе последний элемент прячется под неё
    let navH = 0;
    if (navRef.current) { const nr = navRef.current.getBoundingClientRect(), lr = el.getBoundingClientRect(); navH = Math.max(0, lr.bottom - nr.top); }
    el.style.paddingBottom = navH + "px";
    const usable = el.clientHeight - navH;
    let pt = Math.max(0, usable - Math.min(rowsH, fourH));
    sp.style.height = pt + "px";
    el.scrollTop = rowsH >= usable ? pt : Math.max(0, el.scrollHeight - el.clientHeight);
    // доводка по факту, как в основном списке
    if (kids.length && rowsH < usable && navRef.current) {
      const delta = navRef.current.getBoundingClientRect().top - kids[kids.length - 1].getBoundingClientRect().bottom;
      if (Math.abs(delta) > 0.5) {
        pt = Math.max(0, pt + delta);
        sp.style.height = pt + "px";
        el.scrollTop = Math.max(0, el.scrollHeight - el.clientHeight);
      }
    }
    /* eslint-disable-next-line */
  }, [arcView && arcView.entries, arcPath]);
  const [shared, setShared] = useState([]);
  const [saveMode, setSaveMode] = useState(false);
  const checkShared = async () => {
    try {
      const r = await Apps.getShared();
      const files = r.files || [];
      if (files.length === 0) { setShared([]); return; }
      if (r.mode === "open") { setShared([]); openSharedHere(); }
      else if (r.mode === "save") { setShared([]); setSaveMode(true); }
      else setShared(files);
    } catch {}
  };
  const openSharedHere = async () => {
    try {
      const t = await Apps.saveSharedTemp();
      setShared([]);
      if (t && t.uri) await showOpenMenu({ name: t.name, uri: t.uri, type: "file" }, mimeOf(t.name));
    } catch (e) { showToast("Не удалось открыть: " + (e?.message || "")); }
  };
  useEffect(() => { checkShared(); const h = CapApp.addListener("resume", checkShared); return () => { h.then((x) => x.remove()).catch(() => {}); }; }, []);
  const saveSharedHere = async () => {
    try { const u = await Filesystem.getUri({ path, directory: DIR }); const r = await Apps.saveShared({ dir: u.uri }); showToast("Сохранено: " + (r.saved || 0) + " в " + (baseName(path) || "Storage")); setShared([]); setSaveMode(false); refresh(); }
    catch (e) { showToast("Ошибка сохранения: " + (e?.message || "")); }
  };
  const dismissShared = async () => { try { await Apps.clearShared(); } catch {} setShared([]); };
  const extractSelected = () => { if (!arcSel.size) return; startExtract(arcView.uri, [...arcSel], arcView.name); };
  const [allFiles, setAllFiles] = useState(true); // {file, mime, apps, useDefault, editHide}

  const cur = tabs[active], path = cur?.path || "";
  const srcRef = useRef(null); srcRef.current = (cur && cur.src) || null;
  const srcKey = cur && cur.src ? cur.src.kind + "|" + (cur.src.folder || cur.src.url || "") : "";
  const persist = (t) => { setTabs(t); saveTabs(t); };
  const toastT = useRef(null);
  const showToast = (m, ms) => { clearTimeout(toastT.current); setToast(m); toastT.current = setTimeout(() => setToast(null), ms || 1900); };
  const byName = (n) => entries.find((x) => x.name === n);
  const keyOf = (name) => join(path, name);
  const isHidden = (e) => meta.hidden.has(keyOf(e.name)) || e.name.startsWith(".");

  const applyMeta = (m) => { setMeta({ ...m }); saveMeta(m); };

  const reqRef = useRef(0);
  const forceRef = useRef(false);
  const LC_KEY = "fm_lcache_v1";
  const localCache = useRef(null);
  if (localCache.current === null) { try { localCache.current = JSON.parse(localStorage.getItem(LC_KEY) || "{}") || {}; } catch { localCache.current = {}; } }
  // кэш листингов держим в файле: localStorage мал (~5 МБ) и пишет синхронно, подвешивая прокрутку
  const lcLoaded = useRef(false);
  useEffect(() => {
    if (lcLoaded.current) return; lcLoaded.current = true;
    Apps.cacheGet({ key: LC_KEY }).then((r) => {
      if (!r || !r.data) return;
      try {
        const disk = JSON.parse(r.data) || {};
        localCache.current = { ...disk, ...(localCache.current || {}) };
        try { localStorage.removeItem(LC_KEY); } catch {} // переехали на диск
      } catch {}
    }).catch(() => {});
  }, []);
  const lcSaveT = useRef();
  const lcSave = () => {
    clearTimeout(lcSaveT.current);
    lcSaveT.current = setTimeout(() => {
      try {
        const keys = Object.keys(localCache.current);
        if (keys.length > 120) keys.slice(0, keys.length - 120).forEach((k) => delete localCache.current[k]);
        Apps.cacheSet({ key: LC_KEY, data: JSON.stringify(localCache.current) }).catch(() => {
          try { localStorage.setItem(LC_KEY, JSON.stringify(localCache.current)); } catch {}
        });
      } catch {}
    }, 800);
  };
  const GDC_KEY = "fm_gd_cache_v1", GDPT_KEY = "fm_gd_ptoken_v1";
  const gdCacheAll = () => { try { return JSON.parse(localStorage.getItem(GDC_KEY) || "{}"); } catch { return {}; } };
  const gdCacheGet = (fid) => gdCacheAll()[fid];
  const gdCacheSet = (fid, files) => { try { const a = gdCacheAll(); a[fid] = files; localStorage.setItem(GDC_KEY, JSON.stringify(a)); } catch {} };
  const gdCacheClear = () => { try { localStorage.removeItem(GDC_KEY); } catch {} };
  const list = useCallback(async () => {
    const my = ++reqRef.current;
    const src0 = srcRef.current;
    if (src0) {
      setError(null);
      if (src0.kind === "gdrive") {
        const fid = src0.folder;
        const cached = gdCacheGet(fid);
        if (cached && !forceRef.current) { setEntries(cached); setLoading(false); switchingRef.current = false; return; }
        setEntries([]); setLoading(true);
        try { const r = await Apps.gdriveList({ folder: fid }); const files = (r.files || []).map((f) => ({ name: f.name, type: f.type, size: f.size, remote: "gdrive", uri: f.id, id: f.id, mime: f.mime, thumb: f.thumb })); if (my !== reqRef.current) return; setEntries(files); gdCacheSet(fid, files); }
        catch (e) { if (my !== reqRef.current) return; setError((e && e.message) || "Ошибка"); setEntries([]); }
        if (my === reqRef.current) { setLoading(false); switchingRef.current = false; forceRef.current = false; }
        return;
      }
      setEntries([]); setLoading(true);
      try { const r = await Apps.webdavList({ url: src0.url, user: src0.acc.user, pass: src0.acc.pass }); const files = (r.files || []).map((f) => ({ name: f.name, type: f.type, size: f.size, remote: "webdav", uri: f.url, url: f.url })); if (my !== reqRef.current) return; setEntries(files); }
      catch (e) { if (my !== reqRef.current) return; setError((e && e.message) || "Ошибка"); setEntries([]); }
      if (my === reqRef.current) { setLoading(false); switchingRef.current = false; forceRef.current = false; }
      return;
    }
    const cached = localCache.current[path];
    if (cached && !forceRef.current) {
      setEntries(cached); setLoading(false); switchingRef.current = false;
      try {
        const u = await uriForPath(path);
        if (my !== reqRef.current) return;
        setCurUri(u.uri);
        let files;
        try { const r = await Apps.list({ uri: u.uri }); files = r.files; } catch { return; }
        if (my !== reqRef.current) return;
        localCache.current[path] = files || []; lcSave();
        setEntries((prev) => { const a = JSON.stringify((prev || []).map((x) => x.name + x.size + x.mtime)); const b = JSON.stringify((files || []).map((x) => x.name + x.size + x.mtime)); return a === b ? prev : (files || []); });
        if ((files || []).some((f) => f.name === ".icon" && f.type === "directory")) scanIconFolder(path);
        else if ((files || []).some((f) => f.name === ".icon" && f.type !== "directory")) scanIconMarker(path, files || []);
      } catch {}
      return;
    }
    setLoading(true); setError(null);
    try {
      const u = await uriForPath(path);
      if (my !== reqRef.current) return;
      setCurUri(u.uri);
      let files;
      try { const r = await Apps.list({ uri: u.uri }); files = r.files; }
      catch (er) { showToast("Системное чтение недоступно: " + (er?.message || "ошибка плагина")); const r = await Filesystem.readdir({ path, directory: DIR }); files = r.files; }
      if (my !== reqRef.current) return;
      if (srcRef.current) return; // источник сменился, пока читали
      localCache.current[path] = files || []; lcSave();
      setEntries(files || []);
      if ((files || []).some((f) => f.name === ".icon" && f.type === "directory")) scanIconFolder(path);
        else if ((files || []).some((f) => f.name === ".icon" && f.type !== "directory")) scanIconMarker(path, files || []);
    } catch (e) { if (my !== reqRef.current) return; setError(e.message || "Нет доступа к хранилищу"); setEntries([]); }
    if (my === reqRef.current) { setLoading(false); switchingRef.current = false; forceRef.current = false; }
  }, [path]);
  // Файл-маркер .icon: срабатывает ТОЛЬКО если изображение в папке единственное — иначе конфликт, ничего не делаем
  const scanIconMarker = async (folderPath, files) => {
    try {
      const imgs = files.filter((f) => f.type !== "directory" && f.name !== ".icon" && isImg(f.name));
      if (imgs.length !== 1) return; // ноль или несколько — молчим, маркер ждёт
      const pic = imgs[0];
      const data = await Filesystem.readFile({ path: pic.uri });
      const ext = (pic.name.split(".").pop() || "png").toLowerCase();
      const mime = ext === "ico" ? "image/x-icon" : ext === "jpg" || ext === "jpeg" ? "image/jpeg" : "image/" + ext;
      const db = loadMap(ICONKEY); db[folderPath] = "data:" + mime + ";base64," + data.data; saveIconDB(db);
      try { const mu = await Filesystem.getUri({ path: join(folderPath, ".icon"), directory: DIR }); await Apps.delete({ uri: mu.uri }); } catch { try { await Filesystem.deleteFile({ path: join(folderPath, ".icon"), directory: DIR }); } catch {} }
      showToast("Иконка папки сохранена: " + (baseName(folderPath) || "Storage"));
      refresh();
    } catch {}
  };
  const scanIconFolder = async (folderPath) => {
    try {
      const fu = await Filesystem.getUri({ path: join(folderPath, ".icon"), directory: DIR });
      const r = await Apps.list({ uri: fu.uri });
      const pic = (r.files || []).find((f) => f.type !== "directory" && /\.(png|ico|jpg|jpeg|webp)$/i.test(f.name));
      if (!pic) return;
      const data = await Filesystem.readFile({ path: pic.uri });
      const ext = (pic.name.split(".").pop() || "png").toLowerCase();
      const mime = ext === "ico" ? "image/x-icon" : ext === "jpg" || ext === "jpeg" ? "image/jpeg" : "image/" + ext;
      const db = loadMap(ICONKEY); db[folderPath] = "data:" + mime + ";base64," + data.data; saveIconDB(db);
      try { await Apps.delete({ uri: fu.uri }); } catch { try { await Filesystem.rmdir({ path: join(folderPath, ".icon"), directory: DIR, recursive: true }); } catch {} }
      showToast("Иконка папки сохранена: " + (baseName(folderPath) || "Storage"));
      refresh();
    } catch (e) { showToast("Иконка: " + (e?.message || "ошибка")); }
  };

  useEffect(() => { const t = THEMES[theme] || THEMES.dark; Apps.setBars({ color: t["--bg"], light: theme === "light" }).catch(() => {}); }, [theme]);
  useEffect(() => { Filesystem.rmdir({ path: "Download/.yevtmp", directory: DIR, recursive: true }).catch(() => {}); }, []);
  useEffect(() => { Filesystem.requestPermissions().catch(() => {}); checkAccess(); }, []);
  const checkAccess = async () => { try { const r = await Apps.hasAllFiles(); setAllFiles(!!r.granted); } catch { setAllFiles(true); } };
  const listRef = useRef(null);
  const spacerRef = useRef(null);
  const visLen = useRef(0);
  const scrollPos = useRef({});
  const pathKeyRef = useRef("");
  const restoring = useRef(false);
  const navRef = useRef(null);
  pathKeyRef.current = active + "|" + path;
  // распорка сверху = пустая зона ровно в 4 строки, чтобы первые файлы доставались пальцем внизу.
  // высоты строк измеряются, а не берутся константой — иначе погрешность копится на каждой строке
  const measureRows = (sp) => {
    const wrap = sp && sp.parentElement; if (!wrap) return { rowsH: 0, fourH: 0 };
    const rows = Array.from(wrap.children).filter(
      (k) => k !== sp && (sp.compareDocumentPosition(k) & Node.DOCUMENT_POSITION_FOLLOWING) && k.getBoundingClientRect().height > 0
    );
    if (!rows.length) return { rowsH: 0, fourH: 0, last: null };
    const bottom = rows[rows.length - 1].getBoundingClientRect().bottom;
    const rowsH = Math.max(0, bottom - rows[0].getBoundingClientRect().top);
    const take = Math.min(4, rows.length);
    const fourH = Math.max(0, bottom - rows[rows.length - take].getBoundingClientRect().top);
    return { rowsH, fourH, last: rows[rows.length - 1] };
  };
  const layoutList = useCallback(() => {
    const el = listRef.current, sp = spacerRef.current; if (!el || !sp) return;
    let navH = 72;
    if (navRef.current) { const nr = navRef.current.getBoundingClientRect(), lr = el.getBoundingClientRect(); navH = Math.max(0, lr.bottom - nr.top); }
    el.style.paddingBottom = navH + "px";
    sp.style.height = "0px"; // обнулить ПЕРЕД замером: старая распорка сталкивает строки за экран, и content-visibility отдаёт заготовку вместо реальной высоты
    const ch = el.clientHeight;
    const usable = ch - navH;
    const { rowsH, fourH, last } = measureRows(sp);
    if (!last) { if (loading || switchingRef.current) return; sp.style.height = "0px"; el.scrollTop = 0; return; } // пустая папка: без распорки; во время загрузки/переключения кадр не трогаем
    let pt = Math.max(0, usable - Math.min(rowsH, fourH));
    sp.style.height = pt + "px";
    const short = rowsH < usable; // всё помещается на экран
    const saved = short ? null : scrollPos.current[active + "|" + path];
    restoring.current = true;
    if (saved != null) el.scrollTop = saved;
    else el.scrollTop = rowsH >= usable ? pt : Math.max(0, el.scrollHeight - ch);
    // доводка по факту: где реально оказался низ последнего файла — лечит любую погрешность замера.
    // для короткого списка выполняется всегда (сохранённый скролл там не используется)
    if (short && last && navRef.current) {
      const delta = navRef.current.getBoundingClientRect().top - last.getBoundingClientRect().bottom;
      if (Math.abs(delta) > 0.5) {
        pt = Math.max(0, pt + delta);
        sp.style.height = pt + "px";
        el.scrollTop = Math.max(0, el.scrollHeight - el.clientHeight);
      }
    }
    requestAnimationFrame(() => { requestAnimationFrame(() => { restoring.current = false; }); });
    /* eslint-disable-next-line */
  }, [active, path]);
  useLayoutEffect(() => { layoutList(); }, [path, active, entries, query, clip, layoutList]);
  // на старте геометрия панели (вырезы, безопасные зоны) доходит до финала не в первом кадре:
  // держим список скрытым до первого честного расчёта и пересчитываем по факту изменения панели
  const [listShown, setListShown] = useState(false);
  useLayoutEffect(() => {
    if (listShown) return;
    // старт: ждём, пока панель перестанет менять геометрию, и показываем список
    // синхронно в том же кадре, где сделан финальный расчёт — без промежуточных отрисовок
    let stable = 0, prevH = -1, raf;
    const tick = () => {
      const h = navRef.current ? navRef.current.getBoundingClientRect().height : 0;
      if (Math.abs(h - prevH) < 0.5) stable++; else stable = 0;
      prevH = h;
      layoutList();
      if (stable >= 2) { setListShown(true); return; }
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    const t = setTimeout(() => { layoutList(); setListShown(true); }, 400); // предохранитель
    return () => { cancelAnimationFrame(raf); clearTimeout(t); };
    /* eslint-disable-next-line */
  }, [listShown]);
  useEffect(() => {
    let ro;
    if (typeof ResizeObserver !== "undefined" && navRef.current) { ro = new ResizeObserver(() => layoutList()); ro.observe(navRef.current); }
    const vv = window.visualViewport;
    const onVV = () => layoutList();
    if (vv) vv.addEventListener("resize", onVV);
    return () => { if (ro) ro.disconnect(); if (vv) vv.removeEventListener("resize", onVV); };
  }, [layoutList]);
  const [fsBar, setFsBar] = useState(null); // { top, h, label } — ползунок быстрой прокрутки
  const fsHide = useRef();
  const fsDrag = useRef(false);
  const updateFs = (el) => {
    if (!el) return;
    const over = el.scrollHeight - el.clientHeight;
    if (over < el.clientHeight * 1.5) { setFsBar(null); return; } // короткие списки — ползунок не нужен
    const navH = parseFloat(el.style.paddingBottom) || 0;
    const track = el.clientHeight - navH - 16;
    const h = Math.max(48, track * (el.clientHeight / el.scrollHeight));
    const top = 8 + (track - h) * (el.scrollTop / over);
    setFsBar({ top, h, label: fsLabelAt(el) });
    clearTimeout(fsHide.current);
    if (!fsDrag.current) fsHide.current = setTimeout(() => setFsBar((b) => (b ? { ...b, idle: true } : null)), 1200);
  };
  const fsLabelAt = (el) => {
    const wrap = spacerRef.current && spacerRef.current.parentElement; if (!wrap) return "";
    const rows = Array.from(wrap.children).filter((k) => k !== spacerRef.current && k.getBoundingClientRect().height > 0);
    const top = el.getBoundingClientRect().top + 4;
    for (const r of rows) { const b = r.getBoundingClientRect(); if (b.bottom > top) return (r.dataset && r.dataset.nm) ? r.dataset.nm.slice(0, 1).toUpperCase() : ""; }
    return "";
  };
  const fsFromY = (clientY) => {
    const el = listRef.current; if (!el) return;
    const navH = parseFloat(el.style.paddingBottom) || 0;
    const r = el.getBoundingClientRect();
    const track = el.clientHeight - navH - 16;
    const h = Math.max(48, track * (el.clientHeight / el.scrollHeight));
    const p = Math.min(1, Math.max(0, (clientY - r.top - 8 - h / 2) / Math.max(1, track - h)));
    el.scrollTop = p * (el.scrollHeight - el.clientHeight);
    updateFs(el);
  };
  const onListScroll = (e) => { const el = e.currentTarget; updateFs(el); if (restoring.current) return; if (el.scrollHeight <= el.clientHeight + 1) return; scrollPos.current[pathKeyRef.current] = el.scrollTop; };
  // Фоновая подгрузка превью: только видимые на экране строки, ограниченная нагрузка
  const slideRef = useRef(0);
  const seenKeys = useRef(new Set());
  const thumbQueue = useRef([]);
  const thumbRunning = useRef(0);
  const thumbWanted = useRef(new Set());
  const THUMB_CONCURRENCY = 3;
  const tkeyOf = (e) => e.uri + "|" + (e.mtime || 0) + "|" + (e.size || 0);
  const pumpThumbs = useCallback(() => {
    if (slideRef.current !== 0) return; // не грузим превью во время слайд-анимации — иначе дёргается
    while (thumbRunning.current < THUMB_CONCURRENCY && thumbQueue.current.length) {
      const it = thumbQueue.current.shift();
      if (thumbs[it.key] || !thumbWanted.current.has(it.key)) continue;
      thumbRunning.current++;
      (it.gd ? Apps.gdriveThumb({ id: it.gd.id, link: it.gd.link }) : Apps.thumb({ uri: it.uri }))
        .then((r) => { if (r && r.thumb) setThumbs((m) => ({ ...m, [it.key]: r.thumb })); })
        .catch(() => {})
        .finally(() => { thumbRunning.current--; setTimeout(pumpThumbs, 30); });
    }
  }, [thumbs]);
  const requestThumb = useCallback((uri, key, gd) => {
    const k = key || uri;
    if (!uri || thumbs[k] || thumbWanted.current.has(k)) return;
    thumbWanted.current.add(k);
    thumbQueue.current.push({ uri, key: k, gd: gd || null });
    pumpThumbs();
  }, [thumbs, pumpThumbs]);
  const releaseThumb = useCallback((uri, key) => { thumbWanted.current.delete(key || uri); }, []);
  useEffect(() => { slideRef.current = slide; if (slide === 0) pumpThumbs(); /* eslint-disable-next-line */ }, [slide]);
  // очистка кэша превью раз за сессию
  useEffect(() => { Apps.thumbSweep && Apps.thumbSweep().catch(() => {}); }, []);
  // при смене папки сбрасываем очередь желаемых (новые строки сами запросят)
  useEffect(() => { thumbQueue.current = []; thumbWanted.current = new Set(); }, [path, active]);
  const silentRefresh = useCallback(async () => {
    if (srcRef.current) return; // открыт Диск или WebDAV — локальное обновление не к месту
    try {
      const u = await Filesystem.getUri({ path, directory: DIR });
      let files;
      try { const r = await Apps.list({ uri: u.uri }); files = r.files; } catch { return; }
      localCache.current[path] = files || []; lcSave();
      setEntries((prev) => { const a = JSON.stringify((prev || []).map((x) => x.name + x.size + x.mtime)); const b = JSON.stringify((files || []).map((x) => x.name + x.size + x.mtime)); return a === b ? prev : (files || []); });
    } catch {}
  }, [path]);
  useEffect(() => {
    let h, t;
    const onChange = () => { clearTimeout(t); t = setTimeout(silentRefresh, 250); };
    Apps.addListener("fschange", onChange).then((l) => (h = l));
    return () => { clearTimeout(t); h && h.remove(); };
  }, [silentRefresh]);
  useEffect(() => { if (curUri) Apps.watch({ uri: curUri }).catch(() => {}); }, [curUri]);
  // заранее готовим превью для видимой части папки — иначе они появляются рывками при прокрутке
  useEffect(() => {
    if (!entries || !entries.length) return;
    const t = setTimeout(() => {
      const uris = entries
        .filter((e) => e.type !== "directory" && !e.remote && e.uri && (isImg(e.name) || isVid(e.name)))
        .slice(0, 60)
        .map((e) => e.uri);
      if (uris.length) Apps.warmThumbs({ uris }).catch(() => {});
    }, 250);
    return () => clearTimeout(t);
  }, [entries]);
  // пустой съёмный том без доступа — предлагаем дать доступ (чтение USB часто только через SAF)
  const safAskedRef = useRef(new Set());
  useEffect(() => {
    if (loading || !path.startsWith("@abs:") || entries.length > 0) return;
    const abs = path.slice(5);
    if (safAskedRef.current.has(abs)) return;
    Apps.safStatus({ path: abs }).then((st) => {
      if (st && st.needed && !st.granted) { safAskedRef.current.add(abs); setSafPrompt({ abs }); }
    }).catch(() => {});
  }, [loading, entries, path]);
  // изменения снаружи приложения (докачался файл, снято фото) — обновляемся сразу, а не по возврату
  useEffect(() => {
    let h, t;
    Apps.watchMedia().catch(() => {});
    const onMedia = () => { clearTimeout(t); t = setTimeout(silentRefresh, 400); };
    Apps.addListener("mediaChanged", onMedia).then((l) => (h = l));
    return () => { clearTimeout(t); h && h.remove(); };
  }, [silentRefresh]);
  useLayoutEffect(() => { switchingRef.current = true; list(); exitSel(); setQuery(null); const _k = active + "|" + path; setTimeout(() => seenKeys.current.add(_k), 350); /* eslint-disable-next-line */ }, [active, path, srcKey]);
  useEffect(() => { let h; CapApp.addListener("resume", () => list()).then((l) => (h = l)); return () => h && h.remove(); }, [list]);
  useEffect(() => {
    let cancelled = false;
    const t = setTimeout(async () => {
      for (const tb of tabs) {
        if (cancelled) break;
        if (tb.src) continue;
        const p = tb.path || "";
        if (localCache.current[p]) continue;
        try {
          const u = await Filesystem.getUri({ path: p, directory: DIR });
          if (cancelled) break;
          const r = await Apps.list({ uri: u.uri });
          if (cancelled) break;
          localCache.current[p] = r.files || []; lcSave();
        } catch {}
      }
    }, 900);
    return () => { cancelled = true; clearTimeout(t); };
    /* eslint-disable-next-line */
  }, []);
  useEffect(() => {
    const onVis = () => { if (document.visibilityState === "visible") { checkAccess(); list(); } };
    document.addEventListener("visibilitychange", onVis);
    window.addEventListener("focus", onVis);
    return () => { document.removeEventListener("visibilitychange", onVis); window.removeEventListener("focus", onVis); };
  }, [list]);
  useEffect(() => { ls.set(SORTKEY, sortMode); }, [sortMode]);
  useEffect(() => {
    if (!gdIn) return;
    let dead = false;
    const tok = localStorage.getItem(GDPT_KEY) || "";
    Apps.gdriveChanges({ token: tok }).then((r) => { if (dead || !r) return; if (r.token) localStorage.setItem(GDPT_KEY, r.token); if (r.changed) gdCacheClear(); }).catch(() => {});
    return () => { dead = true; };
  }, [gdIn]);
  const [propApkIcon, setPropApkIcon] = useState(null);
  useEffect(() => {
    setPropApkIcon(null);
    if (props && /\.apk$/i.test(props.name)) { Apps.apkInfo({ uri: props.uri }).then((info) => setPropApkIcon(info && info.icon || null)).catch(() => {}); }
  }, [props]);
  const [shz, setShz] = useState(null);
  // ---- Резервная копия настроек ----
  const [backupTabs, setBackupTabs] = useState(false);
  const [exportPick, setExportPick] = useState(null); // { payload } — режим выбора папки для сохранения настроек
  const exportSettings = (withTabs) => {
    try {
      const keys = withTabs ? [...BACKUP_KEYS, ...BACKUP_TABS_KEYS] : BACKUP_KEYS;
      const data = {};
      for (const k of [...new Set(keys)]) { const v = ls.get(k); if (v != null) data[k] = v; }
      const payload = JSON.stringify({ app: "YevFiles", kind: "settings", version: APP_VERSION, tabs: !!withTabs, data }, null, 2);
      setExportPick({ payload });
      setSettings(false); setSettingsPage(null); // уходим в файловый менеджер выбирать папку
    } catch (e) { showToast("Ошибка экспорта: " + (e?.message || "")); }
  };
  const doExportHere = async () => {
    const pk = exportPick; if (!pk) return;
    setExportPick(null);
    const name = "YevFiles_settings.json";
    try {
      if (path.startsWith("@abs:")) {
        const abs = path.slice(5);
        const st = await Apps.safStatus({ path: abs }).catch(() => ({}));
        if (st && st.needed) {
          if (!st.granted) { setSafPrompt({ abs }); setExportPick(pk); return; }
          // пишем во временный файл и копируем на носитель через SAF
          const tmp = "Download/.yevtmp/" + name;
          await Filesystem.writeFile({ path: tmp, data: pk.payload, directory: DIR, encoding: Encoding.UTF8, recursive: true });
          const tu = await Filesystem.getUri({ path: tmp, directory: DIR });
          await Apps.safCopyInto({ from: tu.uri, destDir: abs });
          try { await Filesystem.deleteFile({ path: tmp, directory: DIR }); } catch {}
          showToast("Сохранено на носитель"); refresh(); return;
        }
      }
      const rel = (path ? path + "/" : "") + name;
      await Filesystem.writeFile({ path: rel, data: pk.payload, directory: DIR, encoding: Encoding.UTF8, recursive: true });
      showToast("Сохранено: " + name); refresh();
    } catch (e) { showToast("Ошибка сохранения: " + (e?.message || "")); }
  };
  const importInputRef = useRef(null);
  const importSettings = async (file) => {
    try {
      const text = await file.text();
      const obj = JSON.parse(text);
      const data = obj && obj.data;
      if (!data || obj.kind !== "settings") { showToast("Это не файл настроек YevFiles"); return; }
      let n = 0;
      for (const k of Object.keys(data)) {
        if (![...BACKUP_KEYS, ...BACKUP_TABS_KEYS].includes(k)) continue; // чужие ключи игнорируем
        ls.set(k, data[k]); n++;
      }
      showToast("Импортировано настроек: " + n + ". Перезапуск…");
      setTimeout(() => { try { location.reload(); } catch {} }, 900);
    } catch (e) { showToast("Ошибка импорта: " + (e?.message || "")); }
  };
  const loadShz = React.useCallback(() => {
    Apps.shizukuStatus().then(setShz).catch(() => setShz({ state: "absent" }));
  }, []);
  useEffect(() => {
    if (!settings || settingsPage !== "shizuku") return;
    loadShz();
    const t = setInterval(loadShz, 1500); // состояние меняется снаружи — подхватываем сами
    return () => clearInterval(t);
  }, [settings, settingsPage, loadShz]);
  const [propMeta, setPropMeta] = useState(null);
  useEffect(() => {
    setPropMeta(null);
    if (!props || props.multi || props.type === "directory" || !props.uri) return;
    let dead = false;
    Apps.fileMeta({ uri: props.uri }).then((m) => { if (!dead && m && m.kind && m.kind !== "other") setPropMeta(m); }).catch(() => {});
    return () => { dead = true; };
  }, [props]);
  const [propSize, setPropSize] = useState(null);
  useEffect(() => {
    if (props && props.multi) {
      setPropCount(null); setPropSize(null);
      let dead = false;
      (async () => {
        let total = 0;
        for (const it of props.multi) {
          if (dead) return;
          if (it.type === "directory") {
            try { const c = sizeCache.get(it.uri); if (c && Date.now() - c.t < 60000) total += c.bytes; else { const r = await Apps.pathSize({ uri: it.uri }); sizeCache.set(it.uri, { bytes: r.bytes || 0, t: Date.now() }); total += r.bytes || 0; } } catch {}
          } else total += it.size || 0;
        }
        if (!dead) setPropSize(total);
      })();
      return () => { dead = true; };
    }
    if (!props || props.type !== "directory") { setPropCount(null); setPropSize(null); return; }
    (async () => { try { const { files } = await Filesystem.readdir({ path: props.uri }); setPropCount({ d: files.filter((f) => f.type === "directory").length, f: files.filter((f) => f.type !== "directory").length }); } catch { setPropCount(null); } })();
    setPropSize(null);
    (async () => { try { const c = sizeCache.get(props.uri); if (c && Date.now() - c.t < 60000) { setPropSize(c.bytes); return; } const r = await Apps.pathSize({ uri: props.uri }); sizeCache.set(props.uri, { bytes: r.bytes || 0, t: Date.now() }); setPropSize(r.bytes || 0); } catch { setPropSize(null); } })();
  }, [props]);

  const exitSel = () => { setSel(new Set()); setSelMode(false); setConfirmDel(null); setSelMenu(false); };
  const setTabPath = (p) => setTabs((ts) => ts.map((x, i) => (i === active ? { ...x, path: p } : x)));
  // Крошки: путь разбит на сегменты, каждый — переход на свой уровень
  const crumbRef = useRef(null);
  const [crumbOver, setCrumbOver] = useState(false);
  const crumbs = React.useMemo(() => {
    const src = cur && cur.src;
    if (src) return (src.stack || []).map((x, i) => ({ name: x.name, i }));
    if (!path) return [];
    if (path.startsWith("@abs:")) {
      const raw = path.slice(5);
      const vol = volumes.find((v) => raw === v.path || raw.startsWith(v.path + "/"));
      const rest = vol ? raw.slice(vol.path.length).split("/").filter(Boolean) : raw.split("/").filter(Boolean);
      const head = { name: vol ? vol.name : "Хранилище", i: 0, abs: true };
      return [head, ...rest.map((name, k) => ({ name, i: k + 1, abs: true }))];
    }
    return path.split("/").filter(Boolean).map((name, i) => ({ name, i }));
  }, [cur && cur.src, path, volumes]);
  const goCrumb = (i) => {
    if (i === crumbs.length - 1) return; // уже здесь
    const src = srcRef.current;
    slideNav(-1);
    if (src) {
      const st = (src.stack || []).slice(0, i + 1), top = st[st.length - 1];
      if (!top) { setTabs((ts) => ts.map((t, k) => (k === active ? { ...t, src: null } : t))); return; }
      setTabs((ts) => ts.map((t, k) => (k === active ? { ...t, src: src.kind === "gdrive" ? { ...src, folder: top.id, stack: st } : { ...src, url: top.url, stack: st } } : t)));
      return;
    }
    if (path.startsWith("@abs:")) {
      const raw = path.slice(5);
      const vol = volumes.find((v) => raw === v.path || raw.startsWith(v.path + "/"));
      const base = vol ? vol.path : "";
      const rest = (vol ? raw.slice(vol.path.length) : raw).split("/").filter(Boolean);
      const sub = rest.slice(0, i).join("/"); // i=0 → корень тома
      setTabPath("@abs:" + base + (sub ? "/" + sub : ""));
      return;
    }
    setTabPath(path.split("/").filter(Boolean).slice(0, i + 1).join("/"));
  };
  // лента сама доезжает до текущей папки
  useLayoutEffect(() => {
    const el = crumbRef.current; if (!el) return;
    el.scrollLeft = el.scrollWidth;
    setCrumbOver(el.scrollWidth > el.clientWidth + 1);
  }, [crumbs]);
  const goUp = () => {
    const src = srcRef.current;
    if (src) {
      slideNav(-1);
      if (src.stack.length <= 1) { setTabs((ts) => ts.map((t, i) => (i === active ? { ...t, src: null } : t))); return; }
      const st = src.stack.slice(0, -1), top = st[st.length - 1];
      setTabs((ts) => ts.map((t, i) => (i === active ? { ...t, src: src.kind === "gdrive" ? { ...src, folder: top.id, stack: st } : { ...src, url: top.url, stack: st } } : t)));
      return;
    }
    if (path) {
      slideNav(-1);
      // из корня тома-флешки уходим не в /storage, а обратно в шторку
      if (path.startsWith("@abs:")) {
        const raw = path.slice(5);
        const vol = volumes.find((v) => raw === v.path);
        if (vol) { setDrawer(true); return; }
      }
      setTabPath(parent(path));
    }
  };
  const closeTab = (i) => { if (tabs.length === 1) return; const t = tabs.filter((_, idx) => idx !== i); persist(t); setActive(Math.max(0, Math.min(active, t.length - 1))); };

  const backRef = useRef(() => {});
  const backExit = useRef(0);
  backRef.current = () => {
    if (pwPrompt) { resolvePassword(null); return; }
    if (fontView) { setFontView(null); return; }
    if (exportPick) { setExportPick(null); return; }
    if (savePick) { restoreSavePick(); return; }
    if (pendingExtract) { setPendingExtract(null); return; }
    if (conflict) { resolveConflict("cancel", false); return; }
    if (settings) { if (settingsPage) { setSettingsPage(null); return; } setSettings(false); return; }
    if (arcView && arcSel.size > 0) { setArcSel(new Set()); return; }
    if (arcView && arcPath) { setArcPath(arcPath.replace(/[^/]+\/$/, "")); return; }
    if (arcView) { setArcView(null); return; }
    if (pasteMenu) { setPasteMenu(false); return; }
    if (openMenu) { setOpenMenu(null); return; }
    if (props) { setProps(null); return; }
    if (pdf) { closePdf(); return; }
    if (player) { playerClose(); return; }
    if (viewerDel) { setViewerDel(false); return; }
    if (viewer) { setViewer(null); return; }
    if (sheet) { setSheet(null); return; }
    if (gd) { gdBack(); return; }
    if (wd) { wdBack(); return; }
    if (drawer) { setDrawer(false); return; }
    if (selMenu) { setSelMenu(false); return; }
    if (headMenu) { if (headSub) { setHeadSub(null); return; } setHeadMenu(false); return; }
    if (confirmDel) { setConfirmDel(null); return; }
    if (createOpen) { setCreateOpen(false); return; }
    if (query !== null) { setQuery(null); return; }
    if (selMode) { exitSel(); return; }
    { const t = tabs[active]; if (t && t.src) { goUp(); return; } const atStart = t && t.startup && (t.startupPath || "") === path; if (path && !atStart) { goUp(); return; } }
    const now = Date.now();
    if (now - backExit.current < 2000) { CapApp.exitApp(); }
    else { backExit.current = now; showToast("Нажмите «Назад» ещё раз для выхода"); }
  };
  useEffect(() => {
    let h;
    CapApp.addListener("backButton", () => backRef.current()).then((l) => (h = l));
    return () => { h && h.remove(); };
  }, []);

  const toggle = (name) => { const n = new Set(sel); n.has(name) ? n.delete(name) : n.add(name); setSel(n); setSelMode(n.size > 0); };
  const selAllWant = useRef(false);
  const switchingRef = useRef(false);
  const selectAll = () => {
    if (arcView && arcView.entries) { setArcSel(new Set(arcView.entries.map((e) => e.name))); return; }
    if (!loading && !switchingRef.current) { if (!visible.length) { showToast("Папка пуста"); return; } selAllWant.current = false; setSelMode(true); setSel(new Set(visible.map((e) => e.name))); return; }
    selAllWant.current = true; setSelMode(true);
  };

  const videoPlaylist = (e) => {
    if (!isVid(e.name)) return undefined;
    try {
      const list = visibleRef.current.filter((x) => x.type !== "directory" && isVid(x.name) && !x.remote).map((x) => x.uri);
      return list.length > 1 ? list : undefined;
    } catch { return undefined; }
  };
  const openExternal = async (e) => {
    Apps.warmThumbs({ uris: [] }).catch(() => {}); // стоп фоновому прогреву: не мешать открытию
    const mime = mimeOf(e.name);
    const ext = (e.name.split(".").pop() || "").toLowerCase();
    // apk и архивы — всегда меню выбора (там есть «Открыть как архив»), без авто-привязки
    if (EXT.archive.includes(ext)) { await showOpenMenu(e, mime); return; }
    const cat = defaultOpenAs(e.name);
    const defs = loadMap(DEFKEY);
    const d = defs[cat] || defs[mime];
    if (d) { showToast("Открываю…"); try { const [pkg, act] = d.split("|"); await Apps.open({ uri: e.uri, mime, packageName: pkg, activityName: act, uris: videoPlaylist(e) }); return; } catch {} }
    await showOpenMenu(e, mime);
  };
  const showOpenMenu = async (e, mime, opts) => {
    const edit = !!(opts && opts.edit);
    const split = !!(opts && opts.split);
    const cat = OPEN_AS.some(([m]) => m === mime) ? mime : defaultOpenAs(e.name);
    let apps = [];
    if (!split) { try { const r = await Apps.query({ uri: e.uri, mime, action: edit ? "edit" : "view" }); apps = (r.apps || []).filter((a) => a.packageName !== "leshugan.fm"); } catch {} }
    setOpenMenu({ file: e, mime: cat, apps, useDefault: false, editHide: false, edit, split, originX: pX.current, originY: pY.current });
    if (/\.(apk|apks|xapk|apkm|apkx)$/i.test(e.name)) { Apps.apkInfo({ uri: e.uri }).then((info) => setOpenMenu((m) => (m && m.file === e ? { ...m, apkInfo: info } : m))).catch(() => {}); }
  };
  const pickApp = async (app) => {
    const om = openMenu;
    if (om.editHide) {
      const hm = loadMap(HIDEKEY); const arr = new Set(hm[om.mime] || []);
      const id = app.packageName + "|" + app.activityName;
      arr.has(id) ? arr.delete(id) : arr.add(id);
      hm[om.mime] = [...arr]; saveMap(HIDEKEY, hm); setOpenMenu({ ...om }); return;
    }
    const defs = loadMap(DEFKEY);
    const openMime = om.asCat ? om.mime : mimeOf(om.file.name);
    if (om.edit) { setOpenMenu(null); try { await Apps.open({ uri: om.file.uri, mime: mimeOf(om.file.name), packageName: app.packageName, activityName: app.activityName, action: "edit" }); } catch (err) { showToast("Не удалось открыть: " + (err?.message || "")); } return; }
    const dkey = defaultOpenAs(om.file.name);
    if (om.useDefault) { defs[dkey] = app.packageName + "|" + app.activityName; saveMap(DEFKEY, defs); }
    else if (defs[dkey]) { delete defs[dkey]; saveMap(DEFKEY, defs); } // разовый выбор — сбросить прежнюю привязку
    setOpenMenu(null);
    try { await Apps.open({ uri: om.file.uri, mime: openMime, packageName: app.packageName, activityName: app.activityName, uris: videoPlaylist(om.file) }); }
    catch (err) { showToast("Не удалось открыть: " + (err?.message || "")); }
  };
  const reQueryAs = async (mime) => {
    const e = openMenu.file;
    setOpenMenu((m) => (m ? { ...m, mime, asCat: true, apps: null } : m));
    try { const { apps } = await Apps.query({ uri: e.uri, mime, action: "view" }); const fa = (apps || []).filter((a) => a.packageName !== "leshugan.fm"); setOpenMenu((m) => (m && m.file === e ? { ...m, apps: fa } : m)); }
    catch { setOpenMenu((m) => (m && m.file === e ? { ...m, apps: [] } : m)); }
  };
  const arcAnchor = useRef(null);
  const absPath = async (rel) => { const u = await Filesystem.getUri({ path: rel, directory: DIR }); let p = u.uri; if (p.startsWith("file://")) p = p.slice(7); try { p = decodeURIComponent(p); } catch {} return p; };
  const extractAllTo = async (uri, destRel, names) => {
    const destDir = await absPath(destRel);
    // проверка конфликтов имён с содержимым папки назначения
    try {
      const zl = await Apps.zipList({ uri, password: getCachedPw(uri) || undefined }); // список берётся из кэша, повторного разбора нет
      const dl = await Filesystem.readdir({ path: destDir }).catch(() => ({ files: [] }));
      const destNames = new Set((dl.files || []).map((f) => f.name));
      const wanted = names ? names : (zl.entries || []).map((x) => x.name);
      const tops = new Set(wanted.map((n) => String(n).split("/")[0]).filter(Boolean));
      const clash = [...tops].filter((n) => destNames.has(n));
      if (clash.length) {
        const action = await askConflict(clash.length === 1 ? clash[0] : clash.length + " объект(ов) совпадают");
        if (action === "cancel" || action === "skip") { showToast("Отменено"); return; }
        // overwrite/rename → извлекаем (нативно перезаписывает)
      }
    } catch {}
    let sub = null;
    try { sub = await Apps.addListener("opProgress", (ev) => setProgress({ current: ev.done, total: ev.total, name: ev.name, mode: "ext" })); } catch {}
    setProgress({ current: 0, total: (names ? names.length : 1), name: "", mode: "ext" });
    const doExtract = async (password) => Apps.zipExtractAll({ uri, dest: destDir, entries: names || undefined, password: password || undefined });
    try {
      await doExtract(getCachedPw(uri));
      showToast("Извлечено в " + (baseName(destRel) || "Storage"));
    } catch (e) {
      const enc = e && (e.code === "ENCRYPTED" || e.code === "BADPASS" || /ENCRYPTED|BADPASS|пароль/i.test(e.message || ""));
      if (enc) {
        let ok = false;
        for (let t = 0; t < 3 && !ok; t++) {
          const pw = await askPassword(t > 0);
          if (pw == null || pw === "") { break; }
          try { await doExtract(pw); setCachedPw(uri, pw); showToast("Извлечено в " + (baseName(destRel) || "Storage")); ok = true; }
          catch (e2) { if (t === 2) showToast("Неверный пароль"); }
        }
      } else showToast("Ошибка: " + (e?.message || ""));
    }
    if (sub) try { sub.remove(); } catch {}
    setProgress(null); await refresh();
  };
  const startExtract = (uri, names, label) => { setOpenMenu(null); setArcView(null); setArcSel(new Set()); setPendingExtract({ uri, names: names || null, label: label || "архив" }); };
  const doExtractHere = async () => { const pe = pendingExtract; setPendingExtract(null); if (pe) await extractAllTo(pe.uri, path, pe.names); };
  const arcBase = (n) => n.replace(/\.[^.]+$/, "");
  const [dragId, setDragId] = useState(null);
  const dragRef = useRef(null);
  const suppressClick = useRef(false);
  const menuCat = (om) => { const f = om.file; const ext = (f.name.split(".").pop() || "").toLowerCase(); if (om.split) return "split"; if (/\.apk$/i.test(f.name)) return "apk"; if (EXT.archive.includes(ext)) return "archive"; if (isImg(f.name)) return "image"; return om.mime; };
  // ЕДИНЫЙ список: приложения (логическая категория) сверху по умолчанию, стоковые снизу; всё скрываемо/перемещаемо
  const buildStockItems = (om) => {
    const f = om.file; const ext = (f.name.split(".").pop() || "").toLowerCase();
    const isApkF = /\.apk$/i.test(f.name); const isArc = /\.(zip|jar|war|obb|rar|7z|tar|tgz|gz|bz2|xz|001|z01|r00)$/i.test(f.name) || /\.part\d+\.rar$/i.test(f.name) || /\.r\d\d$/i.test(f.name) || /\.z\d\d$/i.test(f.name); const items = [];
    const fm = mimeOf(f.name);
    const showApps = !om.split && ((fm !== "*/*" && fm !== "application/octet-stream") || (om.asCat && om.mime !== "*/*"));
    if (showApps) (om.apps || []).forEach((a) => items.push({ id: "app|" + a.packageName + "|" + a.activityName, label: a.label, icon: a.icon, color: TXT, onClick: () => pickApp(a) }));
    if (isImg(f.name)) items.push({ id: "viewer", label: "Открыть (просмотр)", d: I.img, size: 26, color: GOLD, onClick: () => { const defs = loadMap(DEFKEY); if (om.useDefault) defs[defaultOpenAs(f.name)] = "__viewer__"; else if (defs[defaultOpenAs(f.name)]) delete defs[defaultOpenAs(f.name)]; saveMap(DEFKEY, defs); setOpenMenu(null); openViewer(f); } });
    if (isPdf(f.name)) items.push({ id: "pdfview", label: "PDF Читалка", d: I.pdf, size: 26, color: "#E0574F", onClick: () => { const defs = loadMap(DEFKEY); if (om.useDefault) defs[defaultOpenAs(f.name)] = "__pdf__"; else if (defs[defaultOpenAs(f.name)]) delete defs[defaultOpenAs(f.name)]; saveMap(DEFKEY, defs); setOpenMenu(null); openPdf(f); } });
    if (isAudio(f.name)) items.push({ id: "player", label: "Воспроизвести", d: I.audio, size: 26, color: "#E36FB0", onClick: () => { const defs = loadMap(DEFKEY); if (om.useDefault) defs[defaultOpenAs(f.name)] = "__player__"; else if (defs[defaultOpenAs(f.name)]) delete defs[defaultOpenAs(f.name)]; saveMap(DEFKEY, defs); setOpenMenu(null); openAudio(f); } });
    if (isApkF) {
      items.push({ id: "apk_archive", label: "Открыть как архив", d: I.folder, size: 26, color: GOLD, onClick: () => openArchive(f) });
    }
    if (om.split) {
      items.push({ id: "split_install", label: "Установщик пакетов (split)", d: I.plus, size: 28, color: "#6FD3A8", onClick: () => { setOpenMenu(null); showToast("Установка пакета…"); Apps.installSplit({ uri: f.uri }).catch((er) => showToast("Ошибка: " + (er?.message || ""))); } });
      items.push({ id: "split_archive", label: "Открыть как архив", d: I.folder, size: 26, color: GOLD, onClick: () => openArchive(f) });
    }
    if (isArc || isGzTar(f.name)) {
      items.push({ id: "arc_open", label: "Открыть", d: I.folder, size: 26, color: GOLD, onClick: () => openArchive(f) });
      items.push({ id: "arc_to", label: "Распаковать в…", d: I.dl, size: 22, color: TXT, onClick: () => startExtract(f.uri, null, f.name) });
      items.push({ id: "arc_folder", label: "Распаковать в папку «" + arcBase(f.name) + "»", d: I.folder, size: 22, color: TXT, onClick: () => { setOpenMenu(null); extractAllTo(f.uri, join(path, arcBase(f.name)), null); } });
      items.push({ id: "arc_here", label: "Распаковать здесь", d: I.dl, size: 22, color: TXT, onClick: () => { setOpenMenu(null); extractAllTo(f.uri, path, null); } });
    }
    return items;
  };
  const orderItems = (items, cat) => { const saved = loadMap(ORDERKEY)[cat] || []; const byId = {}; items.forEach((it) => (byId[it.id] = it)); const res = []; saved.forEach((id) => { if (byId[id]) { res.push(byId[id]); delete byId[id]; } }); items.forEach((it) => { if (byId[it.id]) res.push(it); }); return res; };
  const toggleHideItem = (cat, id) => { const m = loadMap(HIDEKEY); const arr = new Set(m[cat] || []); if (arr.has(id)) arr.delete(id); else arr.add(id); m[cat] = [...arr]; saveMap(HIDEKEY, m); setOpenMenu((o) => (o ? { ...o } : o)); };
  const menuDragStart = (idx, e, ordered) => {
    if (!openMenu || !openMenu.editHide) return;
    const id = ordered[idx] && ordered[idx].id; if (!id) return;
    const y0 = e.touches[0].clientY, x0 = e.touches[0].clientX;
    dragRef.current = { id, active: false, moved: false, y0, x0, order: ordered.map((x) => x.id), t: setTimeout(() => {
      const dt = dragRef.current; if (!dt || dt.moved) return; dt.active = true;
      const els = dt.order.map((i) => document.querySelector('[data-mid="' + i + '"]'));
      dt.slots = els.map((el) => { const r = el.getBoundingClientRect(); return { top: r.top, h: r.height, mid: r.top + r.height / 2 }; });
      dt.els = els; dt.startIndex = dt.order.indexOf(id); dt.curIndex = dt.startIndex; setDragId(id); buzz(12);
    }, 320) };
  };
  const menuDragMove = (e) => {
    const dt = dragRef.current; if (!dt) return;
    if (!dt.active) { const tt = e.touches[0]; if (Math.abs(tt.clientX - dt.x0) > 8 || Math.abs(tt.clientY - dt.y0) > 8) { dt.moved = true; if (dt.t) clearTimeout(dt.t); } return; }
    e.preventDefault(); const t = e.touches[0]; if (!dt.slots) return;
    const startSlot = dt.slots[dt.startIndex], self = dt.els[dt.startIndex];
    const dragY = t.clientY - dt.y0;
    if (self) { self.style.transition = "none"; self.style.transform = "translateY(" + dragY + "px)"; self.style.zIndex = "30"; self.style.position = "relative"; }
    const dragMid = startSlot.mid + dragY; let newIndex = dt.startIndex;
    for (let i = 0; i < dt.slots.length; i++) { if (i === dt.startIndex) continue; const s = dt.slots[i]; if (i < dt.startIndex && dragMid < s.mid) newIndex = Math.min(newIndex, i); else if (i > dt.startIndex && dragMid > s.mid) newIndex = Math.max(newIndex, i); }
    if (newIndex !== dt.curIndex) { dt.curIndex = newIndex; const dragH = startSlot.h; dt.order.forEach((id, i) => { if (i === dt.startIndex) return; const el = dt.els[i]; if (!el) return; let shift = 0; if (dt.startIndex < newIndex && i > dt.startIndex && i <= newIndex) shift = -dragH; else if (dt.startIndex > newIndex && i < dt.startIndex && i >= newIndex) shift = dragH; el.style.transition = "transform 200ms cubic-bezier(.22,1,.36,1)"; el.style.transform = shift ? "translateY(" + shift + "px)" : ""; }); }
  };
  const menuDragEnd = (cat) => {
    const dt = dragRef.current; dragRef.current = null;
    if (!dt) return; if (dt.t) clearTimeout(dt.t);
    if (!dt.active) return;
    (dt.els || []).forEach((el) => { if (el) { el.style.transition = ""; el.style.transform = ""; el.style.zIndex = ""; el.style.position = ""; } });
    suppressClick.current = true; setTimeout(() => (suppressClick.current = false), 60);
    const from = dt.startIndex, to = dt.curIndex; setDragId(null);
    if (from !== to) { const no = [...dt.order]; const [m] = no.splice(from, 1); no.splice(to, 0, m); const om = loadMap(ORDERKEY); om[cat] = no; saveMap(ORDERKEY, om); setOpenMenu((o) => (o ? { ...o } : o)); }
  };
  const openArchive = async (e) => {
    setOpenMenu(null);
    setArcPath("");
    setArcView({ name: e.name, uri: e.uri, entries: null });
    const mapEntries = (r) => (r.entries || []).filter((x) => !x.dir).map((x) => ({ name: x.name, size: x.size || 0 })); // порядок задаётся при показе уровня
    const T0 = Date.now();
    try {
      const known = getCachedPw(e.uri);
      let r = await Apps.zipList({ uri: e.uri, password: known || undefined });
      const T1 = Date.now();
      let entries = mapEntries(r);
      const T2 = Date.now();
      arcTimes.current = { T0, T1, T2, ms: r.ms, msOpen: r.msOpen, count: r.count != null ? r.count : entries.length, src: r.src };
      // пароль нужен, если данные зашифрованы или скрыты сами имена (пустой список)
      if (r.encrypted && !(known && entries.length)) {
        const destDir = await absPath("Download/.yevtmp");
        let ok = false;
        for (let t = 0; t < 3 && !ok; t++) {
          const pw = await askPassword(t > 0);
          if (pw == null || pw === "") { setArcView(null); return; }
          try {
            const r2 = await Apps.zipList({ uri: e.uri, password: pw });
            const list = mapEntries(r2);
            if (!list.length) throw new Error("empty");            // имена не расшифровались — пароль не тот
            // проверяем пароль только на первом по порядку файле и только если он небольшой:
            // распаковка ради проверки не должна тормозить открытие
            const first = list[0];
            if (first && (first.size || 0) <= 4 * 1024 * 1024) {
              await Apps.zipExtract({ uri: e.uri, entry: first.name, dest: destDir + "/.pwtest", password: pw, quiet: true });
            }
            setCachedPw(e.uri, pw); entries = list; ok = true;
          } catch (er) { if (t === 2) { showToast("Неверный пароль"); setArcView(null); return; } }
        }
      }
      setArcView({ name: e.name, uri: e.uri, entries });
      const a = arcTimes.current;
      if (a) {
        requestAnimationFrame(() => requestAnimationFrame(() => {
          const total = Date.now() - a.T0;
          if (total >= 300) {   // молчим, когда открылось быстро
            const read = a.ms != null ? a.ms : 0;
            const bridge = Math.max(0, a.T1 - a.T0 - read);
            const prep = a.T2 - a.T1;
            const draw = Math.max(0, Date.now() - a.T2);
            showToast("Открытие " + total + " мс: чтение " + read + " · передача " + bridge + " · подготовка " + prep + " · отрисовка " + draw + " · файлов " + a.count + (a.src ? " · " + a.src : ""), 9000);
          }
          arcTimes.current = null;
        }));
      }
    } catch (err) { setArcView(null); showToast("Не удалось открыть архив: " + (err?.message || "")); }
  };
  const extractOpen = async (entry) => {
    setArcView((m) => (m ? { ...m, busy: "Извлекаю…" } : m));
    try {
      const fname = entry.name.split("/").pop();
      const destDir = await absPath("Download/.yevtmp");
      const doOne = async (password) => Apps.zipExtract({ uri: arcView.uri, entry: entry.name, dest: destDir + "/" + fname, password: password || undefined });
      try { await doOne(getCachedPw(arcView.uri)); }
      catch (err) {
        const enc = err && (err.code === "ENCRYPTED" || err.code === "BADPASS" || /ENCRYPTED|BADPASS|пароль/i.test(err.message || ""));
        if (!enc) throw err;
        let ok = false;
        for (let t = 0; t < 3 && !ok; t++) {
          const pw = await askPassword(t > 0);
          if (pw == null || pw === "") { setArcView((m) => (m ? { ...m, busy: null } : m)); return; }
          try { await doOne(pw); setCachedPw(arcView.uri, pw); ok = true; } catch (e2) { if (t === 2) { showToast("Неверный пароль"); setArcView((m) => (m ? { ...m, busy: null } : m)); return; } }
        }
      }
      const u = await Filesystem.getUri({ path: "Download/.yevtmp/" + fname, directory: DIR });
      setArcView((m) => (m ? { ...m, busy: null } : m)); // архив остаётся открытым, как папка
      const fe = { name: fname, uri: u.uri, type: "file" };
      if (/\.apk$/i.test(fname)) await showOpenMenu(fe, mimeOf(fname)); // меню с вариантами (Установить / Открыть с помощью)
      else await Apps.open({ uri: u.uri, mime: mimeOf(fname) });
    } catch (err) { setArcView((m) => (m ? { ...m, busy: null } : m)); showToast("Не удалось открыть: " + (err?.message || "")); }
  };
  const resetDefault = () => { const defs = loadMap(DEFKEY); const f = openMenu.file; delete defs[openMenu.mime]; delete defs[mimeOf(f.name)]; delete defs[defaultOpenAs(f.name)]; saveMap(DEFKEY, defs); showToast("Привязка сброшена"); };
  const remoteEnter = (e) => {
    const src = srcRef.current; if (!src) return;
    if (e.type === "directory") {
      setSlide(1); setTimeout(() => setSlide(0), 300);
      setTabs((ts) => ts.map((t, i) => (i === active ? { ...t, src: src.kind === "gdrive" ? { ...src, folder: e.id, stack: [...src.stack, { id: e.id, name: e.name }] } : { ...src, url: e.url, stack: [...src.stack, { url: e.url, name: e.name }] } } : t)));
    } else {
      setSheet({ kind: "remote", file: e, src });
    }
  };
  const remoteTempOpen = (e, src) => {
    setSheet(null); showToast("Загрузка…");
    const p = src.kind === "gdrive"
      ? Apps.gdriveGet({ id: e.id, name: e.name, mime: e.mime || "", dest: "temp" })
      : Apps.webdavGet({ url: e.url, user: src.acc.user, pass: src.acc.pass, name: e.name, dest: "temp" });
    p.then((r) => {
      const uri = r.uri || ("file://" + r.path);
      const te = { name: e.name, uri, type: "file" };
      const ext = (e.name.split(".").pop() || "").toLowerCase();
      if (isImg(e.name)) { setViewer({ items: [te], idx: 0 }); setViewerBar(true); setDragX(0); setDragY(0); setZoom(1); setPan({ x: 0, y: 0 }); setViewerDel(false); }
      else if (isPdf(e.name)) openPdf(te);
      else if (isAudio(e.name)) { playerList.current = { uris: [uri], names: [e.name] }; Apps.audioOpen({ uris: [uri], names: [e.name], index: 0, autoNext: false }).catch((er) => showToast("Плеер: " + (er?.message || ""))); setPlayer({ idx: 0, count: 1, name: e.name, playing: true, pos: 0, dur: 0 }); setPlayerMenu(false); }
      else if (EXT.archive.includes(ext)) openArchive(te);
      else Apps.open({ uri, mime: mimeOf(e.name) || "*/*" }).catch((er) => showToast("Открытие: " + (er?.message || "")));
    }).catch((er) => showToast("Ошибка: " + (er?.message || "")));
  };

  const [savePick, setSavePick] = useState(null); // { file, src, prevSrc } — выбор папки для облачного файла
  const saveTo = (file, src) => { setSheet(null); setSavePick({ file, src, prevSrc: src }); setTabs((ts) => ts.map((t, i) => (i === active ? { ...t, src: null } : t))); };
  const restoreSavePick = () => { const sp = savePick; setSavePick(null); if (sp) setTabs((ts) => ts.map((t, i) => (i === active ? { ...t, src: sp.prevSrc } : t))); };
  const doSavePickHere = async () => {
    const sp = savePick; if (!sp) return;
    const e = sp.file, src = sp.src;
    try {
      showToast("Загрузка…");
      const r = src.kind === "gdrive"
        ? await Apps.gdriveGet({ id: e.id, name: e.name, mime: e.mime || "", dest: "temp" })
        : await Apps.webdavGet({ url: e.url, user: src.acc.user, pass: src.acc.pass, name: e.name, dest: "temp" });
      const fromUri = r.uri || ("file://" + r.path);
      if (path.startsWith("@abs:")) {
        const abs = path.slice(5);
        const st = await Apps.safStatus({ path: abs }).catch(() => ({}));
        if (st && st.needed) {
          if (!st.granted) { setSafPrompt({ abs }); return; } // выбор папки не сбрасываем — можно повторить
          await Apps.safCopyInto({ from: fromUri, destDir: abs });
          showToast("Сохранено: " + e.name); restoreSavePick(); refresh(); return;
        }
      }
      await Filesystem.copy({ from: fromUri, to: targetUri(e.name) });
      showToast("Сохранено: " + e.name); restoreSavePick(); refresh();
    } catch (er) { showToast("Ошибка: " + (er?.message || "")); }
  };
  const remoteDownload = (e, src) => {
    setSheet(null); showToast("Загрузка…");
    const done = () => showToast("Скачано → Download/" + e.name), fail = (er) => showToast("Ошибка: " + (er?.message || ""));
    if (src.kind === "gdrive") Apps.gdriveGet({ id: e.id, name: e.name, mime: e.mime || "" }).then(done).catch(fail);
    else Apps.webdavGet({ url: e.url, user: src.acc.user, pass: src.acc.pass, name: e.name }).then(done).catch(fail);
  };
  const open = (e, ev) => {
    if (selMode) { toggle(e.name); return; }
    if (e.remote) { remoteEnter(e); return; }
    if (e.type === "directory") { slideNav(1); setTabPath(join(path, e.name)); return; }
    arcAnchor.current = ev && ev.currentTarget ? ev.currentTarget.getBoundingClientRect().top : null;
    const ext = (e.name.split(".").pop() || "").toLowerCase();
    if (isFont(e.name)) { openFontViewer(e); return; }
    if (isSplitApk(e.name)) { showOpenMenu(e, "application/octet-stream", { split: true }); return; }
    if (isImg(e.name)) {
      const mime = mimeOf(e.name), cat = defaultOpenAs(e.name), defs = loadMap(DEFKEY), d = defs[cat] || defs[mime];
      if (d === "__viewer__") { openViewer(e); return; }
      if (d) { const [pkg, act] = d.split("|"); Apps.open({ uri: e.uri, mime, packageName: pkg, activityName: act, uris: videoPlaylist(e) }).catch(() => showOpenMenu(e, mime)); return; }
      showOpenMenu(e, mime); return;
    }
    if (isPdf(e.name)) {
      const mime = mimeOf(e.name), cat = defaultOpenAs(e.name), defs = loadMap(DEFKEY), d = defs[cat] || defs[mime];
      if (d === "__pdf__") { openPdf(e); return; }
      if (d) { const [pkg, act] = d.split("|"); Apps.open({ uri: e.uri, mime, packageName: pkg, activityName: act, uris: videoPlaylist(e) }).catch(() => showOpenMenu(e, mime)); return; }
      showOpenMenu(e, mime); return;
    }
    if (isAudio(e.name)) {
      const mime = mimeOf(e.name), cat = defaultOpenAs(e.name), defs = loadMap(DEFKEY), d = defs[cat] || defs[mime];
      if (d === "__player__") { openAudio(e); return; }
      if (d) { const [pkg, act] = d.split("|"); Apps.open({ uri: e.uri, mime, packageName: pkg, activityName: act, uris: videoPlaylist(e) }).catch(() => showOpenMenu(e, mime)); return; }
      showOpenMenu(e, mime); return;
    }
    if (EXT.archive.includes(ext)) { showOpenMenu(e, mimeOf(e.name)); return; }
    openExternal(e);
  };

  const addTab = () => { const id = Date.now(); const t = [...tabs, { id, path: "" }]; persist(t); setActive(t.length - 1); };
  const switchTab = (dir) => { const ni = active + dir; if (ni < 0 || ni >= tabs.length) return; setSlide(dir); setActive(ni); setTimeout(() => setSlide(0), 300); };
  const sx = useRef(0), sy = useRef(0), swiped = useRef(false);
  const onTS = (e) => { sx.current = e.touches[0].clientX; sy.current = e.touches[0].clientY; swiped.current = false; };
  const onTM = (e) => { const dx = e.touches[0].clientX - sx.current, dy = e.touches[0].clientY - sy.current; if (!swiped.current && Math.abs(dx) > 45 && Math.abs(dx) > Math.abs(dy) * 1.3) { swiped.current = true; switchTab(dx > 0 ? -1 : 1); } };
  const tabRefs = useRef([]);
  const [tabDragId, setTabDragId] = useState(null);
  const tabDrag = useRef({ pid: null, from: -1, to: -1, startX: 0, startY: 0, rects: [], gap: 6, active: false });
  const clearTabDrag = () => { tabRefs.current.forEach((el) => { if (el) el.style.transform = ""; }); };
  const beginTabDrag = () => {
    const d = tabDrag.current;
    d.rects = tabRefs.current.map((el) => (el ? el.getBoundingClientRect() : null));
    d.active = true; d.to = d.from; buzz(12); setTabDragId(tabs[d.from].id);
    try { const el = tabRefs.current[d.from]; el && el.setPointerCapture(d.pid); } catch {}
  };
  const tabHoldT = useRef();
  const tabsScrollRef = useRef(null);
  useEffect(() => {
    const cont = tabsScrollRef.current, el = tabRefs.current[active];
    if (!cont || !el) return;
    const cw = cont.clientWidth, left = el.offsetLeft - cont.offsetLeft, w = el.offsetWidth;
    if (w >= cw) cont.scrollTo({ left, behavior: "smooth" });                       // шире окна — прижать к левому краю
    else if (left < cont.scrollLeft) cont.scrollTo({ left: left - 8, behavior: "smooth" });
    else if (left + w > cont.scrollLeft + cw) cont.scrollTo({ left: left + w - cw + 8, behavior: "smooth" });
  }, [active, tabs.length]);
  const onTabDown = (ev, i) => {
    const d = tabDrag.current;
    d.pid = ev.pointerId; d.from = i; d.to = i; d.startX = ev.clientX; d.startY = ev.clientY; d.active = false;
    clearTimeout(tabHoldT.current);
    // перенос — по долгому удержанию (450мс × 2.5), чтобы не конфликтовать с прокруткой панели
    tabHoldT.current = setTimeout(() => { if (d.from >= 0 && !d.active) { buzz(15); beginTabDrag(); } }, 1125);
  };
  const onTabMove = (ev) => {
    const d = tabDrag.current; if (d.from < 0) return;
    if (!d.active) {
      const adx = Math.abs(ev.clientX - d.startX), ady = Math.abs(ev.clientY - d.startY);
      if (adx > 8 || ady > 8) { clearTimeout(tabHoldT.current); d.from = -1; } // палец поехал — это прокрутка
      return;
    }
    ev.preventDefault();
    const rf = d.rects[d.from]; if (!rf) return;
    const dx = ev.clientX - d.startX;
    const fingerX = rf.left + rf.width / 2 + dx;
    let count = 0;
    for (let j = 0; j < d.rects.length; j++) { const r = d.rects[j]; if (!r || j === d.from) continue; if (r.left + r.width / 2 < fingerX) count++; }
    let to = count; if (to < 0) to = 0; if (to > d.rects.length - 1) to = d.rects.length - 1;
    d.to = to;
    const span = rf.width + d.gap;
    for (let j = 0; j < d.rects.length; j++) {
      const el = tabRefs.current[j]; if (!el) continue;
      if (j === d.from) { el.style.transform = "translateX(" + dx + "px)"; continue; }
      let t = 0;
      if (d.from < to && j > d.from && j <= to) t = -span;
      else if (to < d.from && j >= to && j < d.from) t = span;
      el.style.transform = t ? "translateX(" + t + "px)" : "translateX(0)";
    }
  };
  const onTabUp = (i) => {
    clearTimeout(tabHoldT.current);
    const d = tabDrag.current;
    try { if (d.pid != null && tabRefs.current[d.from]) tabRefs.current[d.from].releasePointerCapture(d.pid); } catch {}
    if (d.active) {
      const from = d.from, to = d.to;
      d.active = false; d.from = -1; clearTabDrag(); setTabDragId(null);
      if (to !== from && to >= 0) { setTabs((arr) => { const a = [...arr]; const [m] = a.splice(from, 1); a.splice(to, 0, m); saveTabs(a); return a; }); setActive(to); }
      return;
    }
    d.from = -1; clearTabDrag(); setTabDragId(null);
    const dir = i > active ? 1 : i < active ? -1 : 0; if (dir) { setSlide(dir); setTimeout(() => setSlide(0), 300); }
    setActive(i);
  };
  const onTabCancel = () => { clearTimeout(tabHoldT.current); const d = tabDrag.current; d.active = false; d.from = -1; clearTabDrag(); setTabDragId(null); };

  const saveAllTabs = () => { setTabsMenu(false); const t = tabs.map((x) => ({ ...x, saved: true })); persist(t); showToast("Вкладки сохранены"); };
  const startupHere = () => { setTabsMenu(false); const t = tabs.map((x, i) => ({ ...x, startup: i === active, startupPath: i === active ? path : x.startupPath, saved: i === active ? true : x.saved })); persist(t); showToast("Запуск при открытии: " + (path ? baseName(path) : "Storage")); };
  const resetTabs = () => { setTabsMenu(false); setTabs((arr) => { const t = arr.map((x) => ({ ...x, saved: false, startup: false })); saveTabs(t); return t; }); showToast("Вкладки сброшены"); };

  /* операции через .uri */
  const refresh = () => { forceRef.current = true; list(); };
  const targetUri = (name) => (curUri ? curUri + "/" + name : null);
  const doCreateFolder = async (name) => {
    setSheet(null); if (!name) return;
    const src = srcRef.current;
    if (src && src.kind === "gdrive") {
      try { await Apps.gdriveMkdir({ folder: src.folder || "root", name }); refresh(); }
      catch (e) {
        const msg = (e?.message || "");
        if (/insufficient|scope|PERMISSION_DENIED|403/i.test(msg)) {
          try { await Apps.gdriveLogout(); } catch {}
          setGdIn(false);
          showToast("Нужен полный доступ к Google Drive — подключитесь заново");
        } else showToast("Ошибка: " + msg);
      }
      return;
    }
    if (src) { showToast("Создание папок недоступно здесь"); return; }
    if (path.startsWith("@abs:")) {
      const abs = path.slice(5);
      try {
        const st = await Apps.safStatus({ path: abs });
        if (st && st.needed) {
          if (!st.granted) { setSafPrompt({ abs }); return; }
          await Apps.safMkdir({ destDir: abs, name }); refresh(); return;
        }
      } catch {}
    }
    try { await Filesystem.mkdir({ path: targetUri(name) }); refresh(); } catch (e) { showToast("Ошибка: " + e.message); }
  };
  const doCreateTxt = async (name) => { setSheet(null); if (!name) return; if (!/\.txt$/i.test(name)) name += ".txt"; try { await Filesystem.writeFile({ path: targetUri(name), data: "", encoding: Encoding.UTF8 }); refresh(); } catch (e) { showToast("Ошибка: " + e.message); } };
  const doCreateNomedia = async () => { try { await Filesystem.writeFile({ path: targetUri(".nomedia"), data: "", encoding: Encoding.UTF8 }); refresh(); showToast("Создан .nomedia"); } catch (e) { showToast("Ошибка: " + e.message); } };
  const doCreateDotFile = async (nm) => { try { await Filesystem.writeFile({ path: targetUri(nm), data: "", encoding: Encoding.UTF8 }); refresh(); showToast("Создан " + nm); } catch (e) { showToast("Ошибка: " + e.message); } };
  const doRename = async (oldName, newName) => { setSheet(null); if (!newName || newName === oldName) return; const e = byName(oldName); if (!e) return; try { await Filesystem.rename({ from: e.uri, to: targetUri(newName) }); exitSel(); refresh(); } catch (er) { showToast("Ошибка: " + er.message); } };
  const doArchive = async (base) => { setSheet(null); const nm = (base || "archive").trim().replace(/\.zip$/i, "") + ".zip"; const uris = [...sel].map((n) => (byName(n) || {}).uri).filter(Boolean); if (!uris.length) return; let sub; try { sub = await Apps.addListener("opProgress", (ev) => setZipProg(Math.max(0, Math.min(100, ev.done)))); } catch {} setZipProg(0); showToast("Архивирование…"); try { await Apps.zipCreate({ dir: curUri, name: nm, uris }); showToast("Готово: " + nm); exitSel(); refresh(); } catch (e) { showToast("Ошибка: " + (e?.message || "")); } if (sub) { try { sub.remove(); } catch {} } setZipProg(null); };
  const delTree = async (e) => {
    if (e.remote === "gdrive") { await Apps.gdriveDelete({ id: e.id || e.uri }); return; }
    try { const r = await Apps.deletePath({ uri: e.uri }); if (r && r.ok) return; } catch {}
    try { const r = await Apps.delete({ uri: e.uri }); if (r && r.deleted) return; } catch {}
    // фолбэк
    if (e.type === "directory") {
      try { const { files } = await Apps.list({ uri: e.uri }); for (const f of files) await delTree(f); } catch {}
      await Filesystem.rmdir({ path: e.uri, recursive: true });
    } else await Filesystem.deleteFile({ path: e.uri });
  };
  const doDelete = async () => {
    const items = [...sel].map(byName).filter(Boolean); setConfirmDel(null);
    cancelRef.current = false; let ok = 0, fail = 0;
    setProgress({ current: 0, total: items.length, name: "", mode: "del" });
    let dsub = null;
    try { dsub = await Apps.addListener("opProgress", (ev) => { setProgress((p) => (p ? { ...p, sub: { done: ev.done, total: ev.total, name: ev.name } } : p)); }); } catch {}
    for (let i = 0; i < items.length; i++) {
      if (cancelRef.current) break;
      const e = items[i];
      setProgress((p) => ({ ...(p || {}), current: i, total: items.length, name: e.name, mode: "del", sub: null }));
      Apps.notifyProgress({ title: "Удаление", text: e.name, progress: i, max: items.length }).catch(() => {});
      try { await delTree(e); ok++; } catch { fail++; }
      setProgress((p) => ({ ...(p || {}), current: i + 1, total: items.length, mode: "del" }));
    }
    try { dsub && dsub.remove(); } catch {}
    setProgress(null); Apps.cancelNotify().catch(() => {});
    exitSel(); await refresh();
    showToast(cancelRef.current ? "Отменено" : fail ? "Не удалено: " + fail + (ok ? ", удалено: " + ok : "") : "Удалено: " + ok);
  };
  const visibleRef = useRef([]);
  const cutSet = React.useMemo(() => {
    const st = new Set();
    for (const t of (clip || [])) if (t.mode !== "copy") for (const it of t.items) st.add(it.uri);
    return st;
  }, [clip]);
  const grab = (mode) => {
    const items = [...sel].map((n) => { const e = byName(n); return e ? { name: n, uri: e.uri, type: e.type } : null; }).filter(Boolean);
    if (!items.length) return;
    setClip((q) => [...(q || []), { id: Date.now() + Math.random(), mode, items, srcPath: path }]);
    exitSel();
    showToast((mode === "copy" ? "Копировать: " : "Вырезать: ") + items.length + " об.");
  };
  const runTask = async (task) => {
    for (const it of task.items) {
      const to = targetUri(it.name);
      if (!to || it.uri === to) continue;
      if (it.type === "directory" && curUri && curUri === it.uri) continue;
      try {
        if (task.mode === "copy") {
          if (it.type === "directory") await Apps.copyTree({ from: it.uri, to });
          else await Filesystem.copy({ from: it.uri, to });
        } else await Filesystem.rename({ from: it.uri, to });
      } catch (e) { showToast(it.name + ": " + e.message); }
    }
  };
  const [opErr, setOpErr] = useState(null); // { name, msg, resolve }
  const [safPrompt, setSafPrompt] = useState(null); // { abs } — просьба дать доступ к флешке
  const opErrAll = useRef(null);
  const askOpErr = (name, msg) => new Promise((resolve) => setOpErr({ name, msg, resolve }));
  const resolveOpErr = (action, all) => { if (all) opErrAll.current = action; setOpErr((c) => { if (c) c.resolve(action); return null; }); };
  const [conflict, setConflict] = useState(null); // { name, resolve }
  const [conflictApplyAll, setConflictApplyAll] = useState(false);
  const conflictAll = useRef(null);
  const askConflict = (name, isDir) => new Promise((resolve) => setConflict({ name, isDir, resolve }));
  const resolveConflict = (action, all) => { if (all) conflictAll.current = action; setConflict((c) => { if (c) c.resolve(action); return null; }); };
  const freeName = (name, taken) => {
    const dot = name.lastIndexOf("."); const base = dot > 0 ? name.slice(0, dot) : name; const ext = dot > 0 ? name.slice(dot) : "";
    const names = taken || new Set(entries.map((e) => e.name));
    let i = 1, cand; do { cand = base + " (" + i + ")" + ext; i++; } while (names.has(cand));
    return cand;
  };
  const runQueue = async (queue) => {
    const all = [];
    for (const t of queue) for (const it of t.items) all.push({ it, mode: t.mode });
    conflictAll.current = null; setConflictApplyAll(false); opErrAll.current = null;
    const existing = new Set(entries.map((e) => e.name));
    const takenNames = new Set(existing);
    // ПРЕ-ПАСС: разрешаем конфликты имён ДО показа прогресса
    const plan = [];
    for (const { it, mode } of all) {
      if (it.type === "directory" && curUri && curUri === it.uri) continue;
      let destName = it.name, overwrite = false, merge = false;
      if (existing.has(it.name)) {
        let action = conflictAll.current || await askConflict(it.name, it.type === "directory");
        if (action === "cancel") { showToast("Отменено"); return; }
        if (action === "skip") continue;
        if (action === "rename") destName = freeName(it.name, takenNames);
        else if (action === "merge") merge = true;   // папки: досыпать в существующую
        else overwrite = true; // перезапись
      }
      takenNames.add(destName);
      plan.push({ it, mode, destName, overwrite, merge });
    }
    if (!plan.length) { showToast("Нечего вставлять"); return; }
    const total = plan.length; cancelRef.current = false;
    // приёмник на съёмном носителе (флешка/SD) требует записи через SAF
    let safDest = null;
    if (path.startsWith("@abs:")) {
      const abs = path.slice(5);
      try {
        const st = await Apps.safStatus({ path: abs });
        if (st && st.needed) {
          if (!st.granted) { setSafPrompt({ abs }); return; }
          safDest = abs;
        }
      } catch {}
    }
    setProgress({ current: 0, total, name: "", unit: "items" });
    let sub = null;
    try { sub = await Apps.addListener("opProgress", (ev) => { setProgress((p) => (p ? { ...p, sub: { done: ev.done, total: ev.total, name: ev.name } } : p)); }); } catch {}
    for (let i = 0; i < plan.length; i++) {
      if (cancelRef.current) break;
      const { it, mode, destName, overwrite, merge } = plan[i];
      setProgress((p) => ({ ...(p || {}), current: i, total, name: it.name, mode, sub: null }));
      const to = targetUri(destName);
      if (to && it.uri !== to) {
        try {
          if (safDest) {
            // запись на флешку через SAF (перезапись/рекурсия — внутри нативного метода)
            await Apps.safCopyInto({ from: it.uri, destDir: safDest });
            if (mode !== "copy") { try { await Apps.deletePath({ uri: it.uri }); } catch {} }
            Apps.notifyProgress({ title: mode === "copy" ? "Копирование" : "Перемещение", text: it.name, progress: i + 1, max: total }).catch(() => {});
          } else {
          // папку-приёмник не удаляем: замена содержимого, а не снос каталога
          if (overwrite && !merge && it.type !== "directory") { try { await Apps.deletePath({ uri: to }); } catch {} }
          if (mode === "copy") {
            if (it.type === "directory") await Apps.copyTree({ from: it.uri, to }); // внутри — замена совпадающих файлов
            else { await Filesystem.copy({ from: it.uri, to }); Apps.notifyProgress({ title: "Копирование", text: it.name, progress: i + 1, max: total }).catch(() => {}); }
          } else if (it.type === "directory") {
            // слияние при перемещении: досыпаем содержимое и убираем исходник
            await Apps.copyTree({ from: it.uri, to });
            await Apps.deletePath({ uri: it.uri });
            Apps.notifyProgress({ title: "Перемещение", text: it.name, progress: i + 1, max: total }).catch(() => {});
          } else { await Filesystem.rename({ from: it.uri, to }); Apps.notifyProgress({ title: "Перемещение", text: it.name, progress: i + 1, max: total }).catch(() => {}); }
          }
        } catch (e) {
          const act = opErrAll.current || await askOpErr(it.name, e && e.message ? e.message : "не удалось");
          if (act === "cancel") { cancelRef.current = true; break; }
          if (act === "retry") { i--; continue; } // тот же элемент ещё раз
        }
      }
      setProgress((p) => ({ ...(p || {}), current: i + 1, total, sub: null }));
    }
    if (sub && sub.remove) sub.remove();
    setProgress(null); Apps.cancelNotify().catch(() => {});
    // сообщаем системе о новых файлах, иначе они не видны в галерее до переиндексации
    try {
      const touched = plan.map((x) => (x && x.destName ? targetUri(x.destName) : null)).filter(Boolean);
      if (touched.length) Apps.scanMedia({ paths: touched }).catch(() => {});
    } catch {}
    await refresh(); showToast(cancelRef.current ? "Отменено" : "Готово");
  };
  const pasteAll = async () => { const q = clip || []; setPasteMenu(false); setClip(null); await runQueue(q); };
  const pasteOne = async (task) => { setPasteMenu(false); setClip((q) => (q || []).filter((t) => t.id !== task.id)); await runQueue([task]); };
  const dropTask = (id) => setClip((q) => { const n = (q || []).filter((t) => t.id !== id); return n.length ? n : null; });

  /* три точки тулбара: скрыть / закрепить */
  const metaToggle = (which) => {
    const m = loadMeta();
    for (const n of sel) { const k = keyOf(n);
      if (which === "hidden") { m.hidden.has(k) ? m.hidden.delete(k) : m.hidden.add(k); }
      if (which === "top") { m.pinBot.delete(k); m.pinTop.has(k) ? m.pinTop.delete(k) : m.pinTop.add(k); }
      if (which === "bot") { m.pinTop.delete(k); m.pinBot.has(k) ? m.pinBot.delete(k) : m.pinBot.add(k); }
      if (which === "unpin") { m.pinTop.delete(k); m.pinBot.delete(k); }
    }
    applyMeta(m); setSelMenu(false); exitSel();
    showToast(which === "hidden" ? "Готово" : which === "unpin" ? "Откреплено" : "Закреплено");
  };

  const copyPath = async (p) => { try { await navigator.clipboard.writeText(p); showToast("Путь скопирован"); } catch { showToast("Не удалось скопировать"); } };

  /* отображаемый список: фильтр скрытых -> поиск -> сортировка -> папки сверху -> пины */
    const effSort = effSortFor(path);
const cmp = (a, b) => {
    if (effSort === "az") return nameCmp(a.name, b.name);
    if (effSort === "za") return nameCmp(b.name, a.name);
    if (effSort === "sizeA") return ((a.size || 0) - (b.size || 0)) || nameCmp(a.name, b.name);
    if (effSort === "sizeD") return ((b.size || 0) - (a.size || 0)) || nameCmp(a.name, b.name);
    if (effSort === "dateN") return ((b.mtime || 0) - (a.mtime || 0)) || nameCmp(a.name, b.name);
    if (effSort === "dateO") return ((a.mtime || 0) - (b.mtime || 0)) || nameCmp(a.name, b.name);
    return nameCmp(a.name, b.name);
  };
  let visible = entries.filter((e) => (showHidden || !isHidden(e)) && matchFilter(e));
  const dq = useDeferredValue((query || "").toLowerCase());
  if (dq) visible = visible.filter((e) => e.name.toLowerCase().includes(dq));
  const isRemote = !!(cur && cur.src);
  const isSysFolder = (e) => !isRemote && path === "" && e.type === "directory" && REAL_SYS.has(e.name.toLowerCase());
  const rank = (e) => (isRemote ? 0 : meta.pinTop.has(keyOf(e.name)) ? -1 : meta.pinBot.has(keyOf(e.name)) ? 1 : 0);
  visible = [...visible].sort((a, b) => {
    // 1) закреплённые сверху/снизу
    const ra = rank(a), rb = rank(b);
    if (ra !== rb) return ra - rb;
    const ad = a.type === "directory", bd = b.type === "directory";
    // 2) системные папки сверху (только локально), НЕ затирая выбранную сортировку остального
    if (sysTop && !isRemote) {
      const sa = isSysFolder(a) ? 0 : 1, sb = isSysFolder(b) ? 0 : 1;
      if (sa !== sb) return sa - sb;
      if (sa === 0 && sb === 0) return nameCmp(a.name, b.name); // сами системные папки — по алфавиту
    }
    // 3) папки выше файлов
    if (ad !== bd) return ad ? -1 : 1;
    // 4) выбранная сортировка
    return cmp(a, b);
  });
  // «Открыть с помощью» для нескольких видео/аудио: строим плейлист в текущем порядке —
  // внешний плеер получает ровно эти файлы и ровно в этой последовательности
  const openSelPlaylist = async () => {
    try {
      const chosen = new Set(sel);
      const list = visible.filter((e) => chosen.has(e.name) && e.type !== "directory" && (isVid(e.name) || isAudio(e.name)));
      if (list.length < 2) return;
      const toPath = (u) => { let pp = (u || "").replace(/^file:\/\//, ""); try { pp = decodeURIComponent(pp); } catch {} return pp; };
      const body = "#EXTM3U\n" + list.map((e) => "#EXTINF:-1," + e.name + "\n" + toPath(e.uri)).join("\n") + "\n";
      const rel = "Download/.yevtmp/playlist.m3u";
      await Filesystem.writeFile({ path: rel, data: body, directory: DIR, encoding: Encoding.UTF8, recursive: true });
      const u = await Filesystem.getUri({ path: rel, directory: DIR });
      setSel(new Set());
      // меню приложений — как при тапе по одному видео/аудио; открываем им плейлист
      const first = list[0];
      await showOpenMenu({ name: first.name, uri: u.uri, type: "file" }, mimeOf(first.name));
    } catch (e) { showToast("Ошибка: " + (e?.message || "")); }
  };
  visibleRef.current = visible;

  useEffect(() => {
    if (selAllWant.current && !loading) {
      selAllWant.current = false;
      if (visible.length) { setSelMode(true); setSel(new Set(visible.map((e) => e.name))); }
      else setSelMode(false);
    }
  }, [loading, entries]);

  const lpTimer = useRef(), lpFired = useRef(false), moved = useRef(false), pX = useRef(0), pY = useRef(0);
  const selAnchor = useRef(null), visOrder = useRef([]), icoTimer = useRef(), icoFired = useRef(false);
  const selectRange = (toName) => {
    const list = visOrder.current;
    const to = list.indexOf(toName); if (to < 0) return;
    let from = selAnchor.current != null ? list.indexOf(selAnchor.current) : -1;
    if (from < 0) from = 0;
    const [a, b] = from <= to ? [from, to] : [to, from];
    const n = new Set(sel);
    for (let i = a; i <= b; i++) n.add(list[i]);
    setSel(n); setSelMode(n.size > 0); buzz(15);
  };
  const icoDown = (ev, e) => {
    ev.stopPropagation(); icoFired.current = false;
    pX.current = ev.clientX; pY.current = ev.clientY;
    clearTimeout(icoTimer.current);
    icoTimer.current = setTimeout(() => { icoFired.current = true; selectRange(e.name); }, 450);
  };
  const icoUp = (ev, e) => {
    ev.stopPropagation(); clearTimeout(lpTimer.current); clearTimeout(icoTimer.current);
    if (icoFired.current) { icoFired.current = false; return; }
    selAnchor.current = e.name; toggle(e.name);
  };
  const rDown = (ev, e) => { lpFired.current = false; moved.current = false; pX.current = ev.clientX; pY.current = ev.clientY; lpTimer.current = setTimeout(() => { lpFired.current = true; buzz(15); selAnchor.current = e.name; toggle(e.name); }, 450); };
  const rMove = (ev) => { if (Math.abs(ev.clientX - pX.current) > 10 || Math.abs(ev.clientY - pY.current) > 10) { moved.current = true; clearTimeout(lpTimer.current); clearTimeout(icoTimer.current); } };
  const rUp = (e, ev) => { clearTimeout(lpTimer.current); if (lpFired.current || moved.current) return; open(e, ev); };

  const one = sel.size === 1 ? byName([...sel][0]) : null;

  return (
    <div style={{ ...S.app, ...(THEMES[theme] || THEMES.dark), fontFamily: fontCss }}>
      <style>{`html,body{background:${(THEMES[theme] || THEMES.dark)["--bg"]}}@import url('https://fonts.googleapis.com/css2?family=Comfortaa:wght@400;600;700&family=Roboto:wght@400;500;700&display=swap');`}</style>
      {/* ВКЛАДКИ + действия шапки */}
      <div style={S.tabsbar}>
        <div style={{ position: "relative", display: "flex", alignItems: "center", justifyContent: "center", height: "100%", padding: "0 16px" }}>
          <button style={{ ...S.hbtn }} onClick={() => setDrawer(true)}><Svg d={I.bars} size={20} /></button>
        </div>
        <div ref={tabsScrollRef} style={{ ...S.tabs, overflowX: tabDragId ? "visible" : "auto" }}>
          <div style={{ display: "flex", alignItems: "center", gap: 6, margin: "0 auto" }}>
          {tabs.map((t, i) => (
            <div key={t.id} ref={(el) => (tabRefs.current[i] = el)}
              onPointerDown={(ev) => onTabDown(ev, i)} onPointerMove={onTabMove} onPointerUp={() => onTabUp(i)} onPointerCancel={onTabCancel}
              style={{ ...S.tab, ...(i === active ? S.tabActive : {}), flexShrink: 0, touchAction: "pan-x", transition: t.id === tabDragId ? "none" : (tabDragId ? "transform .18s cubic-bezier(.2,.8,.2,1)" : "box-shadow .2s"), ...(t.id === tabDragId ? { zIndex: 6, position: "relative", boxShadow: "0 6px 16px rgba(0,0,0,.28)" } : (tabDragId ? { opacity: 0.6 } : {})) }}>
              <span style={{ overflow: "hidden", textOverflow: "ellipsis", maxWidth: i === active ? 220 : 130 }}>{t.src ? t.src.stack[t.src.stack.length - 1].name : (t.path ? baseName(t.path) : "Storage")}</span>
            </div>
          ))}
          </div>
        </div>
        <div style={{ position: "relative", display: "flex", alignItems: "center", height: "100%", padding: "0 16px" }}>
          <button style={S.hbtn} onClick={() => setHeadMenu((v) => !v)}><Svg d={I.dots} size={20} /></button>
          {headMenu && (
            <>
              <div style={S.overlay} onClick={() => { setHeadMenu(false); setHeadSub(null); }} />
              <div ref={headSubRef} style={{ ...S.menu, ...(headSub ? { position: "fixed", top: headSub.top, left: headSub.left, right: "auto", maxWidth: "calc(100vw - " + (headSub.left + 4) + "px)", maxHeight: "calc(100vh - " + Math.max(8, headSub.top + 8) + "px)", overflowY: "auto", transformOrigin: "top left" } : { top: 46, right: 4, transformOrigin: "top right" }), minWidth: 190 }}>
                {headSub ? (() => {
                  const conf = headSub.kind === "sort" ? { title: "Сортировка", list: SORTS, cur: effSortFor(path), pick: (k) => setSortAsk({ mode: k }) }
                    : headSub.kind === "view" ? { title: "Вид", list: [["list", "Подробная сетка"], ["gallery", "Галерея"]], cur: viewMode, pick: (k) => { setViewMode(k); ls.set(VIEWKEY, k); } }
                    : { title: "Фильтр", list: FILTERS, cur: typeFilter, pick: (k) => setTypeFilter(k) };
                  return (
                    <>
                      <div style={S.menuItem} onClick={(ev) => { ev.stopPropagation(); setHeadSub(null); }}><span style={{ display: "flex", width: 20, height: 20, alignItems: "center", justifyContent: "center", color: ACC }}><Svg d={I.back} size={16} /></span>{conf.title}</div>
                      <div style={{ height: 1, background: LINE }} />
                      {conf.list.map(([k, lbl], ix) => (
                        <React.Fragment key={k}>
                          {ix > 0 && <div style={{ height: 1, background: LINE }} />}
                          <div style={{ ...S.menuItem, whiteSpace: "normal", ...(conf.cur === k ? { color: ACC } : {}) }} onClick={() => { setHeadMenu(false); setHeadSub(null); conf.pick(k); }}>
                            {lbl}{conf.cur === k && <span style={{ marginLeft: "auto" }}>{"\u2713"}</span>}
                          </div>
                        </React.Fragment>
                      ))}
                    </>
                  );
                })() : (<>
                <div style={S.menuItem} onClick={() => { setHeadMenu(false); addTab(); }}>
                  <span style={{ color: ACC, display: "flex" }}><Svg d={I.plus} size={20} /></span>Новая вкладка
                </div>
                <div style={{ height: 1, background: LINE }} />
                <div style={S.menuItem} onClick={() => { setHeadMenu(false); saveAllTabs(); }}><span style={{ color: ACC, display: "flex" }}><Svg d={I.pin} size={20} /></span>Сохранить вкладки</div>
                <div style={{ height: 1, background: LINE }} />
                <div style={S.menuItem} onClick={() => { setHeadMenu(false); startupHere(); }}><span style={{ color: GOLD, display: "flex" }}><Svg d={I.home} size={20} /></span>Запуск при открытии</div>
                <div style={{ height: 1, background: LINE }} />
                <div style={S.menuItem} onClick={() => { setHeadMenu(false); resetTabs(); }}><span style={{ color: SUB, display: "flex" }}><Svg d={I.x} size={20} /></span>Сбросить вкладки</div>
                {tabs.length > 1 && <>
                  <div style={{ height: 1, background: LINE }} />
                  <div style={S.menuItem} onClick={() => { setHeadMenu(false); closeTab(active); }}><span style={{ color: RED, display: "flex" }}><Svg d={I.x} size={20} /></span>Закрыть вкладку</div>
                </>}
                <div style={{ height: 1, background: LINE }} />
                <div style={S.menuItem} onClick={(ev) => { ev.stopPropagation(); const r = ev.currentTarget.getBoundingClientRect(); setHeadSub({ kind: "sort", top: r.top, left: r.left }); }}>
                  <span style={{ color: ACC, display: "flex" }}><Svg d={I.sort} size={20} /></span>Сортировка
                </div>
                <div style={{ height: 1, background: LINE }} />
                <div style={S.menuItem} onClick={(ev) => { ev.stopPropagation(); const r = ev.currentTarget.getBoundingClientRect(); setHeadSub({ kind: "filter", top: r.top, left: r.left }); }}>
                  <span style={{ color: typeFilter !== "all" ? ACC : SUB, display: "flex" }}><Svg d={I.sort} size={20} /></span>Фильтр{typeFilter !== "all" ? " \u00b7 " + (FILTERS.find(([k]) => k === typeFilter) || [])[1] : ""}
                </div>
                <div style={{ height: 1, background: LINE }} />
                <div style={S.menuItem} onClick={(ev) => { ev.stopPropagation(); const r = ev.currentTarget.getBoundingClientRect(); setHeadSub({ kind: "view", top: r.top, left: r.left }); }}>
                  <span style={{ color: ACC, display: "flex" }}><Svg d={I.img} size={20} /></span>Вид
                </div>
                <div style={{ height: 1, background: LINE }} />
                <div style={S.menuItem} onClick={() => { setShowHidden((v) => !v); setHeadMenu(false); refresh(); }}>
                  <span style={{ color: showHidden ? ACC : SUB, display: "flex" }}><Svg d={showHidden ? I.eye : I.eyeOff} size={20} /></span>
                  Скрытые объекты
                  <span style={{ marginLeft: "auto", ...S.tgl, ...(showHidden ? S.tglOn : {}) }}><span style={{ ...S.knob, ...(showHidden ? S.knobOn : {}) }} /></span>
                </div>
                <div style={{ height: 1, background: LINE }} />
                <div style={S.menuItem} onClick={() => { setHeadMenu(false); setSettings(true); setSettingsPage(null); }}>
                  <span style={{ color: ACC, display: "flex" }}><Svg d={I.gear} size={20} /></span>Настройки
                </div>
                </>)}
              </div>
            </>
          )}
        </div>
      </div>

      {/* ПУТЬ */}
      <div style={S.crumb}>
        {(path || (cur && cur.src)) && (
          <span onClick={goUp} style={{ display: "inline-flex", alignItems: "center", color: ACC, flexShrink: 0, paddingRight: 4 }}><Svg d={I.back} size={18} /></span>
        )}
        <span ref={crumbRef} style={{ flex: 1, minWidth: 0, display: "flex", alignItems: "center", overflowX: "auto", overflowY: "hidden", whiteSpace: "nowrap", scrollbarWidth: "none", touchAction: "pan-x", WebkitOverflowScrolling: "touch", overscrollBehaviorX: "contain", WebkitMaskImage: crumbOver ? "linear-gradient(to right, transparent 0, #000 10px, #000 calc(100% - 14px), transparent 100%)" : "none", maskImage: crumbOver ? "linear-gradient(to right, transparent 0, #000 10px, #000 calc(100% - 14px), transparent 100%)" : "none" }}>
          {crumbs.length === 0 ? <span style={{ color: SUB }}>/storage</span>
            : crumbs.map((c, i) => (
              <React.Fragment key={i}>
                {i > 0 && <span style={{ color: SUB, opacity: 0.55, padding: "0 5px", flexShrink: 0 }}>/</span>}
                <span onClick={() => goCrumb(i)}
                  style={{ flexShrink: 0, color: i === crumbs.length - 1 ? ACC : SUB, fontWeight: i === crumbs.length - 1 ? 600 : 400, maxWidth: i === crumbs.length - 1 ? "none" : 140, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap", padding: "2px 0" }}>{c.name}</span>
              </React.Fragment>
            ))}
        </span>
        {themeBtn && (
          <button onClick={toggleTheme} aria-label="Тема"
            style={{ position: "absolute", right: 12, top: "calc(100% + 4px)", zIndex: 7, width: 34, height: 34, borderRadius: 17, border: "1px solid rgba(255,255,255,.14)", background: BAR, color: ACC, display: "flex", alignItems: "center", justifyContent: "center", padding: 0, margin: 0, lineHeight: 0, boxShadow: "0 2px 8px rgba(0,0,0,.28)" }}>
            <Svg d={theme === "light" ? I.sun : I.moon} size={18} />
          </button>
        )}
        {zipProg != null && (
          <div style={{ position: "absolute", right: 9, top: "calc(100% + 42px)", zIndex: 7, pointerEvents: "none" }}>
            <svg width="40" height="26" viewBox="0 0 40 26">
              <path d="M4 8 A16 16 0 0 0 36 8" fill="none" stroke="var(--chip)" strokeWidth="4" strokeLinecap="round" />
              <path d="M4 8 A16 16 0 0 0 36 8" fill="none" stroke={ACC} strokeWidth="4" strokeLinecap="round" strokeDasharray="50.27" strokeDashoffset={(50.27 * (1 - zipProg / 100)).toFixed(2)} style={{ transition: "stroke-dashoffset .2s linear" }} />
            </svg>
          </div>
        )}
      </div>

      {shared.length > 0 && (
        <div style={{ position: "fixed", inset: 0, zIndex: 1300, background: "rgba(0,0,0,.5)", display: "flex", alignItems: "flex-end", justifyContent: "center" }} onClick={dismissShared}>
          <div onClick={(e) => e.stopPropagation()} style={{ width: "100%", background: BAR, borderRadius: "20px 20px 0 0", padding: "16px 16px calc(14px + env(safe-area-inset-bottom))", boxShadow: "0 -8px 30px rgba(0,0,0,.5)", animation: "dropGrow .2s cubic-bezier(.2,.9,.3,1.1)" }}>
            <div style={{ fontSize: 15, color: TXT, fontWeight: 600, marginBottom: 3 }}>Файл из другого приложения{shared.length > 1 ? " (" + shared.length + ")" : ""}</div>
            <div style={{ fontSize: 13, color: SUB, marginBottom: 12 }}>Что сделать с файлом?</div>
            <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
              <button onClick={() => { setShared([]); setSaveMode(true); }} style={{ display: "flex", alignItems: "center", gap: 10, padding: "12px 14px", borderRadius: 12, border: "1px solid " + LINE, background: ROW2, color: TXT, fontSize: 15 }}><span style={{ color: ACC, display: "flex" }}><Svg d={I.dl} size={20} /></span>Сохранить</button>
              <button onClick={openSharedHere} style={{ display: "flex", alignItems: "center", gap: 10, padding: "12px 14px", borderRadius: 12, border: "1px solid " + LINE, background: ROW2, color: TXT, fontSize: 15 }}><span style={{ color: ACC, display: "flex" }}><Svg d={I.folder} size={20} /></span>Открыть</button>
              <button onClick={dismissShared} style={{ padding: "10px 14px", borderRadius: 12, border: "none", background: "none", color: SUB, fontSize: 14 }}>Отмена</button>
            </div>
          </div>
        </div>
      )}
      {!allFiles && (
        <div style={S.accessBar}>
          <div style={{ flex: 1, fontSize: 13, lineHeight: 1.4 }}>Нет доступа ко всем файлам — архивы, PDF и APK не видны.</div>
          <button style={S.accessBtn} onClick={() => Apps.requestAllFiles().catch(() => {})}>Дать доступ</button>
        </div>
      )}
      {exportPick && (
        <>
          <div style={S.savePop}>
            <Svg d={I.dl} size={20} />
            <span style={{ flex: 1, fontSize: 13.5, lineHeight: 1.35 }}>Перейдите в папку для сохранения настроек и нажмите «Сохранить сюда»</span>
          </div>
          <div style={S.saveBar}>
            <button style={S.saveBtnCancel} onClick={() => setExportPick(null)}>Отмена</button>
            <button style={S.saveBtnSave} onClick={doExportHere}><Svg d={I.dl} size={16} /> Сохранить сюда</button>
          </div>
        </>
      )}
      {savePick && (
        <>
          <div style={S.savePop}>
            <Svg d={I.dl} size={20} />
            <span style={{ flex: 1, fontSize: 13.5, lineHeight: 1.35 }}>Перейдите в папку и нажмите «Сохранить сюда» — «{savePick.file.name}» скачается туда</span>
          </div>
          <div style={S.saveBar}>
            <button style={S.saveBtnCancel} onClick={restoreSavePick}>Отмена</button>
            <button style={S.saveBtnSave} onClick={doSavePickHere}><Svg d={I.dl} size={16} /> Сохранить сюда</button>
          </div>
        </>
      )}
      {pendingExtract && (
        <>
          <div style={S.savePop}>
            <Svg d={I.dl} size={20} />
            <span style={{ flex: 1, fontSize: 13.5, lineHeight: 1.35 }}>Из «{pendingExtract.label}»{pendingExtract.names ? " (" + pendingExtract.names.length + ")" : ""} — перейдите в папку и нажмите «Извлечь сюда»</span>
          </div>
          <div style={S.saveBar}>
            <button style={S.saveBtnCancel} onClick={() => setPendingExtract(null)}>Отмена</button>
            <button style={S.saveBtnSave} onClick={doExtractHere}><Svg d={I.dl} size={16} /> Извлечь сюда</button>
          </div>
        </>
      )}
      {/* СПИСОК */}
      <main ref={listRef} style={S.list} onScroll={onListScroll} onTouchStart={onTS} onTouchMove={onTM}>
        {false && (
          <div style={S.accessBar}>
            <div style={{ flex: 1, fontSize: 13, lineHeight: 1.4 }}>Нет доступа ко всем файлам — архивы, PDF и APK не видны.</div>
            <button style={S.accessBtn} onClick={() => Apps.requestAllFiles().catch(() => {})}>Дать доступ</button>
          </div>
        )}
        <div key={active + "|" + path} style={{ ...S.slideWrap, marginTop: 0, visibility: listShown ? "visible" : "hidden", pointerEvents: slide ? "none" : "auto", animation: (slide && ((!(cur && cur.src) && localCache.current[path]) || seenKeys.current.has(active + "|" + path))) ? `fm-in-${slide > 0 ? "r" : "l"} .28s cubic-bezier(.22,.61,.36,1)` : "none" }}>
          {loading && null}
          {error && <div style={{ ...S.note, color: RED }}>{error}<br /><span style={{ fontSize: 12 }}>Разрешите «Доступ ко всем файлам» в настройках приложения.</span></div>}
          <div ref={spacerRef} style={{ height: 0 }} />
          {(() => {
            const renderRow = (e) => {
              const isSel = sel.has(e.name), hid = isHidden(e);
              const isDir = e.type === "directory";
              const sf = isDir ? SYS_FOLDERS[e.name.toLowerCase()] : null;
              const ic = isDir ? { d: (sf && sf.d) || I.folder, c: (sf && sf.c) || ACC, w: sf && sf.w } : fileIcon(e.name);
              const pinned = meta.pinTop.has(keyOf(e.name)) || meta.pinBot.has(keyOf(e.name));
              return (
                <div key={e.uri || e.name} data-nm={e.name} style={{ ...S.row, ...(visible.length <= 12 ? { contentVisibility: "visible" } : {}), ...(isDir ? S.rowDir : {}), ...(isSel ? S.rowSel : {}), opacity: cutSet.has(e.uri) ? 0.35 : hid ? 0.5 : 1 }}
                  onPointerDown={(ev) => rDown(ev, e)} onPointerMove={rMove} onPointerUp={(ev) => rUp(e, ev)} onPointerCancel={() => clearTimeout(lpTimer.current)}>
                  <span style={{ ...S.iconWrap, color: ic.c, background: "var(--chip)", overflow: "hidden", position: "relative" }}
                    onPointerDown={(ev) => icoDown(ev, e)} onPointerMove={rMove} onPointerUp={(ev) => icoUp(ev, e)} onPointerCancel={() => clearTimeout(icoTimer.current)}>
                    {(isDir && iconDB[keyOf(e.name)]) ? <img src={iconDB[keyOf(e.name)]} alt="" style={S.iconImg} />
                      : (!isDir && (e.remote === "gdrive" ? !!e.thumb : !e.remote && (isImg(e.name) || isVid(e.name) || isPdf(e.name) || /\.apk$/i.test(e.name)))) ?
                          <ThumbIcon uri={e.uri} tkey={tkeyOf(e)} gd={e.remote === "gdrive" ? { id: e.id, link: e.thumb } : null} cached={thumbs[tkeyOf(e)]} request={requestThumb} release={releaseThumb}
                            fallback={/\.apk$/i.test(e.name) ? <Svg d={ic.d} size={24} /> : isPdf(e.name) ? <Svg d={ic.d} size={24} /> : <Svg d={ic.d} size={24} />} />
                      : (!isDir && EXT.archive.includes((e.name.split(".").pop() || "").toLowerCase())) ? <ArcBadge name={e.name} />
                      : <Svg d={ic.d} size={24} vw={ic.w} />}
                    {isDir && !iconDB[keyOf(e.name)] && e.thumb ? <img src={cfs(e.thumb)} alt="" loading="lazy" style={S.folderThumb} /> : null}
                  </span>
                  <span style={S.rowMid}>
                    <span style={{ ...S.name, fontWeight: isDir ? 600 : 400, display: "flex", alignItems: "center", gap: 7 }}>
                      <span style={{ overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{e.name}</span>
                      {isDir && startupPath != null && join(path, e.name) === startupPath && <span style={{ color: GOLD, display: "flex", flexShrink: 0 }}><Svg d={I.home} size={15} /></span>}
                    </span>
                    {!isDir && e.mtime ? <span style={S.rowDate}>{fmtDate(e.mtime)}</span> : null}
                  </span>
                  {pinned && <span style={{ color: SUB, display: "flex" }}><Svg d={meta.pinTop.has(keyOf(e.name)) ? I.pinT : I.pinB} size={14} /></span>}
                  <span style={S.rowSize}>{isDir ? (e.count != null ? "(" + e.count + ")" : "") : fmtSizeShort(e.size)}</span>
                  {!isDir && <div style={S.rowLine} />}
                </div>
              );
            };
            const renderCell = (e) => {
              const isSel = sel.has(e.name), hid = isHidden(e);
              const isDir = e.type === "directory";
              const sf = isDir ? SYS_FOLDERS[e.name.toLowerCase()] : null;
              const ic = isDir ? { d: (sf && sf.d) || I.folder, c: (sf && sf.c) || ACC, w: sf && sf.w } : fileIcon(e.name);
              const thumb = !isDir && (e.remote === "gdrive" ? !!e.thumb : !e.remote && (isImg(e.name) || isVid(e.name) || isPdf(e.name) || /\.apk$/i.test(e.name)));
              return (
                <div key={e.uri || e.name} onPointerDown={(ev) => rDown(ev, e)} onPointerMove={rMove} onPointerUp={(ev) => rUp(e, ev)} onPointerCancel={() => clearTimeout(lpTimer.current)}
                  style={{ display: "flex", flexDirection: "column", gap: 5, padding: 6, borderRadius: 12, background: isSel ? "var(--accbg)" : "transparent", opacity: cutSet.has(e.uri) ? 0.35 : hid ? 0.5 : 1, contentVisibility: visible.length <= 24 ? "visible" : "auto", containIntrinsicSize: "0 132px" }}>
                  <div style={{ position: "relative", width: "100%", aspectRatio: "1 / 1", borderRadius: 10, overflow: "hidden", background: "var(--chip)", display: "flex", alignItems: "center", justifyContent: "center", color: ic.c }}>
                    {(isDir && iconDB[keyOf(e.name)]) ? <img src={iconDB[keyOf(e.name)]} alt="" style={{ width: "100%", height: "100%", objectFit: "cover" }} />
                      : thumb ? <ThumbIcon uri={e.uri} tkey={tkeyOf(e)} gd={e.remote === "gdrive" ? { id: e.id, link: e.thumb } : null} cached={thumbs[tkeyOf(e)]} request={requestThumb} release={releaseThumb} fallback={<Svg d={ic.d} size={42} />} />
                      : isDir && e.thumb ? <img src={cfs(e.thumb)} alt="" loading="lazy" style={{ width: "100%", height: "100%", objectFit: "cover", opacity: 0.9 }} />
                      : <Svg d={ic.d} size={42} vw={ic.w} />}
                  </div>
                  <div style={{ fontSize: 11.5, color: TXT, lineHeight: 1.25, maxHeight: 29, overflow: "hidden", wordBreak: "break-word", textAlign: "center", fontWeight: isDir ? 600 : 400 }}>{e.name}</div>
                </div>
              );
            };
            const firstFile = visible.findIndex((e) => e.type !== "directory");
            const startupPath = (tabs.find((t) => t.startup) || {}).startupPath;
            visLen.current = visible.length;
            visOrder.current = visible.map((x) => x.name);
                        if (viewMode === "gallery") return (
              <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 6, padding: "8px 10px 20px" }}>
                {visible.map((e) => renderCell(e))}
              </div>
            );
            return visible.map((e, i) => (
              <React.Fragment key={e.uri || e.name}>
                {renderRow(e)}
              </React.Fragment>
            ));
          })()}
        </div>
      </main>
      {!loading && !error && visible.length === 0 && !arcView && (
        <div style={{ position: "absolute", left: 0, right: 0, top: "42%", textAlign: "center", color: SUB, pointerEvents: "none", zIndex: 2 }}>Пусто</div>
      )}
      {fsBar && (
        <div
          onPointerDown={(ev) => { ev.preventDefault(); fsDrag.current = true; ev.currentTarget.setPointerCapture(ev.pointerId); fsFromY(ev.clientY); }}
          onPointerMove={(ev) => { if (fsDrag.current) fsFromY(ev.clientY); }}
          onPointerUp={() => { fsDrag.current = false; updateFs(listRef.current); }}
          onPointerCancel={() => { fsDrag.current = false; }}
          style={{ position: "absolute", right: 0, top: fsBar.top, width: 34, height: fsBar.h, zIndex: 8, display: "flex", alignItems: "center", justifyContent: "flex-end", touchAction: "none", cursor: "grab" }}>
          {fsDrag.current && fsBar.label && (
            <span style={{ position: "absolute", right: 30, background: BAR, color: ACC, borderRadius: 12, padding: "6px 12px", fontSize: 18, fontWeight: 600, boxShadow: "var(--barsh)" }}>{fsBar.label}</span>
          )}
          <span style={{ width: fsDrag.current ? 6 : 4, height: "100%", marginRight: 4, borderRadius: 3, background: fsDrag.current ? ACC : "var(--sub)", opacity: fsDrag.current ? 1 : (fsBar.idle ? 0.25 : 0.55), transition: "opacity .25s, width .15s, background .15s" }} />
        </div>
      )}

      {/* ПОИСК */}
      {query !== null && (
        <div style={S.searchBar}>
          <input autoFocus value={query} placeholder="Поиск в папке…" onChange={(e) => setQuery(e.target.value)} style={S.searchInput} />
          <button style={S.searchClose} onClick={() => setQuery(null)}>×</button>
        </div>
      )}

      {/* НИЖНЯЯ ПАНЕЛЬ (плавает над списком — контент уходит под неё) */}
      <div ref={navRef} style={{ position: "absolute", left: 0, right: 0, bottom: 0, zIndex: 60, pointerEvents: "none", transform: "translateZ(0)", background: arcView ? BG : "transparent" }}>
       <div style={{ pointerEvents: "auto" }}>
      {selMode ? (
        <nav style={{ ...S.bottom, justifyContent: "flex-start" }}>
          <div style={{ width: 38, display: "flex", alignItems: "center", justifyContent: "flex-end", paddingRight: 2, flexShrink: 0 }}>
            <div style={S.selCount}>
              <span key={sel.size} style={{ fontSize: 13, fontWeight: 700, color: "#fff", lineHeight: 1, display: "block", textAlign: "center", animation: "pulse .3s cubic-bezier(.2,.9,.3,1.3)" }}>{sel.size}</span>
            </div>
          </div>
          <div style={{ flex: 1, overflow: "hidden", display: "flex" }}>
            <div style={{ display: "flex", overflowX: "auto", overflowY: "hidden", flex: 1, justifyContent: "flex-start", paddingBottom: 20, marginBottom: -20 }}>
            <Btn onClick={exitSel} icon={I.x} label="Отмена" flexNone />
            <Btn onClick={() => setProps(sel.size === 1 ? one : { multi: [...sel].map((n) => byName(n)).filter(Boolean) })} icon={I.info} label="Свойства" flexNone disabled={sel.size < 1} />
            <Btn onClick={() => grab("cut")} icon={I.cut} label="Вырезать" flexNone />
            <Btn onClick={() => grab("copy")} icon={I.copy} label="Копир." flexNone />
            <Btn onClick={(ev) => { const t = ev.currentTarget; const r = t.getBoundingClientRect(); const p = t.previousElementSibling; const cr = p ? p.getBoundingClientRect() : r; setConfirmDel({ cx: cr.left + cr.width / 2, top: r.top }); }} icon={I.trash} label="Удалить" red flexNone />
            <Btn onClick={() => { const e = one; const sp = splitExt(e.name, e.type === "directory"); setSheet({ kind: "rename", old: e.name, base: sp.base, ext: sp.ext, editExt: false }); }} icon={I.rename} label="Имя" flexNone disabled={sel.size !== 1} />
            <Btn onClick={() => setSelMenu((v) => !v)} icon={I.dots} label="Ещё" flexNone />
          </div>
          </div>
        </nav>
      ) : (
        <nav style={S.bottom}>
          <Zone><Btn onClick={() => setQuery(query === null ? "" : null)} icon={I.search} label="Поиск" /></Zone>
          <Zone>{clip && clip.length > 0 ? <Btn onClick={() => setClip(null)} icon={I.x} label="Отмена" red /> : saveMode ? <Btn onClick={() => { setSaveMode(false); dismissShared(); }} icon={I.x} label="Отмена" red /> : null}</Zone>
          <Zone><Btn onClick={selectAll} icon={I.selectAll} label="Все" /></Zone>
          <Zone>{clip && clip.length > 0 ? <Btn onClick={() => (clip.length === 1 ? pasteAll() : setPasteMenu((v) => !v))} icon={I.paste} label={"Вставить (" + clip.length + ")"} /> : saveMode ? <Btn onClick={saveSharedHere} icon={I.paste} label="Вставить" /> : null}</Zone>
          <Zone><Btn onClick={() => setCreateOpen((v) => !v)} icon={I.plus} label="Создать" /></Zone>
        </nav>
      )}
       </div>
      </div>

      {/* МЕНЮ «СОЗДАТЬ» (поверх тулбара) */}
      {createOpen && (
        <>
          <div style={{ position: "fixed", inset: 0, zIndex: 1190 }} onClick={() => { setCreateOpen(false); setCreateSub(null); }} />
          <div style={{ ...S.menu, position: "fixed", right: 8, bottom: "calc(62px + env(safe-area-inset-bottom))", zIndex: 1200, minWidth: 150, transformOrigin: "bottom right" }}>
            {createSub === "dot" ? (
              <>
                <div style={S.createItem} onClick={() => { setCreateSub(null); setCreateOpen(false); doCreateDotFile(".nomedia"); }}>
                  <div>.nomedia<div style={{ fontSize: 10.5, color: SUB, marginTop: 2 }}>(скроет все медиа + в подпапках)</div></div>
                </div>
                <div style={{ height: 1, background: LINE }} />
                <div style={S.createItem} onClick={() => { setCreateSub(null); setCreateOpen(false); doCreateDotFile(".nofolder"); }}>
                  <div>.nofolder<div style={{ fontSize: 10.5, color: SUB, marginTop: 2 }}>(скроет медиа от YevGallery только в этой, папке без подпапок)</div></div>
                </div>
                <div style={{ height: 1, background: LINE }} />
                <div style={S.createItem} onClick={() => { setCreateSub(null); setCreateOpen(false); doCreateDotFile(".icon"); }}>
                  <div>.icon<div style={{ fontSize: 10.5, color: SUB, marginTop: 2 }}>(сделает иконку, что будет лежать в этой папке иконой папки)</div></div>
                </div>
                <div style={{ height: 1, background: LINE }} />
                <div style={{ ...S.createItem, color: SUB }} onClick={() => setCreateSub(null)}>‹ Назад</div>
              </>
            ) : (
              <>
                <div style={S.createItem} onClick={() => setCreateSub("dot")}>.CreateFile ›</div>
                <div style={{ height: 1, background: LINE }} />
                <div style={S.createItem} onClick={() => { setCreateOpen(false); setSheet({ kind: "folder", val: "" }); }}>Папка</div>
                <div style={{ height: 1, background: LINE }} />
                <div style={S.createItem} onClick={() => { setCreateOpen(false); setSheet({ kind: "txt", val: "" }); }}>TXT</div>
              </>
            )}
          </div>
        </>
      )}

      {/* МЕНЮ «ЕЩЁ» выделения (поверх тулбара) */}
      {selMenu && (
        <>
          <div style={{ position: "fixed", inset: 0, zIndex: 1190 }} onClick={() => setSelMenu(false)} />
          <div style={{ ...S.menu, position: "fixed", right: 8, bottom: "calc(56px + env(safe-area-inset-bottom))", zIndex: 1200, transformOrigin: "bottom right" }}>
            {one && one.type === "directory" && (
              <>
                <div style={S.menuItem} onClick={() => { const t = [...tabs, { id: Date.now(), path: keyOf(one.name) }]; persist(t); setSelMenu(false); exitSel(); setActive(t.length - 1); }}>
                  <span style={{ color: ACC, display: "flex" }}><Svg d={I.folder} size={20} /></span>Открыть во вкладке
                </div>
                <div style={{ height: 1, background: LINE }} />
              </>
            )}
            {(() => {
              const items = visibleRef.current.filter((x) => sel.has(x.name) && x.type !== "directory" && !x.remote);
              const media = items.length > 1 && items.every((x) => isVid(x.name) || isAudio(x.name) || isImg(x.name));
              if (!media) return null;
              const mime = items.every((x) => isVid(x.name)) ? "video/*" : items.every((x) => isAudio(x.name)) ? "audio/*" : items.every((x) => isImg(x.name)) ? "image/*" : "*/*";
              return (
                <>
                  <div style={S.menuItem} onClick={() => { setSelMenu(false); const uris = items.map((x) => x.uri); Apps.open({ uri: uris[0], mime, uris, chooser: true }).catch((err) => showToast("Не удалось открыть: " + (err?.message || ""))); exitSel(); }}>
                    <span style={{ color: ACC, display: "flex" }}><Svg d={I.open} size={20} /></span>Открыть с помощью
                  </div>
                  <div style={{ height: 1, background: LINE }} />
                </>
              );
            })()}
            {(() => { const allHid = [...sel].every((n) => meta.hidden.has(keyOf(n))); return (
              <div style={S.menuItem} onClick={() => metaToggle("hidden")}>
                <span style={{ color: SUB, display: "flex" }}><Svg d={allHid ? I.eye : I.eyeOff} size={20} /></span>{allHid ? "Показать" : "Скрыть"}
              </div>
            ); })()}
            <div style={{ height: 1, background: LINE }} />
            {(() => {
              const pinnedNow = [...sel].every((n) => meta.pinTop.has(keyOf(n)) || meta.pinBot.has(keyOf(n)));
              if (pinnedNow) return <div style={S.menuItem} onClick={() => metaToggle("unpin")}><span style={{ color: ACC, display: "flex" }}><Svg d={I.x} size={20} /></span>Открепить</div>;
              return (<>
                <div style={S.menuItem} onClick={() => metaToggle("top")}><span style={{ color: ACC, display: "flex" }}><Svg d={I.pinT} size={20} /></span>Закрепить сверху</div>
                <div style={{ height: 1, background: LINE }} />
                <div style={S.menuItem} onClick={() => metaToggle("bot")}><span style={{ color: ACC, display: "flex" }}><Svg d={I.pinB} size={20} /></span>Закрепить снизу</div>
              </>);
            })()}
            {one && one.type !== "directory" && (
              <>
                <div style={{ height: 1, background: LINE }} />
                <div style={S.menuItem} onClick={() => { setSelMenu(false); const e = one; exitSel(); showOpenMenu(e, mimeOf(e.name)); }}><span style={{ color: TXT, display: "flex" }}><Svg d={I.dots} size={20} /></span>Открыть с помощью</div>
              </>
            )}
            {one && /\.apk$/i.test(one.name) && (
              <>
                <div style={{ height: 1, background: LINE }} />
                <div style={S.menuItem} onClick={() => { setSelMenu(false); Apps.installApk({ uri: one.uri }).catch((er) => showToast("Ошибка: " + (er?.message || ""))); }}><span style={{ color: "#6FD3A8", display: "flex" }}><Svg d={I.plus} size={20} /></span>Установить</div>
                <div style={{ height: 1, background: LINE }} />
                <div style={S.menuItem} onClick={() => { setSelMenu(false); Apps.uninstall({ uri: one.uri }).catch((er) => showToast("Ошибка: " + (er?.message || ""))); }}><span style={{ color: RED, display: "flex" }}><Svg d={I.trash} size={20} /></span>Деинсталлировать</div>
              </>
            )}
            {(() => {
              const items = [...sel].map(byName).filter(Boolean);
              const allMedia = items.length >= 2 && items.every((e) => e.type !== "directory" && (isVid(e.name) || isAudio(e.name)));
              if (!allMedia) return null;
              return (<>
                <div style={{ height: 1, background: LINE }} />
                <div style={S.menuItem} onClick={() => { setSelMenu(false); openSelPlaylist(); }}><span style={{ color: ACC, display: "flex" }}><Svg d={I.play} size={20} /></span>Открыть</div>
              </>);
            })()}            <div style={{ height: 1, background: LINE }} />
            <div style={S.menuItem} onClick={() => { setSelMenu(false); const b = sel.size === 1 ? splitExt([...sel][0], (byName([...sel][0]) || {}).type === "directory").base : "archive"; setSheet({ kind: "archive", val: b }); }}><span style={{ color: GOLD, display: "flex" }}><Svg d={I.dl} size={20} /></span>Архивировать (.zip)</div>
          </div>
        </>
      )}
      {sheet && (
        <div style={S.backdrop} onPointerUp={() => setSheet(null)}>
          <div style={S.sheet} onPointerDown={(e) => e.stopPropagation()} onPointerUp={(e) => e.stopPropagation()} onClick={(e) => e.stopPropagation()}>
            {sheet.kind === "folder" && <SheetInput title="Новая папка" value={sheet.val} placeholder="Имя папки" onChange={(v) => setSheet({ ...sheet, val: v })} onCancel={() => setSheet(null)} onOk={() => doCreateFolder(sheet.val.trim())} okText="Создать" />}
            {sheet.kind === "txt" && <SheetInput title="Новый TXT-файл" value={sheet.val} placeholder="Имя файла" onChange={(v) => setSheet({ ...sheet, val: v })} onCancel={() => setSheet(null)} onOk={() => doCreateTxt(sheet.val.trim())} okText="Создать" />}
            {sheet.kind === "archive" && <SheetInput title="Архивировать в .zip" value={sheet.val} placeholder="Имя архива" onChange={(v) => setSheet({ ...sheet, val: v })} onCancel={() => setSheet(null)} onOk={() => doArchive(sheet.val.trim())} okText="Создать" />}
            {sheet.kind === "rename" && (
              <>
                <div style={S.sheetTitle}>Переименовать</div>
                <input autoFocus onFocus={(ev) => ev.target.select()} key={sheet.editExt ? "ext" : "base"} value={sheet.editExt ? sheet.ext : sheet.base} placeholder={sheet.editExt ? "расширение" : "имя"}
                  onChange={(e) => setSheet({ ...sheet, [sheet.editExt ? "ext" : "base"]: e.target.value })} style={S.sheetField} />
                <div style={{ display: "flex", gap: 10 }}>
                  <button style={S.sheetGhost} onClick={() => setSheet({ ...sheet, editExt: !sheet.editExt })}>{sheet.editExt ? "Имя" : "Расширение"}</button>
                  <button style={S.sheetGhost} onClick={() => setSheet(null)}>Отмена</button>
                  <button style={S.sheetOk} onClick={() => { const nn = sheet.base.trim() + (sheet.ext.trim() ? "." + sheet.ext.trim() : ""); doRename(sheet.old, nn); }}>ОК</button>
                </div>
              </>
            )}
            {sheet.kind === "filter" && (
              <>
                <div style={S.sheetTitle}>Фильтр</div>
                {FILTERS.map(([k, lbl]) => (
                  <div key={k} style={{ ...S.sortRow, ...(typeFilter === k ? { color: ACC } : {}) }} onClick={() => { setTypeFilter(k); setSheet(null); }}>
                    {lbl}{typeFilter === k && <span style={{ marginLeft: "auto" }}>✓</span>}
                  </div>
                ))}
              </>
            )}
            {sheet.kind === "view" && (
              <>
                <div style={S.sheetTitle}>Вид</div>
                {[["list", "Подробная сетка"], ["gallery", "Галерея"]].map(([k, lbl]) => (
                  <div key={k} style={{ ...S.sortRow, ...(viewMode === k ? { color: ACC } : {}) }} onClick={() => { setViewMode(k); ls.set(VIEWKEY, k); setSheet(null); }}>
                    {lbl}{viewMode === k && <span style={{ marginLeft: "auto" }}>✓</span>}
                  </div>
                ))}
              </>
            )}
            {sheet.kind === "sort" && (
              <>
                <div style={S.sheetTitle}>Сортировка</div>
                {SORTS.map(([k, lbl]) => (
                  <div key={k} style={{ ...S.sortRow, ...(effSortFor(path) === k ? { color: ACC } : {}) }} onClick={() => { setSheet(null); setSortAsk({ mode: k }); }}>
                    {lbl}{effSortFor(path) === k && <span style={{ marginLeft: "auto" }}>✓</span>}
                  </div>
                ))}
              </>
            )}
            {sheet.kind === "remote" && (
              <>
                <div style={{ ...S.sheetTitle, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{sheet.file.name}</div>
                <div style={S.sortRow} onClick={() => remoteTempOpen(sheet.file, sheet.src)}>Сохранить во временной папке</div>
                <div style={S.sortRow} onClick={() => saveTo(sheet.file, sheet.src)}>Сохранить в…</div>
                <div style={S.sortRow} onClick={() => remoteDownload(sheet.file, sheet.src)}>Сохранить в Download</div>
              </>
            )}
          </div>
        </div>
      )}
      {/* ПРОСМОТРЩИК ИЗОБРАЖЕНИЙ */}
      {player && (
        <div style={{ position: "fixed", left: 8, right: 8, bottom: "calc(78px + env(safe-area-inset-bottom))", zIndex: 70, background: BAR, borderRadius: 20, padding: "10px 12px 10px", boxShadow: "var(--barsh)" }}>
          <div style={{ display: "flex", alignItems: "center", gap: 6, marginBottom: 6 }}>
            <span style={{ flex: 1, minWidth: 0, color: TXT, fontSize: 13.5, fontWeight: 600, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{player.name}</span>
            <div style={{ position: "relative", flexShrink: 0 }}>
              <button onClick={() => setPlayerMenu((v) => !v)} aria-label="Меню" style={{ background: ROW2, border: "1px solid " + LINE, borderRadius: 11, color: ACC, display: "flex", alignItems: "center", justifyContent: "center", width: 32, height: 32 }}><Svg d={I.dots} size={20} /></button>
              {playerMenu && (
                <div style={{ position: "absolute", right: 0, bottom: "calc(100% + 6px)", background: BAR, borderRadius: 14, overflow: "hidden", minWidth: 210, boxShadow: "var(--barsh)", zIndex: 5 }}>
                  <div style={S.menuItem} onClick={() => playerSetAs("ringtone")}><span style={{ color: ACC, display: "flex" }}><Svg d={I.bell} size={20} /></span>Установить на звонок</div>
                </div>
              )}
            </div>
            <button onClick={playerClose} aria-label="Закрыть" style={{ background: ROW2, border: "1px solid " + LINE, borderRadius: 14, color: RED, display: "flex", alignItems: "center", justifyContent: "center", width: 46, height: 42, flexShrink: 0 }}><Svg d={I.x} size={26} /></button>
          </div>
          <input type="range" min={0} max={player.dur || 0} value={Math.min(player.pos || 0, player.dur || 0)} onChange={(e) => playerSeek(Number(e.target.value))} style={{ width: "100%", accentColor: ACC, height: 7, borderRadius: 4, margin: 0 }} />
          <div style={{ display: "flex", justifyContent: "space-between", fontSize: 11, color: SUB, marginTop: 3 }}><span>{fmtTime(player.pos)}</span><span>{fmtTime(player.dur)}</span></div>
          <div style={{ display: "flex", alignItems: "center", justifyContent: "center", gap: 30, marginTop: 4 }}>
            <button onClick={playerPrev} aria-label="Назад" style={{ background: ROW2, border: "1px solid " + LINE, borderRadius: 16, color: TXT, display: "flex", alignItems: "center", justifyContent: "center", width: 50, height: 44 }}><Svg d={I.prev} size={26} /></button>
            <button onClick={playerToggle} aria-label="Плей/Пауза" style={{ background: ACC, border: "none", color: "#fff", display: "flex", alignItems: "center", justifyContent: "center", width: 56, height: 56, borderRadius: 28 }}><Svg d={player.playing ? I.pause : I.play} size={27} /></button>
            <button onClick={playerNext} aria-label="Вперёд" style={{ background: ROW2, border: "1px solid " + LINE, borderRadius: 16, color: TXT, display: "flex", alignItems: "center", justifyContent: "center", width: 50, height: 44 }}><Svg d={I.next} size={26} /></button>
          </div>
        </div>
      )}
      {drawer && (
        <div style={{ position: "fixed", inset: 0, zIndex: 1500 }}>
          <div onClick={() => { setDrawer(false); setPlusMenu(false); }} style={{ position: "absolute", inset: 0, background: "rgba(0,0,0,.5)" }} />
          <div style={{ position: "absolute", left: 0, top: 0, bottom: 0, width: "82%", maxWidth: 330, background: BAR, borderRight: "1px solid " + LINE, boxShadow: "6px 0 26px rgba(0,0,0,.5)", display: "flex", flexDirection: "column", animation: "drawerIn .24s cubic-bezier(.2,.8,.3,1)" }}>
            <div style={{ flex: 1, minHeight: "env(safe-area-inset-top)" }} />
            <div style={{ overflow: "auto", touchAction: dDragId ? "none" : "auto" }}>
              {(() => {
                const avail = [
                  ...webdavs.map((a) => ({ id: "wd:" + a.url, kind: "wd", a })),
                  ...(gdIn ? [{ id: "gd", kind: "gd" }] : []),
                  { id: "data", kind: "st", n: "Data", sub: "data", d: I.android, c: "#8FB84A", p: "Android/data" },
                  { id: "obb", kind: "st", n: "OBB", sub: "obb", d: I.android, c: "#E3B14F", p: "Android/obb" },
                  ...volumes.map((v, i) => ({
                    id: v.primary ? "storage" : ("vol:" + v.path),
                    kind: "st",
                    n: v.primary ? "Storage" : v.name,
                    sub: v.path,
                    d: I.folder,
                    c: v.primary ? "#4FC3D9" : (v.removable ? "#E58A4F" : "#7F9FD9"),
                    p: v.primary ? "" : "@abs:" + v.path,
                    removable: v.removable,
                  })),
                ];
                const byId = {}; avail.forEach((it) => (byId[it.id] = it));
                const ordered = drawerOrder.filter((id) => byId[id]).map((id) => byId[id]);
                const rest = avail.filter((it) => !drawerOrder.includes(it.id));
                const rendered = [...rest, ...ordered];
                dRenderedRef.current = rendered;
                return rendered.map((it) => (
                  <div key={it.id} ref={(el) => (dItemRefs.current[it.id] = el)}
                    onPointerDown={(ev) => dDown(ev, it.id)} onPointerMove={dMove} onPointerUp={() => dUp(it)} onPointerCancel={() => { clearTimeout(dLp.current); dLpFired.current = false; dDragIdRef.current = null; clearDDrag(); setDDragId(null); }}
                    style={{ display: "flex", alignItems: "center", gap: 12, padding: "12px 14px", borderTop: "1px solid " + LINE, background: dDragId === it.id ? ROW2 : "transparent", opacity: dDragId && dDragId !== it.id ? 0.6 : 1, boxShadow: dDragId === it.id ? "0 6px 18px rgba(0,0,0,.5)" : "none", touchAction: "none", transition: dDragId === it.id ? "none" : (dDragId ? "transform .18s cubic-bezier(.2,.8,.2,1)" : "none"), ...(dDragId === it.id ? { position: "relative", zIndex: 3 } : {}) }}>
                    {it.kind === "wd" && <>
                      <span style={{ width: 40, height: 40, borderRadius: 20, background: "#5AA9E622", color: "#5AA9E6", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}><Svg d={I.dl} size={22} /></span>
                      <div style={{ minWidth: 0, flex: 1 }}><div style={{ color: TXT, fontSize: 16, fontWeight: 600, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{it.a.name}</div><div style={{ color: SUB, fontSize: 12 }}>WebDAV</div></div>
                      <button onPointerDown={(ev) => ev.stopPropagation()} onClick={(ev) => { ev.stopPropagation(); delWebdav(webdavs.indexOf(it.a)); }} aria-label="Удалить" style={{ background: "none", border: "none", color: RED, display: "flex", padding: 6, flexShrink: 0 }}><Svg d={I.x} size={18} /></button>
                    </>}
                    {it.kind === "gd" && <>
                      <span style={{ width: 40, height: 40, borderRadius: 20, background: "var(--accbg)", color: ACC, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}><Svg d={I.gdrive} size={24} /></span>
                      <div style={{ minWidth: 0, flex: 1 }}><div style={{ color: TXT, fontSize: 16, fontWeight: 600 }}>Google Drive</div><div style={{ color: SUB, fontSize: 12 }}>Подключён</div></div>
                      <button onPointerDown={(ev) => ev.stopPropagation()} onClick={(ev) => { ev.stopPropagation(); Apps.gdriveLogout().catch(() => {}); setGdIn(false); }} aria-label="Выйти" style={{ background: "none", border: "none", color: RED, display: "flex", padding: 6, flexShrink: 0 }}><Svg d={I.x} size={18} /></button>
                    </>}
                    {it.kind === "st" && <>
                      <span style={{ width: 40, height: 40, borderRadius: 20, background: it.c + "22", color: it.c, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}><Svg d={it.d} size={22} /></span>
                      <div style={{ minWidth: 0 }}><div style={{ color: TXT, fontSize: 16, fontWeight: 600 }}>{it.n}</div><div style={{ color: SUB, fontSize: 12, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{it.sub}</div></div>
                    </>}
                  </div>
                ));
              })()}
            </div>
            <div style={{ position: "relative", display: "flex", alignItems: "center", padding: "10px 12px calc(12px + env(safe-area-inset-bottom))", borderTop: "1px solid " + LINE }}>
              <span style={{ flex: 1, fontSize: 18, fontWeight: 700, color: TXT, paddingLeft: 6 }}>YevFiles</span>
              <button onClick={() => setPlusMenu((v) => !v)} aria-label="Добавить" style={{ width: 34, height: 34, borderRadius: 17, background: ROW2, border: "1px solid " + LINE, color: ACC, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}><Svg d={I.plus} size={22} /></button>
              {plusMenu && (
                <div style={{ position: "absolute", right: 10, bottom: "calc(100% + 4px)", background: BAR, borderRadius: 12, overflow: "hidden", minWidth: 190, boxShadow: "var(--barsh)" }}>
                  {!gdIn && <div style={S.menuItem} onClick={() => { setPlusMenu(false); googleLogin(); }}><span style={{ background: "var(--accbg)", color: ACC, borderRadius: 8, display: "flex", padding: 4 }}><Svg d={I.gdrive} size={18} /></span>Google Drive</div>}
                  <div style={S.menuItem} onClick={() => { setPlusMenu(false); setDrawer(false); setWdForm({ name: "", url: "", user: "", pass: "" }); }}><span style={{ color: "#5AA9E6", display: "flex" }}><Svg d={I.dl} size={20} /></span>WebDAV</div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
      {wdForm && (
        <div style={{ position: "fixed", inset: 0, zIndex: 1600, background: "rgba(0,0,0,.55)", display: "flex", alignItems: "center", justifyContent: "center", padding: 20 }} onClick={() => setWdForm(null)}>
          <div onClick={(e) => e.stopPropagation()} style={{ width: "100%", maxWidth: 360, background: BAR, borderRadius: 18, padding: 18, boxShadow: "0 12px 40px rgba(0,0,0,.5)" }}>
            <div style={{ fontSize: 16, fontWeight: 700, color: TXT, marginBottom: 14 }}>WebDAV</div>
            {[["name", "Название"], ["url", "https://…/dav/"], ["user", "Логин"], ["pass", "Пароль"]].map(([k, ph]) => (
              <input key={k} value={wdForm[k]} placeholder={ph} type={k === "pass" ? "password" : "text"} autoCapitalize="none" autoCorrect="off" onChange={(e) => setWdForm((f) => ({ ...f, [k]: e.target.value }))}
                style={{ width: "100%", boxSizing: "border-box", marginBottom: 10, padding: "11px 12px", borderRadius: 10, border: "1px solid " + LINE, background: ROW2, color: TXT, fontSize: 15, outline: "none" }} />
            ))}
            <div style={{ display: "flex", gap: 10, marginTop: 4 }}>
              <button onClick={() => setWdForm(null)} style={{ ...S.sheetGhost, flex: 1, borderColor: LINE }}>Отмена</button>
              <button onClick={saveWebdav} style={{ flex: 1, padding: 11, borderRadius: 10, border: "none", background: ACC, color: "#fff", fontSize: 15, fontWeight: 600 }}>Сохранить</button>
            </div>
          </div>
        </div>
      )}
      {gd && (
        <div style={{ position: "fixed", inset: 0, zIndex: 1450, background: BG, display: "flex", flexDirection: "column" }}>
          <div style={{ display: "flex", alignItems: "center", gap: 8, padding: "calc(10px + env(safe-area-inset-top)) 12px 10px", background: BAR }}>
            <button onClick={gdBack} style={{ background: "none", border: "none", color: ACC, display: "flex", padding: 4 }}><Svg d={I.back} size={22} /></button>
            <span style={{ flex: 1, minWidth: 0, color: TXT, fontWeight: 600, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{gd.stack[gd.stack.length - 1].name}</span>
            <button onClick={() => setGd(null)} style={{ background: "none", border: "none", color: RED, display: "flex", padding: 4 }}><Svg d={I.x} size={22} /></button>
          </div>
          <div style={{ flex: 1, overflow: "auto" }}>
            {gd.entries.length === 0 && <div style={S.note}>Пусто</div>}
            {gd.entries.map((e, i) => (
              <div key={i} onClick={() => gdEnter(e)} style={{ ...S.row, ...(e.type === "directory" ? S.rowDir : {}) }}>
                <span style={{ ...S.iconWrap, color: e.type === "directory" ? ACC : GOLD }}><Svg d={e.type === "directory" ? I.folder : fileIcon(e.name).d} size={24} /></span>
                <span style={S.rowMid}><span style={{ ...S.name, fontWeight: e.type === "directory" ? 600 : 400 }}>{e.name}</span></span>
                <span style={S.rowSize}>{e.type === "directory" ? "" : fmtSizeShort(e.size)}</span>
              </div>
            ))}
          </div>
          <div style={{ padding: "8px 12px calc(8px + env(safe-area-inset-bottom))", background: BAR, fontSize: 12, color: SUB, textAlign: "center" }}>Тап по файлу — скачать в Download</div>
        </div>
      )}
      {wd && (
        <div style={{ position: "fixed", inset: 0, zIndex: 1450, background: BG, display: "flex", flexDirection: "column" }}>
          <div style={{ display: "flex", alignItems: "center", gap: 8, padding: "calc(10px + env(safe-area-inset-top)) 12px 10px", background: BAR }}>
            <button onClick={wdBack} style={{ background: "none", border: "none", color: ACC, display: "flex", padding: 4 }}><Svg d={I.back} size={22} /></button>
            <span style={{ flex: 1, minWidth: 0, color: TXT, fontWeight: 600, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{wd.stack[wd.stack.length - 1].name}</span>
            <button onClick={() => setWd(null)} style={{ background: "none", border: "none", color: RED, display: "flex", padding: 4 }}><Svg d={I.x} size={22} /></button>
          </div>
          <div style={{ flex: 1, overflow: "auto" }}>
            {wd.entries.length === 0 && <div style={S.note}>Пусто</div>}
            {wd.entries.map((e, i) => (
              <div key={i} onClick={() => wdEnter(e)} style={{ ...S.row, ...(e.type === "directory" ? S.rowDir : {}) }}>
                <span style={{ ...S.iconWrap, color: e.type === "directory" ? ACC : GOLD }}><Svg d={e.type === "directory" ? I.folder : fileIcon(e.name).d} size={24} /></span>
                <span style={S.rowMid}><span style={{ ...S.name, fontWeight: e.type === "directory" ? 600 : 400 }}>{e.name}</span></span>
                <span style={S.rowSize}>{e.type === "directory" ? "" : fmtSizeShort(e.size)}</span>
              </div>
            ))}
          </div>
          <div style={{ padding: "8px 12px calc(8px + env(safe-area-inset-bottom))", background: BAR, fontSize: 12, color: SUB, textAlign: "center" }}>Тап по файлу — скачать в Download</div>
        </div>
      )}
      {pdf && (
        <div style={{ position: "fixed", inset: 0, zIndex: 1400, background: "#111", display: "flex", flexDirection: "column" }}>
          <div onTouchStart={pdfTouchStart} onTouchMove={pdfTouchMove} style={{ flex: 1, overflow: "auto", background: "#2b2b2b", WebkitOverflowScrolling: "touch", touchAction: "pan-x pan-y", paddingTop: "env(safe-area-inset-top)" }}>
            <div style={{ width: (pdfZoom * 100) + "%", margin: "0 auto", padding: "10px 0 24px", display: "flex", flexDirection: "column", alignItems: "center", gap: 10 }}>
              {pdfArr.map((src, i) => <img key={i} src={src} alt={"p" + i} style={{ width: "100%", display: "block", background: "#fff" }} />)}
              {(pdfN === 0 || pdfArr.length < pdfN) && <div style={{ color: "#bbb", fontSize: 13, padding: 20 }}>{pdfN === 0 ? "Открываю PDF…" : "Загрузка " + pdfArr.length + "/" + pdfN}</div>}
            </div>
          </div>
          <div style={{ display: "flex", alignItems: "center", gap: 8, padding: "8px 8px calc(8px + env(safe-area-inset-bottom)) 14px", background: "rgba(0,0,0,.65)" }}>
            <span style={{ flex: 1, minWidth: 0, color: "#fff", fontSize: 14, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{pdf.name}</span>
            <span style={{ color: "rgba(255,255,255,.7)", fontSize: 13, flexShrink: 0 }}>{pdfN ? pdfArr.length + "/" + pdfN : "…"}</span>
            <button onClick={closePdf} aria-label="Закрыть" style={{ background: "none", border: "none", color: "#fff", display: "flex", padding: 6, flexShrink: 0 }}><Svg d={I.x} size={24} /></button>
          </div>
        </div>
      )}
      {viewer && viewerCur && (
        <div style={{ position: "fixed", inset: 0, zIndex: 1300, background: "#000", display: "flex", flexDirection: "column", touchAction: "none", overflow: "hidden" }}>
          <div style={{ flex: 1, position: "relative", overflow: "hidden", display: "flex", alignItems: "center", justifyContent: "center" }}
            onTouchStart={(e) => {
              if (e.touches.length === 2) { const a = e.touches[0], b = e.touches[1]; pinchRef.current = { d: Math.hypot(a.clientX - b.clientX, a.clientY - b.clientY), z: zoom }; vTouch.current = null; setDragging(true); return; }
              const t = e.touches[0]; vTouch.current = { x: t.clientX, y: t.clientY, t: Date.now(), px: pan.x, py: pan.y }; setDragging(true);
            }}
            onTouchMove={(e) => {
              if (pinchRef.current && e.touches.length === 2) { const a = e.touches[0], b = e.touches[1]; const d = Math.hypot(a.clientX - b.clientX, a.clientY - b.clientY); setZoom(Math.max(1, Math.min(5, pinchRef.current.z * d / pinchRef.current.d))); return; }
              if (!vTouch.current) return; const t = e.touches[0]; const dx = t.clientX - vTouch.current.x; const dy = t.clientY - vTouch.current.y;
              if (zoom > 1) { setPan({ x: vTouch.current.px + dx, y: vTouch.current.py + dy }); return; }
              if (dy > Math.abs(dx)) setDragY(dy); else setDragX(dx);
            }}
            onTouchEnd={(e) => {
              setDragging(false);
              if (pinchRef.current) { pinchRef.current = null; if (zoom < 1.05) { setZoom(1); setPan({ x: 0, y: 0 }); } return; }
              const v = vTouch.current; vTouch.current = null; if (!v) { setDragX(0); setDragY(0); return; }
              if (zoom > 1) return;
              const t = e.changedTouches[0]; const dx = t.clientX - v.x; const dy = t.clientY - v.y; const dt = Date.now() - v.t;
              if (Math.abs(dx) < 12 && Math.abs(dy) < 12 && dt < 300) { setViewerBar((b) => !b); setDragX(0); setDragY(0); return; }
              if (dy > 120 && dy > Math.abs(dx)) { setViewer(null); setDragX(0); setDragY(0); return; }
              const TH = Math.min(45, window.innerWidth * 0.10);
              const flick = dt < 260 && Math.abs(dx) > 28;
              if ((dx < -TH || (flick && dx < 0)) && viewer.idx < viewer.items.length - 1) viewerGo(1);
              else if ((dx > TH || (flick && dx > 0)) && viewer.idx > 0) viewerGo(-1);
              setDragX(0); setDragY(0);
            }}>
            <img key={viewerCur.uri} src={cfs(viewerCur.uri)} alt={viewerCur.name}
              style={{ maxWidth: "100%", maxHeight: "100%", objectFit: "contain", transform: "translate(" + (pan.x + dragX) + "px," + (pan.y + dragY) + "px) scale(" + zoom + ")", transition: dragging ? "none" : "transform .2s ease", opacity: dragY > 0 ? Math.max(0.3, 1 - dragY / 500) : 1, userSelect: "none", pointerEvents: "none" }} />
            {[-2, -1, 1, 2].map((d) => { const it = viewer.items[viewer.idx + d]; return it && isImg(it.name) ? <img key={"pl" + it.uri} src={cfs(it.uri)} alt="" aria-hidden="true" style={{ position: "absolute", width: 2, height: 2, top: 0, left: 0, opacity: 0, pointerEvents: "none" }} /> : null; })}
          </div>

          {/* заголовок сверху: имя + счётчик + крестик справа */}
          <div style={{ position: "absolute", top: 0, left: 0, right: 0, paddingTop: "env(safe-area-inset-top)", background: "linear-gradient(to bottom, rgba(0,0,0,.75), transparent)", transform: viewerBar ? "translateY(0)" : "translateY(-110%)", transition: "transform .2s ease", pointerEvents: viewerBar ? "auto" : "none" }}>
            <div style={{ display: "flex", alignItems: "center", gap: 10, padding: "12px 14px 16px" }}>
              <span style={{ flex: 1, minWidth: 0, color: "#fff", fontSize: 14, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{viewerCur.name}</span>
              <span style={{ color: "rgba(255,255,255,.7)", fontSize: 13, flexShrink: 0 }}>{viewer.idx + 1}/{viewer.items.length}</span>
            </div>
          </div>

          {/* тулбар снизу: справа-налево — удалить, свойства, поделиться, редактировать */}
          <div style={{ position: "absolute", bottom: 0, left: 0, right: 0, paddingBottom: "env(safe-area-inset-bottom)", background: "linear-gradient(to top, rgba(0,0,0,.8), transparent)", transform: viewerBar ? "translateY(0)" : "translateY(110%)", transition: "transform .2s ease", pointerEvents: viewerBar ? "auto" : "none" }}>
            <div style={{ display: "flex", justifyContent: "space-around", alignItems: "flex-end", padding: "16px 76px 14px 8px" }}>
              {[
                [I.share, "Поделиться", () => Apps.share({ uri: viewerCur.uri, mime: mimeOf(viewerCur.name) }).catch(() => {}), false],
                [I.rename, "Изменить", () => showOpenMenu(viewerCur, mimeOf(viewerCur.name), { edit: true }), false],
                [I.info, "Свойства", () => setProps(viewerCur), false],
                [I.trash, "Удалить", () => setViewerDel(true), true],
              ].map(([ic, lbl, fn, red], i) => (
                <span key={i} onClick={fn} style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 5, color: red ? "#FF6B6B" : "#fff", minWidth: 60, padding: "4px 2px" }}>
                  <Svg d={ic} size={23} /><span style={{ fontSize: 11 }}>{lbl}</span>
                </span>
              ))}
            </div>
          </div>

          {/* крестик закрытия — правый нижний угол */}
          <div style={{ position: "absolute", right: 14, bottom: 0, paddingBottom: "calc(env(safe-area-inset-bottom) + 16px)", transform: viewerBar ? "translateY(0)" : "translateY(110%)", transition: "transform .2s ease", pointerEvents: viewerBar ? "auto" : "none", zIndex: 2 }}>
            <span onClick={() => setViewer(null)} style={{ display: "flex", width: 44, height: 44, borderRadius: 22, background: "rgba(0,0,0,.5)", border: "1px solid rgba(255,255,255,.25)", color: "#fff", alignItems: "center", justifyContent: "center" }}><Svg d={I.x} size={24} /></span>
          </div>

          {/* подтверждение удаления в просмотрщике */}
          {viewerDel && (
            <div style={{ position: "fixed", inset: 0, zIndex: 1360, background: "rgba(0,0,0,.6)", display: "flex", alignItems: "center", justifyContent: "center" }} onClick={() => setViewerDel(false)}>
              <div onClick={(e) => e.stopPropagation()} style={{ background: BAR, borderRadius: 16, padding: 18, width: "78%", maxWidth: 320, boxShadow: "0 18px 48px rgba(0,0,0,.6)" }}>
                <div style={{ color: TXT, fontSize: 15, marginBottom: 4 }}>Удалить файл?</div>
                <div style={{ color: SUB, fontSize: 13, marginBottom: 16, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{viewerCur.name}</div>
                <div style={{ display: "flex", gap: 10, justifyContent: "flex-end" }}>
                  <button onClick={() => setViewerDel(false)} style={{ background: ROW2, border: "1px solid " + LINE, borderRadius: 10, color: SUB, fontSize: 14, padding: "9px 20px" }}>Нет</button>
                  <button onClick={viewerDelete} style={{ background: RED, border: "none", borderRadius: 10, color: "#fff", fontSize: 14, fontWeight: 700, padding: "9px 20px" }}>Да</button>
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {props && (
        <div style={S.backdrop} onClick={() => setProps(null)}>
          <div style={S.sheet} onClick={(e) => e.stopPropagation()}>
            {props.multi ? (
              <>
                <div style={S.sheetTitle}>Выбрано: {props.multi.length}</div>
                <Prop k="Папок" v={String(props.multi.filter((x) => x.type === "directory").length)} />
                <Prop k="Файлов" v={String(props.multi.filter((x) => x.type !== "directory").length)} />
                <Prop k="Общий вес" v={propSize == null ? "подсчёт…" : fmtSize(propSize)} />
                <div style={{ maxHeight: 180, overflowY: "auto", marginTop: 10, borderTop: "1px solid " + LINE, paddingTop: 8 }}>
                  {props.multi.map((x) => (
                    <div key={x.uri || x.name} style={{ display: "flex", justifyContent: "space-between", gap: 10, padding: "4px 0", fontSize: 12, color: SUB }}>
                      <span style={{ overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{x.name}</span>
                      <span style={{ flexShrink: 0 }}>{x.type === "directory" ? "папка" : fmtSize(x.size)}</span>
                    </div>
                  ))}
                </div>
                <button style={{ ...S.sheetGhost, width: "100%", marginTop: 14 }} onClick={() => setProps(null)}>Закрыть</button>
              </>
            ) : (
              <>
            <div style={S.sheetTitle}>{propApkIcon && <img src={propApkIcon} alt="" style={{ width: 28, height: 28, borderRadius: 7, verticalAlign: "middle", marginRight: 10 }} />}{props.name}</div>
            <Prop k="Путь (нажмите, чтобы скопировать)" v={path ? "/" + keyOf(props.name) : "/" + props.name} onClick={() => copyPath(props.uri)} link />
            {props.type === "directory" && <Prop k="Содержимое" v={propCount ? propCount.d + " папок, " + propCount.f + " файлов" : "…"} />}
            <Prop k="Вес" v={props.type === "directory" ? (propSize == null ? "подсчёт…" : fmtSize(propSize)) : fmtSize(props.size)} />
            <Prop k="Изменено" v={ago(props.mtime)} />
            <Prop k="Тип" v={props.type === "directory" ? "Папка" : (props.name.includes(".") ? props.name.split(".").pop().toUpperCase() : "Файл")} />
            {propMeta && propMeta.w > 0 && <Prop k="Разрешение" v={propMeta.w + " × " + propMeta.h} />}
            {propMeta && propMeta.duration && <Prop k="Длительность" v={propMeta.duration} />}
            {propMeta && propMeta.bitrate && <Prop k="Битрейт" v={propMeta.bitrate} />}
            {propMeta && propMeta.codec && <Prop k="Кодек" v={propMeta.codec} />}
            {propMeta && propMeta.fps && <Prop k="Кадров/с" v={propMeta.fps} />}
            {propMeta && propMeta.title && <Prop k="Название" v={propMeta.title} />}
            {propMeta && propMeta.artist && <Prop k="Исполнитель" v={propMeta.artist} />}
            {propMeta && propMeta.album && <Prop k="Альбом" v={propMeta.album} />}
            {propMeta && propMeta.year && <Prop k="Год" v={propMeta.year} />}
            {propMeta && propMeta.camera && <Prop k="Камера" v={propMeta.camera} />}
            {propMeta && propMeta.lens && <Prop k="Объектив" v={propMeta.lens} />}
            {propMeta && (propMeta.aperture || propMeta.exposure || propMeta.iso) &&
              <Prop k="Съёмка" v={[propMeta.aperture, propMeta.exposure, propMeta.iso, propMeta.focal].filter(Boolean).join("  ·  ")} />}
            {propMeta && propMeta.taken && <Prop k="Снято" v={propMeta.taken} />}
            {propMeta && propMeta.gps && <Prop k="Координаты" v={propMeta.gps} />}
            <Prop k="Скрытый" v={isHidden(props) ? "Да" : "Нет"} />
            <button style={{ ...S.sheetGhost, width: "100%", marginTop: 14 }} onClick={() => setProps(null)}>Закрыть</button>
              </>
            )}
          </div>
        </div>
      )}

      {/* ЗАПРОС ПАРОЛЯ АРХИВА */}
      {pwPrompt && (
        <div style={{ position: "fixed", inset: 0, zIndex: 1460, background: "rgba(0,0,0,.55)", display: "flex", alignItems: "flex-end", justifyContent: "center" }} onClick={() => resolvePassword(null)}>
          <div onClick={(e) => e.stopPropagation()} style={{ width: "100%", maxWidth: 460, background: BAR, borderTopLeftRadius: 18, borderTopRightRadius: 18, padding: "16px 16px calc(env(safe-area-inset-bottom) + 16px)", boxShadow: "0 -8px 32px rgba(0,0,0,.5)" }}>
            <div style={{ color: TXT, fontSize: 15, fontWeight: 600, marginBottom: 4 }}>Архив защищён паролем</div>
            {pwPrompt.retry && <div style={{ color: RED, fontSize: 12, marginBottom: 8 }}>Неверный пароль, попробуйте ещё раз</div>}
            <input value={pwVal} onChange={(e) => setPwVal(e.target.value)} type="password" autoFocus placeholder="Пароль"
              style={{ width: "100%", boxSizing: "border-box", background: BG, border: "1px solid " + LINE, borderRadius: 12, color: TXT, fontSize: 15, padding: "12px 14px", marginBottom: 12, outline: "none" }} />
            <div style={{ display: "flex", gap: 8 }}>
              <button onClick={() => resolvePassword(null)} style={{ flex: 1, background: ROW2, border: "1px solid " + LINE, borderRadius: 10, color: SUB, fontSize: 14, padding: "11px 0" }}>Отмена</button>
              <button onClick={() => resolvePassword(pwVal)} style={{ flex: 1, background: ACC, border: "none", borderRadius: 10, color: "#fff", fontSize: 14, fontWeight: 600, padding: "11px 0" }}>Ок</button>
            </div>
          </div>
        </div>
      )}

      {/* ВЬЮВЕР ШРИФТОВ */}
      {fontView && (
        <div style={{ position: "fixed", inset: 0, zIndex: 1350, background: BG, display: "flex", flexDirection: "column" }}>
          {fontView.css && <style>{fontView.css}</style>}
          <div style={{ display: "flex", alignItems: "center", gap: 10, padding: "calc(env(safe-area-inset-top) + 10px) 14px 10px", borderBottom: "1px solid " + LINE }}>
            <button onClick={() => setFontView(null)} style={{ background: "transparent", border: "none", color: ACC, padding: 4, display: "flex" }}><Svg d={I.back} size={24} /></button>
            <div style={{ flex: 1, minWidth: 0, color: TXT, fontSize: 15, fontWeight: 600, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{fontView.name}</div>
          </div>
          {fontView.loading ? (
            <div style={{ flex: 1, display: "flex", alignItems: "center", justifyContent: "center", color: SUB }}>Загрузка…</div>
          ) : (
            <>
              <div style={{ flex: 1, overflowY: "auto", padding: 16 }}>
                {fontText.trim() && [40, 28, 20].map((sz) => (
                  <div key={"c" + sz} style={{ fontFamily: "'" + fontView.family + "'", fontSize: sz, color: TXT, lineHeight: 1.35, marginBottom: 14, wordBreak: "break-word" }}>{fontText}</div>
                ))}
                {[
                  ["Русский", "Съешь же ещё этих мягких французских булок да выпей чаю."],
                  ["English", "The quick brown fox jumps over the lazy dog."],
                ].map(([lbl, txt]) => (
                  <div key={lbl} style={{ marginBottom: 20 }}>
                    <div style={{ color: SUB, fontSize: 11, textTransform: "uppercase", letterSpacing: 1, marginBottom: 6 }}>{lbl}</div>
                    {[34, 24, 18, 14].map((sz) => (
                      <div key={lbl + sz} style={{ fontFamily: "'" + fontView.family + "'", fontSize: sz, color: TXT, lineHeight: 1.4, marginBottom: 8, wordBreak: "break-word" }}>{txt}</div>
                    ))}
                  </div>
                ))}
                <div style={{ fontFamily: "'" + fontView.family + "'", fontSize: 26, color: TXT, marginBottom: 8 }}>ABCDEFGHIJKLMNOPQRSTUVWXYZ</div>
                <div style={{ fontFamily: "'" + fontView.family + "'", fontSize: 26, color: TXT, marginBottom: 8 }}>abcdefghijklmnopqrstuvwxyz</div>
                <div style={{ fontFamily: "'" + fontView.family + "'", fontSize: 26, color: TXT, marginBottom: 8 }}>АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯ</div>
                <div style={{ fontFamily: "'" + fontView.family + "'", fontSize: 26, color: TXT, marginBottom: 20 }}>0123456789</div>
              </div>
              <div style={{ padding: "10px 14px calc(env(safe-area-inset-bottom) + 12px)", borderTop: "1px solid " + LINE, background: BAR }}>
                <input value={fontText} onChange={(e) => setFontText(e.target.value)} placeholder="Введите свой текст…"
                  style={{ width: "100%", boxSizing: "border-box", background: BG, border: "1px solid " + LINE, borderRadius: 12, color: TXT, fontSize: 15, padding: "12px 14px", outline: "none" }} />
              </div>
            </>
          )}
        </div>
      )}

      {/* КОНФЛИКТ ИМЁН ПРИ ВСТАВКЕ — компактно, внизу */}
      {sortAsk && (
        <>
          <div style={{ position: "fixed", inset: 0, zIndex: 1449, background: "rgba(0,0,0,.35)" }} onClick={() => setSortAsk(null)} />
          <div style={{ position: "fixed", zIndex: 1450, left: 10, right: 10, bottom: "calc(84px + env(safe-area-inset-bottom))", background: BAR, borderRadius: 16, padding: 14, boxShadow: "var(--barsh)" }}>
            <div style={{ color: TXT, fontSize: 15, fontWeight: 600, marginBottom: 6 }}>Подпапки сортировать тоже?</div>
            <div style={{ color: SUB, fontSize: 12.5, lineHeight: 1.5, marginBottom: 12 }}>«Да» — к этой папке и всем её подпапкам. «Нет» — только к этой папке.</div>
            <div style={{ display: "flex", gap: 8 }}>
              <button onClick={() => { const k = sortAsk.mode; setSortAsk(null); const m = {}; for (const kk in sortMap) { const raw = kk.startsWith("sub://") ? kk.slice(6) : kk; if (raw === path || raw.startsWith(path ? path + "/" : "")) continue; m[kk] = sortMap[kk]; } m["sub://" + path] = k; setSortMap(m); ls.set("fm_sortmap_v1", JSON.stringify(m)); }}
                style={{ flex: 1, height: 44, borderRadius: 12, border: "none", background: ACC, color: "#fff", fontSize: 14, fontWeight: 600 }}>Да</button>
              <button onClick={() => { const k = sortAsk.mode; setSortAsk(null); const m = { ...sortMap, [path]: k }; setSortMap(m); ls.set("fm_sortmap_v1", JSON.stringify(m)); }}
                style={{ flex: 1, height: 44, borderRadius: 12, border: "1px solid " + LINE, background: ROW2, color: TXT, fontSize: 14 }}>Нет</button>
            </div>
          </div>
        </>
      )}
      {safPrompt && (
        <>
          <div style={{ position: "fixed", inset: 0, zIndex: 1449, background: "rgba(0,0,0,.35)" }} onClick={() => setSafPrompt(null)} />
          <div style={{ position: "fixed", zIndex: 1450, left: 10, right: 10, bottom: "calc(84px + env(safe-area-inset-bottom))", background: BAR, borderRadius: 16, padding: 14, boxShadow: "var(--barsh)" }}>
            <div style={{ color: TXT, fontSize: 15, fontWeight: 600, marginBottom: 6 }}>Доступ к флешке</div>
            <div style={{ color: SUB, fontSize: 12.5, lineHeight: 1.5, marginBottom: 12 }}>
              Android даёт работать со съёмными носителями только через системный выбор папки. Нажмите «Разрешить», в открывшемся окне выберите этот накопитель и подтвердите — после этого просмотр и копирование заработают.
            </div>
            <div style={{ display: "flex", gap: 8 }}>
              <button onClick={async () => { const abs = safPrompt.abs; setSafPrompt(null); try { await Apps.safRequest({ path: abs }); showToast("Доступ выдан"); loadVolumes(); refresh(); } catch (e) { showToast("Ошибка: " + (e?.message || "")); } }}
                style={{ flex: 1, height: 44, borderRadius: 12, border: "none", background: ACC, color: "#fff", fontSize: 14, fontWeight: 600 }}>Разрешить</button>
              <button onClick={() => setSafPrompt(null)} style={{ flex: 1, height: 44, borderRadius: 12, border: "1px solid " + LINE, background: ROW2, color: TXT, fontSize: 14 }}>Отмена</button>
            </div>
          </div>
        </>
      )}
      {opErr && (
        <>
          <div style={{ position: "fixed", inset: 0, zIndex: 1449 }} />
          <div style={{ position: "fixed", zIndex: 1450, left: 10, right: 10, bottom: "calc(84px + env(safe-area-inset-bottom))", background: BAR, borderRadius: 16, padding: 12, boxShadow: "var(--barsh)" }}>
            <div style={{ color: RED, fontSize: 13, marginBottom: 2 }}>Не удалось обработать:</div>
            <div style={{ color: TXT, fontSize: 12, marginBottom: 4, wordBreak: "break-all" }}>{opErr.name}</div>
            <div style={{ color: SUB, fontSize: 11.5, marginBottom: 10, wordBreak: "break-all" }}>{opErr.msg}</div>
            <div style={{ display: "flex", gap: 6 }}>
              <button onClick={() => resolveOpErr("retry", false)} style={{ flex: 1, background: ACC, border: "none", borderRadius: 9, color: "#fff", fontSize: 13, fontWeight: 600, padding: "10px 0" }}>Повторить</button>
              <button onClick={() => resolveOpErr("skip", false)} style={{ flex: 1, background: ROW2, border: "1px solid " + LINE, borderRadius: 9, color: TXT, fontSize: 13, padding: "10px 0" }}>Пропустить</button>
              <button onClick={() => resolveOpErr("skip", true)} style={{ flex: 1, background: ROW2, border: "1px solid " + LINE, borderRadius: 9, color: TXT, fontSize: 13, padding: "10px 0" }}>Пропустить все</button>
            </div>
            <div style={{ display: "flex", justifyContent: "flex-end", marginTop: 8 }}>
              <button onClick={() => resolveOpErr("cancel", false)} style={{ background: "transparent", border: "none", color: SUB, fontSize: 12, padding: "4px 6px" }}>Отменить всё</button>
            </div>
          </div>
        </>
      )}
      {conflict && (
        <>
          <div style={{ position: "fixed", inset: 0, zIndex: 1449 }} />
          <div style={{ position: "fixed", zIndex: 1450, left: 10, right: 10, bottom: "calc(84px + env(safe-area-inset-bottom))", background: BAR, borderRadius: 16, padding: 12, boxShadow: "var(--barsh)" }}>
            <div style={{ color: TXT, fontSize: 13, marginBottom: 2 }}>Уже существует:</div>
            <div style={{ color: SUB, fontSize: 12, marginBottom: 10, wordBreak: "break-all" }}>{conflict.name}</div>
            <div style={{ display: "flex", gap: 6 }}>
              <button onClick={() => resolveConflict("rename", conflictApplyAll)} style={{ flex: 1, background: ACC, border: "none", borderRadius: 9, color: "#fff", fontSize: 13, fontWeight: 600, padding: "10px 0" }}>Копия (1)</button>
              <button onClick={() => resolveConflict("skip", conflictApplyAll)} style={{ flex: 1, background: ROW2, border: "1px solid " + LINE, borderRadius: 9, color: TXT, fontSize: 13, padding: "10px 0" }}>Пропустить</button>
              {conflict.isDir && <button onClick={() => resolveConflict("merge", conflictApplyAll)} style={{ flex: 1, background: ROW2, border: "1px solid " + LINE, borderRadius: 9, color: TXT, fontSize: 13, padding: "10px 0" }}>Объединить</button>}
              <button onClick={() => resolveConflict("overwrite", conflictApplyAll)} style={{ flex: 1, background: RED, border: "none", borderRadius: 9, color: "#fff", fontSize: 13, fontWeight: 600, padding: "10px 0" }}>Перезаписать</button>
            </div>
            <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginTop: 8 }}>
              <div onClick={() => setConflictApplyAll((v) => !v)} style={{ display: "flex", alignItems: "center", gap: 7, color: SUB, fontSize: 12 }}>
                <span style={{ ...S.cbox, ...(conflictApplyAll ? S.cboxOn : {}) }}>{conflictApplyAll ? <Svg d={I.check} size={12} /> : null}</span>
                Ко всем
              </div>
              <button onClick={() => resolveConflict("cancel", false)} style={{ background: "transparent", border: "none", color: SUB, fontSize: 12, padding: "4px 6px" }}>Отменить всё</button>
            </div>
          </div>
        </>
      )}

      {/* ПОДТВЕРЖДЕНИЕ УДАЛЕНИЯ — над кнопкой «Удалить» */}
      {confirmDel && (
        <>
          <div style={{ position: "fixed", inset: 0, zIndex: 1290 }} onClick={() => setConfirmDel(null)} />
          <div style={{ position: "fixed", zIndex: 1300, left: Math.max(90, Math.min(confirmDel.cx, window.innerWidth - 90)), transform: "translateX(-50%)", top: confirmDel.top - 92, minWidth: 180, background: BAR, borderRadius: 14, padding: 10, boxShadow: "var(--barsh)", animation: "popCenter .15s ease" }}>
            <div style={{ color: TXT, fontSize: 14, fontWeight: 600, textAlign: "center", marginBottom: delInfo && delInfo.bytes > 0 ? 8 : 10 }}>
              Удалить {delInfo ? delInfo.items : [...sel].length}?
            </div>
            {delInfo && delInfo.bytes > 0 && (
              <div style={{ textAlign: "center", marginBottom: 10 }}>
                <span style={{ display: "inline-block", background: "rgba(224,82,82,.15)", color: "#E88", fontSize: 12, fontWeight: 600, padding: "3px 11px", borderRadius: 999 }}>{fmtSizeShort(delInfo.bytes)}</span>
              </div>
            )}
            {!delInfo && (<div style={{ color: SUB, fontSize: 12, textAlign: "center", marginBottom: 10 }}>подсчёт…</div>)}
            <div style={{ display: "flex", gap: 8, justifyContent: "center" }}>
              <button onClick={doDelete} style={{ background: RED, border: "none", borderRadius: 8, color: "#fff", fontSize: 14, fontWeight: 700, padding: "8px 20px" }}>Да</button>
              <button onClick={() => setConfirmDel(null)} style={{ background: ROW2, border: "1px solid " + LINE, borderRadius: 8, color: SUB, fontSize: 14, padding: "8px 20px" }}>Нет</button>
            </div>
          </div>
        </>
      )}

      {/* ПРОСМОТР АРХИВА — как папка */}
      {arcView && (
        <div style={S.arcScreen}>
          <div style={{ ...S.crumb, borderBottom: "none" }}>
            <span onClick={() => (arcPath ? setArcPath(arcPath.replace(/[^/]+\/$/, "")) : setArcView(null))} style={{ display: "inline-flex", alignItems: "center", gap: 6, color: ACC, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}><Svg d={I.back} size={18} /> {arcView.name + (arcPath ? " / " + arcPath.replace(/\/$/, "") : "")}</span>
          </div>
          {arcView.busy && <div style={{ position: "absolute", top: 50, left: 0, right: 0, zIndex: 5, padding: "8px 16px", color: GOLD, fontSize: 13, textAlign: "center", pointerEvents: "none", textShadow: "0 1px 4px rgba(0,0,0,.6)" }}>{arcView.busy}</div>}
          {arcView.entries == null ? (
            <div style={{ flex: 1, display: "flex", alignItems: "center", justifyContent: "center", color: SUB }}>Открываю архив…</div>
          ) : (
          <div ref={arcListRef} style={{ flex: 1, overflowY: "auto", display: "flex", flexDirection: "column" }}>
            <div ref={arcSpacerRef} style={{ height: 0, flexShrink: 0 }} />
            <div style={{ flexShrink: 0 }}>
              {arcLevel.map((it, i) => {
                const isDir = !!it.dir;
                const label = isDir ? it.name : (it.label || it.name);
                const ic = isDir ? { d: I.folder, c: ACC } : fileIcon(label);
                const asel = isDir ? (it.count > 0 && arcSelUnder.get(it.prefix) === it.count) : arcSel.has(it.name);
                const tog = () => { const selNames = isDir ? arcNamesUnder(it.prefix) : [it.name]; const n = new Set(arcSel); if (asel) selNames.forEach((x) => n.delete(x)); else selNames.forEach((x) => n.add(x)); setArcSel(n); };
                return (
                  <div key={i}
                    onClick={() => { if (arcSel.size > 0) tog(); else if (!arcLp.current) { if (isDir) setArcPath(it.prefix); else extractOpen(it); } }}
                    onPointerDown={(ev) => { arcLp.current = false; arcPX.current = ev.clientX; arcPY.current = ev.clientY; clearTimeout(arcLpT.current); arcLpT.current = setTimeout(() => { arcLp.current = true; tog(); }, 400); }}
                    onPointerUp={() => clearTimeout(arcLpT.current)}
                    onPointerMove={(ev) => { if (Math.abs(ev.clientX - arcPX.current) > 10 || Math.abs(ev.clientY - arcPY.current) > 10) clearTimeout(arcLpT.current); }}
                    onPointerCancel={() => clearTimeout(arcLpT.current)}
                    style={{ ...S.row, ...(arcLevel.length <= 12 ? { contentVisibility: "visible" } : {}), ...(asel ? { background: "var(--accbg)" } : {}) }}>
                    <span style={{ ...S.iconWrap, color: ic.c, background: asel ? "transparent" : "var(--chip)" }}
                      onClick={(ev) => { ev.stopPropagation(); tog(); }}>
                      {asel ? <span style={S.cbk}><Svg d={I.check} size={14} /></span>
                        : isDir ? <Svg d={I.folder} size={24} />
                        : /\.apk$/i.test(label) ? <Svg d={ic.d} size={24} />
                        : (EXT.archive.includes((label.split(".").pop() || "").toLowerCase())) ? <ArcBadge name={label} />
                        : <Svg d={ic.d} size={24} />}
                    </span>
                    <span style={S.rowMid}>
                      <span style={S.name}>{label}</span>
                      <span style={S.rowDate}>{isDir ? (it.count + " " + plural(it.count, "объект", "объекта", "объектов")) : "в архиве"}</span>
                    </span>
                    <span style={S.rowSize}>{fmtSizeShort(it.size)}</span>
                    <div style={S.rowLine} />
                  </div>
                );
              })}
            </div>
          </div>
          )}
          {arcSel.size > 0 && (
            <div style={S.arcSelBar}>
              <span style={{ color: "#fff", fontWeight: 700, fontSize: 15 }}>{arcSel.size}</span>
              <button onClick={() => setArcSel(new Set())} style={S.arcSelCancel}>Отмена</button>
              <button onClick={extractSelected} style={S.arcSelGo}><Svg d={I.dl} size={16} /> Извлечь</button>
            </div>
          )}
        </div>
      )}

      {/* МЕНЮ ОТКРЫТИЯ ФАЙЛА */}
      {openMenu && (() => {
        return (
          <div style={{ ...S.backdrop, pointerEvents: menuArmed ? "auto" : "none" }} onClick={() => setOpenMenu(null)}>
            <div ref={omSheetRef} style={{ ...S.sheet, animation: "growSheet .26s cubic-bezier(.2,.8,.3,1.05)" }} onClick={(e) => e.stopPropagation()}>
              {/\.(apk|apks|xapk|apkm|apkx)$/i.test(openMenu.file.name) && openMenu.apkInfo && (
                <div style={{ padding: "10px 12px", margin: "0 0 12px", background: ROW2, borderRadius: 12, fontSize: 13, lineHeight: 1.7, color: SUB }}>
                  <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 4 }}>
                    {openMenu.apkInfo.icon && <img src={openMenu.apkInfo.icon} alt="" style={{ width: 40, height: 40, borderRadius: 9, flexShrink: 0 }} />}
                    <div style={{ minWidth: 0 }}>
                      {openMenu.apkInfo.label && <div style={{ color: TXT, fontWeight: 600, fontSize: 15 }}>{openMenu.apkInfo.label}</div>}
                      {openMenu.apkInfo.package && <div style={{ color: "#7FB4E6", wordBreak: "break-all", fontSize: 12 }}>{openMenu.apkInfo.package}</div>}
                    </div>
                  </div>
                  {openMenu.apkInfo.versionName && <div>Версия: <span style={{ color: TXT }}>{openMenu.apkInfo.versionName} ({openMenu.apkInfo.versionCode})</span>{openMenu.apkInfo.installed && openMenu.apkInfo.installedVersionCode != null && Number(openMenu.apkInfo.versionCode) > Number(openMenu.apkInfo.installedVersionCode) && <span style={{ color: "#5FCF80", fontWeight: 700 }}> (новее)</span>}</div>}
                  {openMenu.apkInfo.installed && <div>Установлено: <span style={{ color: GOLD }}>{openMenu.apkInfo.installedVersionName || "—"}</span></div>}
                  {openMenu.apkInfo.installed && openMenu.apkInfo.sigMatch === true && <div style={{ color: "#5FCF80" }}>Подпись совпадает — установится поверх</div>}
                  {openMenu.apkInfo.installed && openMenu.apkInfo.sigMatch === false && <div style={{ color: RED, fontWeight: 600 }}>Подпись отличается — поверх НЕ установится</div>}
                  {openMenu.apkInfo.installed && openMenu.apkInfo.sigMatch === false && openMenu.apkInfo.package && (
                    <div onClick={() => { const f = openMenu.file, p = openMenu.apkInfo.package; setOpenMenu(null); Apps.apkReinstall({ uri: f.uri, package: p }).catch((er) => showToast("Ошибка: " + (er?.message || ""))); }}
                      style={{ marginTop: 8, padding: "10px 12px", borderRadius: 10, background: "var(--accbg)", color: ACC, fontWeight: 600, fontSize: 14, display: "flex", alignItems: "center", justifyContent: "center", gap: 8 }}>
                      <Svg d={I.plus} size={18} /> Деинсталировать и установить
                    </div>
                  )}
                  {!openMenu.apkInfo.installed && openMenu.apkInfo.sig && <div style={{ color: SUB, fontSize: 11, wordBreak: "break-all" }}>Подпись: {openMenu.apkInfo.sig.slice(0, 24)}…</div>}
                  <div>Целевая ОС: <span style={{ color: TXT }}>SDK {openMenu.apkInfo.targetSdk}</span></div>
                  {openMenu.apkInfo.minSdk != null && <div>Минимальная ОС: <span style={{ color: TXT }}>SDK {openMenu.apkInfo.minSdk}</span></div>}
                </div>
              )}
              <div style={{ display: "flex", alignItems: "center", marginBottom: 14 }}>
                <div style={{ ...S.sheetTitle, marginBottom: 0, flex: 1, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{openMenu.file.name}</div>
                <button style={{ ...S.iconBtn, color: openMenu.editHide ? ACC : SUB }} onClick={() => setOpenMenu({ ...openMenu, editHide: !openMenu.editHide })}><Svg d={I.rename} size={20} /></button>
              </div>
              {!openMenu.editHide && !openMenu.edit && (
                <>
                  <div onClick={() => setOpenMenu({ ...openMenu, showCats: !openMenu.showCats })} style={{ ...S.appRow, color: SUB }}>
                    <span style={{ width: 38, display: "flex", justifyContent: "center" }}><Svg d={I.chev} size={22} /></span>
                    <span style={{ flex: 1, fontSize: 15 }}>Открыть как…</span>
                  </div>
                  {openMenu.showCats && (
                    <div style={{ display: "flex", gap: 6, overflowX: "auto", margin: "2px 0 12px", paddingBottom: 2 }}>
                      {OPEN_AS.map(([m, lbl]) => (
                        <button key={m} onClick={() => reQueryAs(m)}
                          style={{ ...S.chip, ...(openMenu.asCat && openMenu.mime === m ? S.chipOn : {}) }}>{lbl}</button>
                      ))}
                    </div>
                  )}
                </>
              )}
              {openMenu.editHide && <div style={{ fontSize: 12, color: GOLD, marginBottom: 10 }}>Глаз — скрыть/показать. Кнопки перетаскиваются (удержание). Тап по приложению — скрыть/показать.</div>}
              <div style={{ maxHeight: "52vh", overflowY: dragId ? "hidden" : "auto" }} onTouchMove={menuDragMove} onTouchEnd={() => menuDragEnd(menuCat(openMenu))} onTouchCancel={() => menuDragEnd(menuCat(openMenu))}>
                {(() => {
                  const cat = menuCat(openMenu);
                  const sh = new Set(loadMap(HIDEKEY)[cat] || []);
                  const stock = orderItems(buildStockItems(openMenu), cat);
                  const vis = openMenu.editHide ? stock : stock.filter((it) => !sh.has(it.id));
                  return vis.map((it, idx) => {
                    const isHid = sh.has(it.id);
                    return (
                      <div key={it.id} data-mid={it.id}
                        onTouchStart={(e) => menuDragStart(idx, e, vis)}
                        onClick={() => { if (suppressClick.current) return; if (openMenu.editHide) toggleHideItem(cat, it.id); else it.onClick(); }}
                        style={{ ...S.appRow, color: it.color || TXT, opacity: isHid ? 0.4 : 1, background: dragId === it.id ? ROW2 : "transparent" }}>
                        {it.icon ? <img src={it.icon} alt="" style={{ width: 38, height: 38, borderRadius: 9 }} />
                          : <span style={{ width: 38, display: "flex", justifyContent: "center" }}><Svg d={it.d} size={it.size || 26} /></span>}
                        <span style={{ flex: 1, fontSize: 15 }}>{it.label}</span>
                        {openMenu.editHide && <span style={{ color: isHid ? SUB : ACC, display: "flex", marginRight: 8 }}><Svg d={isHid ? I.eyeOff : I.eye} size={20} /></span>}
                        {openMenu.editHide && <span style={{ color: SUB, display: "flex" }}><Svg d={I.drag} size={20} /></span>}
                      </div>
                    );
                  });
                })()}
              </div>
              {openMenu.apps == null && (() => { const fm = mimeOf(openMenu.file.name); return !openMenu.split && ((fm !== "*/*" && fm !== "application/octet-stream") || (openMenu.asCat && openMenu.mime !== "*/*")); })() && (
                <div style={{ color: SUB, padding: 16, textAlign: "center" }}>Загрузка приложений…</div>
              )}
              {!openMenu.editHide && !openMenu.edit && !openMenu.split && !/\.apk$/i.test(openMenu.file.name) && (
                <div style={{ display: "flex", alignItems: "center", gap: 10, padding: "10px 2px 2px" }}>
                  <div onClick={() => setOpenMenu({ ...openMenu, useDefault: !openMenu.useDefault })}
                    style={{ display: "flex", alignItems: "center", gap: 10, flex: 1, cursor: "pointer" }}>
                    <span style={{ ...S.cbox, ...(openMenu.useDefault ? S.cboxOn : {}) }}>{openMenu.useDefault ? "✓" : ""}</span>
                    <span style={{ fontSize: 14 }}>Использовать по умолчанию</span>
                  </div>
                  <button style={{ ...S.sheetGhost, color: RED, borderColor: LINE, padding: "8px 18px", flexShrink: 0 }} onClick={resetDefault}>Сбросить</button>
                </div>
              )}
            </div>
          </div>
        );
      })()}

      {/* НАСТРОЙКИ */}
      {settings && (
        <div style={S.settingsScreen}>
          <div style={S.crumb}>
            <span onClick={() => { if (settingsPage) setSettingsPage(null); else setSettings(false); }} style={{ display: "inline-flex", alignItems: "center", gap: 6, color: ACC }}>
              <Svg d={I.back} size={18} /> {settingsPage === "theme" ? "Тема" : settingsPage === "fonts" ? "Шрифты" : settingsPage === "sort" ? "Сортировка" : settingsPage === "icons" ? "Иконки папок" : settingsPage === "player" ? "Плеер" : settingsPage === "shizuku" ? "Расширенный доступ" : settingsPage === "backup" ? "Резервная копия" : settingsPage === "anim" ? "Анимации" : "Настройки"}
            </span>
          </div>
          <div style={{ flex: 1, overflowY: "auto", padding: "8px 14px calc(20px + env(safe-area-inset-bottom))" }}>
            {settingsPage === null && (
              <>
                {[["theme", I.sun, "Тема"], ["fonts", I.rename, "Шрифты"], ["sort", I.sort, "Сортировка"], ["icons", I.folder, "Иконки папок"], ["shizuku", I.android, "Расширенный доступ"], ["backup", I.dl, "Резервная копия"], ["anim", I.sun, "Анимации"], ["player", I.audio, "Плеер"]].map(([pg, ic, lbl]) => (
                  <div key={pg} style={S.menuItem} onClick={() => setSettingsPage(pg)}>
                    <span style={{ color: ACC, display: "flex" }}><Svg d={ic} size={20} /></span>
                    <span style={{ flex: 1 }}>{lbl}</span>
                    <span style={{ color: SUB, display: "flex", transform: "rotate(180deg)" }}><Svg d={I.back} size={18} /></span>
                  </div>
                ))}
                <div style={{ color: SUB, fontSize: 11, textAlign: "center", marginTop: 18 }}>Версия {APP_VERSION}</div>
              </>
            )}
            {settingsPage === "anim" && (
              <>
                <div style={{ display: "flex", alignItems: "center", padding: "12px 2px" }} onClick={() => { const v = !animFolders; setAnimFolders(v); ls.set("fm_anim_folders_v1", v ? "1" : "0"); }}>
                  <div style={{ flex: 1 }}>
                    <div style={{ color: TXT, fontSize: 15 }}>Открытие папок</div>
                    <div style={{ color: SUB, fontSize: 12 }}>Скольжение списка при входе и выходе из папки</div>
                  </div>
                  <span style={{ ...S.tgl, ...(animFolders ? S.tglOn : {}) }}><span style={{ ...S.knob, ...(animFolders ? S.knobOn : {}) }} /></span>
                </div>
              </>
            )}
            {settingsPage === "backup" && (
              <>
                <div style={{ color: SUB, fontSize: 12.5, lineHeight: 1.5, padding: "10px 2px 14px" }}>
                  Сохраняет темы, сортировку, иконки папок, привязки открытия, порядок меню и прочие настройки в файл. Кэши и вход в аккаунты не сохраняются.
                </div>
                <div style={{ display: "flex", alignItems: "center", padding: "10px 2px" }} onClick={() => setBackupTabs((v) => !v)}>
                  <div style={{ flex: 1 }}>
                    <div style={{ color: TXT, fontSize: 15 }}>Сохранить вкладки</div>
                    <div style={{ color: SUB, fontSize: 12 }}>Открытые вкладки и стартовую папку</div>
                  </div>
                  <span style={{ ...S.tgl, ...(backupTabs ? S.tglOn : {}) }}><span style={{ ...S.knob, ...(backupTabs ? S.knobOn : {}) }} /></span>
                </div>
                <button onClick={() => exportSettings(backupTabs)}
                  style={{ width: "100%", height: 46, borderRadius: 14, border: "none", background: ACC, color: "#fff", fontSize: 15, fontWeight: 600, marginTop: 12 }}>Экспортировать</button>
                <button onClick={() => importInputRef.current && importInputRef.current.click()}
                  style={{ width: "100%", height: 46, borderRadius: 14, border: "1px solid " + LINE, background: ROW2, color: TXT, fontSize: 15, marginTop: 10 }}>Импортировать из файла</button>
                <input ref={importInputRef} type="file" accept="application/json,.json" style={{ display: "none" }}
                  onChange={(e) => { const f = e.target.files && e.target.files[0]; if (f) importSettings(f); e.target.value = ""; }} />
              </>
            )}
            {settingsPage === "shizuku" && (
              <>
                {(() => {
                  const st = (shz && shz.state) || "absent";
                  const map = {
                    old: ["Недоступно на этой версии Android", "Функция работает начиная с Android 6.0. На вашей версии менеджер работает как обычно.", SUB],
                    absent: ["Shizuku не установлен", "Нужно отдельное приложение Shizuku. Без него менеджер работает как обычно.", SUB],
                    stopped: ["Shizuku установлен, но не запущен", "Запусти Shizuku и подними службу — после перезагрузки телефона это нужно делать заново.", GOLD],
                    denied: ["Нет разрешения", "Нажми «Разрешить» и подтверди запрос в окне Shizuku.", GOLD],
                    ok: ["Работает", "Папки Android/data и Android/obb открываются как обычные.", ACC],
                  };
                  const [title, hint, col] = map[st] || map.absent;
                  return (
                    <>
                      <div style={{ display: "flex", alignItems: "center", gap: 10, padding: "12px 2px 6px" }}>
                        <span style={{ width: 10, height: 10, borderRadius: 5, background: col, flexShrink: 0 }} />
                        <span style={{ color: TXT, fontSize: 15, fontWeight: 600 }}>{title}</span>
                      </div>
                      <div style={{ color: SUB, fontSize: 12.5, lineHeight: 1.5, padding: "0 2px 12px" }}>{hint}</div>
                      {st === "denied" && (
                        <button onClick={() => { Apps.shizukuRequest().catch(() => {}); setTimeout(loadShz, 800); }}
                          style={{ width: "100%", height: 46, borderRadius: 14, border: "none", background: ACC, color: "#fff", fontSize: 15, fontWeight: 600 }}>Разрешить</button>
                      )}
                      {st === "absent" && (
                        <button onClick={() => Apps.openUrl({ url: "https://shizuku.rikka.app/" }).catch(() => {})}
                          style={{ width: "100%", height: 46, borderRadius: 14, border: "1px solid " + LINE, background: ROW2, color: TXT, fontSize: 15 }}>Открыть страницу Shizuku</button>
                      )}
                      {st === "stopped" && (
                        <button onClick={loadShz}
                          style={{ width: "100%", height: 46, borderRadius: 14, border: "1px solid " + LINE, background: ROW2, color: TXT, fontSize: 15 }}>Проверить снова</button>
                      )}
                      <div style={{ color: SUB, fontSize: 11.5, lineHeight: 1.5, marginTop: 16 }}>
                        Разрешение выдаётся один раз и не слетает. После перезагрузки телефона достаточно поднять Shizuku — менеджер подхватит это сам.
                      </div>
                    </>
                  );
                })()}
              </>
            )}
            {settingsPage === "theme" && (
              <>
                <div style={{ display: "flex", gap: 8, marginBottom: 6 }}>
                  {[["dark", "Тёмная"], ["light", "Светлая"]].map(([t, lbl]) => (
                    <button key={t} onClick={() => { setTheme(t); ls.set("fm_theme_v1", t); }}
                      style={{ flex: 1, height: 44, borderRadius: 14, fontSize: 14, fontWeight: 600, background: theme === t ? "var(--accbg)" : "transparent", border: "1px solid " + (theme === t ? ACC : LINE), color: theme === t ? ACC : TXT }}>{lbl}</button>
                  ))}
                </div>
                <div style={S.menuItem} onClick={() => { const v = !themeBtn; setThemeBtn(v); ls.set("fm_themebtn_v1", v ? "1" : "0"); }}>
                  <span style={{ color: themeBtn ? ACC : SUB, display: "flex" }}><Svg d={theme === "dark" ? I.sun : I.moon} size={20} /></span>
                  Кнопка темы в шапке
                  <span style={{ marginLeft: "auto", ...S.tgl, ...(themeBtn ? S.tglOn : {}) }}><span style={{ ...S.knob, ...(themeBtn ? S.knobOn : {}) }} /></span>
                </div>
              </>
            )}
            {settingsPage === "fonts" && (
              <>
                {allFonts.map((f) => (
                  <div key={f.id} style={{ ...S.menuItem, justifyContent: "flex-start" }}>
                    <span onClick={() => saveFonts({ ...fonts, sel: f.id })} style={{ flex: 1, display: "flex", alignItems: "center", gap: 10 }}>
                      <span style={{ width: 22, color: fonts.sel === f.id ? ACC : "transparent", display: "flex" }}><Svg d={I.check} size={18} /></span>
                      <span style={{ fontFamily: f.css, fontSize: 15 }}>{f.name}</span>
                    </span>
                    {f.id !== "sys" && <span onClick={() => removeFont(f.id)} style={{ color: RED, display: "flex", padding: 4 }}><Svg d={I.trash} size={18} /></span>}
                  </div>
                ))}
                <input ref={fontFileRef} type="file" accept=".ttf,.otf,.woff,.woff2" onChange={onFontFile} style={{ display: "none" }} />
                <div style={S.menuItem} onClick={() => fontFileRef.current && fontFileRef.current.click()}>
                  <span style={{ color: ACC, display: "flex" }}><Svg d={I.plus} size={20} /></span>
                  Добавить шрифт (TTF/OTF)
                </div>
              </>
            )}
            {settingsPage === "sort" && (
              <div style={S.menuItem} onClick={() => { const v = !sysTop; setSysTop(v); ls.set("fm_systop_v2", v ? "1" : "0"); }}>
                <span style={{ color: sysTop ? ACC : SUB, display: "flex" }}><Svg d={I.folder} size={20} /></span>
                Системные папки всегда сверху
                <span style={{ marginLeft: "auto", ...S.tgl, ...(sysTop ? S.tglOn : {}) }}><span style={{ ...S.knob, ...(sysTop ? S.knobOn : {}) }} /></span>
              </div>
            )}
            {settingsPage === "player" && (
              <>
                <div style={S.menuItem} onClick={() => { const v = !audioAuto; setAudioAuto(v); ls.set(AUTONEXTKEY, v ? "1" : "0"); Apps.audioConfig({ autoNext: v }).catch(() => {}); }}>
                  <span style={{ color: audioAuto ? ACC : SUB, display: "flex" }}><Svg d={I.next} size={20} /></span>
                  Автопереход к следующему треку
                  <span style={{ marginLeft: "auto", ...S.tgl, ...(audioAuto ? S.tglOn : {}) }}><span style={{ ...S.knob, ...(audioAuto ? S.knobOn : {}) }} /></span>
                </div>
                <div style={{ color: SUB, fontSize: 12, lineHeight: 1.5, marginTop: 10 }}>Зацикливания нет. При выключенной опции после трека воспроизведение останавливается.</div>
              </>
            )}
            {settingsPage === "icons" && (
              <>
                <div style={{ color: SUB, fontSize: 12, lineHeight: 1.5, marginBottom: 12 }}>
                  Чтобы задать иконку папке — создайте в ней папку <span style={{ color: GOLD }}>.icon</span> и положите туда PNG/ICO. Иконка сохранится сюда, а файл удалится.
                </div>
                {Object.keys(iconDB).length === 0 && <div style={{ color: SUB, padding: 16, textAlign: "center" }}>Пока нет изменённых иконок</div>}
                {Object.keys(iconDB).map((k) => (
                  <div key={k} style={{ display: "flex", alignItems: "center", gap: 12, padding: "9px 2px", borderBottom: "1px solid " + LINE }}>
                    <img src={iconDB[k]} alt="" style={{ width: 40, height: 40, borderRadius: 11, objectFit: "cover", flexShrink: 0 }} />
                    <span style={{ flex: 1, minWidth: 0 }}>
                      <span style={{ fontSize: 14, display: "block", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{baseName(k) || "Storage"}</span>
                      <span style={{ fontSize: 11, color: SUB, wordBreak: "break-all", display: "block" }}>{"Internal/" + (k || "")}</span>
                    </span>
                    <span onClick={() => { const db = { ...iconDB }; delete db[k]; saveIconDB(db); }} style={{ color: RED, display: "flex", padding: 6 }}><Svg d={I.trash} size={18} /></span>
                  </div>
                ))}
              </>
            )}
          </div>
        </div>
      )}

      {/* МЕНЮ ЗАДАЧ БУФЕРА */}
      {pasteMenu && clip && clip.length > 0 && (
        <div style={S.backdrop} onClick={() => setPasteMenu(false)}>
          <div style={S.sheet} onClick={(e) => e.stopPropagation()}>
            <div style={{ ...S.sheetTitle }}>Буфер ({clip.length})</div>
            <div style={{ maxHeight: "50vh", overflowY: "auto" }}>
              {clip.slice().reverse().map((t, idx) => (
                <div key={t.id} style={{ display: "flex", alignItems: "center", gap: 12, padding: "11px 2px", borderBottom: "1px solid " + LINE }}>
                  <span style={{ color: t.mode === "cut" ? GOLD : "#6FD3A8", display: "flex" }}><Svg d={t.mode === "cut" ? I.cut : I.copy} size={20} /></span>
                  <span style={{ flex: 1, minWidth: 0 }}>
                    <span style={{ fontSize: 14, display: "block" }}>{clip.length - idx}. {t.items.length === 1 ? t.items[0].name : t.items.length + " объектов"}</span>
                    <span style={{ fontSize: 12, color: SUB }}>{t.mode === "cut" ? "переместить" : "копировать"}{t.srcPath ? " · из " + (baseName(t.srcPath) || "Storage") : ""}</span>
                  </span>
                  <span onClick={() => dropTask(t.id)} style={{ color: SUB, display: "flex", padding: 4 }}><Svg d={I.x} size={18} /></span>
                </div>
              ))}
            </div>
            <button style={{ ...S.accessBtn, width: "100%", marginTop: 14, padding: "12px" }} onClick={pasteAll}>Всё сюда</button>
          </div>
        </div>
      )}

      {/* МЕНЮ ЗАДАЧ — конец */}
      {/* ПРОГРЕСС КОПИРОВАНИЯ */}
      {progress && !progress.bg && !conflict && (() => {
        // процент: если есть по-файловый прогресс внутри элемента — учитываем его
        const sub = progress.sub;
        const pct = progress.total ? Math.round(((progress.current + (sub && sub.total ? sub.done / sub.total : 0)) / progress.total) * 100) : 0;
        const label = progress.mode === "del" ? "Удаление" : progress.mode === "cut" ? "Перемещение" : progress.mode === "ext" ? "Распаковка" : progress.mode === "zip" ? "Архивирование" : "Копирование";
        return (
        <div style={S.backdrop}>
          <div style={{ ...S.sheet, paddingBottom: 24 }} onClick={(e) => e.stopPropagation()}>
            <div style={S.sheetTitle}>{label} {Math.min(progress.current + (sub ? 1 : 0), progress.total)}/{progress.total}{pct >= 100 && <span style={{ display: "inline-block", marginLeft: 8, color: ACC, verticalAlign: "middle", animation: "pulse .4s cubic-bezier(.2,.9,.3,1.4)" }}><Svg d={I.check} size={18} /></span>}</div>
            <div style={{ height: 8, background: ROW2, borderRadius: 4, overflow: "hidden", margin: "6px 0 12px" }}>
              <div style={{ height: "100%", width: pct + "%", background: ACC, transition: "width .2s", boxShadow: pct >= 100 ? "0 0 12px " + ACC : "none" }} />
            </div>
            <div style={{ fontSize: 13, color: SUB, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap", marginBottom: 16 }}>{sub && sub.name ? sub.name : progress.name}{sub && sub.total ? "  (" + sub.done + "/" + sub.total + ")" : ""}</div>
            <div style={{ display: "flex", gap: 10 }}>
              <button style={{ ...S.sheetGhost, flex: 1, borderColor: LINE }} onClick={() => { const pr = progress; setProgress((p) => ({ ...p, bg: true })); const lbl = pr.mode === "del" ? "Удаление" : pr.mode === "cut" ? "Перемещение" : pr.mode === "ext" ? "Распаковка" : "Копирование"; Apps.notifyProgress({ title: lbl, text: pr.name || "", progress: pr.current || 0, max: pr.total || 100 }).catch(() => {}); }}>Свернуть в уведомления</button>
              <button style={{ ...S.sheetGhost, flex: 1, color: RED, borderColor: LINE }} onClick={() => { cancelRef.current = true; }}>Отменить</button>
            </div>
          </div>
        </div>
        );
      })()}
      {progress && progress.bg && (() => {
        const sub = progress.sub;
        const pct = progress.total ? Math.round(((progress.current + (sub && sub.total ? sub.done / sub.total : 0)) / progress.total) * 100) : 0;
        const label = progress.mode === "del" ? "Удаление" : progress.mode === "cut" ? "Перемещение" : progress.mode === "ext" ? "Распаковка" : progress.mode === "zip" ? "Архивирование" : "Копирование";
        Apps.notifyProgress({ title: label, text: (sub && sub.name) || progress.name || "", progress: pct, max: 100 }).catch(() => {});
        return null; // прогресс живёт в шторке — внизу ничего не показываем
      })()}

      {toast && <div style={S.toast}>{toast}</div>}

      <style>{`
        @keyframes fm-in-r{from{transform:translateX(100%)}to{transform:translateX(0)}}
        @keyframes fm-in-l{from{transform:translateX(-100%)}to{transform:translateX(0)}}
        @keyframes dropGrow{from{opacity:0;transform:scale(.88)}to{opacity:1;transform:scale(1)}}
        @keyframes growSheet{from{opacity:0;transform:scale(.35)}to{opacity:1;transform:scale(1)}}
        @keyframes drawerIn{from{transform:translateX(-100%)}to{transform:translateX(0)}}
        @keyframes sUp{from{transform:translateY(60px);opacity:0}to{transform:translateY(0);opacity:1}}
        @keyframes fS{from{opacity:0}to{opacity:1}}
        @keyframes cbPop{0%{transform:scale(0);opacity:0}60%{transform:scale(1.25)}100%{transform:scale(1);opacity:1}}
        @keyframes pulse{0%{transform:scale(1)}40%{transform:scale(1.35)}100%{transform:scale(1)}}
        @keyframes toastUp{0%{transform:translateX(-50%) translateY(40px);opacity:0}65%{transform:translateX(-50%) translateY(-6px);opacity:1}100%{transform:translateX(-50%) translateY(0)}}
        @keyframes popCenter{from{opacity:0;transform:translateX(-50%) scale(.9)}to{opacity:1;transform:translateX(-50%) scale(1)}}
        *{box-sizing:border-box;-webkit-tap-highlight-color:transparent;-webkit-user-select:none;user-select:none}
        input{-webkit-user-select:text;user-select:text}
        body{margin:0}::-webkit-scrollbar{width:0;height:0}
        ::selection{background:var(--acc);color:#fff}input::selection,textarea::selection{background:var(--acc);color:#fff}
      `}</style>
    </div>
  );
}

const Zone = ({ children }) => <div style={{ flex: 1, display: "flex" }}>{children}</div>;
const Prop = ({ k, v, onClick, link }) => (
  <div onClick={onClick} style={{ padding: "10px 0", borderBottom: "1px solid " + LINE }}>
    <div style={{ fontSize: 12, color: SUB, marginBottom: 3 }}>{k}</div>
    <div style={{ fontSize: 14, color: link ? ACC : TXT, wordBreak: "break-all" }}>{v}</div>
  </div>
);
function SheetInput({ title, value, placeholder, onChange, onCancel, onOk, okText }) {
  return (
    <>
      <div style={S.sheetTitle}>{title}</div>
      <input autoFocus value={value} placeholder={placeholder} onChange={(e) => onChange(e.target.value)} onKeyDown={(e) => e.key === "Enter" && onOk()} style={S.sheetField} />
      <div style={{ display: "flex", gap: 10 }}>
        <button style={S.sheetGhost} onClick={onCancel}>Отмена</button>
        <button style={S.sheetOk} onClick={onOk}>{okText}</button>
      </div>
    </>
  );
}
function Btn({ onClick, icon, text, label, accent, red, flexNone, disabled }) {
  const color = disabled ? "#5c4d3e" : red ? RED : accent ? ACC : INK;
  return (
    <button onClick={disabled ? undefined : onClick} style={{ ...S.btn, flex: flexNone ? "none" : 1, minWidth: flexNone ? 52 : undefined, color }}>
      <span style={{ display: "flex", height: 28, alignItems: "center", fontSize: 22, fontWeight: 700 }}>{icon ? <Svg d={icon} size={25} /> : text}</span>
      {label ? <span style={S.btnLabel}>{label}</span> : null}
    </button>
  );
}

const S = {
  app: { position: "relative", display: "flex", flexDirection: "column", height: "100vh", background: BG, color: TXT, fontFamily: "system-ui,-apple-system,Roboto,sans-serif", overflow: "hidden" },
  tabsbar: { display: "flex", alignItems: "center", background: "var(--bar)", flexShrink: 0, height: 50, margin: "8px 8px 6px", borderRadius: 26, boxShadow: "var(--barsh)" },
  tabs: { display: "flex", overflowX: "auto", flex: 1, alignItems: "center", padding: "0 4px", height: "100%", scrollbarWidth: "none" },
  tab: { display: "flex", alignItems: "center", gap: 6, padding: "0 12px", height: 34, borderRadius: 17, fontSize: 13.5, color: SUB, whiteSpace: "nowrap", background: "var(--chip)", flexShrink: 0, border: "1px solid transparent" },
  tabActive: { color: ACC, background: "var(--accbg)", border: "1px solid " + ACC, fontWeight: 600, boxShadow: "0 0 0 1px var(--accbg), 0 2px 8px var(--accbg)" },
  tabX: { fontSize: 17, color: SUB, padding: "0 2px" },
  hbtn: { border: "none", background: "rgba(120,120,128,.16)", color: TXT, width: 34, height: 34, borderRadius: 17, flexShrink: 0, display: "flex", alignItems: "center", justifyContent: "center", padding: 0 },
  crumb: { position: "relative", zIndex: 6, height: 30, display: "flex", alignItems: "center", padding: "0 16px", fontSize: 12.5, background: "transparent", flexShrink: 0, overflow: "visible", whiteSpace: "nowrap" },
  list: { flex: 1, overflowY: "auto", overflowX: "hidden", display: "flex", flexDirection: "column" },
  slideWrap: { display: "flex", flexDirection: "column" },
  note: { color: SUB, textAlign: "center", padding: "60px 24px", lineHeight: 1.6 },
  row: { display: "flex", alignItems: "center", gap: 14, padding: "10px 14px", touchAction: "pan-y", position: "relative", contentVisibility: "auto", containIntrinsicSize: "0 68px" },
  rowLine: { position: "absolute", left: 72, right: 0, bottom: 0, height: 1, background: "var(--hair)" },
  sep: { height: 1, background: "var(--hair)", margin: "4px 0" },
  iconWrap: { width: 44, height: 44, borderRadius: 13, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 },
  iconImg: { width: "100%", height: "100%", objectFit: "cover", borderRadius: 13 },
  folderThumb: { position: "absolute", right: 1, bottom: 1, width: 26, height: 26, borderRadius: 7, objectFit: "cover", border: "2px solid " + BG, opacity: 0.7 },
  cbk: { width: 22, height: 22, borderRadius: 6, background: ACC, color: "#fff", display: "flex", alignItems: "center", justifyContent: "center", animation: "cbPop .26s cubic-bezier(.2,.9,.3,1.3)" },
  cbkOff: { width: 22, height: 22, borderRadius: 6, border: "2px solid " + ACC, background: "transparent" },
  rowMid: { flex: 1, minWidth: 0, display: "flex", flexDirection: "column", gap: 3 },
  rowDate: { fontSize: 12, color: SUB },
  rowSize: { fontSize: 11.5, color: "rgba(176,164,152,.5)", flexShrink: 0, marginLeft: 6 },
  rowDir: { background: "var(--chip)", borderRadius: 14, marginBottom: 6, boxShadow: "0 1px 3px rgba(0,0,0,.12)" },
  arcSelBar: { position: "absolute", left: "50%", transform: "translateX(-50%)", bottom: "calc(80px + env(safe-area-inset-bottom))", display: "flex", alignItems: "center", gap: 8, padding: "6px 8px 6px 14px", background: BAR, borderRadius: 22, boxShadow: "0 1px 0 rgba(255,255,255,.07) inset, 0 4px 12px rgba(0,0,0,.4), 0 18px 48px rgba(0,0,0,.62)", animation: "popCenter .2s cubic-bezier(.2,.9,.3,1.1)" },
  arcSelCancel: { background: "transparent", border: "none", borderRadius: 14, color: SUB, fontSize: 13, padding: "7px 12px" },
  arcSelGo: { display: "inline-flex", alignItems: "center", gap: 5, background: ACC, border: "none", borderRadius: 14, color: "#fff", fontWeight: 700, fontSize: 13, padding: "7px 14px" },
  arcScreen: { position: "fixed", top: 62, left: 0, right: 0, bottom: 0, zIndex: 55, background: BG, display: "flex", flexDirection: "column" },
  settingsScreen: { position: "fixed", inset: 0, zIndex: 1600, background: BG, display: "flex", flexDirection: "column", paddingTop: "env(safe-area-inset-top)" },
  cnt: { background: "var(--accbg)", color: GOLD, fontSize: 12, fontWeight: 700, padding: "2px 9px", borderRadius: 10, flexShrink: 0 },
  rowSel: { background: "var(--accbg)" },
  name: { flex: 1, fontSize: 15, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" },
  checkOn: { width: 26, height: 26, borderRadius: 13, background: ACC, color: "#fff", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 15 },
  searchBar: { display: "flex", alignItems: "center", background: ROW2, padding: 8, gap: 8, flexShrink: 0 },
  searchInput: { flex: 1, padding: "10px 12px", borderRadius: 8, border: "1px solid " + LINE, background: BAR, color: TXT, fontSize: 15, outline: "none" },
  searchClose: { border: "none", background: "transparent", color: SUB, fontSize: 24, width: 40 },
  bottom: { display: "flex", alignItems: "center", background: "var(--bar)", flexShrink: 0, borderRadius: 30, margin: "4px 8px calc(8px + env(safe-area-inset-bottom))", boxShadow: "var(--barsh)" },
  btn: { border: "none", background: "transparent", padding: "6px 6px 7px", display: "flex", flexDirection: "column", alignItems: "center", gap: 2 },
  selCount: { width: 26, height: 26, borderRadius: 13, background: ACC, display: "inline-flex", alignItems: "center", justifyContent: "center", flexShrink: 0, lineHeight: 0, boxShadow: "0 1px 3px rgba(0,0,0,.3), inset 0 1px 0 rgba(255,255,255,.25)" },
  btnLabel: { fontSize: 10, color: SUB, whiteSpace: "nowrap" },
  overlay: { position: "fixed", inset: 0, zIndex: 8 },
  menu: { position: "absolute", zIndex: 9, background: BAR, borderRadius: 14, overflow: "hidden", boxShadow: "var(--barsh)", minWidth: 200, animation: "dropGrow .2s cubic-bezier(.2,.9,.3,1.2)" },
  menuItem: { display: "flex", alignItems: "center", gap: 12, padding: "13px 14px", fontSize: 14, color: TXT, whiteSpace: "nowrap" },
  createItem: { padding: "14px 22px", fontSize: 15, color: TXT },
  ctxTitle: { padding: "10px 14px", fontSize: 12, color: SUB, borderBottom: "1px solid " + LINE, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap", maxWidth: 210 },
  tgl: { width: 38, height: 22, borderRadius: 11, background: "var(--tgloff)", position: "relative", flexShrink: 0, transition: "background .15s" },
  tglOn: { background: ACC },
  knob: { position: "absolute", top: 2, left: 2, width: 18, height: 18, borderRadius: 9, background: "#fff", transition: "left .15s" },
  knobOn: { left: 18 },
  backdrop: { position: "fixed", inset: 0, background: "rgba(0,0,0,.62)", display: "flex", alignItems: "flex-end", zIndex: 1400, backdropFilter: "blur(5px)", animation: "fS .2s ease" },
  sheet: { width: "100%", maxWidth: 420, margin: "0 auto", background: BAR, borderRadius: "22px 22px 0 0", padding: "20px 20px 36px", animation: "sUp .34s cubic-bezier(.2,.9,.3,1)", maxHeight: "88vh", overflowY: "auto", boxShadow: "0 -8px 30px rgba(0,0,0,.22), 0 -2px 8px rgba(0,0,0,.12)" },
  sheetTitle: { fontWeight: 700, fontSize: 17, marginBottom: 16 },
  sheetField: { width: "100%", background: ROW2, border: "1px solid " + LINE, borderRadius: 12, padding: "12px 14px", color: TXT, fontSize: 15, marginBottom: 16, outline: "none" },
  sheetGhost: { flex: 1, background: ROW2, border: "1px solid " + LINE, borderRadius: 12, padding: 13, color: SUB, fontSize: 14, cursor: "pointer" },
  sheetOk: { flex: 1, background: ACC, border: "none", borderRadius: 12, padding: 13, color: "#fff", fontSize: 14, fontWeight: 700, cursor: "pointer" },
  savePop: { position: "fixed", top: "calc(68px + env(safe-area-inset-top))", left: 10, right: 10, zIndex: 1260, display: "flex", alignItems: "center", gap: 10, padding: "12px 16px", background: BAR, color: TXT, borderRadius: 18, boxShadow: "var(--barsh)", animation: "dropGrow .22s cubic-bezier(.2,.9,.3,1.1)" },
  saveBar: { position: "fixed", left: 8, right: 8, bottom: "calc(8px + env(safe-area-inset-bottom))", zIndex: 1260, display: "flex", alignItems: "center", gap: 8, height: 56, padding: "0 10px", background: BAR, borderRadius: 26, boxShadow: "0 1px 0 rgba(255,255,255,.07) inset, 0 4px 12px rgba(0,0,0,.4), 0 18px 48px rgba(0,0,0,.62)", animation: "sUp .28s cubic-bezier(.2,.9,.3,1)" },
  saveBtnOpen: { flex: 1, display: "inline-flex", alignItems: "center", justifyContent: "center", gap: 6, height: 42, background: "transparent", border: "1px solid " + LINE, borderRadius: 16, color: TXT, fontWeight: 600, fontSize: 14 },
  saveBtnSave: { flex: 1, display: "inline-flex", alignItems: "center", justifyContent: "center", gap: 6, height: 42, background: "var(--accbg)", border: "1px solid " + ACC, borderRadius: 16, color: ACC, fontWeight: 600, fontSize: 14 },
  saveBtnCancel: { flex: 1, display: "inline-flex", alignItems: "center", justifyContent: "center", gap: 6, height: 42, background: "transparent", border: "1px solid " + LINE, borderRadius: 16, color: SUB, fontWeight: 600, fontSize: 14 },
  accessBar: { display: "flex", alignItems: "center", gap: 10, padding: "10px 14px", background: "var(--accbg)", borderBottom: "1px solid " + LINE },
  accessBtn: { flexShrink: 0, background: ACC, border: "none", borderRadius: 8, color: "#fff", fontSize: 13, fontWeight: 700, padding: "8px 14px" },
  sortRow: { padding: "13px 4px", fontSize: 15, color: TXT, borderBottom: "1px solid " + LINE, display: "flex", alignItems: "center" },
  iconBtn: { border: "none", background: "rgba(120,120,128,.16)", borderRadius: 12, width: 38, height: 38, display: "flex", alignItems: "center", justifyContent: "center" },
  chip: { flexShrink: 0, background: "rgba(120,120,128,.12)", border: "1px solid transparent", borderRadius: 15, padding: "7px 14px", color: SUB, fontSize: 13, whiteSpace: "nowrap" },
  chipOn: { background: ACC, borderColor: ACC, color: "#fff" },
  appRow: { display: "flex", alignItems: "center", gap: 14, padding: "10px 2px", borderBottom: "1px solid " + LINE },
  cbox: { width: 22, height: 22, borderRadius: 6, border: "2px solid " + SUB, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 13, color: "#fff", flexShrink: 0 },
  cboxOn: { background: ACC, borderColor: ACC },
  toast: { position: "fixed", left: "50%", bottom: 90, transform: "translateX(-50%)", pointerEvents: "none", background: "var(--bar)", color: TXT, padding: "10px 18px", borderRadius: 20, fontSize: 13, boxShadow: "var(--barsh)", zIndex: 1500, animation: "toastUp .34s cubic-bezier(.2,.9,.3,1)", maxWidth: "80%", textAlign: "center" },
};
