package leshugan.fm;

import java.util.Calendar;
import java.util.Locale;

/** Даты и размеры — теми же словами и с той же точностью, что в веб-части. */
public final class YevFmt {

    /** «только что», «5 минут назад», «3 часа назад», иначе дата и время. */
    public static String date(long ms) {
        if (ms <= 0) return null;
        long now = System.currentTimeMillis();
        long diff = now - ms;
        if (diff < 0) diff = 0;
        long min = diff / 60000;
        if (min < 1) return "только что";
        if (min < 60) return min + " " + plural(min, "минуту", "минуты", "минут") + " назад";
        Calendar c = Calendar.getInstance();
        c.setTimeInMillis(ms);
        Calendar today = Calendar.getInstance();
        boolean sameDay = c.get(Calendar.YEAR) == today.get(Calendar.YEAR)
                && c.get(Calendar.DAY_OF_YEAR) == today.get(Calendar.DAY_OF_YEAR);
        if (sameDay) { long h = min / 60; return h + " " + plural(h, "час", "часа", "часов") + " назад"; }
        return String.format(Locale.US, "%02d.%02d.%d %02d:%02d",
                c.get(Calendar.DAY_OF_MONTH), c.get(Calendar.MONTH) + 1, c.get(Calendar.YEAR),
                c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE));
    }

    /** «8.9 МБ», «906 Б» — как в веб-части: одна цифра после точки от килобайта. */
    public static String size(long b) {
        if (b < 0) return null;
        if (b < 1024) return b + " Б";
        double kb = b / 1024.0;
        if (kb < 1024) return trim(kb) + " КБ";
        double mb = kb / 1024.0;
        if (mb < 1024) return trim(mb) + " МБ";
        double gb = mb / 1024.0;
        if (gb < 1024) return trim(gb) + " ГБ";
        return trim(gb / 1024.0) + " ТБ";
    }

    private static String trim(double v) {
        String s = String.format(Locale.US, "%.1f", v);
        return s;
    }

    public static String plural(long n, String one, String few, String many) {
        long n10 = n % 10, n100 = n % 100;
        if (n10 == 1 && n100 != 11) return one;
        if (n10 >= 2 && n10 <= 4 && (n100 < 12 || n100 > 14)) return few;
        return many;
    }
}
