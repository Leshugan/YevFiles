package leshugan.fm;

import android.util.Base64;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.crypto.Cipher;
import javax.crypto.Mac;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.SecretKeySpec;

/**
 * Хранилище gocryptfs (формат v2: GCMIV128 + HKDF + DirIV + EMENames + LongNames + Raw64).
 * Совместимо с настоящим gocryptfs: имена — EME-AES с IV папки, содержимое — AES-256-GCM блоками по 4096 байт,
 * мастер-ключ — под паролем через scrypt + AES-GCM. Проверено на эталонном хранилище из тестов gocryptfs.
 */
public final class Gocryptfs {
    public static final String CONF = "gocryptfs.conf";
    public static final String DIRIV = "gocryptfs.diriv";
    private static final String LONG_PREFIX = "gocryptfs.longname.";
    private static final int BS = 4096;                 // блок открытых данных
    private static final int NONCE = 16;                // GCMIV128
    private static final int TAG = 16;
    private static final int CBS = NONCE + BS + TAG;    // блок шифротекста: 4128
    private static final int HEADER = 2 + 16;           // версия + случайный id файла

    public static final class WrongPassword extends Exception { public WrongPassword() { super("Неверный пароль"); } }

    public interface Progress { void bytes(long delta); }

    public static final class Entry {
        public String plain;   // имя открытым текстом (только последний компонент)
        public String cName;   // имя на диске
        public boolean dir;
        public long size;      // размер открытых данных
        public long mtime;
    }

    private final File root;
    private final byte[] gcmKey, emeKey;
    private final boolean emeNames, longNames, raw64;
    private final SecureRandom rnd = new SecureRandom();

    private Gocryptfs(File root, byte[] master, boolean emeNames, boolean longNames, boolean raw64) throws Exception {
        this.root = root;
        this.gcmKey = hkdf(master, "AES-GCM file content encryption", 32);
        this.emeKey = hkdf(master, "EME filename encryption", 32);
        this.emeNames = emeNames; this.longNames = longNames; this.raw64 = raw64;
    }

    public File root() { return root; }

    public static boolean isVault(File dir) {
        return dir != null && dir.isDirectory() && new File(dir, CONF).isFile();
    }

    // ---------------- ключ ----------------

    public static Gocryptfs open(File dir, String password) throws Exception {
        if (password == null) password = "";
        JSONObject cf = new JSONObject(readText(new File(dir, CONF)));
        if (cf.optInt("Version", 0) != 2) throw new Exception("Формат хранилища не поддерживается (версия " + cf.optInt("Version", 0) + ")");
        List<String> flags = new ArrayList<>();
        JSONArray fa = cf.optJSONArray("FeatureFlags");
        if (fa != null) for (int i = 0; i < fa.length(); i++) flags.add(fa.getString(i));
        if (!flags.contains("GCMIV128") || !flags.contains("HKDF") || !flags.contains("DirIV")) throw new Exception("Старый формат gocryptfs не поддерживается");
        if (flags.contains("AESSIV") || flags.contains("XChaCha20Poly1305")) throw new Exception("Режим шифрования этого хранилища не поддерживается");
        JSONObject so = cf.getJSONObject("ScryptObject");
        byte[] salt = Base64.decode(so.getString("Salt"), Base64.DEFAULT);
        byte[] scryptHash = com.lambdaworks.crypto.SCrypt.scrypt(password.getBytes(StandardCharsets.UTF_8), salt,
                so.getInt("N"), so.getInt("R"), so.getInt("P"), so.optInt("KeyLen", 32));
        byte[] ek = Base64.decode(cf.getString("EncryptedKey"), Base64.DEFAULT);
        byte[] kek = hkdf(scryptHash, "AES-GCM file content encryption", 32);
        byte[] master;
        try { master = gcmOpen(kek, Arrays.copyOfRange(ek, 0, NONCE), Arrays.copyOfRange(ek, NONCE, ek.length), longBE(0)); }
        catch (javax.crypto.AEADBadTagException bt) { throw new WrongPassword(); }
        Arrays.fill(scryptHash, (byte) 0);
        return new Gocryptfs(dir, master, flags.contains("EMENames"), flags.contains("LongNames"), flags.contains("Raw64"));
    }

    /** Новое хранилище: папка, gocryptfs.conf и gocryptfs.diriv корня. */
    public static void create(File dir, String password) throws Exception {
        if (!dir.isDirectory() && !dir.mkdirs()) throw new Exception("Не удалось создать папку");
        if (new File(dir, CONF).exists()) throw new Exception("Здесь уже есть хранилище");
        SecureRandom r = new SecureRandom();
        byte[] master = new byte[32]; r.nextBytes(master);
        byte[] salt = new byte[32]; r.nextBytes(salt);
        int N = 1 << 16, R = 8, P = 1;
        byte[] scryptHash = com.lambdaworks.crypto.SCrypt.scrypt(password.getBytes(StandardCharsets.UTF_8), salt, N, R, P, 32);
        byte[] kek = hkdf(scryptHash, "AES-GCM file content encryption", 32);
        byte[] nonce = new byte[NONCE]; r.nextBytes(nonce);
        byte[] ct = gcmSeal(kek, nonce, master, longBE(0));
        byte[] ek = new byte[NONCE + ct.length];
        System.arraycopy(nonce, 0, ek, 0, NONCE); System.arraycopy(ct, 0, ek, NONCE, ct.length);
        JSONObject cf = new JSONObject();
        cf.put("Creator", "YevFiles (gocryptfs v2 format)");
        cf.put("EncryptedKey", Base64.encodeToString(ek, Base64.NO_WRAP));
        JSONObject so = new JSONObject();
        so.put("Salt", Base64.encodeToString(salt, Base64.NO_WRAP)); so.put("N", N); so.put("R", R); so.put("P", P); so.put("KeyLen", 32);
        cf.put("ScryptObject", so);
        cf.put("Version", 2);
        JSONArray flags = new JSONArray();
        for (String f : new String[]{ "GCMIV128", "DirIV", "EMENames", "LongNames", "Raw64", "HKDF" }) flags.put(f);
        cf.put("FeatureFlags", flags);
        writeText(new File(dir, CONF), cf.toString(2) + "\n");
        byte[] iv = new byte[16]; r.nextBytes(iv);
        writeBytes(new File(dir, DIRIV), iv);
        Arrays.fill(master, (byte) 0); Arrays.fill(scryptHash, (byte) 0);
    }

    // ---------------- имена ----------------

    private byte[] dirIV(File cdir) throws Exception {
        File f = new File(cdir, DIRIV);
        if (!f.isFile()) throw new Exception("В папке хранилища нет " + DIRIV);
        byte[] iv = readBytes(f);
        if (iv.length != 16) throw new Exception("Повреждён " + DIRIV);
        return iv;
    }

    private String b64e(byte[] b) { return Base64.encodeToString(b, Base64.URL_SAFE | Base64.NO_WRAP | (raw64 ? Base64.NO_PADDING : 0)); }
    private byte[] b64d(String s) { return Base64.decode(s, Base64.URL_SAFE | Base64.NO_WRAP | Base64.NO_PADDING); }

    /** Имя на диске для открытого имени в данной шифрованной папке (без учёта длинных имён). */
    private String encNameRaw(String plain, byte[] iv) throws Exception {
        if (!emeNames) return plain;
        byte[] p = plain.getBytes(StandardCharsets.UTF_8);
        return b64e(eme(emeKey, iv, pad16(p), true));
    }

    private String decNameRaw(String cName, byte[] iv) throws Exception {
        if (!emeNames) return cName;
        byte[] c = b64d(cName);
        if (c.length < 16 || c.length % 16 != 0) throw new Exception("bad name");
        byte[] p = unpad16(eme(emeKey, iv, c, false));
        String s = new String(p, StandardCharsets.UTF_8);
        if (s.isEmpty() || s.contains("/") || s.indexOf('\0') >= 0) throw new Exception("bad name");
        return s;
    }

    private static String hashLongName(String cName) throws Exception {
        byte[] h = MessageDigest.getInstance("SHA-256").digest(cName.getBytes(StandardCharsets.UTF_8));
        return LONG_PREFIX + Base64.encodeToString(h, Base64.URL_SAFE | Base64.NO_WRAP | Base64.NO_PADDING);
    }

    /** Имя на диске для открытого имени: длинные имена превращаются в gocryptfs.longname.<hash> (+ .name с полным именем при создании). */
    private String cNameFor(File cdir, String plain, byte[] iv, boolean createLong) throws Exception {
        String c = encNameRaw(plain, iv);
        if (longNames && c.length() > 255) {
            String h = hashLongName(c);
            if (createLong) {
                File nf = new File(cdir, h + ".name");
                if (!nf.exists()) writeText(nf, c);
            }
            return h;
        }
        return c;
    }

    /** Открытое имя для записи на диске (или null, если это служебный файл / не наше). */
    private String plainFor(File cdir, String cName, byte[] iv) {
        try {
            if (cName.equals(CONF) || cName.equals(DIRIV)) return null;
            if (cName.startsWith(LONG_PREFIX)) {
                if (cName.endsWith(".name")) return null;
                String full = readText(new File(cdir, cName + ".name")).trim();
                return decNameRaw(full, iv);
            }
            return decNameRaw(cName, iv);
        } catch (Throwable t) { return null; }
    }

    /** Список одной шифрованной папки. */
    public List<Entry> list(File cdir) throws Exception {
        byte[] iv = dirIV(cdir);
        File[] ks = cdir.listFiles();
        List<Entry> out = new ArrayList<>();
        if (ks == null) return out;
        for (File k : ks) {
            String pl = plainFor(cdir, k.getName(), iv);
            if (pl == null) continue;
            Entry e = new Entry();
            e.plain = pl; e.cName = k.getName(); e.dir = k.isDirectory(); e.mtime = k.lastModified();
            e.size = e.dir ? 0 : plainSize(k.length());
            out.add(e);
        }
        return out;
    }

    /** Шифрованный путь для открытого относительного пути ("a/b/c.txt"); create — создавать папки по дороге. */
    public File cPath(String plainRel, boolean create) throws Exception {
        File cur = root;
        if (plainRel == null) return cur;
        String[] parts = plainRel.split("/");
        for (int i = 0; i < parts.length; i++) {
            String p = parts[i];
            if (p.isEmpty() || p.equals(".")) continue;
            if (p.equals("..")) throw new Exception("bad path");
            byte[] iv = dirIV(cur);
            String c = cNameFor(cur, p, iv, create);
            File next = new File(cur, c);
            if (i < parts.length - 1 && create && !next.exists()) mkdirC(next);
            cur = next;
        }
        return cur;
    }

    /** Создать шифрованную папку с её собственным IV. */
    private void mkdirC(File cdir) throws Exception {
        if (!cdir.isDirectory() && !cdir.mkdirs()) throw new Exception("Не удалось создать папку");
        File ivf = new File(cdir, DIRIV);
        if (!ivf.exists()) { byte[] iv = new byte[16]; rnd.nextBytes(iv); writeBytes(ivf, iv); }
    }

    public void mkdir(String plainRel) throws Exception { mkdirC(cPath(plainRel, true)); }

    // ---------------- содержимое ----------------

    public static long plainSize(long cSize) {
        if (cSize <= HEADER) return 0;
        long body = cSize - HEADER;
        long blocks = (body + CBS - 1) / CBS;
        return Math.max(0, body - blocks * (NONCE + TAG));
    }

    public void decryptFile(File cFile, File out, Progress pr) throws Exception {
        File pd = out.getParentFile(); if (pd != null) pd.mkdirs();
        InputStream in = new FileInputStream(cFile);
        OutputStream os = new FileOutputStream(out);
        try {
            byte[] hdr = new byte[HEADER];
            int got = readFully(in, hdr, HEADER);
            if (got == 0) return;                         // пустой файл
            if (got < HEADER) throw new Exception("Повреждён заголовок файла");
            if (((hdr[0] & 0xFF) << 8 | (hdr[1] & 0xFF)) != 2) throw new Exception("Неизвестная версия файла");
            byte[] fid = Arrays.copyOfRange(hdr, 2, HEADER);
            byte[] blk = new byte[CBS];
            long bn = 0;
            while (true) {
                int n = readFully(in, blk, CBS);
                if (n == 0) break;
                if (n < NONCE + TAG + 1) throw new Exception("Повреждён блок данных");
                byte[] nonce = Arrays.copyOfRange(blk, 0, NONCE);
                byte[] ct = Arrays.copyOfRange(blk, NONCE, n);
                byte[] pt = gcmOpen(gcmKey, nonce, ct, aad(bn, fid));
                os.write(pt);
                if (pr != null) pr.bytes(pt.length);
                bn++;
                if (n < CBS) break;
            }
        } finally { try { in.close(); } catch (Exception ignored) {} try { os.close(); } catch (Exception ignored) {} }
    }

    public void encryptFile(File in, File cFile, Progress pr) throws Exception {
        File pd = cFile.getParentFile(); if (pd != null) pd.mkdirs();
        InputStream is = new FileInputStream(in);
        OutputStream os = new FileOutputStream(cFile);
        try {
            if (in.length() == 0) return;                 // пустой файл — пустой и на диске
            byte[] fid = new byte[16]; rnd.nextBytes(fid);
            os.write(new byte[]{ 0, 2 }); os.write(fid);
            byte[] buf = new byte[BS];
            long bn = 0;
            while (true) {
                int n = readFully(is, buf, BS);
                if (n == 0) break;
                byte[] nonce = new byte[NONCE]; rnd.nextBytes(nonce);
                byte[] ct = gcmSeal(gcmKey, nonce, n == BS ? buf : Arrays.copyOf(buf, n), aad(bn, fid));
                os.write(nonce); os.write(ct);
                if (pr != null) pr.bytes(n);
                bn++;
                if (n < BS) break;
            }
        } finally { try { is.close(); } catch (Exception ignored) {} try { os.close(); } catch (Exception ignored) {} }
    }

    private static byte[] aad(long bn, byte[] fid) {
        byte[] a = new byte[8 + 16];
        System.arraycopy(longBE(bn), 0, a, 0, 8);
        System.arraycopy(fid, 0, a, 8, 16);
        return a;
    }

    // ---------------- примитивы ----------------

    private static byte[] longBE(long v) {
        byte[] b = new byte[8];
        for (int i = 7; i >= 0; i--) { b[i] = (byte) (v & 0xFF); v >>>= 8; }
        return b;
    }

    private static byte[] hkdf(byte[] key, String info, int len) throws Exception {
        Mac mac = Mac.getInstance("HmacSHA256");
        mac.init(new SecretKeySpec(new byte[32], "HmacSHA256"));      // соль пустая → нули длины хеша
        byte[] prk = mac.doFinal(key);
        Mac m2 = Mac.getInstance("HmacSHA256");
        m2.init(new SecretKeySpec(prk, "HmacSHA256"));
        byte[] out = new byte[len]; byte[] t = new byte[0]; int pos = 0; int i = 1;
        byte[] inf = info.getBytes(StandardCharsets.UTF_8);
        while (pos < len) {
            m2.reset(); m2.update(t); m2.update(inf); m2.update((byte) i);
            t = m2.doFinal();
            int n = Math.min(t.length, len - pos);
            System.arraycopy(t, 0, out, pos, n); pos += n; i++;
        }
        return out;
    }

    private static byte[] gcmSeal(byte[] key, byte[] nonce, byte[] pt, byte[] aadB) throws Exception {
        Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
        c.init(Cipher.ENCRYPT_MODE, new SecretKeySpec(key, "AES"), new GCMParameterSpec(TAG * 8, nonce));
        if (aadB != null) c.updateAAD(aadB);
        return c.doFinal(pt);
    }

    private static byte[] gcmOpen(byte[] key, byte[] nonce, byte[] ct, byte[] aadB) throws Exception {
        Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
        c.init(Cipher.DECRYPT_MODE, new SecretKeySpec(key, "AES"), new GCMParameterSpec(TAG * 8, nonce));
        if (aadB != null) c.updateAAD(aadB);
        return c.doFinal(ct);
    }

    private static byte[] pad16(byte[] o) {
        int padLen = 16 - (o.length % 16);
        if (padLen == 0) padLen = 16;
        byte[] p = Arrays.copyOf(o, o.length + padLen);
        for (int i = o.length; i < p.length; i++) p[i] = (byte) padLen;
        return p;
    }

    private static byte[] unpad16(byte[] p) throws Exception {
        if (p.length == 0 || p.length % 16 != 0) throw new Exception("bad pad");
        int n = p[p.length - 1] & 0xFF;
        if (n < 1 || n > 16 || n > p.length) throw new Exception("bad pad");
        for (int i = p.length - n; i < p.length; i++) if ((p[i] & 0xFF) != n) throw new Exception("bad pad");
        return Arrays.copyOf(p, p.length - n);
    }

    /** EME (ECB-Mix-ECB) — широкоблочное шифрование имени, как в библиотеке rfjakob/eme. */
    private static byte[] eme(byte[] key, byte[] tweak, byte[] data, boolean enc) throws Exception {
        if (data.length == 0 || data.length % 16 != 0 || data.length > 16 * 128) throw new Exception("eme: bad length");
        Cipher ecbE = Cipher.getInstance("AES/ECB/NoPadding");
        ecbE.init(Cipher.ENCRYPT_MODE, new SecretKeySpec(key, "AES"));
        Cipher ecbD = Cipher.getInstance("AES/ECB/NoPadding");
        ecbD.init(Cipher.DECRYPT_MODE, new SecretKeySpec(key, "AES"));
        Cipher bc = enc ? ecbE : ecbD;
        int m = data.length / 16;
        // таблица L: L_i = 2^(i+1) * E_K(0)
        byte[][] L = new byte[m][];
        byte[] Li = ecbE.doFinal(new byte[16]);
        for (int i = 0; i < m; i++) { Li = mul2(Li); L[i] = Li; }
        byte[][] C = new byte[m][];
        for (int j = 0; j < m; j++) C[j] = bc.doFinal(xor(Arrays.copyOfRange(data, j * 16, j * 16 + 16), L[j]));
        byte[] MP = xor(C[0], tweak);
        for (int j = 1; j < m; j++) MP = xor(MP, C[j]);
        byte[] MC = bc.doFinal(MP);
        byte[] M = xor(MP, MC);
        for (int j = 1; j < m; j++) { M = mul2(M); C[j] = xor(C[j], M); }
        byte[] CCC1 = xor(MC, tweak);
        for (int j = 1; j < m; j++) CCC1 = xor(CCC1, C[j]);
        C[0] = CCC1;
        byte[] out = new byte[data.length];
        for (int j = 0; j < m; j++) {
            byte[] r = xor(bc.doFinal(C[j]), L[j]);
            System.arraycopy(r, 0, out, j * 16, 16);
        }
        return out;
    }

    private static byte[] mul2(byte[] in) {
        byte[] out = new byte[16];
        out[0] = (byte) ((in[0] & 0xFF) << 1);
        if ((in[15] & 0xFF) >= 128) out[0] ^= (byte) 0x87;
        for (int j = 1; j < 16; j++) {
            int v = ((in[j] & 0xFF) << 1) & 0xFF;
            if ((in[j - 1] & 0xFF) >= 128) v += 1;
            out[j] = (byte) v;
        }
        return out;
    }

    private static byte[] xor(byte[] a, byte[] b) {
        byte[] o = new byte[a.length];
        for (int i = 0; i < a.length; i++) o[i] = (byte) (a[i] ^ b[i]);
        return o;
    }

    private static int readFully(InputStream in, byte[] buf, int want) throws Exception {
        int got = 0;
        while (got < want) { int r = in.read(buf, got, want - got); if (r < 0) break; got += r; }
        return got;
    }

    private static String readText(File f) throws Exception { return new String(readBytes(f), StandardCharsets.UTF_8); }

    private static byte[] readBytes(File f) throws Exception {
        InputStream in = new FileInputStream(f);
        try {
            java.io.ByteArrayOutputStream bo = new java.io.ByteArrayOutputStream();
            byte[] b = new byte[8192]; int r;
            while ((r = in.read(b)) > 0) bo.write(b, 0, r);
            return bo.toByteArray();
        } finally { in.close(); }
    }

    private static void writeText(File f, String s) throws Exception { writeBytes(f, s.getBytes(StandardCharsets.UTF_8)); }

    private static void writeBytes(File f, byte[] b) throws Exception {
        OutputStream os = new FileOutputStream(f);
        try { os.write(b); } finally { os.close(); }
    }
}
