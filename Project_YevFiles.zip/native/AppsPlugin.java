package leshugan.fm;

import android.content.Intent;
import android.content.IntentFilter;
import android.content.Context;
import android.content.BroadcastReceiver;
import android.content.pm.PackageManager;
import android.content.pm.PackageInfo;
import android.content.pm.PackageInstaller;
import android.content.pm.ResolveInfo;
import android.os.FileObserver;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.IntentSender;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.view.Window;
import android.view.View;
import android.graphics.Color;
import android.os.Build;
import android.os.StrictMode;
import android.os.Environment;
import android.provider.Settings;
import android.util.Base64;

import androidx.core.content.FileProvider;


import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import com.getcapacitor.annotation.ActivityCallback;
import androidx.activity.result.ActivityResult;
import androidx.documentfile.provider.DocumentFile;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Enumeration;
import java.util.zip.ZipFile;
import java.util.zip.ZipEntry;
import java.io.OutputStream;
import java.util.List;

@CapacitorPlugin(name = "Apps")
public class AppsPlugin extends Plugin {

    private FileObserver observer;
    private boolean instRegistered = false;

    // ---- Уведомление системы о появившихся/изменившихся файлах ----
    // Без этого скопированное или скачанное фото не видно в галерее до переиндексации
    @PluginMethod
    public void scanMedia(PluginCall call) {
        JSArray a = call.getArray("paths");
        final java.util.List<String> list = new java.util.ArrayList<>();
        try {
            if (a != null) for (Object o : a.toList()) { String v = String.valueOf(o); if (v != null && v.length() > 0) list.add(toFile(v).getAbsolutePath()); }
        } catch (Exception ignored) {}
        String one = call.getString("path");
        if (one != null) { try { list.add(toFile(one).getAbsolutePath()); } catch (Exception ignored) {} }
        call.resolve();
        if (list.isEmpty()) return;
        try {
            android.media.MediaScannerConnection.scanFile(getContext(), list.toArray(new String[0]), null, null);
        } catch (Throwable ignored) {}
    }

    // ---- Слежение за изменениями снаружи приложения ----
    private android.database.ContentObserver mediaObserver;

    @PluginMethod
    public void watchMedia(PluginCall call) {
        try {
            if (mediaObserver == null) {
                android.os.Handler h = new android.os.Handler(android.os.Looper.getMainLooper());
                mediaObserver = new android.database.ContentObserver(h) {
                    private long last = 0;
                    @Override public void onChange(boolean self) {
                        long now = System.currentTimeMillis();
                        if (now - last < 1500) return; // дебаунс: система шлёт события пачками
                        last = now;
                        notifyListeners("mediaChanged", new JSObject());
                    }
                };
                android.content.ContentResolver cr = getContext().getContentResolver();
                cr.registerContentObserver(android.provider.MediaStore.Files.getContentUri("external"), true, mediaObserver);
                cr.registerContentObserver(android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI, true, mediaObserver);
                cr.registerContentObserver(android.provider.MediaStore.Video.Media.EXTERNAL_CONTENT_URI, true, mediaObserver);
            }
            call.resolve();
        } catch (Throwable t) { call.resolve(); }
    }

    // ---- Фоновая подготовка превью ----
    private java.util.concurrent.ExecutorService warmPool;

    @PluginMethod
    public void warmThumbs(PluginCall call) {
        JSArray a = call.getArray("uris");
        final java.util.List<String> uris = new java.util.ArrayList<>();
        if (a != null) { try { for (Object o : a.toList()) uris.add(String.valueOf(o)); } catch (Exception ignored) {} }
        call.resolve();
        if (warmPool != null) warmPool.shutdownNow(); // прошлая пачка больше не актуальна
        if (uris.isEmpty()) return;
        int cores = Runtime.getRuntime().availableProcessors();
        int n = Math.max(1, Math.min(4, cores - 2));
        warmPool = java.util.concurrent.Executors.newFixedThreadPool(n);
        for (final String u : uris) {
            warmPool.execute(new Runnable() {
                @Override public void run() {
                    if (Thread.currentThread().isInterrupted()) return;
                    try { warmOne(u); } catch (Throwable ignored) {}
                }
            });
        }
        warmPool.shutdown();
    }

    // Кадр из видео для превью: пробуем несколько моментов и берём не-чёрный,
    // иначе у роликов с тёмным началом превью выходит чёрным
    private Bitmap videoFrame(File f) {
        android.media.MediaMetadataRetriever mmr = new android.media.MediaMetadataRetriever();
        Bitmap best = null; long bestLum = -1;
        boolean big = f.length() > 400L * 1024 * 1024; // крупные файлы не сканируем на 4 кадра — держим файл минимально
        try {
            mmr.setDataSource(f.getAbsolutePath());
            long durMs = 0;
            try { String d = mmr.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_DURATION); if (d != null) durMs = Long.parseLong(d); } catch (Exception ignored) {}
            long[] pts;
            if (big) {
                pts = new long[]{ durMs > 6000 ? (durMs * 1000 / 3) : 1000000L }; // один кадр
            } else if (durMs > 3000) {
                long u = durMs * 1000; // микросекунды
                pts = new long[]{ (long)(u * 0.15), (long)(u * 0.35), (long)(u * 0.55), 1000000L };
            } else {
                pts = new long[]{ 1000000L, 0L };
            }
            for (long t : pts) {
                Bitmap b = null;
                try {
                    if (Build.VERSION.SDK_INT >= 27) b = mmr.getScaledFrameAtTime(t, android.media.MediaMetadataRetriever.OPTION_CLOSEST_SYNC, 200, 200);
                    if (b == null) b = mmr.getFrameAtTime(t, android.media.MediaMetadataRetriever.OPTION_CLOSEST_SYNC);
                } catch (Exception ignored) {}
                if (b == null) continue;
                long lum = avgLuma(b);
                if (lum > bestLum) { if (best != null && best != b) best.recycle(); best = b; bestLum = lum; }
                else if (b != best) b.recycle();
                if (bestLum > 24) break; // достаточно светлый кадр найден
            }
            if (best == null) best = mmr.getFrameAtTime();
        } catch (Exception ignored) {}
        finally { try { mmr.release(); } catch (Exception ignored) {} }
        return best;
    }

    private long avgLuma(Bitmap b) {
        try {
            int w = b.getWidth(), h = b.getHeight();
            if (w <= 0 || h <= 0) return 0;
            int sx = Math.max(1, w / 16), sy = Math.max(1, h / 16);
            long sum = 0; int n = 0;
            for (int y = 0; y < h; y += sy) for (int x = 0; x < w; x += sx) {
                int c = b.getPixel(x, y);
                sum += (77 * ((c >> 16) & 0xFF) + 150 * ((c >> 8) & 0xFF) + 29 * (c & 0xFF)) >> 8;
                n++;
            }
            return n > 0 ? sum / n : 0;
        } catch (Throwable t) { return 0; }
    }

    // готовит превью в кэш заранее; формат и ключ те же, что у thumb()
    private void warmOne(String uriStr) {
        try {
            File f = toFile(uriStr);
            if (!f.exists() || f.isDirectory()) return;
            File cacheFile = new File(thumbDir(), thumbKey(f) + ".t");
            if (cacheFile.exists()) return;
            String name = f.getName().toLowerCase();
            Bitmap b = null;
            if (name.matches(".*\\.(jpg|jpeg|png|webp|gif|bmp)$")) {
                android.graphics.BitmapFactory.Options o = new android.graphics.BitmapFactory.Options();
                o.inJustDecodeBounds = true;
                android.graphics.BitmapFactory.decodeFile(f.getAbsolutePath(), o);
                int sc = 1; while (o.outWidth / sc > 200 || o.outHeight / sc > 200) sc *= 2;
                android.graphics.BitmapFactory.Options o2 = new android.graphics.BitmapFactory.Options();
                o2.inSampleSize = sc;
                b = android.graphics.BitmapFactory.decodeFile(f.getAbsolutePath(), o2);
            } else if (name.matches(".*\\.(mp4|m4v|mkv|webm|avi|mov|3gp|ts|flv|wmv|mpg|mpeg)$")) {
                if (f.length() <= 200L * 1024 * 1024) b = videoFrame(f);
            }
            if (b == null) return;
            java.io.ByteArrayOutputStream bos = new java.io.ByteArrayOutputStream();
            b.compress(Bitmap.CompressFormat.JPEG, 70, bos);
            b.recycle();
            FileOutputStream fo = new FileOutputStream(cacheFile);
            fo.write(xorBytes(bos.toByteArray()));
            fo.close();
        } catch (Throwable ignored) {}
    }

    // ---- Кэш списков на диске (localStorage мал и пишет синхронно) ----
    private File cacheFileFor(String key) {
        String k = (key == null || key.isEmpty()) ? "list" : key.replaceAll("[^a-zA-Z0-9_]", "_");
        File d = getContext().getCacheDir();
        File dir = new File(d, "lists");
        if (!dir.exists()) dir.mkdirs();
        return new File(dir, k + ".json");
    }

    @PluginMethod
    public void cacheGet(PluginCall call) {
        try {
            File f = cacheFileFor(call.getString("key", "list"));
            JSObject ret = new JSObject();
            if (f.exists()) ret.put("data", new String(readAll(new FileInputStream(f)), "UTF-8"));
            call.resolve(ret);
        } catch (Exception e) { call.resolve(new JSObject()); }
    }

    @PluginMethod
    public void cacheSet(PluginCall call) {
        final String data = call.getString("data", "");
        final String key = call.getString("key", "list");
        call.resolve();
        new Thread(new Runnable() {
            @Override public void run() {
                try {
                    FileOutputStream o = new FileOutputStream(cacheFileFor(key));
                    o.write(data.getBytes("UTF-8"));
                    o.close();
                } catch (Exception ignored) {}
            }
        }).start();
    }

    @PluginMethod
    public void query(PluginCall call) {
        String mime = call.getString("mime", "*/*");
        String uriStr = call.getString("uri");
        String action = call.getString("action", "view");
        String act = "edit".equals(action) ? Intent.ACTION_EDIT : Intent.ACTION_VIEW;
        PackageManager pm = getContext().getPackageManager();

        Intent intent = new Intent(act);
        boolean dataSet = false;
        if (uriStr != null) {
            try {
                try { StrictMode.setVmPolicy(new StrictMode.VmPolicy.Builder().build()); } catch (Exception ignored) {}
                intent.setDataAndType(contentUriFor(toFile(uriStr)), mime);
                dataSet = true;
            } catch (Exception ignored) {}
        }
        if (!dataSet) intent.setType(mime);

        List<ResolveInfo> list = pm.queryIntentActivities(intent, PackageManager.MATCH_ALL);
        if (list.isEmpty()) {
            Intent alt = new Intent(act);
            alt.setType(mime);
            list = pm.queryIntentActivities(alt, PackageManager.MATCH_ALL);
        }
        if (list.isEmpty() && !"edit".equals(action)) {
            Intent edit = new Intent(Intent.ACTION_EDIT);
            edit.setType(mime);
            list = pm.queryIntentActivities(edit, PackageManager.MATCH_ALL);
        }

        JSArray apps = new JSArray();
        for (ResolveInfo ri : list) {
            if (ri.activityInfo == null) continue;
            JSObject o = new JSObject();
            o.put("label", String.valueOf(ri.loadLabel(pm)));
            o.put("packageName", ri.activityInfo.packageName);
            o.put("activityName", ri.activityInfo.name);
            try { o.put("icon", drawableToBase64(ri.loadIcon(pm))); } catch (Exception ignored) {}
            apps.put(o);
        }
        JSObject ret = new JSObject();
        ret.put("apps", apps);
        call.resolve(ret);
    }

    @PluginMethod
    public void open(PluginCall call) {
        String uriStr = call.getString("uri");
        String mime = call.getString("mime", "*/*");
        String pkg = call.getString("packageName");
        String act = call.getString("activityName");
        String action = call.getString("action", "view");
        if (uriStr == null) { call.reject("no uri"); return; }
        try {
            if (uriStr.startsWith("content://")) {
                Intent iv = new Intent(Intent.ACTION_VIEW);
                iv.setDataAndType(Uri.parse(uriStr), call.getString("mime", "*/*"));
                iv.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
                getContext().startActivity(Intent.createChooser(iv, "Открыть").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
                call.resolve(); return;
            }
            File f = toFile(uriStr);
            if (!f.exists()) { call.reject("Файл не найден: " + f.getAbsolutePath()); return; }
            if (f.isDirectory()) { call.reject("Это папка: " + f.getAbsolutePath()); return; }
            try { StrictMode.setVmPolicy(new StrictMode.VmPolicy.Builder().build()); } catch (Exception ignored) {}
            Uri data = contentUriFor(f);
            Intent i = new Intent("edit".equals(action) ? Intent.ACTION_EDIT : Intent.ACTION_VIEW);
            i.setDataAndType(data, mime);
            android.content.ClipData clip = android.content.ClipData.newRawUri("", data);
            // плейлист: список в порядке, как в приложении — плеер играет его, а не свой скан папки
            JSArray plist = call.getArray("uris");
            java.util.ArrayList<Uri> plUris = new java.util.ArrayList<>();
            if (plist != null) {
                for (int pi = 0; pi < plist.length(); pi++) {
                    try {
                        String us = String.valueOf(plist.get(pi));
                        Uri pu = us.startsWith("content://") ? Uri.parse(us) : contentUriFor(toFile(us));
                        plUris.add(pu);
                        clip.addItem(new android.content.ClipData.Item(pu));
                    } catch (Exception ignored) {}
                }
                if (!plUris.isEmpty()) {
                    i.putParcelableArrayListExtra("video_list", plUris); // MX Player и совместимые
                    i.putExtra("video_list_is_explicit", true);
                }
            }
            i.setClipData(clip);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_GRANT_READ_URI_PERMISSION);
            if ("edit".equals(action)) i.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
            if (pkg != null && act != null) i.setClassName(pkg, act);
            else if (pkg != null) i.setPackage(pkg);
            int gf = Intent.FLAG_GRANT_READ_URI_PERMISSION | ("edit".equals(action) ? Intent.FLAG_GRANT_WRITE_URI_PERMISSION : 0);
            try {
                if (pkg != null) getContext().grantUriPermission(pkg, data, gf);
                // грант всем, кто может обработать intent (на случай, если редактор читает файл из другого компонента)
                java.util.List<android.content.pm.ResolveInfo> ris = getContext().getPackageManager().queryIntentActivities(i, PackageManager.MATCH_DEFAULT_ONLY);
                for (android.content.pm.ResolveInfo ri : ris) { try { getContext().grantUriPermission(ri.activityInfo.packageName, data, gf); } catch (Exception ignored) {} }
            } catch (Exception ignored) {}
            try { for (Uri pu : plUris) { java.util.List<android.content.pm.ResolveInfo> r2 = getContext().getPackageManager().queryIntentActivities(i, PackageManager.MATCH_DEFAULT_ONLY); for (android.content.pm.ResolveInfo ri : r2) { try { getContext().grantUriPermission(ri.activityInfo.packageName, pu, Intent.FLAG_GRANT_READ_URI_PERMISSION); } catch (Exception ignored) {} } } } catch (Exception ignored) {}
            if (call.getBoolean("chooser", false) && pkg == null) {
                Intent ch = Intent.createChooser(i, "Открыть с помощью");
                ch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                getContext().startActivity(ch);
            } else getContext().startActivity(i);
            call.resolve();
        } catch (Exception e) {
            call.reject(e.getMessage());
        }
    }

    // ---- Расширенный доступ (Shizuku) ----
    @PluginMethod
    public void shizukuStatus(PluginCall call) {
        JSObject o = new JSObject();
        try {
            if (!ShizukuBridge.supported()) {
                o.put("installed", false); o.put("running", false); o.put("granted", false);
                o.put("ready", false); o.put("state", "old");
                call.resolve(o); return;
            }
            boolean inst = ShizukuBridge.installed(getContext());
            boolean run = ShizukuBridge.running();
            boolean ok = ShizukuBridge.granted();
            if (ok) ShizukuBridge.bind(getContext());
            o.put("installed", inst);
            o.put("running", run);
            o.put("granted", ok);
            o.put("ready", ShizukuBridge.ready());
            o.put("state", !inst ? "absent" : !run ? "stopped" : !ok ? "denied" : "ok");
        } catch (Throwable t) {
            o.put("installed", false); o.put("running", false); o.put("granted", false);
            o.put("ready", false); o.put("state", "absent");
        }
        call.resolve(o);
    }

    @PluginMethod
    public void shizukuRequest(PluginCall call) {
        try {
            ShizukuBridge.requestPermission();
            JSObject o = new JSObject(); o.put("ok", true); call.resolve(o);
        } catch (Throwable t) { call.reject("Shizuku недоступен"); }
    }

    // ---- Запись на флешку/SD через SAF (Android не даёт писать на съёмные носители напрямую) ----
    private String safPrefName() { return "yf_saf"; }
    // id тома из пути /storage/XXXX-XXXX  ->  "XXXX-XXXX"
    private String volumeIdOf(String path) {
        if (path == null) return null;
        String p = path.replace("file://", "");
        java.util.regex.Matcher m = java.util.regex.Pattern.compile("/storage/([^/]+)").matcher(p);
        return m.find() ? m.group(1) : null;
    }
    private String safTreeFor(String volId) {
        if (volId == null) return null;
        return getContext().getSharedPreferences(safPrefName(), Context.MODE_PRIVATE).getString(volId, null);
    }
    // нужен ли SAF: путь на съёмном носителе и Android 11+
    private boolean safNeeded(String path) {
        if (Build.VERSION.SDK_INT < 30) return false;
        String id = volumeIdOf(path);
        return id != null && !id.equals("emulated") && !id.equals("self");
    }

    @PluginMethod
    public void safStatus(PluginCall call) {
        String path = call.getString("path", "");
        String id = volumeIdOf(path);
        boolean needed = safNeeded(path);
        boolean granted = false;
        String tree = safTreeFor(id);
        if (tree != null) {
            try {
                Uri u = Uri.parse(tree);
                for (android.content.UriPermission up : getContext().getContentResolver().getPersistedUriPermissions()) {
                    if (up.getUri().equals(u) && up.isWritePermission()) { granted = true; break; }
                }
            } catch (Throwable ignored) {}
        }
        JSObject o = new JSObject();
        o.put("needed", needed);
        o.put("granted", granted);
        call.resolve(o);
    }

    @PluginMethod
    public void safRequest(PluginCall call) {
        try {
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
            if (Build.VERSION.SDK_INT >= 26) {
                String id = volumeIdOf(call.getString("path", ""));
                if (id != null) {
                    try {
                        Uri hint = android.provider.DocumentsContract.buildDocumentUri("com.android.externalstorage.documents", id + ":");
                        i.putExtra(android.provider.DocumentsContract.EXTRA_INITIAL_URI, hint);
                    } catch (Throwable ignored) {}
                }
            }
            startActivityForResult(call, i, "safResult");
        } catch (Exception e) { call.reject(e.getMessage()); }
    }

    @ActivityCallback
    private void safResult(PluginCall call, ActivityResult result) {
        if (call == null) return;
        try {
            Intent data = result.getData();
            Uri tree = data != null ? data.getData() : null;
            if (tree == null) { JSObject o = new JSObject(); o.put("granted", false); call.resolve(o); return; }
            final int flags = Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION;
            try { getContext().getContentResolver().takePersistableUriPermission(tree, flags); } catch (Throwable ignored) {}
            // сопоставляем выбранное дерево с id тома
            String docId = android.provider.DocumentsContract.getTreeDocumentId(tree);
            String volId = docId != null && docId.contains(":") ? docId.substring(0, docId.indexOf(":")) : docId;
            if (volId != null) getContext().getSharedPreferences(safPrefName(), Context.MODE_PRIVATE).edit().putString(volId, tree.toString()).apply();
            JSObject o = new JSObject(); o.put("granted", true); o.put("volId", volId);
            call.resolve(o);
        } catch (Exception e) { call.reject(e.getMessage()); }
    }

    // Спускаемся/создаём папки дерева SAF до нужного места и возвращаем DocumentFile-папку
    private DocumentFile safDirFor(String destDirPath) {
        String id = volumeIdOf(destDirPath);
        String tree = safTreeFor(id);
        if (tree == null) return null;
        DocumentFile root = DocumentFile.fromTreeUri(getContext(), Uri.parse(tree));
        if (root == null) return null;
        // путь внутри тома: всё после /storage/<id>
        String p = destDirPath.replace("file://", "");
        int idx = p.indexOf("/storage/" + id);
        String rel = idx >= 0 ? p.substring(idx + ("/storage/" + id).length()) : "";
        DocumentFile cur = root;
        for (String seg : rel.split("/")) {
            if (seg.isEmpty()) continue;
            DocumentFile next = cur.findFile(seg);
            if (next == null || !next.isDirectory()) next = cur.createDirectory(seg);
            if (next == null) return null;
            cur = next;
        }
        return cur;
    }

    // Копирование файла или папки на съёмный носитель через SAF
    @PluginMethod
    public void safCopyInto(PluginCall call) {
        String srcUri = call.getString("from");
        String destDir = call.getString("destDir"); // абсолютный путь папки-приёмника на томе
        if (srcUri == null || destDir == null) { call.reject("no args"); return; }
        try {
            File src = toFile(srcUri);
            if (!src.exists()) { call.reject("Источник не найден"); return; }
            DocumentFile dir = safDirFor(destDir);
            if (dir == null) { call.reject("Нет доступа к носителю"); return; }
            if (src.isDirectory()) safPutDir(src, dir);
            else safPutFile(src, dir);
            call.resolve();
        } catch (Exception e) { call.reject(e.getMessage()); }
    }

    private void safPutDir(File src, DocumentFile parent) throws Exception {
        DocumentFile d = parent.findFile(src.getName());
        if (d == null || !d.isDirectory()) d = parent.createDirectory(src.getName());
        if (d == null) throw new Exception("Не удалось создать папку " + src.getName());
        File[] kids = src.listFiles();
        if (kids != null) for (File k : kids) { if (k.isDirectory()) safPutDir(k, d); else safPutFile(k, d); }
    }

    private void safPutFile(File src, DocumentFile parent) throws Exception {
        DocumentFile ex = parent.findFile(src.getName());
        if (ex != null) ex.delete(); // перезапись
        String mime = mimeFromName(src.getName());
        DocumentFile df = parent.createFile(mime != null ? mime : "application/octet-stream", src.getName());
        if (df == null) throw new Exception("Не удалось создать файл " + src.getName());
        InputStream in = new FileInputStream(src);
        OutputStream out = getContext().getContentResolver().openOutputStream(df.getUri());
        try {
            byte[] buf = new byte[262144]; int r;
            while ((r = in.read(buf)) > 0) out.write(buf, 0, r);
            out.flush();
        } finally {
            try { in.close(); } catch (Exception ignored) {}
            try { if (out != null) out.close(); } catch (Exception ignored) {}
        }
    }

    private String mimeFromName(String name) {
        String ext = android.webkit.MimeTypeMap.getFileExtensionFromUrl(name.replace(" ", "_"));
        if (ext == null || ext.isEmpty()) { int d = name.lastIndexOf('.'); if (d >= 0) ext = name.substring(d + 1); }
        if (ext == null || ext.isEmpty()) return null;
        return android.webkit.MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext.toLowerCase());
    }

    @PluginMethod
    public void safMkdir(PluginCall call) {
        String destDir = call.getString("destDir");
        String name = call.getString("name");
        if (destDir == null || name == null) { call.reject("no args"); return; }
        try {
            DocumentFile dir = safDirFor(destDir);
            if (dir == null) { call.reject("Нет доступа к носителю"); return; }
            DocumentFile ex = dir.findFile(name);
            if (ex == null) dir.createDirectory(name);
            call.resolve();
        } catch (Exception e) { call.reject(e.getMessage()); }
    }

    @PluginMethod
    public void list(PluginCall call) {
        String uriStr = call.getString("uri");
        if (uriStr == null) { call.reject("no uri"); return; }
        try {
            File dir = toFile(uriStr);
            File[] kids = dir.listFiles();
            if (kids == null || kids.length == 0) {
                String vid = volumeIdOf(dir.getAbsolutePath());
                if (vid != null && !vid.equals("emulated") && !vid.equals("self")) {
                    String tree = safTreeFor(vid);
                    if (tree != null) {
                        try {
                            DocumentFile cur = DocumentFile.fromTreeUri(getContext(), Uri.parse(tree));
                            String pth = dir.getAbsolutePath();
                            int ix = pth.indexOf("/storage/" + vid);
                            String rel = ix >= 0 ? pth.substring(ix + ("/storage/" + vid).length()) : "";
                            for (String seg : rel.split("/")) {
                                if (seg.isEmpty() || cur == null) continue;
                                cur = cur.findFile(seg);
                            }
                            if (cur != null && cur.isDirectory()) {
                                JSArray outA = new JSArray();
                                for (DocumentFile df : cur.listFiles()) {
                                    JSObject o = new JSObject();
                                    o.put("name", df.getName());
                                    boolean dd = df.isDirectory();
                                    o.put("type", dd ? "directory" : "file");
                                    o.put("size", dd ? 0 : df.length());
                                    o.put("mtime", df.lastModified());
                                    // папкам оставляем file-путь для навигации, файлам — content:// для открытия
                                    o.put("uri", dd ? new File(dir, df.getName()).getAbsolutePath() : df.getUri().toString());
                                    outA.put(o);
                                }
                                JSObject ret = new JSObject(); ret.put("entries", outA); ret.put("saf", true);
                                call.resolve(ret); return;
                            }
                        } catch (Throwable ignored) {}
                    }
                }
            }
            // закрытые системой папки (Android/data, Android/obb) читаем через Shizuku, если он поднят
            if ((kids == null || kids.length == 0) && ShizukuBridge.restricted(dir.getAbsolutePath()) && ShizukuBridge.ready()) {
                try {
                    String js = ShizukuBridge.get().list(dir.getAbsolutePath());
                    if (js != null) {
                        org.json.JSONArray ja = new org.json.JSONArray(js);
                        if (ja.length() > 0) {
                            JSArray out = new JSArray();
                            for (int i = 0; i < ja.length(); i++) out.put(ja.getJSONObject(i));
                            JSObject ret = new JSObject(); ret.put("entries", out); ret.put("shizuku", true); call.resolve(ret); return;
                        }
                    }
                } catch (Throwable ignored) {}
            }
            JSArray arr = new JSArray();
            if (kids != null) {
                for (File k : kids) {
                    JSObject o = new JSObject();
                    o.put("name", k.getName());
                    boolean isDir = k.isDirectory();
                    o.put("type", isDir ? "directory" : "file");
                    if (isDir) {
                        File[] sub = k.listFiles();
                        int cnt = 0; File thumb = null; long thumbTime = 0;
                        if (sub != null) {
                            for (File sf : sub) {
                                if (sf.getName().startsWith(".")) continue;
                                cnt++;
                                String ln = sf.getName().toLowerCase();
                                if (!sf.isDirectory() && (ln.endsWith(".jpg") || ln.endsWith(".jpeg") || ln.endsWith(".png") || ln.endsWith(".webp") || ln.endsWith(".gif") || ln.endsWith(".bmp"))) {
                                    if (sf.lastModified() >= thumbTime) { thumbTime = sf.lastModified(); thumb = sf; }
                                }
                            }
                        }
                        o.put("count", cnt);
                        if (thumb != null) o.put("thumb", "file://" + thumb.getAbsolutePath());
                    }
                    o.put("size", k.length());
                    o.put("mtime", k.lastModified());
                    o.put("uri", "file://" + k.getAbsolutePath());
                    arr.put(o);
                }
            }
            JSObject ret = new JSObject();
            ret.put("files", arr);
            call.resolve(ret);
        } catch (Exception e) {
            call.reject(e.getMessage());
        }
    }

    private File thumbDir() {
        File base = getContext().getExternalCacheDir();
        if (base == null) base = getContext().getCacheDir();
        File d = new File(base, "yev_thumbs");
        if (!d.exists()) d.mkdirs();
        return d;
    }
    private byte[] xorBytes(byte[] d) {
        final byte[] k = { (byte) 0x5A, (byte) 0xA5, (byte) 0x3C, (byte) 0xC3, (byte) 0x69, (byte) 0x96, (byte) 0x1E, (byte) 0xE1 };
        byte[] o = new byte[d.length];
        for (int i = 0; i < d.length; i++) o[i] = (byte) (d[i] ^ k[i % k.length]);
        return o;
    }
    private String thumbKey(File src) {
        // ключ = хэш пути + mtime, чтобы кэш инвалидировался при изменении файла
        String base = src.getAbsolutePath() + "|" + src.lastModified() + "|" + src.length();
        return Integer.toHexString(base.hashCode()) + "_" + src.lastModified();
    }

    @PluginMethod
    public void thumb(PluginCall call) {
        String uriStr = call.getString("uri");
        if (uriStr == null) { call.reject("no uri"); return; }
        try {
            File f = toFile(uriStr);
            if (!f.exists()) { call.resolve(new JSObject()); return; }
            String name = f.getName().toLowerCase();
            boolean isApk = name.endsWith(".apk");
            String ext = isApk ? ".png" : ".jpg";
            String mimeOut = isApk ? "image/png" : "image/jpeg";
            File cacheFile = new File(thumbDir(), thumbKey(f) + ".t");
            JSObject ret = new JSObject();
            // готовое превью из кэша (деобфускация)
            if (cacheFile.exists()) {
                byte[] data = xorBytes(readAll(new FileInputStream(cacheFile)));
                ret.put("thumb", "data:" + mimeOut + ";base64," + Base64.encodeToString(data, Base64.NO_WRAP));
                call.resolve(ret); return;
            }
            // удалить устаревшие кэши этого же файла (другой mtime)
            String prefix = Integer.toHexString((f.getAbsolutePath() + "|").hashCode());
            File[] stale = thumbDir().listFiles();
            Bitmap b = null;
            if (name.matches(".*\\.(jpg|jpeg|png|webp|gif|bmp)$")) {
                android.graphics.BitmapFactory.Options o = new android.graphics.BitmapFactory.Options();
                o.inJustDecodeBounds = true;
                android.graphics.BitmapFactory.decodeFile(f.getAbsolutePath(), o);
                int s = 1; while (o.outWidth / s > 200 || o.outHeight / s > 200) s *= 2;
                android.graphics.BitmapFactory.Options o2 = new android.graphics.BitmapFactory.Options();
                o2.inSampleSize = s;
                b = android.graphics.BitmapFactory.decodeFile(f.getAbsolutePath(), o2);
            } else if (name.endsWith(".pdf")) {
                android.os.ParcelFileDescriptor pfd = android.os.ParcelFileDescriptor.open(f, android.os.ParcelFileDescriptor.MODE_READ_ONLY);
                android.graphics.pdf.PdfRenderer r = new android.graphics.pdf.PdfRenderer(pfd);
                if (r.getPageCount() > 0) {
                    android.graphics.pdf.PdfRenderer.Page page = r.openPage(0);
                    int w = 150, h = (int) (150f * page.getHeight() / Math.max(1, page.getWidth())); if (h <= 0) h = 190;
                    b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888); b.eraseColor(0xFFFFFFFF);
                    page.render(b, null, null, android.graphics.pdf.PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY); page.close();
                }
                r.close(); pfd.close();
            } else if (name.matches(".*\\.(mp4|m4v|mkv|webm|avi|mov|qt|wmv|flv|f4v|3gp|3g2|mpg|mpeg|mpe|m2v|ts|m2ts|mts|vob|ogv|divx|asf)$")) {
                if (f.length() <= 700L * 1024 * 1024) b = videoFrame(f);
            } else if (name.endsWith(".apk")) {
                PackageManager pm = getContext().getPackageManager();
                android.content.pm.PackageInfo pi = pm.getPackageArchiveInfo(f.getAbsolutePath(), 0);
                if (pi != null) { pi.applicationInfo.sourceDir = f.getAbsolutePath(); pi.applicationInfo.publicSourceDir = f.getAbsolutePath();
                    Drawable d = pi.applicationInfo.loadIcon(pm); b = drawableToBitmap(d); }
            }
            if (b == null) { call.resolve(ret); return; }
            // даунскейл до ~150px
            int mx = Math.max(b.getWidth(), b.getHeight());
            if (mx > 150) { float sc = 150f / mx; b = Bitmap.createScaledBitmap(b, Math.round(b.getWidth() * sc), Math.round(b.getHeight() * sc), true); }
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            if (isApk) b.compress(Bitmap.CompressFormat.PNG, 100, out);
            else b.compress(Bitmap.CompressFormat.JPEG, 80, out);
            byte[] bytes = out.toByteArray();
            try { OutputStream fos = new java.io.FileOutputStream(cacheFile); fos.write(xorBytes(bytes)); fos.close(); } catch (Exception ignored) {}
            ret.put("thumb", "data:" + mimeOut + ";base64," + Base64.encodeToString(bytes, Base64.NO_WRAP));
            call.resolve(ret);
        } catch (Exception e) { call.resolve(new JSObject()); }
    }

    @PluginMethod
    public void thumbSweep(PluginCall call) {
        // удаляет кэши старше 30 дней или сверх лимита, чтобы папка не разрасталась
        try {
            File dir = thumbDir();
            File[] files = dir.listFiles();
            if (files != null) {
                long now = System.currentTimeMillis();
                long maxAge = 30L * 24 * 3600 * 1000;
                long total = 0;
                java.util.Arrays.sort(files, (a, c) -> Long.compare(c.lastModified(), a.lastModified()));
                for (File f : files) {
                    total += f.length();
                    if (now - f.lastModified() > maxAge || total > 80L * 1024 * 1024) f.delete();
                }
            }
            call.resolve(new JSObject());
        } catch (Exception e) { call.resolve(new JSObject()); }
    }

    private Bitmap drawableToBitmap(Drawable d) {
        if (d == null) return null;
        try { if (d instanceof android.graphics.drawable.BitmapDrawable) { Bitmap bm = ((android.graphics.drawable.BitmapDrawable) d).getBitmap(); if (bm != null) return bm; } } catch (Exception ignored) {}
        int w = d.getIntrinsicWidth(), h = d.getIntrinsicHeight();
        if (w <= 0 || h <= 0) { w = 144; h = 144; }
        Bitmap b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        android.graphics.Canvas c = new android.graphics.Canvas(b);
        d.setBounds(0, 0, w, h); d.draw(c);
        return b;
    }

    private byte[] readAll(InputStream in) throws Exception {
        ByteArrayOutputStream o = new ByteArrayOutputStream();
        byte[] buf = new byte[65536]; int r;
        while ((r = in.read(buf)) > 0) o.write(buf, 0, r);
        in.close(); return o.toByteArray();
    }

    @PluginMethod
    public void pdfPage(PluginCall call) {
        String uriStr = call.getString("uri");
        int page = call.getInt("page", 0);
        int width = call.getInt("width", 1080);
        if (uriStr == null) { call.reject("no uri"); return; }
        try {
            File f = toFile(uriStr);
            android.os.ParcelFileDescriptor pfd = android.os.ParcelFileDescriptor.open(f, android.os.ParcelFileDescriptor.MODE_READ_ONLY);
            android.graphics.pdf.PdfRenderer r = new android.graphics.pdf.PdfRenderer(pfd);
            int pages = r.getPageCount();
            JSObject ret = new JSObject();
            ret.put("pages", pages);
            if (page >= 0 && page < pages) {
                android.graphics.pdf.PdfRenderer.Page pg = r.openPage(page);
                int w = width < 1 ? 1080 : width;
                int h = (int) ((long) w * pg.getHeight() / Math.max(1, pg.getWidth()));
                if (h <= 0) h = w;
                if ((long) w * h > 12000000L) { h = (int) (12000000L / w); }
                Bitmap b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
                b.eraseColor(0xFFFFFFFF);
                pg.render(b, null, null, android.graphics.pdf.PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY);
                pg.close();
                ByteArrayOutputStream out = new ByteArrayOutputStream();
                b.compress(Bitmap.CompressFormat.JPEG, 80, out);
                b.recycle();
                ret.put("data", "data:image/jpeg;base64," + Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP));
                ret.put("w", w); ret.put("h", h);
            }
            r.close(); pfd.close();
            call.resolve(ret);
        } catch (Exception e) { call.reject(e.getMessage()); }
    }

    @PluginMethod
    public void pdfThumb(PluginCall call) {
        String uriStr = call.getString("uri");
        if (uriStr == null) { call.reject("no uri"); return; }
        try {
            File f = toFile(uriStr);
            android.os.ParcelFileDescriptor pfd = android.os.ParcelFileDescriptor.open(f, android.os.ParcelFileDescriptor.MODE_READ_ONLY);
            android.graphics.pdf.PdfRenderer r = new android.graphics.pdf.PdfRenderer(pfd);
            JSObject ret = new JSObject();
            if (r.getPageCount() > 0) {
                android.graphics.pdf.PdfRenderer.Page page = r.openPage(0);
                int w = 160, h = (int) (160f * page.getHeight() / Math.max(1, page.getWidth()));
                if (h <= 0) h = 200;
                Bitmap b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
                b.eraseColor(0xFFFFFFFF);
                page.render(b, null, null, android.graphics.pdf.PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY);
                page.close();
                ByteArrayOutputStream out = new ByteArrayOutputStream();
                b.compress(Bitmap.CompressFormat.PNG, 90, out);
                ret.put("thumb", "data:image/png;base64," + Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP));
            }
            r.close(); pfd.close();
            call.resolve(ret);
        } catch (Exception e) { call.reject(e.getMessage()); }
    }

    @PluginMethod
    public void saveSharedTemp(PluginCall call) {
        try {
            if (MainActivity.pendingShared.isEmpty()) { call.resolve(new JSObject()); return; }
            android.net.Uri u = MainActivity.pendingShared.get(0);
            String name = queryName(u);
            File dir = new File(android.os.Environment.getExternalStorageDirectory(), "Download/.yevtmp");
            if (!dir.exists()) dir.mkdirs();
            File out = new File(dir, name);
            java.io.InputStream in = getContext().getContentResolver().openInputStream(u);
            java.io.FileOutputStream fos = new java.io.FileOutputStream(out);
            byte[] buf = new byte[65536]; int r;
            while ((r = in.read(buf)) > 0) fos.write(buf, 0, r);
            fos.close(); in.close();
            MainActivity.pendingShared.clear();
            JSObject ret = new JSObject(); ret.put("uri", "file://" + out.getAbsolutePath()); ret.put("name", name); call.resolve(ret);
        } catch (Exception e) { call.reject(e.getMessage()); }
    }

    @PluginMethod
    public void getShared(PluginCall call) {
        try {
            JSArray arr = new JSArray();
            for (android.net.Uri u : MainActivity.pendingShared) {
                JSObject o = new JSObject();
                String name = queryName(u);
                o.put("name", name);
                o.put("mime", getContext().getContentResolver().getType(u));
                arr.put(o);
            }
            JSObject ret = new JSObject(); ret.put("files", arr); ret.put("mode", MainActivity.pendingMode); call.resolve(ret);
        } catch (Exception e) { call.reject(e.getMessage()); }
    }

    @PluginMethod
    public void saveShared(PluginCall call) {
        String destDir = call.getString("dir");
        if (destDir == null) { call.reject("no dir"); return; }
        try {
            File dir = toFile(destDir);
            int ok = 0;
            for (android.net.Uri u : MainActivity.pendingShared) {
                String name = queryName(u);
                File out = new File(dir, name);
                int n = 0; String base = name, ext = "";
                int dot = name.lastIndexOf('.');
                if (dot > 0) { base = name.substring(0, dot); ext = name.substring(dot); }
                while (out.exists()) { n++; out = new File(dir, base + " (" + n + ")" + ext); }
                java.io.InputStream in = getContext().getContentResolver().openInputStream(u);
                java.io.FileOutputStream fos = new java.io.FileOutputStream(out);
                byte[] buf = new byte[65536]; int r;
                while ((r = in.read(buf)) > 0) fos.write(buf, 0, r);
                fos.close(); in.close(); ok++;
            }
            MainActivity.pendingShared.clear();
            JSObject ret = new JSObject(); ret.put("saved", ok); call.resolve(ret);
        } catch (Exception e) { call.reject(e.getMessage()); }
    }

    @PluginMethod
    public void clearShared(PluginCall call) {
        MainActivity.pendingShared.clear();
        call.resolve(new JSObject());
    }

    private String queryName(android.net.Uri u) {
        String name = null;
        try {
            android.database.Cursor c = getContext().getContentResolver().query(u, null, null, null, null);
            if (c != null) {
                int idx = c.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME);
                if (idx >= 0 && c.moveToFirst()) name = c.getString(idx);
                c.close();
            }
        } catch (Exception ignored) {}
        if (name == null) { name = u.getLastPathSegment(); if (name != null && name.contains("/")) name = name.substring(name.lastIndexOf('/') + 1); }
        if (name == null || name.isEmpty()) name = "shared_" + System.currentTimeMillis();
        return name;
    }

    private File reinstallFile;
    private boolean reinstallRegistered = false;

    @PluginMethod
    public void apkReinstall(PluginCall call) {
        String uriStr = call.getString("uri");
        String pkg = call.getString("package");
        if (uriStr == null || pkg == null) { call.reject("no args"); return; }
        File f = toFile(uriStr);
        if (f == null || !f.exists()) { call.reject("Файл не найден"); return; }
        reinstallFile = f;
        try {
            registerReinstallReceiver();
            PackageInstaller pi = getContext().getPackageManager().getPackageInstaller();
            Intent statusIntent = new Intent("leshugan.fm.UNINSTALL_RESULT").setPackage(getContext().getPackageName());
            int flags = PendingIntent.FLAG_UPDATE_CURRENT;
            if (Build.VERSION.SDK_INT >= 31) flags |= PendingIntent.FLAG_MUTABLE;
            PendingIntent pending = PendingIntent.getBroadcast(getContext(), 4242, statusIntent, flags);
            pi.uninstall(pkg, pending.getIntentSender());
            call.resolve();
        } catch (Exception e) { call.reject(e.getMessage()); }
    }

    private void registerReinstallReceiver() {
        if (reinstallRegistered) return;
        BroadcastReceiver r = new BroadcastReceiver() {
            @Override public void onReceive(Context c, Intent i) {
                int status = i.getIntExtra(PackageInstaller.EXTRA_STATUS, -1);
                if (status == PackageInstaller.STATUS_PENDING_USER_ACTION) {
                    Intent confirm = i.getParcelableExtra(Intent.EXTRA_INTENT);
                    if (confirm != null) { confirm.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); try { c.startActivity(confirm); } catch (Exception ignored) {} }
                } else if (status == PackageInstaller.STATUS_SUCCESS) {
                    File f = reinstallFile; reinstallFile = null;
                    if (f != null) { try { installApkFileInternal(f); } catch (Exception ignored) {} }
                }
            }
        };
        IntentFilter filter = new IntentFilter("leshugan.fm.UNINSTALL_RESULT");
        if (Build.VERSION.SDK_INT >= 33) getContext().registerReceiver(r, filter, Context.RECEIVER_NOT_EXPORTED);
        else getContext().registerReceiver(r, filter);
        reinstallRegistered = true;
    }

    private void installApkFileInternal(File f) throws Exception {
        registerInstallReceiver();
        PackageInstaller pi = getContext().getPackageManager().getPackageInstaller();
        PackageInstaller.SessionParams params = new PackageInstaller.SessionParams(PackageInstaller.SessionParams.MODE_FULL_INSTALL);
        int sessionId = pi.createSession(params);
        PackageInstaller.Session session = pi.openSession(sessionId);
        OutputStream out = session.openWrite("apk", 0, f.length());
        InputStream in = new FileInputStream(f);
        byte[] buf = new byte[65536]; int n;
        while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
        session.fsync(out); in.close(); out.close();
        Intent statusIntent = new Intent("leshugan.fm.INSTALL_RESULT").setPackage(getContext().getPackageName());
        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= 31) flags |= PendingIntent.FLAG_MUTABLE;
        PendingIntent pending = PendingIntent.getBroadcast(getContext(), sessionId, statusIntent, flags);
        session.commit(pending.getIntentSender());
        session.close();
    }

    // Метаданные по типу файла: размеры и EXIF для картинок, длительность/битрейт/кодек для аудио и видео
    @PluginMethod
    public void fileMeta(PluginCall call) {
        String uriStr = call.getString("uri");
        if (uriStr == null) { call.reject("no uri"); return; }
        try {
            File f = toFile(uriStr);
            if (!f.exists()) { call.reject("not found"); return; }
            String n = f.getName().toLowerCase();
            JSObject o = new JSObject();
            if (n.matches(".*\\.(png|jpg|jpeg|webp|gif|bmp|heic|heif|avif)$")) {
                android.graphics.BitmapFactory.Options bo = new android.graphics.BitmapFactory.Options();
                bo.inJustDecodeBounds = true;
                android.graphics.BitmapFactory.decodeFile(f.getAbsolutePath(), bo);
                if (bo.outWidth > 0) { o.put("w", bo.outWidth); o.put("h", bo.outHeight); }
                try {
                    androidx.exifinterface.media.ExifInterface ex = new androidx.exifinterface.media.ExifInterface(f.getAbsolutePath());
                    putIf(o, "camera", join(ex.getAttribute(androidx.exifinterface.media.ExifInterface.TAG_MAKE),
                                            ex.getAttribute(androidx.exifinterface.media.ExifInterface.TAG_MODEL)));
                    putIf(o, "lens", ex.getAttribute(androidx.exifinterface.media.ExifInterface.TAG_LENS_MODEL));
                    String exp = ex.getAttribute(androidx.exifinterface.media.ExifInterface.TAG_EXPOSURE_TIME);
                    if (exp != null) { try { double d = Double.parseDouble(exp); o.put("exposure", d >= 1 ? (trim(d) + " с") : ("1/" + Math.round(1 / d) + " с")); } catch (Exception ignored) {} }
                    String fn = ex.getAttribute(androidx.exifinterface.media.ExifInterface.TAG_F_NUMBER);
                    if (fn != null) { try { o.put("aperture", "f/" + trim(Double.parseDouble(fn))); } catch (Exception ignored) {} }
                    int iso = ex.getAttributeInt(androidx.exifinterface.media.ExifInterface.TAG_PHOTOGRAPHIC_SENSITIVITY, 0);
                    if (iso > 0) o.put("iso", "ISO " + iso);
                    String fl = ex.getAttribute(androidx.exifinterface.media.ExifInterface.TAG_FOCAL_LENGTH);
                    if (fl != null) { try { String[] pr = fl.split("/"); double v = pr.length == 2 ? Double.parseDouble(pr[0]) / Double.parseDouble(pr[1]) : Double.parseDouble(fl); o.put("focal", trim(v) + " мм"); } catch (Exception ignored) {} }
                    putIf(o, "taken", ex.getAttribute(androidx.exifinterface.media.ExifInterface.TAG_DATETIME_ORIGINAL));
                    double[] ll = ex.getLatLong();
                    if (ll != null) o.put("gps", String.format(java.util.Locale.US, "%.5f, %.5f", ll[0], ll[1]));
                    int rot = ex.getAttributeInt(androidx.exifinterface.media.ExifInterface.TAG_ORIENTATION, 0);
                    if ((rot == 6 || rot == 8) && bo.outWidth > 0) { o.put("w", bo.outHeight); o.put("h", bo.outWidth); }
                } catch (Exception ignored) {}
                o.put("kind", "image");
            } else if (n.matches(".*\\.(mp3|m4a|aac|flac|ogg|opus|wav|wma|mp4|m4v|mkv|webm|avi|mov|3gp|ts|flv|wmv|mpg|mpeg)$")) {
                android.media.MediaMetadataRetriever mmr = new android.media.MediaMetadataRetriever();
                try {
                    mmr.setDataSource(f.getAbsolutePath());
                    String dur = mmr.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_DURATION);
                    if (dur != null) { try { o.put("duration", fmtDur(Long.parseLong(dur))); } catch (Exception ignored) {} }
                    String br = mmr.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_BITRATE);
                    if (br != null) { try { o.put("bitrate", Math.round(Long.parseLong(br) / 1000.0) + " кбит/с"); } catch (Exception ignored) {} }
                    putIf(o, "title", mmr.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_TITLE));
                    putIf(o, "artist", mmr.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_ARTIST));
                    putIf(o, "album", mmr.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_ALBUM));
                    putIf(o, "year", mmr.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_YEAR));
                    String w = mmr.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH);
                    String h = mmr.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT);
                    if (w != null && h != null) { o.put("w", Integer.parseInt(w)); o.put("h", Integer.parseInt(h)); }
                    if (Build.VERSION.SDK_INT >= 23) {
                        putIf(o, "fps", mmr.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_CAPTURE_FRAMERATE));
                    }
                    putIf(o, "codec", mmr.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_MIMETYPE));
                    o.put("kind", w != null ? "video" : "audio");
                } catch (Exception ignored) { o.put("kind", "media"); }
                finally { try { mmr.release(); } catch (Exception ignored) {} }
            } else {
                o.put("kind", "other");
            }
            call.resolve(o);
        } catch (Exception e) { call.reject(e.getMessage()); }
    }

    private void putIf(JSObject o, String k, String v) { if (v != null && v.trim().length() > 0) o.put(k, v.trim()); }
    private String join(String a, String b) {
        if (a == null && b == null) return null;
        if (a == null) return b; if (b == null) return a;
        return b.toLowerCase().startsWith(a.toLowerCase()) ? b : (a + " " + b);
    }
    private String trim(double d) {
        String s = String.format(java.util.Locale.US, "%.2f", d);
        while (s.contains(".") && (s.endsWith("0") || s.endsWith("."))) s = s.substring(0, s.length() - 1);
        return s;
    }
    private String fmtDur(long ms) {
        long t = ms / 1000, h = t / 3600, m = (t % 3600) / 60, sec = t % 60;
        return h > 0 ? String.format(java.util.Locale.US, "%d:%02d:%02d", h, m, sec)
                     : String.format(java.util.Locale.US, "%d:%02d", m, sec);
    }

    @PluginMethod
    public void apkInfo(PluginCall call) {
        String uriStr = call.getString("uri");
        if (uriStr == null) { call.reject("no uri"); return; }
        try {
            File f = toFile(uriStr);
            String p = f.getAbsolutePath();
            String lower = f.getName().toLowerCase();
            boolean split = lower.endsWith(".apks") || lower.endsWith(".xapk") || lower.endsWith(".apkm") || lower.endsWith(".apkx");
            File tmpBase = null;
            if (split) { tmpBase = extractBaseApk(f); if (tmpBase != null) p = tmpBase.getAbsolutePath(); }
            PackageManager pm = getContext().getPackageManager();
            android.content.pm.PackageInfo pi = pm.getPackageArchiveInfo(p, 0);
            JSObject ret = new JSObject();
            if (pi != null) {
                pi.applicationInfo.sourceDir = p;
                pi.applicationInfo.publicSourceDir = p;
                ret.put("package", pi.packageName);
                ret.put("versionName", pi.versionName);
                ret.put("versionCode", android.os.Build.VERSION.SDK_INT >= 28 ? pi.getLongVersionCode() : pi.versionCode);
                ret.put("targetSdk", pi.applicationInfo.targetSdkVersion);
                if (android.os.Build.VERSION.SDK_INT >= 24) ret.put("minSdk", pi.applicationInfo.minSdkVersion);
                try { ret.put("label", pm.getApplicationLabel(pi.applicationInfo).toString()); } catch (Exception ignored) {}
                try { Drawable ic = pm.getApplicationIcon(pi.applicationInfo); ret.put("icon", drawableToBase64(ic)); } catch (Exception ignored) {}
                // подпись apk (из архива)
                String apkSig = null;
                try { android.content.pm.PackageInfo sp = pm.getPackageArchiveInfo(p, PackageManager.GET_SIGNATURES); apkSig = firstCertSha256(sp); } catch (Exception ignored) {}
                if (apkSig != null) ret.put("sig", apkSig);
                // установлена ли уже + версия + подпись установленной
                try {
                    android.content.pm.PackageInfo inst = pm.getPackageInfo(pi.packageName, 0);
                    ret.put("installedVersionName", inst.versionName);
                    ret.put("installedVersionCode", android.os.Build.VERSION.SDK_INT >= 28 ? inst.getLongVersionCode() : inst.versionCode);
                    ret.put("installed", true);
                    try {
                        android.content.pm.PackageInfo instSig = pm.getPackageInfo(pi.packageName, PackageManager.GET_SIGNATURES);
                        String is = firstCertSha256(instSig);
                        if (is != null) ret.put("installedSig", is);
                        if (apkSig != null && is != null) ret.put("sigMatch", apkSig.equals(is));
                    } catch (Exception ignored) {}
                } catch (Exception e) { ret.put("installed", false); }
            }
            if (tmpBase != null) try { tmpBase.delete(); } catch (Exception ignored) {}
            call.resolve(ret);
        } catch (Exception e) { call.reject(e.getMessage()); }
    }

    private String firstCertSha256(android.content.pm.PackageInfo pi) {
        try {
            android.content.pm.Signature[] sigs = pi.signatures;
            if (sigs == null || sigs.length == 0) return null;
            java.security.MessageDigest md = java.security.MessageDigest.getInstance("SHA-256");
            byte[] d = md.digest(sigs[0].toByteArray());
            StringBuilder sb = new StringBuilder();
            for (byte b : d) sb.append(String.format("%02X", b));
            return sb.toString();
        } catch (Exception e) { return null; }
    }

    private File extractBaseApk(File pkg) {
        try {
            ZipFile zf = new ZipFile(pkg);
            ZipEntry best = null; long bestSize = -1;
            Enumeration<? extends ZipEntry> en = zf.entries();
            while (en.hasMoreElements()) {
                ZipEntry e = en.nextElement();
                if (e.isDirectory()) continue;
                String nm = e.getName().toLowerCase();
                if (!nm.endsWith(".apk")) continue;
                long sz = e.getSize();
                // base обычно самый большой .apk (не config.* / split_*)
                boolean cfg = nm.contains("config.") || nm.contains("split_") || nm.contains("split.");
                if (!cfg && (best == null || sz > bestSize)) { best = e; bestSize = sz; }
                else if (best == null) { best = e; bestSize = sz; }
            }
            if (best == null) { zf.close(); return null; }
            File out = new File(getContext().getCacheDir(), "base_" + System.currentTimeMillis() + ".apk");
            InputStream in = zf.getInputStream(best);
            OutputStream os = new FileOutputStream(out);
            byte[] buf = new byte[65536]; int n; while ((n = in.read(buf)) > 0) os.write(buf, 0, n);
            os.close(); in.close(); zf.close();
            return out;
        } catch (Exception e) { return null; }
    }

    @PluginMethod
    public void apkIcon(PluginCall call) {
        String uriStr = call.getString("uri");
        if (uriStr == null) { call.reject("no uri"); return; }
        try {
            File f = toFile(uriStr);
            String p = f.getAbsolutePath();
            PackageManager pm = getContext().getPackageManager();
            android.content.pm.PackageInfo pi = pm.getPackageArchiveInfo(p, 0);
            JSObject ret = new JSObject();
            if (pi != null) {
                pi.applicationInfo.sourceDir = p;
                pi.applicationInfo.publicSourceDir = p;
                Drawable icon = pi.applicationInfo.loadIcon(pm);
                ret.put("icon", drawableToBase64(icon));
            }
            call.resolve(ret);
        } catch (Exception e) { call.reject(e.getMessage()); }
    }

    @PluginMethod
    public void delete(PluginCall call) {
        String uriStr = call.getString("uri");
        if (uriStr == null) { call.reject("no uri"); return; }
        File f = toFile(uriStr);
        boolean ok = deleteRecursive(f);
        JSObject ret = new JSObject();
        ret.put("deleted", ok || !f.exists());
        call.resolve(ret);
    }

    private int[] copyCounter = new int[2]; // [done, total]

    @PluginMethod
    public void copyTree(PluginCall call) {
        String fromStr = call.getString("from");
        String toStr = call.getString("to");
        if (fromStr == null || toStr == null) { call.reject("no from/to"); return; }
        try {
            File src = toFile(fromStr);
            File dst = toFile(toStr);
            String skip = dst.getCanonicalPath();
            copyCounter[0] = 0;
            copyCounter[1] = countFiles(src, skip);
            copyRecursive(src, dst, skip);
            JSObject ret = new JSObject(); ret.put("ok", true); ret.put("total", copyCounter[1]); call.resolve(ret);
        } catch (Exception e) { call.reject(e.getMessage()); }
    }

    private int countFiles(File src, String skipPath) {
        try { if (src.getCanonicalPath().equals(skipPath)) return 0; } catch (Exception e) { return 0; }
        if (src.isDirectory()) {
            int c = 0; File[] kids = src.listFiles();
            if (kids != null) for (File k : kids) c += countFiles(k, skipPath);
            return c;
        }
        return 1;
    }

    private void copyRecursive(File src, File dst, String skipPath) throws Exception {
        if (src.getCanonicalPath().equals(skipPath)) return;
        if (src.isDirectory()) {
            if (!dst.exists()) dst.mkdirs();
            File[] kids = src.listFiles();
            if (kids != null) for (File c : kids) {
                if (c.getCanonicalPath().equals(skipPath)) continue;
                copyRecursive(c, new File(dst, c.getName()), skipPath);
            }
        } else {
            java.io.FileInputStream in = new java.io.FileInputStream(src);
            java.io.FileOutputStream out = new java.io.FileOutputStream(dst);
            byte[] buf = new byte[65536]; int r;
            while ((r = in.read(buf)) > 0) out.write(buf, 0, r);
            in.close(); out.close();
            copyCounter[0]++;
            // событие прогресса в JS + уведомление Android
            JSObject ev = new JSObject(); ev.put("done", copyCounter[0]); ev.put("total", copyCounter[1]); ev.put("name", src.getName());
            notifyListeners("opProgress", ev);
            if (copyCounter[1] > 0) postProgressNotif("Копирование", src.getName(), copyCounter[0], copyCounter[1]);
        }
    }

    // Поток с прогрессом: крупный файл внутри архива теперь двигает полосу по байтам,
    // а не «замирает» на 1/1 до самого конца
    private class ProgOut extends OutputStream {
        private final OutputStream out; private final String name;
        private final int idx, total; private final long size;
        private long wrote = 0, lastEv = 0;
        ProgOut(OutputStream out, String name, int idx, int total, long size) {
            this.out = out; this.name = name; this.idx = idx; this.total = Math.max(1, total); this.size = size;
        }
        private void tick(boolean force) {
            long now = System.currentTimeMillis();
            if (!force && now - lastEv < 120) return;
            lastEv = now;
            double frac = size > 0 ? Math.min(1.0, (double) wrote / size) : 1.0;
            int pct = (int) Math.round(((idx + frac) / total) * 100.0);
            if (pct > 100) pct = 100;
            JSObject ev = new JSObject(); ev.put("done", pct); ev.put("total", 100); ev.put("name", name);
            notifyListeners("opProgress", ev);
            postProgressNotif("Распаковка", name, pct, 100);
        }
        @Override public void write(int b) throws java.io.IOException { out.write(b); wrote++; tick(false); }
        @Override public void write(byte[] b, int off, int len) throws java.io.IOException { out.write(b, off, len); wrote += len; tick(false); }
        @Override public void flush() throws java.io.IOException { out.flush(); }
        @Override public void close() throws java.io.IOException { out.close(); tick(true); }
    }

    private void postProgressNotif(String title, String text, int prog, int max) {
        try {
            NotificationManager nm = (NotificationManager) getContext().getSystemService(Context.NOTIFICATION_SERVICE);
            if (android.os.Build.VERSION.SDK_INT >= 26) {
                NotificationChannel ch = new NotificationChannel("yev_progress", "Операции с файлами", NotificationManager.IMPORTANCE_LOW);
                nm.createNotificationChannel(ch);
            }
            Notification.Builder b = android.os.Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(getContext(), "yev_progress") : new Notification.Builder(getContext());
            b.setContentTitle(title).setContentText(text).setSmallIcon(android.R.drawable.stat_sys_download)
             .setProgress(max, prog, false).setOngoing(prog < max).setOnlyAlertOnce(true);
            try {
                Intent li = getContext().getPackageManager().getLaunchIntentForPackage(getContext().getPackageName());
                if (li != null) {
                    li.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    int fl = Build.VERSION.SDK_INT >= 23 ? android.app.PendingIntent.FLAG_IMMUTABLE | android.app.PendingIntent.FLAG_UPDATE_CURRENT : android.app.PendingIntent.FLAG_UPDATE_CURRENT;
                    b.setContentIntent(android.app.PendingIntent.getActivity(getContext(), 0, li, fl));
                }
            } catch (Throwable ignored) {}
            nm.notify(777, b.build());
        } catch (Exception ignored) {}
    }

    // ---- Подключённые тома: внутренняя память, SD-карты, USB-флешки ----
    @PluginMethod
    public void storageVolumes(PluginCall call) {
        JSArray arr = new JSArray();
        java.util.LinkedHashMap<String, JSObject> seen = new java.util.LinkedHashMap<>();
        try {
            // 1) внутренняя память — всегда первой
            File primary = Environment.getExternalStorageDirectory();
            if (primary != null) {
                JSObject o = new JSObject();
                o.put("path", primary.getAbsolutePath());
                o.put("name", "Внутренняя память");
                o.put("primary", true);
                o.put("removable", false);
                seen.put(primary.getAbsolutePath(), o);
            }
            // 2) через StorageManager (Android 7+) — самые точные имена и признак съёмности
            if (Build.VERSION.SDK_INT >= 24) {
                android.os.storage.StorageManager sm = (android.os.storage.StorageManager) getContext().getSystemService(Context.STORAGE_SERVICE);
                if (sm != null) {
                    for (android.os.storage.StorageVolume v : sm.getStorageVolumes()) {
                        File dir = null;
                        if (Build.VERSION.SDK_INT >= 30) { try { dir = v.getDirectory(); } catch (Throwable ignored) {} }
                        if (dir == null) {
                            try {
                                java.lang.reflect.Method m = v.getClass().getMethod("getPathFile");
                                Object r = m.invoke(v); if (r instanceof File) dir = (File) r;
                            } catch (Throwable ignored) {}
                        }
                        if (dir == null) {
                            try {
                                java.lang.reflect.Method m = v.getClass().getMethod("getPath");
                                Object r = m.invoke(v); if (r instanceof String) dir = new File((String) r);
                            } catch (Throwable ignored) {}
                        }
                        if (dir == null || !dir.exists()) continue;
                        String path = dir.getAbsolutePath();
                        if (seen.containsKey(path)) { if (v.isRemovable()) seen.get(path).put("removable", true); continue; }
                        String desc = null;
                        try { desc = v.getDescription(getContext()); } catch (Throwable ignored) {}
                        JSObject o = new JSObject();
                        o.put("path", path);
                        o.put("name", desc != null && desc.length() > 0 ? desc : (v.isRemovable() ? "Съёмный носитель" : "Хранилище"));
                        o.put("primary", v.isPrimary());
                        o.put("removable", v.isRemovable());
                        seen.put(path, o);
                    }
                }
            }
            // 3) добор через /storage — ловит флешки, которые StorageManager не отдал
            File st = new File("/storage");
            File[] mounts = st.listFiles();
            if (mounts != null) {
                for (File m : mounts) {
                    String nm = m.getName();
                    if (nm.equals("self") || nm.equals("emulated") || nm.equals("enc_emulated") || nm.equals("knox-emulated")) continue;
                    String path = m.getAbsolutePath();
                    if (seen.containsKey(path)) continue;
                    if (!m.canRead()) continue;
                    File[] probe = m.listFiles();
                    if (probe == null) continue; // не смонтирован / нет доступа
                    JSObject o = new JSObject();
                    o.put("path", path);
                    boolean looksUsb = nm.matches("(?i).*(usb|otg).*");
                    o.put("name", looksUsb ? "USB-накопитель" : ("Носитель " + nm));
                    o.put("primary", false);
                    o.put("removable", true);
                    seen.put(path, o);
                }
            }
        } catch (Throwable ignored) {}
        for (JSObject o : seen.values()) arr.put(o);
        JSObject ret = new JSObject();
        ret.put("volumes", arr);
        call.resolve(ret);
    }

    @PluginMethod
    public void hasAllFiles(PluginCall call) {
        boolean granted;
        if (Build.VERSION.SDK_INT >= 30) granted = Environment.isExternalStorageManager();
        else granted = true;
        JSObject ret = new JSObject();
        ret.put("granted", granted);
        call.resolve(ret);
    }

    @PluginMethod
    public void requestAllFiles(PluginCall call) {
        try {
            Intent i;
            if (Build.VERSION.SDK_INT >= 30) {
                i = new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION);
                i.setData(Uri.parse("package:" + getContext().getPackageName()));
            } else {
                i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                i.setData(Uri.parse("package:" + getContext().getPackageName()));
            }
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            getContext().startActivity(i);
            call.resolve();
        } catch (Exception e) {
            call.reject(e.getMessage());
        }
    }

    @PluginMethod
    public void installSplit(PluginCall call) {
        String uriStr = call.getString("uri");
        if (uriStr == null) { call.reject("no uri"); return; }
        try {
            File f = toFile(uriStr);
            if (!f.exists()) { call.reject("Файл не найден: " + f.getAbsolutePath()); return; }
            registerInstallReceiver();
            PackageInstaller pi = getContext().getPackageManager().getPackageInstaller();
            PackageInstaller.SessionParams params = new PackageInstaller.SessionParams(PackageInstaller.SessionParams.MODE_FULL_INSTALL);
            int sessionId = pi.createSession(params);
            PackageInstaller.Session session = pi.openSession(sessionId);
            ZipFile zf = new ZipFile(f);
            Enumeration<? extends ZipEntry> en = zf.entries();
            int idx = 0; boolean any = false;
            byte[] buf = new byte[65536];
            while (en.hasMoreElements()) {
                ZipEntry e = en.nextElement();
                if (e.isDirectory()) continue;
                String nm = e.getName().toLowerCase();
                if (!nm.endsWith(".apk")) continue;
                long sz = e.getSize();
                InputStream in = zf.getInputStream(e);
                if (sz <= 0) {
                    ByteArrayOutputStream bos = new ByteArrayOutputStream();
                    int m; while ((m = in.read(buf)) > 0) bos.write(buf, 0, m);
                    byte[] data = bos.toByteArray();
                    OutputStream out = session.openWrite("split" + idx, 0, data.length);
                    out.write(data); session.fsync(out); out.close();
                } else {
                    OutputStream out = session.openWrite("split" + idx, 0, sz);
                    int n; while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
                    session.fsync(out); out.close();
                }
                in.close(); idx++; any = true;
            }
            zf.close();
            if (!any) { session.abandon(); call.reject("В пакете нет apk"); return; }
            Intent statusIntent = new Intent("leshugan.fm.INSTALL_RESULT").setPackage(getContext().getPackageName());
            int flags = PendingIntent.FLAG_UPDATE_CURRENT;
            if (Build.VERSION.SDK_INT >= 31) flags |= PendingIntent.FLAG_MUTABLE;
            PendingIntent pending = PendingIntent.getBroadcast(getContext(), sessionId, statusIntent, flags);
            session.commit(pending.getIntentSender());
            session.close();
            call.resolve();
        } catch (Exception e) { call.reject(e.getMessage()); }
    }

    @PluginMethod
    public void installApk(PluginCall call) {
        String uriStr = call.getString("uri");
        if (uriStr == null) { call.reject("no uri"); return; }
        try {
            File f = toFile(uriStr);
            if (!f.exists()) { call.reject("Файл не найден: " + f.getAbsolutePath()); return; }
            registerInstallReceiver();
            PackageInstaller pi = getContext().getPackageManager().getPackageInstaller();
            PackageInstaller.SessionParams params = new PackageInstaller.SessionParams(PackageInstaller.SessionParams.MODE_FULL_INSTALL);
            int sessionId = pi.createSession(params);
            PackageInstaller.Session session = pi.openSession(sessionId);
            OutputStream out = session.openWrite("apk", 0, f.length());
            InputStream in = new FileInputStream(f);
            byte[] buf = new byte[65536];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            session.fsync(out);
            in.close();
            out.close();
            Intent statusIntent = new Intent("leshugan.fm.INSTALL_RESULT").setPackage(getContext().getPackageName());
            int flags = PendingIntent.FLAG_UPDATE_CURRENT;
            if (Build.VERSION.SDK_INT >= 31) flags |= PendingIntent.FLAG_MUTABLE;
            PendingIntent pending = PendingIntent.getBroadcast(getContext(), sessionId, statusIntent, flags);
            session.commit(pending.getIntentSender());
            session.close();
            call.resolve();
        } catch (Exception e) { call.reject(e.getMessage()); }
    }

    @PluginMethod
    public void uninstall(PluginCall call) {
        String uriStr = call.getString("uri");
        if (uriStr == null) { call.reject("no uri"); return; }
        try {
            File f = toFile(uriStr);
            PackageInfo info = getContext().getPackageManager().getPackageArchiveInfo(f.getAbsolutePath(), 0);
            if (info == null) { call.reject("Не удалось прочитать пакет"); return; }
            Intent i = new Intent(Intent.ACTION_DELETE, Uri.parse("package:" + info.packageName));
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            getContext().startActivity(i);
            call.resolve();
        } catch (Exception e) { call.reject(e.getMessage()); }
    }

    private void registerInstallReceiver() {
        if (instRegistered) return;
        BroadcastReceiver r = new BroadcastReceiver() {
            @Override public void onReceive(Context c, Intent i) {
                int status = i.getIntExtra(PackageInstaller.EXTRA_STATUS, -1);
                if (status == PackageInstaller.STATUS_PENDING_USER_ACTION) {
                    Intent confirm = i.getParcelableExtra(Intent.EXTRA_INTENT);
                    if (confirm != null) { confirm.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); c.startActivity(confirm); }
                }
            }
        };
        IntentFilter filter = new IntentFilter("leshugan.fm.INSTALL_RESULT");
        if (Build.VERSION.SDK_INT >= 33) getContext().registerReceiver(r, filter, Context.RECEIVER_NOT_EXPORTED);
        else getContext().registerReceiver(r, filter);
        instRegistered = true;
    }

    @PluginMethod
    public void notifyProgress(PluginCall call) {
        String title = call.getString("title", "Операция");
        int progress = call.getInt("progress", 0);
        int max = call.getInt("max", 100);
        String text = call.getString("text", "");
        try {
            NotificationManager nm = (NotificationManager) getContext().getSystemService(Context.NOTIFICATION_SERVICE);
            String ch = "yev_progress";
            Notification.Builder b;
            if (Build.VERSION.SDK_INT >= 26) {
                NotificationChannel c = new NotificationChannel(ch, "Операции с файлами", NotificationManager.IMPORTANCE_LOW);
                nm.createNotificationChannel(c);
                b = new Notification.Builder(getContext(), ch);
            } else {
                b = new Notification.Builder(getContext());
            }
            b.setContentTitle(title).setContentText(text)
             .setSmallIcon(android.R.drawable.stat_sys_download)
             .setProgress(max, progress, false).setOngoing(true).setOnlyAlertOnce(true);
            nm.notify(777, b.build());
            call.resolve();
        } catch (Exception e) { call.reject(e.getMessage()); }
    }

    @PluginMethod
    public void cancelNotify(PluginCall call) {
        try { NotificationManager nm = (NotificationManager) getContext().getSystemService(Context.NOTIFICATION_SERVICE); nm.cancel(777); } catch (Exception ignored) {}
        call.resolve();
    }

    @PluginMethod
    public void watch(PluginCall call) {
        String uriStr = call.getString("uri");
        if (uriStr == null) { call.reject("no uri"); return; }
        try {
            final String path = toFile(uriStr).getAbsolutePath();
            if (observer != null) { observer.stopWatching(); observer = null; }
            int mask = FileObserver.CREATE | FileObserver.DELETE | FileObserver.MOVED_FROM | FileObserver.MOVED_TO | FileObserver.CLOSE_WRITE | FileObserver.MODIFY;
            observer = new FileObserver(path, mask) {
                @Override public void onEvent(int event, String p) { notifyListeners("fschange", new JSObject()); }
            };
            observer.startWatching();
            call.resolve();
        } catch (Exception e) { call.reject(e.getMessage()); }
    }

    private boolean zipIsEncrypted(File f) {
        try { net.lingala.zip4j.ZipFile z = new net.lingala.zip4j.ZipFile(f); boolean e = z.isEncrypted(); z.close(); return e; }
        catch (Exception ex) { return false; }
    }

    private void zip4jExtract(File src, String destDir, java.util.List<String> names, String password) throws Exception {
        net.lingala.zip4j.ZipFile z = new net.lingala.zip4j.ZipFile(src);
        if (password != null) z.setPassword(password.toCharArray());
        try {
            if (names != null && !names.isEmpty()) {
                int total = names.size(), done = 0;
                for (String nm : names) {
                    z.extractFile(nm, destDir);
                    done++;
                    JSObject ev = new JSObject(); ev.put("done", done); ev.put("total", total); ev.put("name", nm);
                    notifyListeners("opProgress", ev);
                }
            } else {
                z.extractAll(destDir);
            }
        } finally { try { z.close(); } catch (Exception ignored) {} }
    }

    // ==== gz / tar / tgz поддержка (без внешних библиотек) ====
    // Определение формата по сигнатуре (первые байты), расширение — только запасной вариант.
    // Значения сигнатур — публичные факты из спецификаций форматов.
    private String sniffKind(File f) {
        byte[] h = new byte[8];
        int n = -1;
        InputStream is = null;
        try { is = new FileInputStream(f); n = is.read(h); } catch (Exception ignored) {}
        finally { if (is != null) try { is.close(); } catch (Exception ignored) {} }
        if (n >= 4 && h[0] == 0x50 && h[1] == 0x4B) {          // "PK" — ZIP (в т.ч. apk/jar/docx)
            return "zip";
        }
        if (n >= 7 && h[0] == 0x52 && h[1] == 0x61 && h[2] == 0x72 && h[3] == 0x21
                && h[4] == 0x1A && h[5] == 0x07) {              // "Rar!\x1A\x07"
            return h[6] == 0x00 ? "rar" : "rar5";               // 0x00 — RAR4, 0x01 — RAR5
        }
        if (n >= 2 && (h[0] & 0xFF) == 0x1F && (h[1] & 0xFF) == 0x8B) return "gz";
        if (n >= 6 && (h[0] & 0xFF) == 0x37 && (h[1] & 0xFF) == 0x7A
                && (h[2] & 0xFF) == 0xBC && (h[3] & 0xFF) == 0xAF) return "7z";
        if (n >= 3 && h[0] == 0x42 && h[1] == 0x5A && h[2] == 0x68) return "bz2";   // "BZh"
        if (n >= 6 && (h[0] & 0xFF) == 0xFD && h[1] == 0x37 && h[2] == 0x7A
                && h[3] == 0x58 && h[4] == 0x5A) return "xz";
        // TAR: метка "ustar" по смещению 257
        try {
            java.io.RandomAccessFile ra = new java.io.RandomAccessFile(f, "r");
            try {
                if (ra.length() > 262) {
                    byte[] u = new byte[5];
                    ra.seek(257); ra.readFully(u);
                    if (u[0] == 'u' && u[1] == 's' && u[2] == 't' && u[3] == 'a' && u[4] == 'r') return "tar";
                }
            } finally { ra.close(); }
        } catch (Exception ignored) {}
        return null;
    }

    private String arcKind(File f) {
        String n = f.getName().toLowerCase();
        // .tar.gz / .tgz — двухслойный, по сигнатуре виден только gz, поэтому решаем по имени
        if (n.endsWith(".tar.gz") || n.endsWith(".tgz")) return "tgz";
        String sniff = sniffKind(f);
        if (sniff != null) {
            if (sniff.equals("gz") && (n.endsWith(".tgz") || n.endsWith(".tar.gz"))) return "tgz";
            return sniff;
        }
        if (n.endsWith(".tar")) return "tar";
        if (n.endsWith(".gz")) return "gz";
        if (n.endsWith(".rar")) return "rar";
        return "zip";
    }

    // ---- Многотомные архивы ----
    // .001/.002…  — файл разрезан на куски, склеиваются побайтово
    // .zip + .z01… — разрезанный ZIP, собирается средствами zip4j
    // .rar + .r00… и .partN.rar — тома RAR, их читает сам junrar, начиная с первого тома
    private boolean isVolumeFirst(File f) {
        return f.getName().toLowerCase().matches(".*\\.001$");
    }

    // Если открыт НЕ первый том — возвращает имя первого, иначе null
    private String notFirstVolume(File f) {
        String n = f.getName(), l = n.toLowerCase();
        java.util.regex.Matcher m;
        m = java.util.regex.Pattern.compile("^(.*)\\.(\\d{3})$").matcher(l);
        if (m.matches() && !m.group(2).equals("001")) return m.group(1) + ".001";
        m = java.util.regex.Pattern.compile("^(.*)\\.z(\\d{2,})$").matcher(l);
        if (m.matches()) return m.group(1) + ".zip";
        m = java.util.regex.Pattern.compile("^(.*)\\.r(\\d{2,})$").matcher(l);
        if (m.matches()) return m.group(1) + ".rar";
        m = java.util.regex.Pattern.compile("^(.*)\\.part(\\d+)\\.rar$").matcher(l);
        if (m.matches() && Integer.parseInt(m.group(2)) != 1) {
            int w = m.group(2).length();
            return m.group(1) + ".part" + String.format(java.util.Locale.US, "%0" + w + "d", 1) + ".rar";
        }
        return null;
    }

    private File joinVolumes(File first) throws Exception {
        if (!isVolumeFirst(first)) return first;
        String n = first.getName();
        String base = n.substring(0, n.length() - 4);
        File dir = first.getParentFile();
        java.util.List<File> vols = new java.util.ArrayList<>();
        long total = 0;
        for (int i = 1; i < 1000; i++) {
            File v = new File(dir, base + "." + String.format(java.util.Locale.US, "%03d", i));
            if (!v.exists()) break;
            vols.add(v); total += v.length();
        }
        if (vols.isEmpty()) return first;
        File cacheDir = new File(getContext().getCacheDir(), "joined");
        if (!cacheDir.exists()) cacheDir.mkdirs();
        File out = new File(cacheDir, Integer.toHexString((first.getAbsolutePath() + "|" + total).hashCode()) + "_" + base);
        if (out.exists() && out.length() == total) return out;
        for (File old : cacheDir.listFiles() != null ? cacheDir.listFiles() : new File[0]) { try { old.delete(); } catch (Exception ignored) {} }
        OutputStream os = new FileOutputStream(out);
        byte[] buf = new byte[262144];
        int done = 0;
        for (File v : vols) {
            InputStream is = new FileInputStream(v);
            int r; while ((r = is.read(buf)) > 0) os.write(buf, 0, r);
            is.close(); done++;
            JSObject ev = new JSObject(); ev.put("done", (int) (done * 100.0 / vols.size())); ev.put("total", 100); ev.put("name", base); notifyListeners("opProgress", ev);
        }
        os.close();
        return out;
    }

    // Разрезанный ZIP (.zip + .z01…): собираем цельный файл средствами zip4j
    private File mergeSplitZip(File f) {
        try {
            net.lingala.zip4j.ZipFile z = new net.lingala.zip4j.ZipFile(f);
            if (!z.isSplitArchive()) return f;
            File cacheDir = new File(getContext().getCacheDir(), "joined");
            if (!cacheDir.exists()) cacheDir.mkdirs();
            File out = new File(cacheDir, Integer.toHexString((f.getAbsolutePath() + "|" + f.lastModified()).hashCode()) + "_" + f.getName());
            if (out.exists() && out.length() > 0) return out;
            z.mergeSplitFiles(out);
            return out.exists() && out.length() > 0 ? out : f;
        } catch (Exception e) { return f; }
    }

    // Файл архива для чтения: склеенный том или сам файл
    private File arcFile(String uriStr) throws Exception {
        File f = toFile(uriStr);
        String other = notFirstVolume(f);
        if (other != null) {
            File first = new File(f.getParentFile(), other);
            if (first.exists()) f = first; // открыт средний том — работаем с набором от первого, как WinRAR
            else throw new Exception("Это один из томов архива, а первый том (" + other + ") не найден рядом");
        }
        File joined = joinVolumes(f);
        if (joined != f) return joined;
        if (arcKind(f).equals("zip")) return mergeSplitZip(f);
        return f;
    }

    // ---- RAR5 (libarchive, чтение): junrar умеет только RAR4 ----
    private static class La { long a; android.os.ParcelFileDescriptor pfd; }

    // тома .part1.rar/.part2.rar… — libarchive должен получить их все сразу
    private java.util.List<File> laVolumes(File f) {
        java.util.regex.Matcher m = java.util.regex.Pattern.compile("(?i)^(.*\\.part)(\\d+)(\\.rar)$").matcher(f.getName());
        if (!m.matches()) return null;
        String pre = m.group(1), suf = m.group(3);
        int width = m.group(2).length();
        java.util.List<File> out = new java.util.ArrayList<>();
        for (int i = 1; i < 1000; i++) {
            String num = String.valueOf(i);
            while (num.length() < width) num = "0" + num;
            File v = new File(f.getParentFile(), pre + num + suf);
            if (!v.exists() && width > 1) { // возможен .part1 без нулей
                String alt = String.valueOf(i);
                File v2 = new File(f.getParentFile(), pre + alt + suf);
                if (v2.exists()) v = v2;
            }
            if (!v.exists()) break;
            out.add(v);
        }
        return out.size() > 1 ? out : null;
    }

    private La laOpen(File f, String password) throws Exception {
        La la = new La();
        la.a = me.zhanghai.android.libarchive.Archive.readNew();
        try {
            me.zhanghai.android.libarchive.Archive.setCharset(la.a, "UTF-8".getBytes("UTF-8"));
            me.zhanghai.android.libarchive.Archive.readSupportFilterAll(la.a);
            me.zhanghai.android.libarchive.Archive.readSupportFormatAll(la.a);
            if (password != null && password.length() > 0)
                me.zhanghai.android.libarchive.Archive.readAddPassphrase(la.a, password.getBytes("UTF-8"));
            java.util.List<File> vols = laVolumes(f);
            if (vols != null) {
                byte[][] names = new byte[vols.size()][];
                for (int i = 0; i < vols.size(); i++) names[i] = vols.get(i).getAbsolutePath().getBytes("UTF-8");
                me.zhanghai.android.libarchive.Archive.readOpenFileNames(la.a, names, 262144);
            } else {
                la.pfd = android.os.ParcelFileDescriptor.open(f, android.os.ParcelFileDescriptor.MODE_READ_ONLY);
                me.zhanghai.android.libarchive.Archive.readOpenFd(la.a, la.pfd.getFd(), 262144);
            }
            return la;
        } catch (Exception e) { laClose(la); throw e; }
    }

    private void laClose(La la) {
        if (la == null) return;
        try { me.zhanghai.android.libarchive.Archive.free(la.a); } catch (Throwable ignored) {}
        try { if (la.pfd != null) la.pfd.close(); } catch (Throwable ignored) {}
    }

    private String laName(long entry) {
        String n = me.zhanghai.android.libarchive.ArchiveEntry.pathnameUtf8(entry);
        if (n == null) {
            byte[] b = me.zhanghai.android.libarchive.ArchiveEntry.pathname(entry);
            try { n = b != null ? new String(b, "UTF-8") : ""; } catch (Exception e) { n = ""; }
        }
        return n.replace('\\', '/');
    }

    private boolean laEncErr(Exception e) {
        String m = e.getMessage();
        return m != null && (m.contains("assphrase") || m.contains("ncrypt") || m.contains("password") || m.contains("Password"));
    }

    private JSArray laEntries(File f, String password) throws Exception {
        JSArray arr = new JSArray();
        La la = laOpen(f, password);
        try {
            long entry;
            while ((entry = me.zhanghai.android.libarchive.Archive.readNextHeader(la.a)) != 0) {
                String nm = laName(entry);
                if (nm.isEmpty()) { me.zhanghai.android.libarchive.Archive.readDataSkip(la.a); continue; }
                boolean dir = me.zhanghai.android.libarchive.ArchiveEntry.filetype(entry) == me.zhanghai.android.libarchive.ArchiveEntry.AE_IFDIR;
                JSObject o = new JSObject();
                o.put("name", nm);
                o.put("size", dir ? 0 : me.zhanghai.android.libarchive.ArchiveEntry.size(entry));
                o.put("dir", dir);
                arr.put(o);
                me.zhanghai.android.libarchive.Archive.readDataSkip(la.a);
            }
        } finally { laClose(la); }
        return arr;
    }

    private void laExtract(File f, File destDir, java.util.Set<String> only, String password) throws Exception {
        int total = 0;
        if (only != null) total = only.size();
        else {
            JSArray pre = laEntries(f, password);
            for (int i = 0; i < pre.length(); i++) { org.json.JSONObject o = pre.getJSONObject(i); if (!o.optBoolean("dir")) total++; }
        }
        La la = laOpen(f, password);
        try {
            long entry; int done = 0;
            while ((entry = me.zhanghai.android.libarchive.Archive.readNextHeader(la.a)) != 0) {
                String nm = laName(entry);
                boolean dir = me.zhanghai.android.libarchive.ArchiveEntry.filetype(entry) == me.zhanghai.android.libarchive.ArchiveEntry.AE_IFDIR;
                if (dir) { if (only == null && !nm.isEmpty()) new File(destDir, nm).mkdirs(); me.zhanghai.android.libarchive.Archive.readDataSkip(la.a); continue; }
                if (nm.isEmpty() || (only != null && !only.contains(nm))) { me.zhanghai.android.libarchive.Archive.readDataSkip(la.a); continue; }
                File out = new File(destDir, nm);
                if (out.getParentFile() != null) out.getParentFile().mkdirs();
                android.os.ParcelFileDescriptor po = android.os.ParcelFileDescriptor.open(out,
                        android.os.ParcelFileDescriptor.MODE_WRITE_ONLY | android.os.ParcelFileDescriptor.MODE_CREATE | android.os.ParcelFileDescriptor.MODE_TRUNCATE);
                try { me.zhanghai.android.libarchive.Archive.readDataIntoFd(la.a, po.getFd()); }
                finally { try { po.close(); } catch (Exception ignored) {} }
                done++;
                int pct = total > 0 ? (int) (done * 100.0 / total) : 100;
                JSObject ev = new JSObject(); ev.put("done", pct); ev.put("total", 100); ev.put("name", nm); notifyListeners("opProgress", ev);
                postProgressNotif("Распаковка", nm, pct, 100);
            }
        } finally { laClose(la); }
    }

    // ---- 7z (Apache Commons Compress) ----
    private org.apache.commons.compress.archivers.sevenz.SevenZFile open7z(File f, String password) throws Exception {
        org.apache.commons.compress.archivers.sevenz.SevenZFile.Builder b = org.apache.commons.compress.archivers.sevenz.SevenZFile.builder().setFile(f);
        if (password != null && password.length() > 0) b.setPassword(password.toCharArray());
        return b.get();
    }

    private boolean sevenIsEnc(org.apache.commons.compress.archivers.sevenz.SevenZArchiveEntry e) {
        try {
            Iterable<? extends org.apache.commons.compress.archivers.sevenz.SevenZMethodConfiguration> ms = e.getContentMethods();
            if (ms != null) for (org.apache.commons.compress.archivers.sevenz.SevenZMethodConfiguration m : ms) {
                if (m.getMethod() != null && String.valueOf(m.getMethod()).contains("AES")) return true;
            }
        } catch (Throwable ignored) {}
        return false;
    }

    private JSArray sevenEntries(File f, String password) throws Exception {
        JSArray arr = new JSArray();
        org.apache.commons.compress.archivers.sevenz.SevenZFile z = open7z(f, password);
        try {
            for (org.apache.commons.compress.archivers.sevenz.SevenZArchiveEntry e : z.getEntries()) {
                JSObject o = new JSObject();
                o.put("name", e.getName().replace('\\', '/'));
                o.put("size", e.isDirectory() ? 0 : e.getSize());
                o.put("dir", e.isDirectory());
                o.put("enc", sevenIsEnc(e));
                arr.put(o);
            }
        } finally { try { z.close(); } catch (Exception ignored) {} }
        return arr;
    }

    private void sevenExtract(File f, File destDir, java.util.Set<String> only, String password) throws Exception {
        org.apache.commons.compress.archivers.sevenz.SevenZFile z = open7z(f, password);
        try {
            int total = 0, done = 0;
            for (org.apache.commons.compress.archivers.sevenz.SevenZArchiveEntry e : z.getEntries()) {
                if (e.isDirectory()) continue;
                String nm = e.getName().replace('\\', '/');
                if (only == null || only.contains(nm)) total++;
            }
            org.apache.commons.compress.archivers.sevenz.SevenZArchiveEntry e;
            byte[] buf = new byte[262144];
            while ((e = z.getNextEntry()) != null) {
                String nm = e.getName().replace('\\', '/');
                if (e.isDirectory()) { if (only == null) new File(destDir, nm).mkdirs(); continue; }
                if (only != null && !only.contains(nm)) continue;
                File out = new File(destDir, nm);
                if (out.getParentFile() != null) out.getParentFile().mkdirs();
                OutputStream os = new ProgOut(new FileOutputStream(out), nm, done, total, e.getSize());
                try { int r; while ((r = z.read(buf)) > 0) os.write(buf, 0, r); } finally { os.close(); }
                done++;
            }
        } finally { try { z.close(); } catch (Exception ignored) {} }
    }

    private JSArray rarEntries(File f) throws Exception {
        JSArray arr = new JSArray();
        com.github.junrar.Archive a = new com.github.junrar.Archive(f);
        try {
            for (com.github.junrar.rarfile.FileHeader h : a.getFileHeaders()) {
                JSObject o = new JSObject();
                o.put("name", h.getFileName().replace('\\', '/'));
                o.put("size", h.getFullUnpackSize());
                o.put("dir", h.isDirectory());
                arr.put(o);
            }
        } finally { try { a.close(); } catch (Exception ignored) {} }
        return arr;
    }

    private void rarExtract(File f, File destDir, java.util.Set<String> only) throws Exception {
        com.github.junrar.Archive a = new com.github.junrar.Archive(f);
        try {
            java.util.List<com.github.junrar.rarfile.FileHeader> hs = a.getFileHeaders();
            int total = 0;
            for (com.github.junrar.rarfile.FileHeader h : hs) {
                if (h.isDirectory()) continue;
                String nm = h.getFileName().replace('\\', '/');
                if (only == null || only.contains(nm)) total++;
            }
            int done = 0;
            for (com.github.junrar.rarfile.FileHeader h : hs) {
                if (h.isDirectory()) continue;
                String nm = h.getFileName().replace('\\', '/');
                if (only != null && !only.contains(nm)) continue;
                File out = new File(destDir, nm);
                if (out.getParentFile() != null) out.getParentFile().mkdirs();
                OutputStream os = new ProgOut(new FileOutputStream(out), nm, done, total, h.getFullUnpackSize());
                try { a.extractFile(h, os); } finally { os.close(); }
                done++;
            }
        } finally { try { a.close(); } catch (Exception ignored) {} }
    }
    private String gzBase(File f) {
        String n = f.getName(); String low = n.toLowerCase();
        if (low.endsWith(".tar.gz")) return n.substring(0, n.length() - 3);
        if (low.endsWith(".tgz")) return n.substring(0, n.length() - 4) + ".tar";
        if (low.endsWith(".gz")) return n.substring(0, n.length() - 3);
        return n;
    }
    private void gzExtract(File f, File outFile) throws Exception {
        if (outFile.getParentFile() != null) outFile.getParentFile().mkdirs();
        InputStream in = new java.util.zip.GZIPInputStream(new FileInputStream(f));
        OutputStream os = new FileOutputStream(outFile);
        byte[] buf = new byte[65536]; int n; while ((n = in.read(buf)) > 0) os.write(buf, 0, n);
        os.close(); in.close();
    }
    private InputStream tarStream(File f, String kind) throws Exception {
        return kind.equals("tgz") ? new java.util.zip.GZIPInputStream(new FileInputStream(f)) : new FileInputStream(f);
    }
    private int readFully(InputStream in, byte[] b, int len) throws Exception { int off = 0; while (off < len) { int r = in.read(b, off, len - off); if (r < 0) break; off += r; } return off; }
    private void skipFully(InputStream in, long n) throws Exception { byte[] t = new byte[8192]; while (n > 0) { int want = (int) Math.min(t.length, n); int r = in.read(t, 0, want); if (r < 0) break; n -= r; } }
    private String tarStr(byte[] b, int off, int len) { int end = off; while (end < off + len && b[end] != 0) end++; return new String(b, off, end - off).trim(); }
    private long tarOctal(byte[] b, int off, int len) { long v = 0; for (int i = off; i < off + len; i++) { int c = b[i] & 0xff; if (c == 0 || c == ' ') continue; if (c < '0' || c > '7') continue; v = v * 8 + (c - '0'); } return v; }
    private java.util.List<String[]> tarEntries(InputStream in) throws Exception {
        java.util.List<String[]> out = new java.util.ArrayList<>(); byte[] hdr = new byte[512];
        while (true) {
            if (readFully(in, hdr, 512) < 512) break;
            boolean zero = true; for (byte b : hdr) if (b != 0) { zero = false; break; } if (zero) break;
            String name = tarStr(hdr, 0, 100); if (name.isEmpty()) break;
            long size = tarOctal(hdr, 124, 12); char type = (char) hdr[156];
            out.add(new String[]{ name, String.valueOf(size), String.valueOf(type) });
            skipFully(in, ((size + 511) / 512) * 512);
        }
        return out;
    }
    private void tarExtract(InputStream in, File destDir, java.util.Set<String> only, File singleOut, int total) throws Exception {
        byte[] hdr = new byte[512]; byte[] buf = new byte[65536]; int done = 0;
        while (true) {
            if (readFully(in, hdr, 512) < 512) break;
            boolean zero = true; for (byte b : hdr) if (b != 0) { zero = false; break; } if (zero) break;
            String name = tarStr(hdr, 0, 100); if (name.isEmpty()) break;
            long size = tarOctal(hdr, 124, 12); char type = (char) hdr[156];
            boolean isDir = type == '5' || name.endsWith("/");
            long pad = ((size + 511) / 512) * 512 - size;
            boolean take = !isDir && (only == null || only.contains(name));
            if (take) {
                File out = singleOut != null ? singleOut : new File(destDir, name);
                if (out.getParentFile() != null) out.getParentFile().mkdirs();
                OutputStream fos = new ProgOut(new FileOutputStream(out), name, done, total, size);
                long rem = size; while (rem > 0) { int want = (int) Math.min(buf.length, rem); int got = in.read(buf, 0, want); if (got < 0) break; fos.write(buf, 0, got); rem -= got; }
                fos.close(); skipFully(in, pad);
                done++;
                if (singleOut != null) return;
            } else { skipFully(in, size + pad); }
        }
    }

    @PluginMethod
    public void zipList(PluginCall call) {
        String uriStr = call.getString("uri");
        if (uriStr == null) { call.reject("no uri"); return; }
        try {
            File f = arcFile(uriStr);
            String kind = arcKind(f);
            if (kind.equals("rar5")) {
                try {
                    JSArray arr = laEntries(f, call.getString("password"));
                    JSObject ret = new JSObject(); ret.put("entries", arr); ret.put("encrypted", false); call.resolve(ret); return;
                } catch (Exception le) {
                    if (laEncErr(le)) { JSObject ret = new JSObject(); ret.put("entries", new JSArray()); ret.put("encrypted", true); call.resolve(ret); return; }
                    call.reject("RAR5: " + (le.getMessage() != null ? le.getMessage() : "не удалось прочитать")); return;
                }
            }
            if (kind.equals("7z")) {
                try {
                    JSArray arr = sevenEntries(f, call.getString("password"));
                    boolean anyEnc = false;
                    for (int i = 0; i < arr.length(); i++) { if (arr.getJSONObject(i).optBoolean("enc")) { anyEnc = true; break; } }
                    JSObject ret = new JSObject(); ret.put("entries", arr); ret.put("encrypted", anyEnc); call.resolve(ret); return;
                } catch (org.apache.commons.compress.PasswordRequiredException pe) {
                    JSObject ret = new JSObject(); ret.put("entries", new JSArray()); ret.put("encrypted", true); call.resolve(ret); return;
                } catch (Exception se) {
                    String m = se.getMessage();
                    if (m != null && (m.contains("password") || m.contains("Password") || m.contains("Checksum"))) {
                        JSObject ret = new JSObject(); ret.put("entries", new JSArray()); ret.put("encrypted", true); call.resolve(ret); return;
                    }
                    call.reject("7z: " + (m != null ? m : "не удалось прочитать")); return;
                }
            }
            if (kind.equals("bz2")) { call.reject("Формат bzip2 пока не поддерживается"); return; }
            if (kind.equals("xz")) { call.reject("Формат xz пока не поддерживается"); return; }
            if (kind.equals("rar")) {
                try {
                    JSArray arr = rarEntries(f);
                    JSObject ret = new JSObject(); ret.put("entries", arr); ret.put("encrypted", false); call.resolve(ret); return;
                } catch (Exception re) { call.reject("RAR: " + (re.getMessage() != null ? re.getMessage() : "не удалось прочитать")); return; }
            }
            if (kind.equals("gz")) {
                JSArray arr = new JSArray(); JSObject o = new JSObject(); o.put("name", gzBase(f)); o.put("size", 0); o.put("dir", false); arr.put(o);
                JSObject ret = new JSObject(); ret.put("entries", arr); ret.put("encrypted", false); call.resolve(ret); return;
            }
            if (kind.equals("tar") || kind.equals("tgz")) {
                InputStream in = tarStream(f, kind); java.util.List<String[]> es = tarEntries(in); in.close();
                JSArray arr = new JSArray();
                for (String[] e : es) { JSObject o = new JSObject(); o.put("name", e[0]); o.put("size", Long.parseLong(e[1])); o.put("dir", e[2].equals("5") || e[0].endsWith("/")); arr.put(o); }
                JSObject ret = new JSObject(); ret.put("entries", arr); ret.put("encrypted", false); call.resolve(ret); return;
            }
            boolean enc = zipIsEncrypted(f);
            JSArray arr = new JSArray();
            if (enc) {
                // зашифрованный архив — список через zip4j (без пароля читаются только заголовки)
                net.lingala.zip4j.ZipFile z = new net.lingala.zip4j.ZipFile(f);
                java.util.List<net.lingala.zip4j.model.FileHeader> hs = z.getFileHeaders();
                for (net.lingala.zip4j.model.FileHeader h : hs) {
                    JSObject o = new JSObject();
                    o.put("name", h.getFileName());
                    o.put("size", h.getUncompressedSize());
                    o.put("dir", h.isDirectory());
                    arr.put(o);
                }
                z.close();
            } else {
                ZipFile zf = new ZipFile(f);
                Enumeration<? extends ZipEntry> en = zf.entries();
                while (en.hasMoreElements()) {
                    ZipEntry e = en.nextElement();
                    JSObject o = new JSObject();
                    o.put("name", e.getName());
                    o.put("size", e.getSize());
                    o.put("dir", e.isDirectory());
                    arr.put(o);
                }
                zf.close();
            }
            JSObject ret = new JSObject();
            ret.put("entries", arr);
            ret.put("encrypted", enc);
            call.resolve(ret);
        } catch (Exception e) { call.reject(e.getMessage()); }
    }

    @PluginMethod
    public void zipExtract(PluginCall call) {
        String uriStr = call.getString("uri");
        String entry = call.getString("entry");
        String dest = call.getString("dest");
        if (uriStr == null || entry == null || dest == null) { call.reject("bad args"); return; }
        String password = call.getString("password");
        File src0;
        try { src0 = arcFile(uriStr); } catch (Exception ve) { call.reject(ve.getMessage()); return; }
        String k0 = arcKind(src0);
        if (k0.equals("rar5")) {
            try {
                File out = new File(dest);
                File parent = out.getParentFile() != null ? out.getParentFile() : new File(dest);
                java.util.Set<String> only = new java.util.HashSet<>(); only.add(entry);
                File tmp = new File(getContext().getCacheDir(), "la1"); if (!tmp.exists()) tmp.mkdirs();
                laExtract(src0, tmp, only, password);
                File got = new File(tmp, entry);
                if (!got.exists()) { call.reject("entry not found"); return; }
                parent.mkdirs();
                InputStream is = new FileInputStream(got); OutputStream os = new FileOutputStream(out);
                byte[] bb = new byte[65536]; int rr; while ((rr = is.read(bb)) > 0) os.write(bb, 0, rr);
                is.close(); os.close(); got.delete();
                JSObject ret = new JSObject(); ret.put("path", out.getAbsolutePath()); call.resolve(ret); return;
            } catch (Exception e) {
                if (laEncErr(e)) { call.reject("Неверный пароль"); return; }
                call.reject("RAR5: " + (e.getMessage() != null ? e.getMessage() : "ошибка")); return;
            }
        }
        if (k0.equals("7z")) {
            try {
                File out = new File(dest);
                File parent = out.getParentFile() != null ? out.getParentFile() : new File(dest);
                java.util.Set<String> only = new java.util.HashSet<>(); only.add(entry);
                File tmp = new File(getContext().getCacheDir(), "sz1"); if (!tmp.exists()) tmp.mkdirs();
                sevenExtract(src0, tmp, only, password);
                File got = new File(tmp, entry);
                if (!got.exists()) { call.reject("entry not found"); return; }
                parent.mkdirs();
                InputStream is = new FileInputStream(got); OutputStream os = new FileOutputStream(out);
                byte[] bb = new byte[65536]; int rr; while ((rr = is.read(bb)) > 0) os.write(bb, 0, rr);
                is.close(); os.close(); got.delete();
                JSObject ret = new JSObject(); ret.put("path", out.getAbsolutePath()); call.resolve(ret); return;
            } catch (Exception e) { call.reject("7z: " + (e.getMessage() != null ? e.getMessage() : "ошибка")); return; }
        }
        if (k0.equals("bz2") || k0.equals("xz")) { call.reject("Формат " + k0 + " пока не поддерживается"); return; }
        if (k0.equals("rar")) {
            try {
                File out = new File(dest);
                File parent = out.getParentFile() != null ? out.getParentFile() : new File(dest);
                java.util.Set<String> only = new java.util.HashSet<>(); only.add(entry);
                File tmp = new File(getContext().getCacheDir(), "rar1"); if (!tmp.exists()) tmp.mkdirs();
                rarExtract(src0, tmp, only);
                File got = new File(tmp, entry);
                if (!got.exists()) { call.reject("entry not found"); return; }
                parent.mkdirs();
                InputStream is = new FileInputStream(got); OutputStream os = new FileOutputStream(out);
                byte[] bb = new byte[65536]; int rr; while ((rr = is.read(bb)) > 0) os.write(bb, 0, rr);
                is.close(); os.close(); got.delete();
                JSObject ret = new JSObject(); ret.put("path", out.getAbsolutePath()); call.resolve(ret); return;
            } catch (Exception e) { call.reject("RAR: " + (e.getMessage() != null ? e.getMessage() : "ошибка")); return; }
        }
        if (!k0.equals("zip")) {
            try {
                if (k0.equals("gz")) { gzExtract(src0, new File(dest)); }
                else { InputStream in = tarStream(src0, k0); java.util.Set<String> only = new java.util.HashSet<>(); only.add(entry); tarExtract(in, null, only, new File(dest), 1); in.close(); }
                JSObject ret = new JSObject(); ret.put("path", dest); call.resolve(ret); return;
            } catch (Exception e) { call.reject(e.getMessage()); return; }
        }
        if (zipIsEncrypted(src0)) {
            if (password == null) { call.reject("Требуется пароль", "ENCRYPTED"); return; }
            try {
                File out = new File(dest);
                String destDir = out.getParentFile() != null ? out.getParentFile().getAbsolutePath() : dest;
                java.util.List<String> one = new java.util.ArrayList<>(); one.add(entry);
                zip4jExtract(src0, destDir, one, password);
                JSObject ret = new JSObject(); ret.put("path", dest); call.resolve(ret); return;
            } catch (Exception e) { call.reject("Неверный пароль или ошибка", "BADPASS"); return; }
        }
        ZipFile zf = null;
        try {
            zf = new ZipFile(src0);
            ZipEntry ze = zf.getEntry(entry);
            if (ze == null) { call.reject("entry not found"); return; }
            File out = new File(dest);
            if (out.getParentFile() != null) out.getParentFile().mkdirs();
            InputStream in = zf.getInputStream(ze);
            OutputStream fos = new FileOutputStream(out);
            byte[] buf = new byte[65536];
            int n;
            while ((n = in.read(buf)) > 0) fos.write(buf, 0, n);
            fos.close(); in.close();
            JSObject ret = new JSObject();
            ret.put("path", out.getAbsolutePath());
            call.resolve(ret);
        } catch (Exception e) { call.reject(e.getMessage()); }
        finally { if (zf != null) try { zf.close(); } catch (Exception ignored) {} }
    }

    @PluginMethod
    public void zipExtractAll(PluginCall call) {
        String uriStr = call.getString("uri");
        String destDir = call.getString("dest");
        if (uriStr == null || destDir == null) { call.reject("bad args"); return; }
        JSArray names = call.getArray("entries");
        String password = call.getString("password");
        File src;
        try { src = arcFile(uriStr); } catch (Exception ve) { call.reject(ve.getMessage()); return; }
        String kA = arcKind(src);
        if (kA.equals("rar5")) {
            try {
                File dd = new File(destDir); dd.mkdirs();
                java.util.Set<String> onlyR = names != null ? new java.util.HashSet<String>() : null;
                if (onlyR != null) for (int i = 0; i < names.length(); i++) onlyR.add(String.valueOf(names.get(i)));
                laExtract(src, dd, onlyR, password);
                call.resolve(); return;
            } catch (Exception e) {
                if (laEncErr(e)) { call.reject("Неверный пароль"); return; }
                call.reject("RAR5: " + (e.getMessage() != null ? e.getMessage() : "ошибка")); return;
            }
        }
        if (kA.equals("7z")) {
            try {
                File dd = new File(destDir); dd.mkdirs();
                java.util.Set<String> onlyA = names != null ? new java.util.HashSet<String>() : null;
                if (onlyA != null) for (int i = 0; i < names.length(); i++) onlyA.add(String.valueOf(names.get(i)));
                sevenExtract(src, dd, onlyA, password);
                call.resolve(); return;
            } catch (Exception e) { call.reject("7z: " + (e.getMessage() != null ? e.getMessage() : "ошибка")); return; }
        }
        if (kA.equals("bz2") || kA.equals("xz")) { call.reject("Формат " + kA + " пока не поддерживается"); return; }
        if (kA.equals("rar")) {
            try {
                java.util.Set<String> only = null;
                if (names != null) { only = new java.util.HashSet<>(); for (int i = 0; i < names.length(); i++) only.add(names.getString(i)); }
                rarExtract(src, new File(destDir), only);
                JSObject ret = new JSObject(); ret.put("done", true); call.resolve(ret); return;
            } catch (Exception e) { call.reject("RAR: " + (e.getMessage() != null ? e.getMessage() : "ошибка")); return; }
        }
        if (!kA.equals("zip")) {
            try {
                if (kA.equals("gz")) {
                    File out = new File(destDir, gzBase(src)); gzExtract(src, out);
                    JSObject ev = new JSObject(); ev.put("done", 1); ev.put("total", 1); ev.put("name", gzBase(src)); notifyListeners("opProgress", ev);
                } else {
                    java.util.Set<String> only = null; int total = 0;
                    InputStream cin = tarStream(src, kA); java.util.List<String[]> es = tarEntries(cin); cin.close();
                    for (String[] e : es) if (!(e[2].equals("5") || e[0].endsWith("/"))) total++;
                    if (names != null) { only = new java.util.HashSet<>(); for (int i = 0; i < names.length(); i++) only.add(names.getString(i)); total = only.size(); }
                    InputStream in = tarStream(src, kA); tarExtract(in, new File(destDir), only, null, total); in.close();
                }
                JSObject ret = new JSObject(); ret.put("done", true); call.resolve(ret); return;
            } catch (Exception e) { call.reject(e.getMessage()); return; }
        }
        // архивы с паролем — через zip4j
        if (zipIsEncrypted(src)) {
            if (password == null) { call.reject("Требуется пароль", "ENCRYPTED"); return; }
            try {
                java.util.List<String> list = null;
                if (names != null) { list = new java.util.ArrayList<>(); for (int i = 0; i < names.length(); i++) list.add(names.getString(i)); }
                zip4jExtract(src, destDir, list, password);
                JSObject ret = new JSObject(); ret.put("done", true); call.resolve(ret); return;
            } catch (Exception e) { call.reject("Неверный пароль или ошибка", "BADPASS"); return; }
        }
        ZipFile zf = null;
        try {
            zf = new ZipFile(src);
            java.util.List<String> list = new java.util.ArrayList<>();
            if (names != null) {
                for (int i = 0; i < names.length(); i++) list.add(names.getString(i));
            } else {
                Enumeration<? extends ZipEntry> en = zf.entries();
                while (en.hasMoreElements()) { ZipEntry e = en.nextElement(); if (!e.isDirectory()) list.add(e.getName()); }
            }
            int total = list.size(), done = 0;
            byte[] buf = new byte[65536];
            for (String nm : list) {
                ZipEntry ze = zf.getEntry(nm);
                if (ze == null) continue;
                File out = new File(destDir, nm);
                if (ze.isDirectory()) { out.mkdirs(); continue; }
                if (out.getParentFile() != null) out.getParentFile().mkdirs();
                InputStream in = zf.getInputStream(ze);
                OutputStream fos = new ProgOut(new FileOutputStream(out), nm, done, total, ze.getSize());
                int n;
                while ((n = in.read(buf)) > 0) fos.write(buf, 0, n);
                fos.close(); in.close();
                done++;
            }
            call.resolve();
        } catch (Exception e) { call.reject(e.getMessage()); }
        finally { if (zf != null) try { zf.close(); } catch (Exception ignored) {} }
    }

    @PluginMethod
    public void zipCreate(final PluginCall call) {
        final String dir = call.getString("dir");
        final String name = call.getString("name");
        final com.getcapacitor.JSArray uris = call.getArray("uris");
        if (dir == null || name == null || uris == null) { call.reject("no args"); return; }
        new Thread(() -> {
            try {
                File out = new File(toFile(dir), name);
                if (out.exists()) out.delete();
                net.lingala.zip4j.ZipFile z = new net.lingala.zip4j.ZipFile(out);
                net.lingala.zip4j.model.ZipParameters pp = new net.lingala.zip4j.model.ZipParameters();
                z.setRunInThread(true);
                net.lingala.zip4j.progress.ProgressMonitor pm = z.getProgressMonitor();
                java.util.List<Object> list = uris.toList();
                java.util.List<File> files = new java.util.ArrayList<>();
                java.util.List<File> folders = new java.util.ArrayList<>();
                for (Object o : list) { File f = toFile(String.valueOf(o)); if (f != null && f.exists()) { if (f.isDirectory()) folders.add(f); else files.add(f); } }
                int ops = (files.isEmpty() ? 0 : 1) + folders.size(), done = 0;
                if (!files.isEmpty()) { z.addFiles(files, pp); waitZipOp(pm, name, done, ops); done++; }
                for (File folder : folders) { z.addFolder(folder, pp); waitZipOp(pm, name, done, ops); done++; }
                z.close();
                try { NotificationManager nm = (NotificationManager) getContext().getSystemService(Context.NOTIFICATION_SERVICE); nm.cancel(777); } catch (Exception ignored) {}
                JSObject fin = new JSObject(); fin.put("done", 100); fin.put("total", 100); fin.put("name", name); notifyListeners("opProgress", fin);
                JSObject r = new JSObject(); r.put("ok", true); r.put("dest", out.getAbsolutePath());
                call.resolve(r);
            } catch (Exception e) { try { NotificationManager nm = (NotificationManager) getContext().getSystemService(Context.NOTIFICATION_SERVICE); nm.cancel(777); } catch (Exception ignored) {} call.reject(e.getMessage()); }
        }).start();
    }

    private void waitZipOp(net.lingala.zip4j.progress.ProgressMonitor pm, String name, int opIndex, int ops) throws Exception {
        while (pm.getState() == net.lingala.zip4j.progress.ProgressMonitor.State.BUSY) {
            int pct = pm.getPercentDone();
            int overall = ops > 0 ? (int) ((opIndex * 100.0 + pct) / ops) : pct;
            if (overall > 99) overall = 99;
            postProgressNotif("Архивирование", name, overall, 100);
            JSObject ev = new JSObject(); ev.put("done", overall); ev.put("total", 100); ev.put("name", name); notifyListeners("opProgress", ev);
            Thread.sleep(120);
        }
        if (pm.getException() != null) throw pm.getException();
    }

    // ===== WebDAV (аккаунты в приватном getFilesDir — data/data, без рута недоступно) =====
    private File wdFile() { return new File(getContext().getFilesDir(), "webdav.json"); }
    private static String wdAuth(String u, String p) { return "Basic " + android.util.Base64.encodeToString((u + ":" + p).getBytes(), android.util.Base64.NO_WRAP); }
    private static void wdMethod(java.net.HttpURLConnection c, String m) {
        try { c.setRequestMethod(m); return; } catch (Exception e) {}
        try {
            Object t = c;
            try { java.lang.reflect.Field d = c.getClass().getDeclaredField("delegate"); d.setAccessible(true); Object dv = d.get(c); if (dv instanceof java.net.HttpURLConnection) t = dv; } catch (Exception ig) {}
            Class<?> k = t.getClass();
            while (k != null) { try { java.lang.reflect.Field mf = k.getDeclaredField("method"); mf.setAccessible(true); mf.set(t, m); return; } catch (Exception ig) { k = k.getSuperclass(); } }
        } catch (Exception e) {}
    }
    @PluginMethod
    public void webdavGetAccounts(PluginCall call) {
        JSObject o = new JSObject();
        try { File f = wdFile(); o.put("json", f.exists() ? new String(readAll(new java.io.FileInputStream(f)), "UTF-8") : "[]"); } catch (Exception e) { o.put("json", "[]"); }
        call.resolve(o);
    }
    @PluginMethod
    public void webdavSetAccounts(PluginCall call) {
        try { java.io.FileOutputStream fo = new java.io.FileOutputStream(wdFile()); fo.write(call.getString("json", "[]").getBytes("UTF-8")); fo.close(); call.resolve(); } catch (Exception e) { call.reject(e.getMessage()); }
    }
    @PluginMethod
    public void webdavList(PluginCall call) {
        try {
            String url = call.getString("url"), user = call.getString("user", ""), pass = call.getString("pass", "");
            java.net.HttpURLConnection c = (java.net.HttpURLConnection) new java.net.URL(url).openConnection();
            wdMethod(c, "PROPFIND");
            c.setRequestProperty("Depth", "1");
            c.setRequestProperty("Authorization", wdAuth(user, pass));
            c.setRequestProperty("Content-Type", "text/xml; charset=utf-8");
            c.setDoOutput(true); c.setConnectTimeout(15000); c.setReadTimeout(20000);
            byte[] body = "<?xml version=\"1.0\"?><d:propfind xmlns:d=\"DAV:\"><d:prop><d:resourcetype/><d:getcontentlength/></d:prop></d:propfind>".getBytes("UTF-8");
            c.getOutputStream().write(body); c.getOutputStream().close();
            int code = c.getResponseCode();
            if (code >= 400) { call.reject("HTTP " + code); return; }
            String xml = new String(readAll(c.getInputStream()), "UTF-8");
            com.getcapacitor.JSArray arr = new com.getcapacitor.JSArray();
            java.net.URL base = new java.net.URL(url);
            java.util.regex.Matcher rm = java.util.regex.Pattern.compile("(?is)<[a-z0-9]*:?response[ >](.*?)</[a-z0-9]*:?response>").matcher(xml);
            boolean first = true;
            while (rm.find()) {
                String blk = rm.group(1);
                java.util.regex.Matcher hm = java.util.regex.Pattern.compile("(?is)<[a-z0-9]*:?href[^>]*>(.*?)</[a-z0-9]*:?href>").matcher(blk);
                if (!hm.find()) continue;
                String href = hm.group(1).trim();
                boolean coll = java.util.regex.Pattern.compile("(?is)<[a-z0-9]*:?collection").matcher(blk).find();
                long size = 0;
                java.util.regex.Matcher sm = java.util.regex.Pattern.compile("(?is)<[a-z0-9]*:?getcontentlength[^>]*>(\\d+)").matcher(blk);
                if (sm.find()) size = Long.parseLong(sm.group(1));
                String full = href.startsWith("http") ? href : new java.net.URL(base, href).toString();
                String dec = java.net.URLDecoder.decode(href, "UTF-8").replaceAll("/+$", "");
                String name = dec.substring(dec.lastIndexOf('/') + 1);
                if (first) { first = false; continue; }
                if (name.isEmpty()) continue;
                JSObject o = new JSObject(); o.put("name", name); o.put("url", full); o.put("type", coll ? "directory" : "file"); o.put("size", size);
                arr.put(o);
            }
            JSObject r = new JSObject(); r.put("files", arr); call.resolve(r);
        } catch (Exception e) { call.reject(e.getMessage()); }
    }
    @PluginMethod
    public void webdavGet(PluginCall call) {
        try {
            String url = call.getString("url"), user = call.getString("user", ""), pass = call.getString("pass", ""), name = call.getString("name", "file"), dest = call.getString("dest", "");
            java.net.HttpURLConnection c = (java.net.HttpURLConnection) new java.net.URL(url).openConnection();
            c.setRequestProperty("Authorization", wdAuth(user, pass));
            c.setConnectTimeout(15000); c.setReadTimeout(30000);
            int code = c.getResponseCode();
            if (code >= 400) { call.reject("HTTP " + code); return; }
            File dl;
            if ("temp".equals(dest)) { File dir = new File(android.os.Environment.getExternalStorageDirectory(), "Download/.yevtmp"); if (!dir.exists()) dir.mkdirs(); dl = new File(dir, name); }
            else dl = new File(android.os.Environment.getExternalStoragePublicDirectory(android.os.Environment.DIRECTORY_DOWNLOADS), name);
            java.io.InputStream in = c.getInputStream(); java.io.FileOutputStream fo = new java.io.FileOutputStream(dl);
            byte[] buf = new byte[8192]; int n; while ((n = in.read(buf)) > 0) fo.write(buf, 0, n);
            fo.close(); in.close();
            JSObject r = new JSObject(); r.put("path", dl.getAbsolutePath()); r.put("uri", "file://" + dl.getAbsolutePath()); call.resolve(r);
        } catch (Exception e) { call.reject(e.getMessage()); }
    }

    // ===== Google Drive (OAuth PKCE, токен в приватном getFilesDir) =====
    private static final String GD_CID = "589335091963-6n9ss077f7htshue4vd288eb2t2jduhb.apps.googleusercontent.com";
    private static final String GD_REDIR = "com.googleusercontent.apps.589335091963-6n9ss077f7htshue4vd288eb2t2jduhb:/oauth";
    private String gdToken, gdRefresh; private long gdExp;
    private File gdFile() { return new File(getContext().getFilesDir(), "gdrive.json"); }
    private void gdLoad() {
        if (gdRefresh != null) return;
        try { File f = gdFile(); if (f.exists()) { org.json.JSONObject o = new org.json.JSONObject(new String(readAll(new java.io.FileInputStream(f)), "UTF-8")); gdToken = o.optString("access", null); gdRefresh = o.optString("refresh", null); gdExp = o.optLong("exp", 0); } } catch (Exception e) {}
    }
    private void gdSave() { try { org.json.JSONObject o = new org.json.JSONObject(); o.put("access", gdToken); o.put("refresh", gdRefresh); o.put("exp", gdExp); java.io.FileOutputStream fo = new java.io.FileOutputStream(gdFile()); fo.write(o.toString().getBytes("UTF-8")); fo.close(); } catch (Exception e) {} }
    private String httpPostForm(String url, String body) throws Exception {
        java.net.HttpURLConnection c = (java.net.HttpURLConnection) new java.net.URL(url).openConnection();
        c.setRequestMethod("POST"); c.setDoOutput(true); c.setRequestProperty("Content-Type", "application/x-www-form-urlencoded"); c.setConnectTimeout(15000); c.setReadTimeout(20000);
        c.getOutputStream().write(body.getBytes("UTF-8")); c.getOutputStream().close();
        int code = c.getResponseCode();
        String r = new String(readAll(code >= 400 ? c.getErrorStream() : c.getInputStream()), "UTF-8");
        if (code >= 400) throw new Exception(r);
        return r;
    }
    private void gdEnsure() throws Exception {
        gdLoad();
        if (gdToken != null && System.currentTimeMillis() < gdExp - 60000) return;
        if (gdRefresh == null) throw new Exception("not_authed");
        String body = "client_id=" + java.net.URLEncoder.encode(GD_CID, "UTF-8") + "&grant_type=refresh_token&refresh_token=" + java.net.URLEncoder.encode(gdRefresh, "UTF-8");
        org.json.JSONObject o = new org.json.JSONObject(httpPostForm("https://oauth2.googleapis.com/token", body));
        gdToken = o.getString("access_token"); gdExp = System.currentTimeMillis() + o.optLong("expires_in", 3600) * 1000; gdSave();
    }
    private String httpGetAuth(String url) throws Exception {
        gdEnsure();
        java.net.HttpURLConnection c = (java.net.HttpURLConnection) new java.net.URL(url).openConnection();
        c.setRequestProperty("Authorization", "Bearer " + gdToken); c.setConnectTimeout(15000); c.setReadTimeout(20000);
        int code = c.getResponseCode();
        String r = new String(readAll(code >= 400 ? c.getErrorStream() : c.getInputStream()), "UTF-8");
        if (code >= 400) throw new Exception(r);
        return r;
    }
    @PluginMethod
    public void openExternalUrl(PluginCall call) {
        try { Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(call.getString("url"))); i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); getContext().startActivity(i); call.resolve(); } catch (Exception e) { call.reject(e.getMessage()); }
    }
    @PluginMethod
    public void oauthConsume(PluginCall call) { JSObject o = new JSObject(); o.put("code", MainActivity.oauthCode); MainActivity.oauthCode = null; call.resolve(o); }
    @PluginMethod
    public void gdriveToken(PluginCall call) {
        try {
            String code = call.getString("code"), verifier = call.getString("verifier");
            String body = "client_id=" + java.net.URLEncoder.encode(GD_CID, "UTF-8") + "&code=" + java.net.URLEncoder.encode(code, "UTF-8") + "&code_verifier=" + java.net.URLEncoder.encode(verifier, "UTF-8") + "&grant_type=authorization_code&redirect_uri=" + java.net.URLEncoder.encode(GD_REDIR, "UTF-8");
            org.json.JSONObject o = new org.json.JSONObject(httpPostForm("https://oauth2.googleapis.com/token", body));
            gdToken = o.getString("access_token"); gdRefresh = o.optString("refresh_token", gdRefresh); gdExp = System.currentTimeMillis() + o.optLong("expires_in", 3600) * 1000; gdSave();
            JSObject r = new JSObject(); r.put("ok", true); call.resolve(r);
        } catch (Exception e) { call.reject(e.getMessage()); }
    }
    @PluginMethod
    public void gdriveLoggedIn(PluginCall call) { gdLoad(); JSObject o = new JSObject(); o.put("yes", gdRefresh != null); call.resolve(o); }
    @PluginMethod
    public void gdriveLogout(PluginCall call) { gdToken = null; gdRefresh = null; gdExp = 0; try { gdFile().delete(); } catch (Exception e) {} call.resolve(); }
    @PluginMethod
    public void gdriveDelete(PluginCall call) {
        String id = call.getString("id");
        if (id == null) { call.reject("no id"); return; }
        try {
            gdEnsure();
            java.net.HttpURLConnection c = (java.net.HttpURLConnection) new java.net.URL("https://www.googleapis.com/drive/v3/files/" + java.net.URLEncoder.encode(id, "UTF-8")).openConnection();
            c.setRequestMethod("DELETE");
            c.setRequestProperty("Authorization", "Bearer " + gdToken);
            c.setConnectTimeout(15000); c.setReadTimeout(20000);
            int code = c.getResponseCode();
            if (code >= 400) {
                String r = new String(readAll(c.getErrorStream()), "UTF-8");
                call.reject(r); return;
            }
            JSObject ret = new JSObject(); ret.put("ok", true); call.resolve(ret);
        } catch (Exception e) { call.reject(e.getMessage()); }
    }

    @PluginMethod
    public void gdriveMkdir(PluginCall call) {
        try {
            String parent = call.getString("folder", "root");
            String name = call.getString("name", "Новая папка");
            gdEnsure();
            java.net.HttpURLConnection c = (java.net.HttpURLConnection) new java.net.URL("https://www.googleapis.com/drive/v3/files?fields=id,name,mimeType").openConnection();
            c.setRequestMethod("POST");
            c.setRequestProperty("Authorization", "Bearer " + gdToken);
            c.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
            c.setConnectTimeout(15000); c.setReadTimeout(20000); c.setDoOutput(true);
            org.json.JSONObject body = new org.json.JSONObject();
            body.put("name", name);
            body.put("mimeType", "application/vnd.google-apps.folder");
            body.put("parents", new org.json.JSONArray().put(parent));
            OutputStream os = c.getOutputStream(); os.write(body.toString().getBytes("UTF-8")); os.close();
            int code = c.getResponseCode();
            String r = new String(readAll(code >= 400 ? c.getErrorStream() : c.getInputStream()), "UTF-8");
            if (code >= 400) { call.reject(r); return; }
            org.json.JSONObject f = new org.json.JSONObject(r);
            JSObject ret = new JSObject(); ret.put("id", f.optString("id")); ret.put("name", f.optString("name"));
            call.resolve(ret);
        } catch (Exception e) { call.reject(e.getMessage()); }
    }

    @PluginMethod
    public void gdriveThumb(PluginCall call) {
        String id = call.getString("id");
        String link = call.getString("link");
        if (id == null || link == null) { call.reject("no args"); return; }
        try {
            File cf = new File(thumbDir(), "gd_" + Integer.toHexString(id.hashCode()) + ".t");
            if (cf.exists() && cf.length() > 0) {
                byte[] b = new byte[(int) cf.length()];
                InputStream in = new FileInputStream(cf); int off = 0; while (off < b.length) { int r = in.read(b, off, b.length - off); if (r < 0) break; off += r; } in.close();
                JSObject ret = new JSObject(); ret.put("thumb", "data:image/jpeg;base64," + android.util.Base64.encodeToString(b, android.util.Base64.NO_WRAP)); call.resolve(ret); return;
            }
            gdEnsure();
            java.net.HttpURLConnection c = (java.net.HttpURLConnection) new java.net.URL(link).openConnection();
            c.setRequestProperty("Authorization", "Bearer " + gdToken);
            c.setConnectTimeout(15000); c.setReadTimeout(20000); c.setInstanceFollowRedirects(true);
            int code = c.getResponseCode();
            byte[] b = readAll(code >= 400 ? c.getErrorStream() : c.getInputStream());
            if (code >= 400) { call.reject("thumb " + code); return; }
            try { OutputStream os = new FileOutputStream(cf); os.write(b); os.close(); } catch (Exception ignored) {}
            JSObject ret = new JSObject(); ret.put("thumb", "data:image/jpeg;base64," + android.util.Base64.encodeToString(b, android.util.Base64.NO_WRAP));
            call.resolve(ret);
        } catch (Exception e) { call.reject(e.getMessage()); }
    }

    @PluginMethod
    public void gdriveList(PluginCall call) {
        try {
            String folder = call.getString("folder", "root");
            String q = java.net.URLEncoder.encode("'" + folder + "' in parents and trashed=false", "UTF-8");
            String url = "https://www.googleapis.com/drive/v3/files?q=" + q + "&fields=" + java.net.URLEncoder.encode("files(id,name,mimeType,size,thumbnailLink)", "UTF-8") + "&pageSize=1000&orderBy=folder,name";
            org.json.JSONObject o = new org.json.JSONObject(httpGetAuth(url));
            org.json.JSONArray files = o.optJSONArray("files");
            com.getcapacitor.JSArray arr = new com.getcapacitor.JSArray();
            if (files != null) for (int i = 0; i < files.length(); i++) {
                org.json.JSONObject f = files.getJSONObject(i);
                boolean dir = "application/vnd.google-apps.folder".equals(f.optString("mimeType"));
                JSObject e = new JSObject();
                e.put("id", f.getString("id")); e.put("name", f.optString("name")); e.put("type", dir ? "directory" : "file"); e.put("size", f.optLong("size", 0)); e.put("mime", f.optString("mimeType")); String tl = f.optString("thumbnailLink", null); if (tl != null && !tl.isEmpty()) e.put("thumb", tl);
                arr.put(e);
            }
            JSObject r = new JSObject(); r.put("files", arr); call.resolve(r);
        } catch (Exception e) { call.reject(e.getMessage()); }
    }
    @PluginMethod
    public void gdriveGet(PluginCall call) {
        try {
            gdEnsure();
            String id = call.getString("id"), name = call.getString("name", "file"), mime = call.getString("mime", ""), dest = call.getString("dest", "");
            boolean gdoc = mime.startsWith("application/vnd.google-apps");
            String url = gdoc ? "https://www.googleapis.com/drive/v3/files/" + id + "/export?mimeType=application%2Fpdf" : "https://www.googleapis.com/drive/v3/files/" + id + "?alt=media&acknowledgeAbuse=true";
            java.net.HttpURLConnection c = (java.net.HttpURLConnection) new java.net.URL(url).openConnection();
            c.setRequestProperty("Authorization", "Bearer " + gdToken); c.setConnectTimeout(15000); c.setReadTimeout(60000);
            int code = c.getResponseCode(); if (code >= 400) { call.reject("HTTP " + code); return; }
            if (gdoc && !name.toLowerCase().endsWith(".pdf")) name = name + ".pdf";
            File dl;
            if ("temp".equals(dest)) { File dir = new File(android.os.Environment.getExternalStorageDirectory(), "Download/.yevtmp"); if (!dir.exists()) dir.mkdirs(); dl = new File(dir, name); }
            else dl = new File(android.os.Environment.getExternalStoragePublicDirectory(android.os.Environment.DIRECTORY_DOWNLOADS), name);
            java.io.InputStream in = c.getInputStream(); java.io.FileOutputStream fo = new java.io.FileOutputStream(dl);
            byte[] buf = new byte[8192]; int n; while ((n = in.read(buf)) > 0) fo.write(buf, 0, n); fo.close(); in.close();
            JSObject r = new JSObject(); r.put("path", dl.getAbsolutePath()); r.put("uri", "file://" + dl.getAbsolutePath()); call.resolve(r);
        } catch (Exception e) { call.reject(e.getMessage()); }
    }

    private org.json.JSONObject gdJson(String url) throws Exception {
        java.net.HttpURLConnection c = (java.net.HttpURLConnection) new java.net.URL(url).openConnection();
        c.setRequestProperty("Authorization", "Bearer " + gdToken); c.setConnectTimeout(15000); c.setReadTimeout(30000);
        int code = c.getResponseCode();
        java.io.InputStream is = code >= 400 ? c.getErrorStream() : c.getInputStream();
        String body = new String(readAll(is), "UTF-8");
        if (code >= 400) throw new Exception("HTTP " + code);
        return new org.json.JSONObject(body);
    }

    @PluginMethod
    public void gdriveChanges(PluginCall call) {
        try {
            gdEnsure();
            String token = call.getString("token", "");
            JSObject res = new JSObject();
            if (token == null || token.isEmpty()) {
                org.json.JSONObject o = gdJson("https://www.googleapis.com/drive/v3/changes/startPageToken");
                res.put("changed", false); res.put("token", o.optString("startPageToken", "")); call.resolve(res); return;
            }
            boolean changed = false; String page = token, next = token;
            for (int guard = 0; guard < 50 && page != null && !page.isEmpty(); guard++) {
                org.json.JSONObject o = gdJson("https://www.googleapis.com/drive/v3/changes?pageToken=" + page + "&pageSize=200&fields=newStartPageToken,nextPageToken,changes(fileId)");
                org.json.JSONArray ch = o.optJSONArray("changes");
                if (ch != null && ch.length() > 0) changed = true;
                String np = o.optString("nextPageToken", "");
                if (!np.isEmpty()) page = np;
                else { next = o.optString("newStartPageToken", token); page = null; }
            }
            res.put("changed", changed); res.put("token", next); call.resolve(res);
        } catch (Exception e) { call.reject(e.getMessage()); }
    }

    @PluginMethod
    public void openUrl(PluginCall call) {
        String url = call.getString("url");
        String mime = call.getString("mime", "*/*");
        if (url == null) { call.reject("no url"); return; }
        try {
            Uri data = Uri.parse(url);
            Intent i = new Intent(Intent.ACTION_VIEW);
            if (mime != null && !mime.isEmpty()) i.setDataAndType(data, mime); else i.setData(data);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            Intent chooser = Intent.createChooser(i, "Открыть");
            chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            getContext().startActivity(chooser);
            call.resolve();
        } catch (Exception e) { call.reject(e.getMessage()); }
    }

    @PluginMethod
    public void gdriveLink(PluginCall call) {
        try {
            gdEnsure();
            String id = call.getString("id");
            String url = "https://www.googleapis.com/drive/v3/files/" + id + "?alt=media&acknowledgeAbuse=true&access_token=" + gdToken;
            JSObject r = new JSObject(); r.put("url", url); call.resolve(r);
        } catch (Exception e) { call.reject(e.getMessage()); }
    }

    @PluginMethod
    public void copyText(PluginCall call) {
        try {
            String text = call.getString("text", "");
            android.content.ClipboardManager cm = (android.content.ClipboardManager) getContext().getSystemService(android.content.Context.CLIPBOARD_SERVICE);
            cm.setPrimaryClip(android.content.ClipData.newPlainText("text", text));
            call.resolve();
        } catch (Exception e) { call.reject(e.getMessage()); }
    }

    @PluginMethod
    public void pathSize(final PluginCall call) {
        String uriStr = call.getString("uri");
        if (uriStr == null) { call.reject("no uri"); return; }
        final File root = toFile(uriStr);
        new Thread(new Runnable() {
            public void run() {
                final long[] acc = { 0L, 0L };
                sizeRecursive(root, acc);
                try { getActivity().runOnUiThread(new Runnable() { public void run() {
                    JSObject r = new JSObject(); r.put("bytes", acc[0]); r.put("count", acc[1]); call.resolve(r);
                } }); } catch (Exception e) { JSObject r = new JSObject(); r.put("bytes", acc[0]); r.put("count", acc[1]); call.resolve(r); }
            }
        }).start();
    }

    private void sizeRecursive(File f, long[] acc) {
        try {
            if (f.isDirectory()) {
                File[] kids = f.listFiles();
                if (kids != null) for (File k : kids) sizeRecursive(k, acc);
            } else { acc[0] += f.length(); acc[1]++; }
        } catch (Exception ignored) {}
    }

    @PluginMethod
    public void deletePath(final PluginCall call) {
        String uriStr = call.getString("uri");
        if (uriStr == null) { call.reject("no uri"); return; }
        final File root = toFile(uriStr);
        new Thread(new Runnable() {
            public void run() {
                delDone = 0; delLastEv = 0;
                delTotal = root.isDirectory() ? delCount(root) : 1;
                final boolean ok;
                if (Build.VERSION.SDK_INT >= 26) ok = deleteNio(root);
                else ok = deleteRecursiveCounted(root);
                try { getActivity().runOnUiThread(new Runnable() { public void run() {
                    JSObject r = new JSObject(); r.put("ok", ok); call.resolve(r);
                } }); } catch (Exception e) { JSObject r = new JSObject(); r.put("ok", ok); call.resolve(r); }
            }
        }).start();
    }

    private long delDone = 0, delTotal = 0, delLastEv = 0;

    private long delCount(File f) {
        long n = 1;
        if (f.isDirectory()) { File[] k = f.listFiles(); if (k != null) for (File x : k) n += delCount(x); }
        return n;
    }

    private void delTick(String name) {
        delDone++;
        long now = System.currentTimeMillis();
        if (now - delLastEv >= 90 || delDone >= delTotal) {
            delLastEv = now;
            JSObject ev = new JSObject();
            ev.put("done", (int) Math.min(2147483647L, delDone));
            ev.put("total", (int) Math.min(2147483647L, delTotal));
            ev.put("name", name != null ? name : "");
            notifyListeners("opProgress", ev);
        }
    }

    private boolean deleteRecursiveCounted(File f) {
        if (f.isDirectory()) {
            File[] kids = f.listFiles();
            if (kids != null) for (File k : kids) deleteRecursiveCounted(k);
        }
        boolean ok = f.delete();
        delTick(f.getName());
        return ok;
    }

    // мелкие файлы пачками быстрее через nio: меньше объектов, один системный обход
    private boolean deleteNio(File root) {
        try {
            java.nio.file.Files.walkFileTree(root.toPath(), new java.nio.file.SimpleFileVisitor<java.nio.file.Path>() {
                @Override public java.nio.file.FileVisitResult visitFile(java.nio.file.Path file, java.nio.file.attribute.BasicFileAttributes attrs) {
                    try { java.nio.file.Files.delete(file); } catch (Exception ignored) {}
                    delTick(file.getFileName() != null ? file.getFileName().toString() : "");
                    return java.nio.file.FileVisitResult.CONTINUE;
                }
                @Override public java.nio.file.FileVisitResult postVisitDirectory(java.nio.file.Path dir, java.io.IOException exc) {
                    try { java.nio.file.Files.delete(dir); } catch (Exception ignored) {}
                    delTick(dir.getFileName() != null ? dir.getFileName().toString() : "");
                    return java.nio.file.FileVisitResult.CONTINUE;
                }
                @Override public java.nio.file.FileVisitResult visitFileFailed(java.nio.file.Path file, java.io.IOException exc) {
                    return java.nio.file.FileVisitResult.CONTINUE;
                }
            });
        } catch (Exception ignored) {}
        return !root.exists();
    }

    @PluginMethod
    public void share(PluginCall call) {
        String uriStr = call.getString("uri");
        String mime = call.getString("mime", "*/*");
        if (uriStr == null) { call.reject("no uri"); return; }
        try {
            File f = toFile(uriStr);
            if (!f.exists()) { call.reject("Файл не найден"); return; }
            try { StrictMode.setVmPolicy(new StrictMode.VmPolicy.Builder().build()); } catch (Exception ignored) {}
            Intent i = new Intent(Intent.ACTION_SEND);
            i.setType(mime);
            i.putExtra(Intent.EXTRA_STREAM, contentUriFor(f));
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            Intent ch = Intent.createChooser(i, "Поделиться");
            ch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            getContext().startActivity(ch);
            call.resolve();
        } catch (Exception e) { call.reject(e.getMessage()); }
    }

    @PluginMethod
    public void editImage(PluginCall call) {
        String uriStr = call.getString("uri");
        String mime = call.getString("mime", "image/*");
        if (uriStr == null) { call.reject("no uri"); return; }
        try {
            File f = toFile(uriStr);
            if (!f.exists()) { call.reject("Файл не найден"); return; }
            try { StrictMode.setVmPolicy(new StrictMode.VmPolicy.Builder().build()); } catch (Exception ignored) {}
            Intent i = new Intent(Intent.ACTION_EDIT);
            Uri u = contentUriFor(f);
            i.setDataAndType(u, mime);
            i.setClipData(android.content.ClipData.newRawUri("", u));
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
            Intent ch = Intent.createChooser(i, "Изменить через");
            ch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            getContext().startActivity(ch);
            call.resolve();
        } catch (Exception e) { call.reject(e.getMessage()); }
    }

    @PluginMethod
    public void setBars(PluginCall call) {
        final String color = call.getString("color", "#000000");
        final boolean light = call.getBoolean("light", false);
        try {
            getActivity().runOnUiThread(() -> {
                try {
                    Window w = getActivity().getWindow();
                    int c = Color.parseColor(color);
                    w.setStatusBarColor(c);
                    w.setNavigationBarColor(c);
                    View dv = w.getDecorView();
                    int flags = dv.getSystemUiVisibility();
                    if (Build.VERSION.SDK_INT >= 23) {
                        if (light) flags |= View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
                        else flags &= ~View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
                    }
                    if (Build.VERSION.SDK_INT >= 26) {
                        if (light) flags |= View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
                        else flags &= ~View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
                    }
                    dv.setSystemUiVisibility(flags);
                } catch (Exception ignored) {}
            });
        } catch (Exception ignored) {}
        call.resolve();
    }

    @PluginMethod
    public void unwatch(PluginCall call) {
        if (observer != null) { observer.stopWatching(); observer = null; }
        call.resolve();
    }

    private boolean deleteRecursive(File f) {
        if (f.isDirectory()) {
            File[] kids = f.listFiles();
            if (kids != null) for (File k : kids) deleteRecursive(k);
        }
        return f.delete();
    }

    private File toFile(String u) {
        String p = u;
        if (p.startsWith("file://")) p = p.substring(7);
        if (p.indexOf('%') >= 0) { try { p = java.net.URLDecoder.decode(p, "UTF-8"); } catch (Exception ignored) {} }
        return new File(p);
    }

    private Uri contentUriFor(File f) {
        String pkg = getContext().getPackageName();
        // основной: провайдер Capacitor (.fileprovider) — он гарантированно зарегистрирован;
        // его пути переопределены нашим file_paths.xml (весь storage)
        try { return FileProvider.getUriForFile(getContext(), pkg + ".fileprovider", f); } catch (Exception ignored) {}
        try { return FileProvider.getUriForFile(getContext(), pkg + ".appsfp", f); } catch (Exception ignored) {}
        try { StrictMode.setVmPolicy(new StrictMode.VmPolicy.Builder().build()); } catch (Exception ignored) {}
        return Uri.fromFile(f);
    }

    private String drawableToBase64(Drawable d) {
        Bitmap b = drawableToBitmap(d);
        if (b == null) return null;
        int mx = Math.max(b.getWidth(), b.getHeight());
        if (mx > 144) { float sc = 144f / mx; b = Bitmap.createScaledBitmap(b, Math.max(1, Math.round(b.getWidth() * sc)), Math.max(1, Math.round(b.getHeight() * sc)), true); }
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        b.compress(Bitmap.CompressFormat.PNG, 100, out);
        return "data:image/png;base64," + Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP);
    }

    // ===== АУДИОПЛЕЕР =====
    private android.media.MediaPlayer amp;
    private final java.util.List<String> plUris = new java.util.ArrayList<>();
    private final java.util.List<String> plNames = new java.util.ArrayList<>();
    private int plIdx = 0;
    private boolean autoNext = false;
    private android.media.session.MediaSession aSession;
    private BroadcastReceiver aRcv;
    private static final int A_NOTIF = 47110;
    private static final String A_ACT = "leshugan.fm.AUDIO_CMD";

    private void aEnsureReceiver() {
        if (aRcv != null) return;
        aRcv = new BroadcastReceiver() {
            public void onReceive(android.content.Context c, Intent i) {
                String cmd = i.getStringExtra("cmd");
                if ("toggle".equals(cmd)) aToggleInternal();
                else if ("next".equals(cmd)) aPlayIndex(plIdx + 1);
                else if ("prev".equals(cmd)) aPlayIndex(plIdx - 1);
                else if ("close".equals(cmd)) aStopInternal();
            }
        };
        android.content.IntentFilter f = new android.content.IntentFilter(A_ACT);
        if (android.os.Build.VERSION.SDK_INT >= 33) getContext().registerReceiver(aRcv, f, android.content.Context.RECEIVER_NOT_EXPORTED);
        else getContext().registerReceiver(aRcv, f);
    }

    private android.app.PendingIntent aPI(String cmd) {
        Intent i = new Intent(A_ACT).setPackage(getContext().getPackageName());
        i.putExtra("cmd", cmd);
        int fl = android.app.PendingIntent.FLAG_UPDATE_CURRENT | (android.os.Build.VERSION.SDK_INT >= 23 ? android.app.PendingIntent.FLAG_IMMUTABLE : 0);
        return android.app.PendingIntent.getBroadcast(getContext(), cmd.hashCode(), i, fl);
    }

    private void aNotify() {
        try {
            android.app.NotificationManager nm = (android.app.NotificationManager) getContext().getSystemService(android.content.Context.NOTIFICATION_SERVICE);
            if (android.os.Build.VERSION.SDK_INT >= 26 && nm.getNotificationChannel("audio") == null) {
                android.app.NotificationChannel ch = new android.app.NotificationChannel("audio", "Плеер", android.app.NotificationManager.IMPORTANCE_LOW);
                ch.setShowBadge(false); nm.createNotificationChannel(ch);
            }
            boolean playing = amp != null && amp.isPlaying();
            String name = plIdx >= 0 && plIdx < plNames.size() ? plNames.get(plIdx) : "";
            if (aSession == null) aSession = new android.media.session.MediaSession(getContext(), "yevfm");
            Intent open = getContext().getPackageManager().getLaunchIntentForPackage(getContext().getPackageName());
            android.app.PendingIntent contentPI = android.app.PendingIntent.getActivity(getContext(), 0, open, android.os.Build.VERSION.SDK_INT >= 23 ? android.app.PendingIntent.FLAG_IMMUTABLE : 0);
            android.app.Notification.Builder b = android.os.Build.VERSION.SDK_INT >= 26 ? new android.app.Notification.Builder(getContext(), "audio") : new android.app.Notification.Builder(getContext());
            b.setSmallIcon(android.R.drawable.ic_media_play).setContentTitle(name).setContentText("YevFiles").setContentIntent(contentPI).setOngoing(playing).setVisibility(android.app.Notification.VISIBILITY_PUBLIC);
            b.addAction(new android.app.Notification.Action.Builder(android.graphics.drawable.Icon.createWithResource(getContext(), android.R.drawable.ic_media_previous), "prev", aPI("prev")).build());
            b.addAction(new android.app.Notification.Action.Builder(android.graphics.drawable.Icon.createWithResource(getContext(), playing ? android.R.drawable.ic_media_pause : android.R.drawable.ic_media_play), "toggle", aPI("toggle")).build());
            b.addAction(new android.app.Notification.Action.Builder(android.graphics.drawable.Icon.createWithResource(getContext(), android.R.drawable.ic_media_next), "next", aPI("next")).build());
            b.addAction(new android.app.Notification.Action.Builder(android.graphics.drawable.Icon.createWithResource(getContext(), android.R.drawable.ic_menu_close_clear_cancel), "close", aPI("close")).build());
            android.app.Notification.MediaStyle st = new android.app.Notification.MediaStyle().setShowActionsInCompactView(0, 1, 2);
            st.setMediaSession(aSession.getSessionToken());
            b.setStyle(st);
            nm.notify(A_NOTIF, b.build());
        } catch (Exception ignored) {}
    }

    private void aPlayIndex(int idx) {
        if (idx < 0) return;
        if (idx >= plUris.size()) { aStopInternal(); return; }
        plIdx = idx;
        try {
            if (amp == null) amp = new android.media.MediaPlayer();
            else amp.reset();
            String uri = plUris.get(idx);
            if (uri.startsWith("content://")) amp.setDataSource(getContext(), android.net.Uri.parse(uri));
            else amp.setDataSource(toFile(uri).getAbsolutePath());
            amp.setOnCompletionListener(new android.media.MediaPlayer.OnCompletionListener() {
                public void onCompletion(android.media.MediaPlayer m) { if (autoNext) aPlayIndex(plIdx + 1); else aNotify(); }
            });
            amp.prepare();
            amp.start();
            aEnsureReceiver();
            aNotify();
        } catch (Exception e) {}
    }

    private void aToggleInternal() {
        if (amp == null) return;
        try { if (amp.isPlaying()) amp.pause(); else amp.start(); } catch (Exception e) {}
        aNotify();
    }

    private void aStopInternal() {
        try { if (amp != null) { amp.stop(); amp.release(); } } catch (Exception e) {}
        amp = null;
        try { ((android.app.NotificationManager) getContext().getSystemService(android.content.Context.NOTIFICATION_SERVICE)).cancel(A_NOTIF); } catch (Exception e) {}
    }

    @PluginMethod
    public void audioOpen(PluginCall call) {
        try {
            plUris.clear(); plNames.clear();
            JSArray us = call.getArray("uris"), ns = call.getArray("names");
            for (int i = 0; i < us.length(); i++) plUris.add(us.getString(i));
            for (int i = 0; i < ns.length(); i++) plNames.add(ns.getString(i));
            autoNext = call.getBoolean("autoNext", false);
            aPlayIndex(call.getInt("index", 0));
            call.resolve();
        } catch (Exception e) { call.reject(e.getMessage()); }
    }

    @PluginMethod public void audioToggle(PluginCall call) { aToggleInternal(); call.resolve(); }
    @PluginMethod public void audioNext(PluginCall call) { aPlayIndex(plIdx + 1); call.resolve(); }
    @PluginMethod public void audioPrev(PluginCall call) { aPlayIndex(plIdx - 1); call.resolve(); }
    @PluginMethod public void audioSeek(PluginCall call) { try { if (amp != null) amp.seekTo(call.getInt("ms", 0)); } catch (Exception e) {} call.resolve(); }
    @PluginMethod public void audioClose(PluginCall call) { aStopInternal(); call.resolve(); }
    @PluginMethod public void audioConfig(PluginCall call) { autoNext = call.getBoolean("autoNext", autoNext); call.resolve(); }

    @PluginMethod
    public void audioState(PluginCall call) {
        JSObject o = new JSObject();
        try {
            o.put("playing", amp != null && amp.isPlaying());
            o.put("pos", amp != null ? amp.getCurrentPosition() : 0);
            o.put("dur", amp != null ? amp.getDuration() : 0);
            o.put("idx", plIdx);
            o.put("count", plUris.size());
            o.put("name", plIdx >= 0 && plIdx < plNames.size() ? plNames.get(plIdx) : "");
            o.put("alive", amp != null);
        } catch (Exception e) { o.put("alive", amp != null); }
        call.resolve(o);
    }

    @PluginMethod
    public void audioSetAs(PluginCall call) {
        try {
            String uri = call.getString("uri");
            String type = call.getString("type", "ringtone");
            if (android.os.Build.VERSION.SDK_INT >= 23 && !android.provider.Settings.System.canWrite(getContext())) {
                Intent i = new Intent(android.provider.Settings.ACTION_MANAGE_WRITE_SETTINGS);
                i.setData(android.net.Uri.parse("package:" + getContext().getPackageName()));
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                getContext().startActivity(i);
                call.reject("need_write_settings");
                return;
            }
            File f = toFile(uri);
            boolean alarm = "alarm".equals(type);
            android.net.Uri base = android.provider.MediaStore.Audio.Media.getContentUriForPath(f.getAbsolutePath());
            android.net.Uri newUri = null;
            try {
                android.database.Cursor c = getContext().getContentResolver().query(base, new String[]{ android.provider.MediaStore.MediaColumns._ID }, android.provider.MediaStore.MediaColumns.DATA + "=?", new String[]{ f.getAbsolutePath() }, null);
                if (c != null) { if (c.moveToFirst()) newUri = android.net.Uri.withAppendedPath(base, c.getString(0)); c.close(); }
            } catch (Exception ignored) {}
            android.content.ContentValues cv = new android.content.ContentValues();
            cv.put(android.provider.MediaStore.Audio.Media.IS_RINGTONE, !alarm);
            cv.put(android.provider.MediaStore.Audio.Media.IS_ALARM, alarm);
            cv.put(android.provider.MediaStore.Audio.Media.IS_NOTIFICATION, false);
            if (newUri != null) {
                getContext().getContentResolver().update(newUri, cv, null, null);
            } else {
                cv.put(android.provider.MediaStore.MediaColumns.DATA, f.getAbsolutePath());
                cv.put(android.provider.MediaStore.MediaColumns.TITLE, f.getName());
                cv.put(android.provider.MediaStore.MediaColumns.MIME_TYPE, "audio/mpeg");
                newUri = getContext().getContentResolver().insert(base, cv);
            }
            android.media.RingtoneManager.setActualDefaultRingtoneUri(getContext(), alarm ? android.media.RingtoneManager.TYPE_ALARM : android.media.RingtoneManager.TYPE_RINGTONE, newUri);
            JSObject o = new JSObject(); o.put("ok", true); call.resolve(o);
        } catch (Exception e) { call.reject(e.getMessage()); }
    }
}
