package leshugan.fm;

import android.content.Intent;
import android.content.IntentFilter;
import android.content.Context;
import android.content.BroadcastReceiver;
import android.content.pm.PackageManager;
import android.content.pm.PackageInfo;
import android.content.pm.PackageInstaller;
import android.content.pm.ResolveInfo;
import android.os.FileObserver;
import android.os.Parcelable;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.IntentSender;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.view.Window;
import android.view.View;
import android.graphics.Color;
import android.os.Build;
import android.os.StrictMode;
import android.os.Environment;
import android.provider.Settings;
import android.util.Base64;

import androidx.core.content.FileProvider;


import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import com.getcapacitor.annotation.ActivityCallback;
import androidx.activity.result.ActivityResult;
import androidx.documentfile.provider.DocumentFile;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Enumeration;
import java.util.zip.ZipFile;
import java.util.zip.ZipEntry;
import java.io.OutputStream;
import java.util.List;

@CapacitorPlugin(name = "Apps")
public class AppsPlugin extends Plugin {

    private FileObserver observer;
    private boolean instRegistered = false;

    // ---- Уведомление системы о появившихся/изменившихся файлах ----
    // Без этого скопированное или скачанное фото не видно в галерее до переиндексации
    @PluginMethod
    public void scanMedia(PluginCall call) {
        JSArray a = call.getArray("paths");
        final java.util.List<String> list = new java.util.ArrayList<>();
        try {
            if (a != null) for (Object o : a.toList()) { String v = String.valueOf(o); if (v != null && v.length() > 0) list.add(toFile(v).getAbsolutePath()); }
        } catch (Exception ignored) {}
        String one = call.getString("path");
        if (one != null) { try { list.add(toFile(one).getAbsolutePath()); } catch (Exception ignored) {} }
        call.resolve();
        if (list.isEmpty()) return;
        try {
            android.media.MediaScannerConnection.scanFile(getContext(), list.toArray(new String[0]), null, null);
        } catch (Throwable ignored) {}
    }

    // ---- Слежение за изменениями снаружи приложения ----
    private android.database.ContentObserver mediaObserver;

    @PluginMethod
    public void watchMedia(PluginCall call) {
        try {
            if (mediaObserver == null) {
                android.os.Handler h = new android.os.Handler(android.os.Looper.getMainLooper());
                mediaObserver = new android.database.ContentObserver(h) {
                    private long last = 0;
                    @Override public void onChange(boolean self) {
                        long now = System.currentTimeMillis();
                        if (now - last < 1500) return; // дебаунс: система шлёт события пачками
                        last = now;
                        notifyListeners("mediaChanged", new JSObject());
                    }
                };
                android.content.ContentResolver cr = getContext().getContentResolver();
                cr.registerContentObserver(android.provider.MediaStore.Files.getContentUri("external"), true, mediaObserver);
                cr.registerContentObserver(android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI, true, mediaObserver);
                cr.registerContentObserver(android.provider.MediaStore.Video.Media.EXTERNAL_CONTENT_URI, true, mediaObserver);
            }
            call.resolve();
        } catch (Throwable t) { call.resolve(); }
    }

    // ---- Фоновая подготовка превью ----
    private java.util.concurrent.ExecutorService warmPool;

    @PluginMethod
    public void warmThumbs(PluginCall call) {
        JSArray a = call.getArray("uris");
        final java.util.List<String> uris = new java.util.ArrayList<>();
        if (a != null) { try { for (Object o : a.toList()) uris.add(String.valueOf(o)); } catch (Exception ignored) {} }
        call.resolve();
        if (warmPool != null) warmPool.shutdownNow(); // прошлая пачка больше не актуальна
        if (uris.isEmpty()) return;
        int cores = Runtime.getRuntime().availableProcessors();
        int n = Math.max(1, Math.min(4, cores - 2));
        warmPool = java.util.concurrent.Executors.newFixedThreadPool(n);
        for (final String u : uris) {
            warmPool.execute(new Runnable() {
                @Override public void run() {
                    if (Thread.currentThread().isInterrupted()) return;
                    try { warmOne(u); } catch (Throwable ignored) {}
                }
            });
        }
        warmPool.shutdown();
    }

    // Кадр из видео для превью: пробуем несколько моментов и берём не-чёрный,
    // иначе у роликов с тёмным началом превью выходит чёрным
    private Bitmap videoFrame(File f) {
        android.media.MediaMetadataRetriever mmr = new android.media.MediaMetadataRetriever();
        try {
            mmr.setDataSource(f.getAbsolutePath());
            long durMs = 0;
            try { String d = mmr.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_DURATION); if (d != null) durMs = Long.parseLong(d); } catch (Exception ignored) {}
            // Как в MiXplorer: кадр берём около середины, но не раньше пятой секунды.
            // Начало фильма — это заставки и темнота, поэтому 15% почти всегда мимо.
            long half = Math.max(5000000L, (durMs * 1000L) / 2 - 5000000L);
            long t = half < 5000000L ? half / 2 : half;
            Bitmap b = frameAt(mmr, t);
            // Проверяем, что перемотка вообще сработала: у части файлов проигрыватель
            // молча отдаёт самый первый кадр, и именно он потом висит вместо превью.
            if (b != null && durMs > 12000) {
                Bitmap first = frameAt(mmr, 0);
                if (first != null) {
                    boolean same = sameFrame(b, first);
                    first.recycle();
                    if (same) {                                   // перемотка не удалась — берём кадр точно
                        Bitmap exact = exactFrame(mmr, t);
                        if (exact == null) exact = exactFrame(mmr, (long) (durMs * 1000L * 0.66));
                        if (exact != null) { b.recycle(); b = exact; }
                    }
                }
            }
            if (b == null) b = frameAt(mmr, 1000000L);
            if (b == null) b = mmr.getFrameAtTime();
            // если попали в затемнение — один запасной кадр на две трети
            if (b != null && durMs > 20000 && avgLuma(b) < 14) {
                Bitmap b2 = frameAt(mmr, (long) (durMs * 1000L * 0.66));
                if (b2 != null) { if (avgLuma(b2) > avgLuma(b)) { b.recycle(); b = b2; } else b2.recycle(); }
            }
            return b;
        } catch (Exception ignored) { return null; }
        finally { try { mmr.release(); } catch (Exception ignored) {} }
    }

    /** Точный кадр в заданный момент — медленнее, но не скатывается к началу файла. */
    private Bitmap exactFrame(android.media.MediaMetadataRetriever mmr, long usec) {
        try {
            if (Build.VERSION.SDK_INT >= 27) {
                Bitmap b = mmr.getScaledFrameAtTime(usec, android.media.MediaMetadataRetriever.OPTION_CLOSEST, 320, 320);
                if (b != null) return b;
            }
            return mmr.getFrameAtTime(usec, android.media.MediaMetadataRetriever.OPTION_CLOSEST);
        } catch (Throwable t) { return null; }
    }

    /** Два кадра — это одна и та же картинка? Сравниваем по сетке точек. */
    private boolean sameFrame(Bitmap a, Bitmap b) {
        try {
            if (a == null || b == null) return false;
            if (a.getWidth() != b.getWidth() || a.getHeight() != b.getHeight()) return false;
            int w = a.getWidth(), h = a.getHeight(), diff = 0, n = 0;
            for (int y = 2; y < h; y += Math.max(1, h / 8)) {
                for (int x = 2; x < w; x += Math.max(1, w / 8)) {
                    int p1 = a.getPixel(x, y), p2 = b.getPixel(x, y);
                    int d = Math.abs(((p1 >> 16) & 255) - ((p2 >> 16) & 255))
                          + Math.abs(((p1 >> 8) & 255) - ((p2 >> 8) & 255))
                          + Math.abs((p1 & 255) - (p2 & 255));
                    if (d > 24) diff++;
                    n++;
                }
            }
            return n > 0 && diff * 100 / n < 10;               // почти всё совпало — кадр тот же
        } catch (Throwable t) { return false; }
    }

    private Bitmap frameAt(android.media.MediaMetadataRetriever mmr, long usec) {
        try {
            if (Build.VERSION.SDK_INT >= 27) {
                Bitmap b = mmr.getScaledFrameAtTime(usec, android.media.MediaMetadataRetriever.OPTION_CLOSEST_SYNC, 320, 320);
                if (b != null) return b;
            }
            return mmr.getFrameAtTime(usec, android.media.MediaMetadataRetriever.OPTION_CLOSEST_SYNC);
        } catch (Throwable t) { return null; }
    }

    private long avgLuma(Bitmap b) {
        try {
            int w = b.getWidth(), h = b.getHeight();
            if (w <= 0 || h <= 0) return 0;
            int sx = Math.max(1, w / 16), sy = Math.max(1, h / 16);
            long sum = 0; int n = 0;
            for (int y = 0; y < h; y += sy) for (int x = 0; x < w; x += sx) {
                int c = b.getPixel(x, y);
                sum += (77 * ((c >> 16) & 0xFF) + 150 * ((c >> 8) & 0xFF) + 29 * (c & 0xFF)) >> 8;
                n++;
            }
            return n > 0 ? sum / n : 0;
        } catch (Throwable t) { return 0; }
    }

    // готовит превью в кэш заранее; формат и ключ те же, что у thumb()
    private void warmOne(String uriStr) {
        try {
            File f = toFile(uriStr);
            if (!f.exists() || f.isDirectory()) return;
            File cacheFile = new File(thumbDir(), thumbKey(f) + ".t");
            if (cacheFile.exists()) return;
            String name = f.getName().toLowerCase();
            Bitmap b = null;
            if (name.matches(".*\\.(jpg|jpeg|png|webp|gif|bmp)$")) {
                android.graphics.BitmapFactory.Options o = new android.graphics.BitmapFactory.Options();
                o.inJustDecodeBounds = true;
                android.graphics.BitmapFactory.decodeFile(f.getAbsolutePath(), o);
                int sc = 1; while (o.outWidth / sc > 200 || o.outHeight / sc > 200) sc *= 2;
                android.graphics.BitmapFactory.Options o2 = new android.graphics.BitmapFactory.Options();
                o2.inSampleSize = sc;
                b = android.graphics.BitmapFactory.decodeFile(f.getAbsolutePath(), o2);
            } else if (name.matches(".*\\.(mp4|m4v|mkv|webm|avi|mov|3gp|ts|flv|wmv|mpg|mpeg)$")) {
                b = videoFrame(f);       // размер не важен: читаем один кадр из середины
            }
            if (b == null) return;
            java.io.ByteArrayOutputStream bos = new java.io.ByteArrayOutputStream();
            b.compress(Bitmap.CompressFormat.JPEG, 70, bos);
            b.recycle();
            FileOutputStream fo = new FileOutputStream(cacheFile);
            fo.write(xorBytes(bos.toByteArray()));
            fo.close();
        } catch (Throwable ignored) {}
    }

    // ---- Кэш списков на диске (localStorage мал и пишет синхронно) ----
    private File cacheFileFor(String key) {
        String k = (key == null || key.isEmpty()) ? "list" : key.replaceAll("[^a-zA-Z0-9_]", "_");
        File d = getContext().getCacheDir();
        File dir = new File(d, "lists");
        if (!dir.exists()) dir.mkdirs();
        return new File(dir, k + ".json");
    }

    @PluginMethod
    public void cacheGet(PluginCall call) {
        try {
            File f = cacheFileFor(call.getString("key", "list"));
            JSObject ret = new JSObject();
            if (f.exists()) ret.put("data", new String(readAll(new FileInputStream(f)), "UTF-8"));
            call.resolve(ret);
        } catch (Exception e) { call.resolve(new JSObject()); }
    }

    @PluginMethod
    public void cacheSet(PluginCall call) {
        final String data = call.getString("data", "");
        final String key = call.getString("key", "list");
        call.resolve();
        new Thread(new Runnable() {
            @Override public void run() {
                try {
                    FileOutputStream o = new FileOutputStream(cacheFileFor(key));
                    o.write(data.getBytes("UTF-8"));
                    o.close();
                } catch (Exception ignored) {}
            }
        }).start();
    }

    @PluginMethod
    public void query(PluginCall call) {
        String mime = call.getString("mime", "*/*");
        String uriStr = call.getString("uri");
        String action = call.getString("action", "view");
        String act = "edit".equals(action) ? Intent.ACTION_EDIT : Intent.ACTION_VIEW;
        PackageManager pm = getContext().getPackageManager();

        Intent intent = new Intent(act);
        boolean dataSet = false;
        if (uriStr != null) {
            try {
                try { StrictMode.setVmPolicy(new StrictMode.VmPolicy.Builder().build()); } catch (Exception ignored) {}
                intent.setDataAndType(contentUriFor(toFile(uriStr)), mime);
                dataSet = true;
            } catch (Exception ignored) {}
        }
        if (!dataSet) intent.setType(mime);

        List<ResolveInfo> list = pm.queryIntentActivities(intent, PackageManager.MATCH_ALL);
        if (list.isEmpty()) {
            Intent alt = new Intent(act);
            alt.setType(mime);
            list = pm.queryIntentActivities(alt, PackageManager.MATCH_ALL);
        }
        if (list.isEmpty() && !"edit".equals(action)) {
            Intent edit = new Intent(Intent.ACTION_EDIT);
            edit.setType(mime);
            list = pm.queryIntentActivities(edit, PackageManager.MATCH_ALL);
        }

        JSArray apps = new JSArray();
        for (ResolveInfo ri : list) {
            if (ri.activityInfo == null) continue;
            JSObject o = new JSObject();
            o.put("label", String.valueOf(ri.loadLabel(pm)));
            o.put("packageName", ri.activityInfo.packageName);
            o.put("activityName", ri.activityInfo.name);
            try { o.put("icon", drawableToBase64(ri.loadIcon(pm))); } catch (Exception ignored) {}
            apps.put(o);
        }
        JSObject ret = new JSObject();
        ret.put("apps", apps);
        call.resolve(ret);
    }

    /**
     * Все установленные приложения с иконками — для выбора иконки папки.
     * Иконки кладём один раз в кэш (имя пакета + версия), потом отдаём готовые файлы.
     */
    @PluginMethod
    public void appList(PluginCall call) {
        final int max = call.getInt("iconSize", 144) == null ? 144 : call.getInt("iconSize", 144);
        new Thread(() -> {
            try {
                PackageManager pm = getContext().getPackageManager();
                File dir = new File(getContext().getFilesDir(), "appicons");
                if (!dir.isDirectory()) dir.mkdirs();
                java.util.List<android.content.pm.PackageInfo> pkgs = pm.getInstalledPackages(0);
                JSArray arr = new JSArray();
                for (android.content.pm.PackageInfo pi : pkgs) {
                    android.content.pm.ApplicationInfo ai = pi.applicationInfo;
                    if (ai == null) continue;
                    String label;
                    try { label = String.valueOf(pm.getApplicationLabel(ai)); } catch (Throwable t) { label = pi.packageName; }
                    long vc = Build.VERSION.SDK_INT >= 28 ? pi.getLongVersionCode() : pi.versionCode;
                    String base = pi.packageName.replaceAll("[^A-Za-z0-9_.-]", "_") + "_" + vc + ".png";
                    File f = new File(dir, base);
                    if (!f.exists()) {
                        try {
                            Bitmap b = drawableToBitmap(pm.getApplicationIcon(ai));
                            if (b != null) {
                                int mx = Math.max(b.getWidth(), b.getHeight());
                                if (mx > max) {
                                    float sc = (float) max / mx;
                                    b = Bitmap.createScaledBitmap(b, Math.max(1, Math.round(b.getWidth() * sc)), Math.max(1, Math.round(b.getHeight() * sc)), true);
                                }
                                OutputStream out = new java.io.FileOutputStream(f);
                                b.compress(Bitmap.CompressFormat.PNG, 100, out);
                                out.close();
                            }
                        } catch (Throwable ignored) {}
                    }
                    JSObject o = new JSObject();
                    o.put("pkg", pi.packageName);
                    o.put("label", label);
                    o.put("sys", (ai.flags & (android.content.pm.ApplicationInfo.FLAG_SYSTEM | android.content.pm.ApplicationInfo.FLAG_UPDATED_SYSTEM_APP)) != 0);
                    if (f.exists()) o.put("icon", "file://" + f.getAbsolutePath());
                    arr.put(o);
                }
                JSObject ret = new JSObject(); ret.put("apps", arr); call.resolve(ret);
            } catch (Exception e) { call.reject(e.getMessage()); }
        }).start();
    }

    @PluginMethod
    public void open(PluginCall call) {
        String uriStr = call.getString("uri");
        String mime = call.getString("mime", "*/*");
        String pkg = call.getString("packageName");
        String act = call.getString("activityName");
        String action = call.getString("action", "view");
        if (uriStr == null) { call.reject("no uri"); return; }
        try {
            if (uriStr.startsWith("content://")) {
                Intent iv = new Intent(Intent.ACTION_VIEW);
                iv.setDataAndType(Uri.parse(uriStr), call.getString("mime", "*/*"));
                iv.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
                getContext().startActivity(Intent.createChooser(iv, "Открыть").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
                call.resolve(); return;
            }
            File f = toFile(uriStr);
            if (!f.exists()) { call.reject("Файл не найден: " + f.getAbsolutePath()); return; }
            if (f.isDirectory()) { call.reject("Это папка: " + f.getAbsolutePath()); return; }
            try { StrictMode.setVmPolicy(new StrictMode.VmPolicy.Builder().build()); } catch (Exception ignored) {}
            Uri data = contentUriFor(f);
            Intent i = new Intent("edit".equals(action) ? Intent.ACTION_EDIT : Intent.ACTION_VIEW);
            i.setDataAndType(data, mime);
            android.content.ClipData clip = android.content.ClipData.newRawUri("", data);
            // Очередь для плеера — так её передаёт MiXplorer, и так её ждёт MX Player:
            // массив ссылок (именно массив, а не список), рядом массив имён, и пометка,
            // что список не жёсткий. Общий объём между приложениями ограничен, поэтому режем по 200 КБ.
            JSArray plist = call.getArray("uris");
            JSArray pnames = call.getArray("names");
            java.util.ArrayList<Uri> plUris = new java.util.ArrayList<>();
            java.util.ArrayList<String> plNames = new java.util.ArrayList<>();
            if (plist != null) {
                long budget = 0;
                for (int pi = 0; pi < plist.length(); pi++) {
                    try {
                        String us = String.valueOf(plist.get(pi));
                        Uri pu = us.startsWith("content://") ? Uri.parse(us) : contentUriFor(toFile(us));
                        String nm = null;
                        if (pnames != null && pi < pnames.length()) nm = String.valueOf(pnames.get(pi));
                        if (nm == null || nm.isEmpty()) { String p2 = us; int sl = p2.lastIndexOf('/'); nm = sl >= 0 ? p2.substring(sl + 1) : p2; }
                        budget += pu.toString().length() * 2 + nm.length() * 2 + 32;
                        if (budget > 200000) break;
                        plUris.add(pu); plNames.add(nm);
                        clip.addItem(new android.content.ClipData.Item(pu));
                    } catch (Exception ignored) {}
                }
                if (!plUris.isEmpty()) {
                    Parcelable[] arrU = plUris.toArray(new Parcelable[0]);
                    i.putExtra("video_list", arrU);                                   // MX Player, VLC, mpv
                    i.putExtra("video_list.name", plNames.toArray(new String[0]));
                    i.putExtra("video_list.filename", plNames.toArray(new String[0]));
                    i.putExtra("video_list_is_explicit", false);
                    Integer stI = call.getInt("startIndex", 0);
                    int st = stI == null ? 0 : stI.intValue();
                    if (st > 0 && st < plUris.size()) i.putExtra("video_list.position", st);
                    i.putExtra("title", new File(uriStr.startsWith("file://") ? uriStr.substring(7) : uriStr).getName());
                }
            }
            // Субтитры рядом с видео — тем же способом, что MiXplorer и Solid Explorer
            JSArray sublist = call.getArray("subs");
            JSArray subnames = call.getArray("subNames");
            if (sublist != null && sublist.length() > 0) {
                java.util.ArrayList<Uri> su = new java.util.ArrayList<>();
                java.util.ArrayList<String> sn = new java.util.ArrayList<>();
                for (int si = 0; si < sublist.length(); si++) {
                    try {
                        String us = String.valueOf(sublist.get(si));
                        Uri pu = us.startsWith("content://") ? Uri.parse(us) : contentUriFor(toFile(us));
                        su.add(pu);
                        String nm = subnames != null && si < subnames.length() ? String.valueOf(subnames.get(si)) : ("sub" + (si + 1));
                        sn.add(nm);
                        clip.addItem(new android.content.ClipData.Item(pu));
                    } catch (Exception ignored) {}
                }
                if (!su.isEmpty()) {
                    Parcelable[] arrS = su.toArray(new Parcelable[0]);
                    i.putExtra("subs", arrS);
                    i.putExtra("subs.enable", new Parcelable[]{ arrS[0] });
                    i.putExtra("subs.name", sn.toArray(new String[0]));
                    i.putExtra("subs.filename", sn.toArray(new String[0]));
                    i.putExtra("subtitles_location", su.get(0).toString());
                }
            }
            i.setClipData(clip);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_GRANT_READ_URI_PERMISSION);
            if ("edit".equals(action)) i.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
            if (pkg != null && act != null) i.setClassName(pkg, act);
            else if (pkg != null) i.setPackage(pkg);
            int gf = Intent.FLAG_GRANT_READ_URI_PERMISSION | ("edit".equals(action) ? Intent.FLAG_GRANT_WRITE_URI_PERMISSION : 0);
            try {
                if (pkg != null) getContext().grantUriPermission(pkg, data, gf);
                // грант всем, кто может обработать intent (на случай, если редактор читает файл из другого компонента)
                java.util.List<android.content.pm.ResolveInfo> ris = getContext().getPackageManager().queryIntentActivities(i, PackageManager.MATCH_DEFAULT_ONLY);
                for (android.content.pm.ResolveInfo ri : ris) { try { getContext().grantUriPermission(ri.activityInfo.packageName, data, gf); } catch (Exception ignored) {} }
            } catch (Exception ignored) {}
            try { for (Uri pu : plUris) { java.util.List<android.content.pm.ResolveInfo> r2 = getContext().getPackageManager().queryIntentActivities(i, PackageManager.MATCH_DEFAULT_ONLY); for (android.content.pm.ResolveInfo ri : r2) { try { getContext().grantUriPermission(ri.activityInfo.packageName, pu, Intent.FLAG_GRANT_READ_URI_PERMISSION); } catch (Exception ignored) {} } } } catch (Exception ignored) {}
            if (call.getBoolean("chooser", false) && pkg == null) {
                Intent ch = Intent.createChooser(i, "Открыть с помощью");
                ch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                getContext().startActivity(ch);
            } else getContext().startActivity(i);
            call.resolve();
        } catch (Exception e) {
            call.reject(e.getMessage());
        }
    }

    // ---- Расширенный доступ (Shizuku) ----
    @PluginMethod
    public void shizukuStatus(PluginCall call) {
        ShizukuBridge.listen(getContext());        // подписываемся один раз: связь приходит не сразу
        JSObject o = new JSObject();
        try {
            if (!ShizukuBridge.supported()) {
                o.put("installed", false); o.put("running", false); o.put("granted", false);
                o.put("ready", false); o.put("state", "old");
                call.resolve(o); return;
            }
            boolean inst = ShizukuBridge.installed(getContext());
            boolean run = ShizukuBridge.running();
            boolean ok = ShizukuBridge.granted();
            if (ok) ShizukuBridge.bind(getContext());
            o.put("installed", inst);
            o.put("running", run);
            o.put("granted", ok);
            o.put("ready", ShizukuBridge.ready());
            o.put("bound", ShizukuBridge.bound());
            if (ShizukuBridge.error() != null) o.put("err", ShizukuBridge.error());
            o.put("detail", ShizukuBridge.detail(getContext()));
            o.put("state", !inst ? "absent" : !run ? "stopped" : !ok ? "denied" : ShizukuBridge.ready() ? "ok" : "binding");
        } catch (Throwable t) {
            o.put("installed", false); o.put("running", false); o.put("granted", false);
            o.put("ready", false); o.put("state", "absent");
        }
        call.resolve(o);
    }

    @PluginMethod
    public void shizukuRequest(PluginCall call) {
        try {
            ShizukuBridge.requestPermission();
            JSObject o = new JSObject(); o.put("ok", true); call.resolve(o);
        } catch (Throwable t) { call.reject("Shizuku недоступен"); }
    }

    // ---- Запись на флешку/SD через SAF (Android не даёт писать на съёмные носители напрямую) ----
    private String safPrefName() { return "yf_saf"; }
    // id тома из пути /storage/XXXX-XXXX  ->  "XXXX-XXXX"
    private String volumeIdOf(String path) {
        if (path == null) return null;
        String p = path.replace("file://", "");
        java.util.regex.Matcher m = java.util.regex.Pattern.compile("/storage/([^/]+)").matcher(p);
        return m.find() ? m.group(1) : null;
    }
    private String safTreeFor(String volId) {
        if (volId == null) return null;
        return getContext().getSharedPreferences(safPrefName(), Context.MODE_PRIVATE).getString(volId, null);
    }
    // нужен ли SAF: путь на съёмном носителе и Android 11+
    private boolean safNeeded(String path) {
        if (Build.VERSION.SDK_INT < 30) return false;
        String id = volumeIdOf(path);
        return id != null && !id.equals("emulated") && !id.equals("self");
    }

    @PluginMethod
    public void safStatus(PluginCall call) {
        String path = call.getString("path", "");
        String id = volumeIdOf(path);
        boolean needed = safNeeded(path);
        boolean granted = false;
        String tree = safTreeFor(id);
        if (tree != null) {
            try {
                Uri u = Uri.parse(tree);
                for (android.content.UriPermission up : getContext().getContentResolver().getPersistedUriPermissions()) {
                    if (up.getUri().equals(u) && up.isWritePermission()) { granted = true; break; }
                }
            } catch (Throwable ignored) {}
        }
        JSObject o = new JSObject();
        o.put("needed", needed);
        o.put("granted", granted);
        call.resolve(o);
    }

    /** Дерево, выданное для закрытой папки (Android/data или Android/obb). */
    private String restrictedTree(String path) {
        try {
            String p = path.replace("file://", "");
            String key = p.contains("/Android/obb") ? "primary:Android/obb" : p.contains("/Android/data") ? "primary:Android/data" : null;
            if (key == null) return null;
            return getContext().getSharedPreferences(safPrefName(), Context.MODE_PRIVATE).getString(key, null);
        } catch (Throwable t) { return null; }
    }

    /** Читаем закрытую папку по выданному дереву — без Shizuku. */
    private DocumentFile restrictedDoc(String path, boolean create) {
        String tree = restrictedTree(path);
        if (tree == null) return null;
        try {
            DocumentFile root = DocumentFile.fromTreeUri(getContext(), Uri.parse(tree));
            if (root == null) return null;
            String p = path.replace("file://", "");
            int i = p.indexOf("/Android/");
            if (i < 0) return null;
            String rest = p.substring(i + 9);                 // «data/com.x/files» или «obb/...»
            String[] parts = rest.split("/");
            DocumentFile cur = root;
            for (int k = 1; k < parts.length; k++) {          // первый кусок — сама data/obb, это и есть корень дерева
                if (parts[k].isEmpty()) continue;
                DocumentFile next = cur.findFile(parts[k]);
                if (next == null && create) next = cur.createDirectory(parts[k]);
                if (next == null) return null;
                cur = next;
            }
            return cur;
        } catch (Throwable t) { return null; }
    }

    /** Просит у системы доступ к Android/data или Android/obb — окно открывается сразу на нужной папке. */
    @PluginMethod
    public void safRestricted(PluginCall call) {
        String what = call.getString("what", "data");
        try {
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
            if (Build.VERSION.SDK_INT >= 26) {
                try {
                    Uri hint = android.provider.DocumentsContract.buildDocumentUri(
                            "com.android.externalstorage.documents", "primary:Android/" + ("obb".equals(what) ? "obb" : "data"));
                    i.putExtra(android.provider.DocumentsContract.EXTRA_INITIAL_URI, hint);
                } catch (Throwable ignored) {}
            }
            startActivityForResult(call, i, "safResult");
        } catch (Exception e) { call.reject(e.getMessage()); }
    }

    @PluginMethod
    public void safRequest(PluginCall call) {
        try {
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
            if (Build.VERSION.SDK_INT >= 26) {
                String id = volumeIdOf(call.getString("path", ""));
                if (id != null) {
                    try {
                        Uri hint = android.provider.DocumentsContract.buildDocumentUri("com.android.externalstorage.documents", id + ":");
                        i.putExtra(android.provider.DocumentsContract.EXTRA_INITIAL_URI, hint);
                    } catch (Throwable ignored) {}
                }
            }
            startActivityForResult(call, i, "safResult");
        } catch (Exception e) { call.reject(e.getMessage()); }
    }

    @ActivityCallback
    private void safResult(PluginCall call, ActivityResult result) {
        if (call == null) return;
        try {
            Intent data = result.getData();
            Uri tree = data != null ? data.getData() : null;
            if (tree == null) { JSObject o = new JSObject(); o.put("granted", false); call.resolve(o); return; }
            final int flags = Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION;
            try { getContext().getContentResolver().takePersistableUriPermission(tree, flags); } catch (Throwable ignored) {}
            // сопоставляем выбранное дерево с id тома
            String docId = android.provider.DocumentsContract.getTreeDocumentId(tree);
            String volId = docId != null && docId.contains(":") ? docId.substring(0, docId.indexOf(":")) : docId;
            // отдельно запоминаем деревья закрытых папок — по ним читаем Android/data без Shizuku
            if (docId != null && (docId.endsWith(":Android/data") || docId.endsWith(":Android/obb"))) {
                String key = docId.endsWith(":Android/obb") ? "primary:Android/obb" : "primary:Android/data";
                getContext().getSharedPreferences(safPrefName(), Context.MODE_PRIVATE).edit().putString(key, tree.toString()).apply();
            } else if (volId != null) {
                getContext().getSharedPreferences(safPrefName(), Context.MODE_PRIVATE).edit().putString(volId, tree.toString()).apply();
            }
            JSObject o = new JSObject(); o.put("granted", true); o.put("volId", volId);
            call.resolve(o);
        } catch (Exception e) { call.reject(e.getMessage()); }
    }

    // Спускаемся/создаём папки дерева SAF до нужного места и возвращаем DocumentFile-папку
    private DocumentFile safDirFor(String destDirPath) {
        String id = volumeIdOf(destDirPath);
        String tree = safTreeFor(id);
        if (tree == null) return null;
        DocumentFile root = DocumentFile.fromTreeUri(getContext(), Uri.parse(tree));
        if (root == null) return null;
        // путь внутри тома: всё после /storage/<id>
        String p = destDirPath.replace("file://", "");
        int idx = p.indexOf("/storage/" + id);
        String rel = idx >= 0 ? p.substring(idx + ("/storage/" + id).length()) : "";
        DocumentFile cur = root;
        for (String seg : rel.split("/")) {
            if (seg.isEmpty()) continue;
            DocumentFile next = cur.findFile(seg);
            if (next == null || !next.isDirectory()) next = cur.createDirectory(seg);
            if (next == null) return null;
            cur = next;
        }
        return cur;
    }

    // Копирование файла или папки на съёмный носитель через SAF
    @PluginMethod
    public void safCopyInto(PluginCall call) {
        String srcUri = call.getString("from");
        String destDir = call.getString("destDir"); // абсолютный путь папки-приёмника на томе
        if (srcUri == null || destDir == null) { call.reject("no args"); return; }
        try {
            File src = toFile(srcUri);
            if (!src.exists()) { call.reject("Источник не найден"); return; }
            DocumentFile dir = safDirFor(destDir);
            if (dir == null) { call.reject("Нет доступа к носителю"); return; }
            if (src.isDirectory()) safPutDir(src, dir);
            else safPutFile(src, dir);
            call.resolve();
        } catch (Exception e) { call.reject(e.getMessage()); }
    }

    private void safPutDir(File src, DocumentFile parent) throws Exception {
        DocumentFile d = parent.findFile(src.getName());
        if (d == null || !d.isDirectory()) d = parent.createDirectory(src.getName());
        if (d == null) throw new Exception("Не удалось создать папку " + src.getName());
        File[] kids = src.listFiles();
        if (kids != null) for (File k : kids) { if (k.isDirectory()) safPutDir(k, d); else safPutFile(k, d); }
    }

    private void safPutFile(File src, DocumentFile parent) throws Exception {
        DocumentFile ex = parent.findFile(src.getName());
        if (ex != null) ex.delete(); // перезапись
        String mime = mimeFromName(src.getName());
        DocumentFile df = parent.createFile(mime != null ? mime : "application/octet-stream", src.getName());
        if (df == null) throw new Exception("Не удалось создать файл " + src.getName());
        InputStream in = new FileInputStream(src);
        OutputStream out = getContext().getContentResolver().openOutputStream(df.getUri());
        try {
            byte[] buf = new byte[262144]; int r;
            while ((r = in.read(buf)) > 0) out.write(buf, 0, r);
            out.flush();
        } finally {
            try { in.close(); } catch (Exception ignored) {}
            try { if (out != null) out.close(); } catch (Exception ignored) {}
        }
    }

    private String mimeFromName(String name) {
        String ext = android.webkit.MimeTypeMap.getFileExtensionFromUrl(name.replace(" ", "_"));
        if (ext == null || ext.isEmpty()) { int d = name.lastIndexOf('.'); if (d >= 0) ext = name.substring(d + 1); }
        if (ext == null || ext.isEmpty()) return null;
        return android.webkit.MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext.toLowerCase());
    }

    @PluginMethod
    public void safMkdir(PluginCall call) {
        String destDir = call.getString("destDir");
        String name = call.getString("name");
        if (destDir == null || name == null) { call.reject("no args"); return; }
        try {
            DocumentFile dir = safDirFor(destDir);
            if (dir == null) { call.reject("Нет доступа к носителю"); return; }
            DocumentFile ex = dir.findFile(name);
            if (ex == null) dir.createDirectory(name);
            call.resolve();
        } catch (Exception e) { call.reject(e.getMessage()); }
    }

    @PluginMethod
    public void list(PluginCall call) {
        String uriStr = call.getString("uri");
        if (uriStr == null) { call.reject("no uri"); return; }
        try {
            File dir = toFile(uriStr);
            String[] kids = dir.list();
            if (kids == null || kids.length == 0) {
                String vid = volumeIdOf(dir.getAbsolutePath());
                if (vid != null && !vid.equals("emulated") && !vid.equals("self")) {
                    String tree = safTreeFor(vid);
                    if (tree != null) {
                        try {
                            DocumentFile cur = DocumentFile.fromTreeUri(getContext(), Uri.parse(tree));
                            String pth = dir.getAbsolutePath();
                            int ix = pth.indexOf("/storage/" + vid);
                            String rel = ix >= 0 ? pth.substring(ix + ("/storage/" + vid).length()) : "";
                            for (String seg : rel.split("/")) {
                                if (seg.isEmpty() || cur == null) continue;
                                cur = cur.findFile(seg);
                            }
                            if (cur != null && cur.isDirectory()) {
                                JSArray outA = new JSArray();
                                for (DocumentFile df : cur.listFiles()) {
                                    JSObject o = new JSObject();
                                    o.put("name", df.getName());
                                    boolean dd = df.isDirectory();
                                    o.put("type", dd ? "directory" : "file");
                                    o.put("size", dd ? 0 : df.length());
                                    o.put("mtime", df.lastModified());
                                    // папкам оставляем file-путь для навигации, файлам — content:// для открытия
                                    o.put("uri", dd ? new File(dir, df.getName()).getAbsolutePath() : df.getUri().toString());
                                    outA.put(o);
                                }
                                JSObject ret = new JSObject(); ret.put("files", outA); ret.put("saf", true);
                                call.resolve(ret); return;
                            }
                        } catch (Throwable ignored) {}
                    }
                }
            }
            // закрытые системой папки (Android/data, Android/obb) читаем через Shizuku, если он поднят
            // закрытая папка: сперва пробуем дерево, выданное системным окном (Shizuku для этого не нужен)
            if ((kids == null || kids.length == 0) && ShizukuBridge.restricted(dir.getAbsolutePath())) {
                DocumentFile d = restrictedDoc(dir.getAbsolutePath(), false);
                if (d != null && d.isDirectory()) {
                    DocumentFile[] list = d.listFiles();
                    if (list != null && list.length > 0) {
                        JSArray outA = new JSArray();
                        for (DocumentFile df : list) {
                            JSObject o = new JSObject();
                            o.put("name", df.getName());
                            boolean dd = df.isDirectory();
                            o.put("type", dd ? "directory" : "file");
                            o.put("size", dd ? 0 : df.length());
                            o.put("mtime", df.lastModified());
                            o.put("uri", dd ? new File(dir, df.getName()).getAbsolutePath() : df.getUri().toString());
                            outA.put(o);
                        }
                        JSObject ret = new JSObject(); ret.put("files", outA); ret.put("saf", true);
                        call.resolve(ret); return;
                    }
                }
                ShizukuBridge.bind(getContext());                       // служба могла отвалиться — поднимаем
            }
            // В закрытой папке приложение видит только свою собственную подпапку, поэтому
            // ориентироваться на «пусто» нельзя: читаем командой всегда и берём то, где записей больше.
            if (ShizukuBridge.restricted(dir.getAbsolutePath()) && ShizukuBridge.granted()) {
                String out = ShizukuBridge.shellList(dir.getAbsolutePath());
                if (out != null && out.trim().length() > 0) {
                    JSArray outA = new JSArray();
                    for (String line : out.split("\n")) {
                        String[] p4 = line.split("\\|", 4);
                        if (p4.length < 4) continue;
                        String full = p4[3].trim();
                        int sl = full.lastIndexOf('/');
                        String nm = sl >= 0 ? full.substring(sl + 1) : full;
                        if (nm.isEmpty() || nm.equals(".") || nm.equals("..")) continue;
                        boolean isDir = p4[0].contains("directory");
                        JSObject o = new JSObject();
                        o.put("name", nm);
                        o.put("type", isDir ? "directory" : "file");
                        try { o.put("size", isDir ? 0 : Long.parseLong(p4[1].trim())); } catch (Throwable t) { o.put("size", 0); }
                        try { o.put("mtime", Long.parseLong(p4[2].trim()) * 1000L); } catch (Throwable ignored) {}
                        o.put("uri", new File(dir, nm).getAbsolutePath());
                        outA.put(o);
                    }
                    if (outA.length() > (kids == null ? 0 : kids.length)) {
                        attachAppIcons(dir, outA);
                        JSObject ret = new JSObject(); ret.put("files", outA); ret.put("shell", true);
                        call.resolve(ret); return;
                    }
                }
            }
            if (ShizukuBridge.restricted(dir.getAbsolutePath()) && ShizukuBridge.ready()) {
                try {
                    String js = ShizukuBridge.get().list(dir.getAbsolutePath());
                    if (js != null) {
                        org.json.JSONArray ja = new org.json.JSONArray(js);
                        if (ja.length() > (kids == null ? 0 : kids.length)) {
                            JSArray out = new JSArray();
                            for (int i = 0; i < ja.length(); i++) out.put(ja.getJSONObject(i));
                            JSObject ret = new JSObject();
                            attachAppIcons(dir, out);
                            ret.put("files", out); ret.put("shizuku", true);
                            ret.put("readOnly", ShizukuBridge.readOnlyArea(dir.getAbsolutePath()));   // системные разделы только читаются
                            call.resolve(ret); return;
                        }
                    }
                } catch (Throwable ignored) {}
            }
            // один системный запрос на элемент; число объектов и обложки подпапок — из базы,
            // недостающее досчитывается в фоне и приходит событием dirStats
            JSArray arr = new JSArray();
            java.util.List<YevCore.Ent> ents = YevCore.readDir(dir, kids);
            String base = dir.getAbsolutePath(); if (!base.endsWith("/")) base += "/";
            if (ents != null) for (YevCore.Ent e : ents) arr.put(YevCore.entJson(e, base));
            if (ents != null) core().fillDirStats(dir.getAbsolutePath(), ents, arr);
            attachAppIcons(dir, arr);
            JSObject ret = new JSObject();
            ret.put("files", arr);
            call.resolve(ret);
        } catch (Exception e) {
            call.reject(e.getMessage());
        }
    }

    // ---- ядро чтения папок / движок операций (создаются при первом обращении) ----
    private YevCore coreInst;
    private YevXfer xferInst;
    private synchronized YevCore core() {
        if (coreInst == null) coreInst = new YevCore(getContext(), (ev, d) -> notifyListeners(ev, d));
        return coreInst;
    }
    private synchronized YevXfer xfer() {
        if (xferInst == null) { xferInst = new YevXfer(getContext(), (ev, d) -> notifyListeners(ev, d)); xferInst.setCore(core()); }
        return xferInst;
    }

    // ---- качающиеся файлы в открытой папке ----
    private YevDownloads dlInst;
    private synchronized YevDownloads dl() {
        if (dlInst == null) dlInst = new YevDownloads(getContext(), (ev, d) -> notifyListeners(ev, d));
        return dlInst;
    }

    /** Что из разрешений уже выдано — для раздела «Требуемые разрешения». */
    @PluginMethod
    public void permStatus(PluginCall call) {
        JSObject r = new JSObject();
        boolean files;
        try { files = Build.VERSION.SDK_INT < 30 || Environment.isExternalStorageManager(); } catch (Throwable t) { files = false; }
        r.put("files", files);
        boolean notif = true;
        try {
            if (Build.VERSION.SDK_INT >= 33)
                notif = getContext().checkSelfPermission("android.permission.POST_NOTIFICATIONS") == android.content.pm.PackageManager.PERMISSION_GRANTED;
        } catch (Throwable ignored) {}
        r.put("notif", notif);
        boolean listener = false;
        try {
            String flat = android.provider.Settings.Secure.getString(getContext().getContentResolver(), "enabled_notification_listeners");
            listener = flat != null && flat.contains(getContext().getPackageName());
        } catch (Throwable ignored) {}
        r.put("listener", listener);
        boolean install = true;
        try { if (Build.VERSION.SDK_INT >= 26) install = getContext().getPackageManager().canRequestPackageInstalls(); } catch (Throwable ignored) {}
        r.put("install", install);
        boolean saf = false;
        try { saf = !getContext().getSharedPreferences("yf_saf", Context.MODE_PRIVATE).getAll().isEmpty(); } catch (Throwable ignored) {}
        r.put("saf", saf);
        try {
            android.content.SharedPreferences sp = getContext().getSharedPreferences("yf_saf", Context.MODE_PRIVATE);
            r.put("dataTree", sp.getString("primary:Android/data", null) != null);
            r.put("obbTree", sp.getString("primary:Android/obb", null) != null);
        } catch (Throwable ignored) { r.put("dataTree", false); r.put("obbTree", false); }
        call.resolve(r);
    }

    /** Проверяем у системы: числимся ли мы приложением для выбора файла. */
    @PluginMethod
    public void pickerStatus(PluginCall call) {
        JSObject r = new JSObject();
        StringBuilder who = new StringBuilder();
        boolean me = false;
        try {
            PackageManager pm = getContext().getPackageManager();
            Intent i = new Intent(Intent.ACTION_GET_CONTENT);
            i.addCategory(Intent.CATEGORY_OPENABLE);
            i.setType("*/*");
            java.util.List<android.content.pm.ResolveInfo> list = pm.queryIntentActivities(i, 0);
            for (android.content.pm.ResolveInfo ri : list) {
                if (ri.activityInfo == null) continue;
                if (getContext().getPackageName().equals(ri.activityInfo.packageName)) {
                    me = true;
                    if (who.length() > 0) who.append(", ");
                    who.append(ri.activityInfo.name);
                }
            }
            r.put("total", list.size());
        } catch (Throwable t) { r.put("err", String.valueOf(t.getMessage())); }
        r.put("registered", me);
        r.put("components", who.toString());
        call.resolve(r);
    }

    /** Открыть системное окно нужного разрешения. */
    @PluginMethod
    public void permOpen(PluginCall call) {
        String what = call.getString("what", "");
        try {
            Intent i;
            if ("notif".equals(what)) {
                i = new Intent(android.provider.Settings.ACTION_APP_NOTIFICATION_SETTINGS);
                i.putExtra(android.provider.Settings.EXTRA_APP_PACKAGE, getContext().getPackageName());
            } else if ("install".equals(what)) {
                i = new Intent(android.provider.Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + getContext().getPackageName()));
            } else if ("listener".equals(what)) {
                i = new Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS");
            } else {
                i = new Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + getContext().getPackageName()));
            }
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            getContext().startActivity(i);
            call.resolve();
        } catch (Exception e) { call.reject("Не удалось открыть настройки"); }
    }

    /** Значок приложения по имени пакета — из того же кэша, что и список приложений. */
    private String pkgIcon(String pkg) {
        try {
            PackageManager pm = getContext().getPackageManager();
            android.content.pm.PackageInfo pi = pm.getPackageInfo(pkg, 0);
            if (pi == null || pi.applicationInfo == null) return null;
            long vc = Build.VERSION.SDK_INT >= 28 ? pi.getLongVersionCode() : pi.versionCode;
            File dir = new File(getContext().getFilesDir(), "appicons");
            if (!dir.isDirectory()) dir.mkdirs();
            File f = new File(dir, pkg.replaceAll("[^A-Za-z0-9_.-]", "_") + "_" + vc + ".png");
            if (!f.exists()) {
                Bitmap b = drawableToBitmap(pm.getApplicationIcon(pi.applicationInfo));
                if (b == null) return null;
                int mx = Math.max(b.getWidth(), b.getHeight());
                if (mx > 144) {
                    float sc = 144f / mx;
                    b = Bitmap.createScaledBitmap(b, Math.max(1, Math.round(b.getWidth() * sc)), Math.max(1, Math.round(b.getHeight() * sc)), true);
                }
                OutputStream out = new java.io.FileOutputStream(f);
                b.compress(Bitmap.CompressFormat.PNG, 100, out);
                out.close();
            }
            return "file://" + f.getAbsolutePath();
        } catch (Throwable t) { return null; }
    }

    /** В Android/data и подобных папки названы именами приложений — вешаем их значки. */
    private void attachAppIcons(File dir, JSArray arr) {
        try {
            String p = dir.getAbsolutePath();
            if (!(p.endsWith("/Android/data") || p.endsWith("/Android/obb") || p.endsWith("/Android/media")
                    || p.endsWith("/Android/sandbox") || p.endsWith("/data/app"))) return;
            for (int i = 0; i < arr.length(); i++) {
                JSObject o = (JSObject) arr.get(i);
                String nm = o.getString("name");
                if (nm == null || nm.indexOf('.') < 0) continue;
                String ic = pkgIcon(nm);
                if (ic != null) o.put("appIcon", ic);
            }
        } catch (Throwable ignored) {}
    }

    /** Нас позвали выбрать файл: отдаём выбранное и закрываемся. */
    @PluginMethod
    public void pickResult(PluginCall call) {
        try {
            JSArray uris = call.getArray("uris");
            android.app.Activity act = getActivity();
            if (act == null) { call.reject("нет окна"); return; }
            Intent res = new Intent();
            if (uris != null && uris.length() > 1) {
                android.content.ClipData clip = null;
                for (int i = 0; i < uris.length(); i++) {
                    Uri u = contentUriFor(toFile(String.valueOf(uris.get(i))));
                    if (clip == null) clip = android.content.ClipData.newRawUri("", u);
                    else clip.addItem(new android.content.ClipData.Item(u));
                }
                res.setClipData(clip);
            } else {
                String one = uris != null && uris.length() > 0 ? String.valueOf(uris.get(0)) : call.getString("uri");
                if (one == null) { call.reject("нечего отдавать"); return; }
                Uri u = contentUriFor(toFile(one));
                res.setData(u);
                res.setType(getContext().getContentResolver().getType(u));
            }
            res.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            act.setResult(android.app.Activity.RESULT_OK, res);
            MainActivity.pendingMode = null;
            call.resolve();
            act.finish();
        } catch (Exception e) { call.reject(e.getMessage()); }
    }

    /** Отменить выбор файла. */
    @PluginMethod
    public void pickCancel(PluginCall call) {
        try {
            android.app.Activity act = getActivity();
            MainActivity.pendingMode = null;
            if (act != null) { act.setResult(android.app.Activity.RESULT_CANCELED); act.finish(); }
            call.resolve();
        } catch (Exception e) { call.reject(e.getMessage()); }
    }

    /** Считать ли вес папок (настройка пользователя; по умолчанию выключено). */
    @PluginMethod
    public void dirSizes(PluginCall call) {
        core().setSizesOn(Boolean.TRUE.equals(call.getBoolean("on", false)));
        call.resolve();
    }

    /** Начать следить за папкой (uri = null — перестать). */
    @PluginMethod
    public void dlWatch(PluginCall call) {
        String uriStr = call.getString("uri");
        try { dl().watch(uriStr == null || uriStr.isEmpty() ? null : toFile(uriStr).getAbsolutePath()); call.resolve(); }
        catch (Exception e) { call.reject(e.getMessage()); }
    }

    /** Дан ли доступ к уведомлениям (оттуда берём проценты загрузки). */
    @PluginMethod
    public void notifyAccess(PluginCall call) {
        boolean granted = false;
        try {
            String flat = android.provider.Settings.Secure.getString(getContext().getContentResolver(), "enabled_notification_listeners");
            granted = flat != null && flat.contains(getContext().getPackageName());
        } catch (Throwable ignored) {}
        JSObject r = new JSObject(); r.put("granted", granted); call.resolve(r);
    }

    /** Открыть системный список «Доступ к уведомлениям». */
    @PluginMethod
    public void notifyAccessOpen(PluginCall call) {
        try {
            Intent i = new Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS");
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            getContext().startActivity(i);
            call.resolve();
        } catch (Exception e) { call.reject("Не удалось открыть настройки"); }
    }

    /** Точечное чтение нескольких элементов папки — для событий «появился/изменился». */
    @PluginMethod
    public void statMany(PluginCall call) {
        String uriStr = call.getString("uri");
        JSArray names = call.getArray("names");
        if (uriStr == null || names == null) { call.reject("no args"); return; }
        try {
            java.util.List<String> l = new java.util.ArrayList<>();
            for (Object o : names.toList()) l.add(String.valueOf(o));
            JSObject ret = new JSObject();
            ret.put("files", core().statMany(toFile(uriStr).getAbsolutePath(), l));
            call.resolve(ret);
        } catch (Exception e) { call.reject(e.getMessage()); }
    }

    // ---- движок копирования/перемещения ----
    @PluginMethod
    public void xferStart(PluginCall call) {
        try {
            YevXfer.Job j = xfer().jobFrom(call.getData());
            String id = xfer().enqueue(j);
            core().invalidateSizes(toFile(j.dest).getAbsolutePath());
            JSObject r = new JSObject(); r.put("id", id); call.resolve(r);
        } catch (Exception e) { call.reject(e.getMessage()); }
    }
    @PluginMethod
    public void xferResolve(PluginCall call) {
        boolean all = Boolean.TRUE.equals(call.getBoolean("all", false));
        boolean allFiles = Boolean.TRUE.equals(call.getBoolean("allFiles", all));
        boolean allDirs = Boolean.TRUE.equals(call.getBoolean("allDirs", all));
        if (exHasPending()) {   // открыт вопрос распаковки — ответ ему, а не движку копирования
            exDeliver(call.getString("action", "cancel"), allFiles || allDirs, call.getString("newName"));
            call.resolve(); return;
        }
        xfer().resolve(call.getString("action", "cancel"), allFiles, allDirs, call.getString("newName"));
        call.resolve();
    }
    @PluginMethod
    public void xferCancel(PluginCall call) { xfer().cancel(call.getString("id")); call.resolve(); }
    @PluginMethod
    public void xferPause(PluginCall call) { xfer().pause(Boolean.TRUE.equals(call.getBoolean("on", true))); call.resolve(); }
    @PluginMethod
    public void xferState(PluginCall call) { call.resolve(xfer().state()); }
    @PluginMethod
    public void xferJobs(PluginCall call) { JSObject r = new JSObject(); r.put("jobs", xfer().jobsActive()); call.resolve(r); }

    @PluginMethod
    public void jobsList(PluginCall call) { JSObject r = new JSObject(); r.put("jobs", xfer().listUnfinished()); call.resolve(r); }
    @PluginMethod
    public void jobResume(PluginCall call) { JSObject r = new JSObject(); r.put("ok", xfer().resume(call.getString("id", ""))); call.resolve(r); }
    @PluginMethod
    public void jobForget(PluginCall call) { xfer().forget(call.getString("id", "")); call.resolve(); }

    // ---- поиск: индекс Android + обход диска ----
    @PluginMethod
    public void searchStart(PluginCall call) {
        try {
            String id = call.getString("id", "s");
            YevCore.SearchOpts o = new YevCore.SearchOpts();
            o.query = call.getString("query", "");
            o.types = call.getString("types", "all");
            o.minSize = call.getLong("minSize", -1L); o.maxSize = call.getLong("maxSize", -1L);
            o.from = call.getLong("from", -1L); o.to = call.getLong("to", -1L);
            o.hidden = Boolean.TRUE.equals(call.getBoolean("hidden", false));
            o.deep = !Boolean.FALSE.equals(call.getBoolean("deep", true));
            java.util.List<String> roots = new java.util.ArrayList<>();
            JSArray rs = call.getArray("roots");
            if (rs != null) for (Object x : rs.toList()) roots.add(toFile(String.valueOf(x)).getAbsolutePath());
            if (roots.isEmpty()) roots.add(Environment.getExternalStorageDirectory().getAbsolutePath());
            core().startSearch(id, roots, o);
            call.resolve();
        } catch (Exception e) { call.reject(e.getMessage()); }
    }
    @PluginMethod
    public void searchStop(PluginCall call) { core().stopSearch(call.getString("id", "s")); call.resolve(); }

    private File thumbDir() {
        File base = getContext().getExternalCacheDir();
        if (base == null) base = getContext().getCacheDir();
        File d = new File(base, "yev_thumbs");
        if (!d.exists()) d.mkdirs();
        return d;
    }
    private byte[] xorBytes(byte[] d) {
        final byte[] k = { (byte) 0x5A, (byte) 0xA5, (byte) 0x3C, (byte) 0xC3, (byte) 0x69, (byte) 0x96, (byte) 0x1E, (byte) 0xE1 };
        byte[] o = new byte[d.length];
        for (int i = 0; i < d.length; i++) o[i] = (byte) (d[i] ^ k[i % k.length]);
        return o;
    }
    // Номер поколения превью. Меняем, когда поменялся сам способ их делать —
    // иначе на диске останутся старые картинки и правки будут не видны.
    private static final String THUMB_GEN = "v4";

    private String thumbKey(File src) {
        // ключ = хэш пути + mtime, чтобы кэш инвалидировался при изменении файла
        String base = src.getAbsolutePath() + "|" + src.lastModified() + "|" + src.length();
        return Integer.toHexString(base.hashCode()) + "_" + src.lastModified() + "_" + THUMB_GEN;
    }

    @PluginMethod
    /** Отменённые превью: строку уже увели с экрана, тратиться не на что. */
    private final java.util.Set<String> thumbCancelled = java.util.Collections.newSetFromMap(new java.util.concurrent.ConcurrentHashMap<String, Boolean>());

    /**
     * Снимок под размер экрана: полноразмерный кадр браузерная часть рисует кусками,
     * а такой появляется целиком и сразу. Готовится один раз и лежит в кэше.
     */
    @PluginMethod
    public void viewImage(final PluginCall call) {
        new Thread(() -> {
            try {
                File f = toFile(call.getString("uri"));
                if (!f.isFile()) { call.reject("нет файла"); return; }
                int want = call.getInt("size", 1440) == null ? 1440 : call.getInt("size", 1440);
                File dir = new File(getContext().getCacheDir(), "view");
                if (!dir.isDirectory()) dir.mkdirs();
                File out = new File(dir, Integer.toHexString((f.getAbsolutePath() + "|" + f.lastModified() + "|" + want).hashCode()) + ".jpg");
                if (!out.exists() || out.length() == 0) {
                    android.graphics.BitmapFactory.Options o = new android.graphics.BitmapFactory.Options();
                    o.inJustDecodeBounds = true;
                    android.graphics.BitmapFactory.decodeFile(f.getAbsolutePath(), o);
                    if (o.outWidth <= 0) { call.reject("не картинка"); return; }
                    int mx = Math.max(o.outWidth, o.outHeight);
                    if (mx <= want) { JSObject r = new JSObject(); r.put("uri", "file://" + f.getAbsolutePath()); call.resolve(r); return; }
                    android.graphics.BitmapFactory.Options o2 = new android.graphics.BitmapFactory.Options();
                    int sc = 1; while (mx / sc > want * 2) sc *= 2;
                    o2.inSampleSize = sc;
                    Bitmap b = android.graphics.BitmapFactory.decodeFile(f.getAbsolutePath(), o2);
                    if (b == null) { call.reject("не прочиталось"); return; }
                    b = rotateByExif(b, f);
                    int m2 = Math.max(b.getWidth(), b.getHeight());
                    if (m2 > want) {
                        float k = (float) want / m2;
                        b = Bitmap.createScaledBitmap(b, Math.max(1, Math.round(b.getWidth() * k)), Math.max(1, Math.round(b.getHeight() * k)), true);
                    }
                    OutputStream os = new java.io.FileOutputStream(out);
                    b.compress(Bitmap.CompressFormat.JPEG, 92, os);
                    os.close(); b.recycle();
                }
                JSObject r = new JSObject(); r.put("uri", "file://" + out.getAbsolutePath()); call.resolve(r);
            } catch (Exception e) { call.reject(e.getMessage()); }
        }).start();
    }

    @PluginMethod
    public void thumbCancel(PluginCall call) {
        String k = call.getString("key");
        if (k != null) thumbCancelled.add(k);
        call.resolve();
    }

    /**
     * Готовое превью у самой системы: для всего, что попало в медиатеку, эскиз уже есть,
     * и оригинал читать не нужно. Это самый быстрый путь.
     */
    private Bitmap systemThumb(File f, int want) {
        try {
            android.content.ContentResolver cr = getContext().getContentResolver();
            Uri item = null;
            long id = -1; int mediaType = 0;
            android.database.Cursor c = cr.query(
                    android.provider.MediaStore.Files.getContentUri("external"),
                    new String[]{ "_id", "media_type" }, "_data=?", new String[]{ f.getAbsolutePath() }, null);
            if (c != null) {
                try { if (c.moveToFirst()) { id = c.getLong(0); mediaType = c.getInt(1); } } finally { c.close(); }
            }
            if (id < 0) return null;
            if (Build.VERSION.SDK_INT >= 29) {
                item = android.content.ContentUris.withAppendedId(android.provider.MediaStore.Files.getContentUri("external"), id);
                return cr.loadThumbnail(item, new android.util.Size(want, want), null);
            }
            if (mediaType == 3) return android.provider.MediaStore.Video.Thumbnails.getThumbnail(cr, id, android.provider.MediaStore.Video.Thumbnails.MINI_KIND, null);
            return android.provider.MediaStore.Images.Thumbnails.getThumbnail(cr, id, android.provider.MediaStore.Images.Thumbnails.MINI_KIND, null);
        } catch (Throwable t) { return null; }
    }

    @PluginMethod
    public void thumb(PluginCall call) {
        String uriStr = call.getString("uri");
        if (uriStr == null) { call.reject("no uri"); return; }
        try {
            File f = toFile(uriStr);
            if (!f.exists()) { call.resolve(new JSObject()); return; }
            String ckey = call.getString("key", uriStr);
            thumbCancelled.remove(ckey);
            int want = call.getInt("size", 150) == null ? 150 : call.getInt("size", 150);
            String name = f.getName().toLowerCase();
            boolean isApk = name.endsWith(".apk");
            String ext = isApk ? ".png" : ".jpg";
            String mimeOut = isApk ? "image/png" : "image/jpeg";
            File cacheFile = new File(thumbDir(), thumbKey(f) + (want > 200 ? "_b" : "") + ".t");
            JSObject ret = new JSObject();
            // готовое превью из кэша (деобфускация)
            if (cacheFile.exists()) {
                byte[] data = xorBytes(readAll(new FileInputStream(cacheFile)));
                ret.put("thumb", "data:" + mimeOut + ";base64," + Base64.encodeToString(data, Base64.NO_WRAP));
                call.resolve(ret); return;
            }
            // удалить устаревшие кэши этого же файла (другой mtime)
            String prefix = Integer.toHexString((f.getAbsolutePath() + "|").hashCode());
            File[] stale = thumbDir().listFiles();
            Bitmap b = null;
            if (thumbCancelled.remove(ckey)) { call.resolve(ret); return; }      // строка уже уехала с экрана
            // сперва просим готовое у системы: это мгновенно и без чтения оригинала
            // Готовое превью просим только для картинок. У видео система отдаёт кадр
            // с самого начала — это и есть та «чёрная заставка», поэтому её не берём вовсе.
            if (name.matches(".*\\.(jpg|jpeg|png|webp|gif|bmp|heic|heif)$")) b = systemThumb(f, want);
            if (name.matches(".*\\.(jpg|jpeg|png|webp|gif|bmp|avif|heic|heif|hif|apng)$")) {
                // AVIF и HEIC читает системный декодер там, где он есть (Android 9+/12+); иначе веб-часть пробует сама
                android.graphics.BitmapFactory.Options o = new android.graphics.BitmapFactory.Options();
                o.inJustDecodeBounds = true;
                android.graphics.BitmapFactory.decodeFile(f.getAbsolutePath(), o);
                int lim = Math.max(200, want + want / 2);
                int s = 1; while (o.outWidth / s > lim || o.outHeight / s > lim) s *= 2;
                android.graphics.BitmapFactory.Options o2 = new android.graphics.BitmapFactory.Options();
                o2.inSampleSize = s;
                b = android.graphics.BitmapFactory.decodeFile(f.getAbsolutePath(), o2);
                if (b == null && Build.VERSION.SDK_INT >= 28) b = decodeWithImageDecoder(f, 200);
            } else if (name.matches(".*\\.(dng|cr2|cr3|nef|nrw|arw|orf|rw2|pef|srw|raf|x3f|3fr|erf|kdc|mrw|mos|srf|sr2|rwl|iiq)$")) {
                // RAW: встроенное превью из EXIF (полноценный снимок камеры)
                byte[] pv = rawPreviewBytes(f);
                if (pv != null) {
                    android.graphics.BitmapFactory.Options o = new android.graphics.BitmapFactory.Options();
                    o.inJustDecodeBounds = true;
                    android.graphics.BitmapFactory.decodeByteArray(pv, 0, pv.length, o);
                    int s = 1; while (o.outWidth / s > 200 || o.outHeight / s > 200) s *= 2;
                    android.graphics.BitmapFactory.Options o2 = new android.graphics.BitmapFactory.Options();
                    o2.inSampleSize = s;
                    b = android.graphics.BitmapFactory.decodeByteArray(pv, 0, pv.length, o2);
                    b = rotateByExif(b, f);
                }
            } else if (name.endsWith(".pdf")) {
                android.os.ParcelFileDescriptor pfd = android.os.ParcelFileDescriptor.open(f, android.os.ParcelFileDescriptor.MODE_READ_ONLY);
                android.graphics.pdf.PdfRenderer r = new android.graphics.pdf.PdfRenderer(pfd);
                if (r.getPageCount() > 0) {
                    android.graphics.pdf.PdfRenderer.Page page = r.openPage(0);
                    int w = 150, h = (int) (150f * page.getHeight() / Math.max(1, page.getWidth())); if (h <= 0) h = 190;
                    b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888); b.eraseColor(0xFFFFFFFF);
                    page.render(b, null, null, android.graphics.pdf.PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY); page.close();
                }
                r.close(); pfd.close();
            } else if (name.matches(".*\\.(mp4|m4v|mkv|webm|avi|mov|qt|wmv|flv|f4v|3gp|3g2|mpg|mpeg|mpe|m2v|ts|m2ts|mts|vob|ogv|divx|asf)$")) {
                if (b == null) b = videoFrame(f);
            } else if (name.endsWith(".apk")) {
                PackageManager pm = getContext().getPackageManager();
                android.content.pm.PackageInfo pi = pm.getPackageArchiveInfo(f.getAbsolutePath(), 0);
                if (pi != null) { pi.applicationInfo.sourceDir = f.getAbsolutePath(); pi.applicationInfo.publicSourceDir = f.getAbsolutePath();
                    Drawable d = pi.applicationInfo.loadIcon(pm); b = drawableToBitmap(d); }
            }
            if (b == null) { call.resolve(ret); return; }
            // даунскейл до ~150px
            int mx = Math.max(b.getWidth(), b.getHeight());
            if (mx > want) { float sc = (float) want / mx; b = Bitmap.createScaledBitmap(b, Math.max(1, Math.round(b.getWidth() * sc)), Math.max(1, Math.round(b.getHeight() * sc)), true); }
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            if (isApk) b.compress(Bitmap.CompressFormat.PNG, 100, out);
            else b.compress(Bitmap.CompressFormat.JPEG, 80, out);
            byte[] bytes = out.toByteArray();
            try { OutputStream fos = new java.io.FileOutputStream(cacheFile); fos.write(xorBytes(bytes)); fos.close(); } catch (Exception ignored) {}
            ret.put("thumb", "data:" + mimeOut + ";base64," + Base64.encodeToString(bytes, Base64.NO_WRAP));
            call.resolve(ret);
        } catch (Exception e) { call.resolve(new JSObject()); }
    }

    // ---- RAW / HEIC: встроенное превью и системный декодер ----
    private byte[] rawPreviewBytes(File f) {
        try {
            androidx.exifinterface.media.ExifInterface ex = new androidx.exifinterface.media.ExifInterface(f.getAbsolutePath());
            byte[] t = ex.getThumbnailBytes();
            if (t != null && t.length > 0) return t;
        } catch (Throwable ignored) {}
        // без EXIF-превью: ищем самый большой встроенный JPEG по сигнатуре (так устроены CR2/NEF/ARW)
        try {
            long len = f.length(); if (len > 200L * 1024 * 1024) return null;
            java.io.RandomAccessFile raf = new java.io.RandomAccessFile(f, "r");
            byte[] all = new byte[(int) len]; raf.readFully(all); raf.close();
            int best = -1, bestLen = 0;
            for (int i = 0; i + 3 < all.length; i++) {
                if ((all[i] & 0xff) == 0xFF && (all[i + 1] & 0xff) == 0xD8 && (all[i + 2] & 0xff) == 0xFF) {
                    int j = i + 2;
                    while (j + 1 < all.length && !((all[j] & 0xff) == 0xFF && (all[j + 1] & 0xff) == 0xD9)) j++;
                    int l = j + 2 - i;
                    if (l > bestLen) { bestLen = l; best = i; }
                    i = j;
                }
            }
            if (best >= 0 && bestLen > 4096) { byte[] out = new byte[bestLen]; System.arraycopy(all, best, out, 0, bestLen); return out; }
        } catch (Throwable ignored) {}
        return null;
    }

    private Bitmap rotateByExif(Bitmap b, File f) {
        if (b == null) return null;
        try {
            androidx.exifinterface.media.ExifInterface ex = new androidx.exifinterface.media.ExifInterface(f.getAbsolutePath());
            int deg = ex.getRotationDegrees();
            if (deg == 0) return b;
            android.graphics.Matrix m = new android.graphics.Matrix(); m.postRotate(deg);
            return Bitmap.createBitmap(b, 0, 0, b.getWidth(), b.getHeight(), m, true);
        } catch (Throwable t) { return b; }
    }

    private Bitmap decodeWithImageDecoder(File f, final int maxSide) {
        if (Build.VERSION.SDK_INT < 28) return null;
        try {
            android.graphics.ImageDecoder.Source src = android.graphics.ImageDecoder.createSource(f);
            return android.graphics.ImageDecoder.decodeBitmap(src, (dec, info, s) -> {
                dec.setAllocator(android.graphics.ImageDecoder.ALLOCATOR_SOFTWARE);
                int w = info.getSize().getWidth(), h = info.getSize().getHeight();
                int mx = Math.max(w, h);
                if (maxSide > 0 && mx > maxSide) { float sc = (float) maxSide / mx; dec.setTargetSize(Math.max(1, Math.round(w * sc)), Math.max(1, Math.round(h * sc))); }
            });
        } catch (Throwable t) { return null; }
    }

    /** Полноразмерное превью RAW/HEIC для просмотрщика: JPEG в кэше, путь возвращается веб-части. */
    @PluginMethod
    public void imgPreview(PluginCall call) {
        String uriStr = call.getString("uri");
        if (uriStr == null) { call.reject("no uri"); return; }
        try {
            File f = toFile(uriStr);
            if (!f.exists()) { call.reject("Файл не найден"); return; }
            String name = f.getName().toLowerCase();
            File out = new File(thumbDir(), thumbKey(f) + ".pv.jpg");
            JSObject ret = new JSObject();
            if (out.exists() && out.length() > 0) { ret.put("path", "file://" + out.getAbsolutePath()); call.resolve(ret); return; }
            Bitmap b = null;
            if (name.matches(".*\\.(heic|heif|hif|avif)$")) {
                b = decodeWithImageDecoder(f, 4096);
                if (b == null) b = android.graphics.BitmapFactory.decodeFile(f.getAbsolutePath());
            } else {
                byte[] pv = rawPreviewBytes(f);
                if (pv != null) {
                    android.graphics.BitmapFactory.Options o = new android.graphics.BitmapFactory.Options();
                    o.inJustDecodeBounds = true;
                    android.graphics.BitmapFactory.decodeByteArray(pv, 0, pv.length, o);
                    int s = 1; while (o.outWidth / s > 4096 || o.outHeight / s > 4096) s *= 2;
                    android.graphics.BitmapFactory.Options o2 = new android.graphics.BitmapFactory.Options(); o2.inSampleSize = s;
                    b = android.graphics.BitmapFactory.decodeByteArray(pv, 0, pv.length, o2);
                    b = rotateByExif(b, f);
                }
            }
            if (b == null) { call.reject("Нет встроенного превью"); return; }
            OutputStream fos = new java.io.FileOutputStream(out);
            b.compress(Bitmap.CompressFormat.JPEG, 90, fos); fos.close();
            ret.put("path", "file://" + out.getAbsolutePath());
            call.resolve(ret);
        } catch (Exception e) { call.reject(e.getMessage()); }
    }

    @PluginMethod
    public void thumbSweep(PluginCall call) {
        // удаляет кэши старше 30 дней или сверх лимита, чтобы папка не разрасталась
        try {
            File dir = thumbDir();
            File[] files = dir.listFiles();
            if (files != null) {
                // превью прошлых поколений больше не нужны — способ их делать изменился
                for (File f : files) {
                    String n = f.getName();
                    if (n.endsWith(".t") && !n.startsWith("gd_") && !n.contains("_" + THUMB_GEN)) f.delete();
                }
                files = dir.listFiles();
                if (files == null) { call.resolve(new JSObject()); return; }
                long now = System.currentTimeMillis();
                long maxAge = 30L * 24 * 3600 * 1000;
                long total = 0;
                java.util.Arrays.sort(files, (a, c) -> Long.compare(c.lastModified(), a.lastModified()));
                for (File f : files) {
                    total += f.length();
                    if (now - f.lastModified() > maxAge || total > 80L * 1024 * 1024) f.delete();
                }
            }
            call.resolve(new JSObject());
        } catch (Exception e) { call.resolve(new JSObject()); }
    }

    private Bitmap drawableToBitmap(Drawable d) {
        if (d == null) return null;
        try { if (d instanceof android.graphics.drawable.BitmapDrawable) { Bitmap bm = ((android.graphics.drawable.BitmapDrawable) d).getBitmap(); if (bm != null) return bm; } } catch (Exception ignored) {}
        int w = d.getIntrinsicWidth(), h = d.getIntrinsicHeight();
        if (w <= 0 || h <= 0) { w = 144; h = 144; }
        Bitmap b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        android.graphics.Canvas c = new android.graphics.Canvas(b);
        d.setBounds(0, 0, w, h); d.draw(c);
        return b;
    }

    private byte[] readAll(InputStream in) throws Exception {
        ByteArrayOutputStream o = new ByteArrayOutputStream();
        byte[] buf = new byte[65536]; int r;
        while ((r = in.read(buf)) > 0) o.write(buf, 0, r);
        in.close(); return o.toByteArray();
    }

    @PluginMethod
    public void pdfPage(PluginCall call) {
        String uriStr = call.getString("uri");
        int page = call.getInt("page", 0);
        int width = call.getInt("width", 1080);
        if (uriStr == null) { call.reject("no uri"); return; }
        try {
            File f = toFile(uriStr);
            android.os.ParcelFileDescriptor pfd = android.os.ParcelFileDescriptor.open(f, android.os.ParcelFileDescriptor.MODE_READ_ONLY);
            android.graphics.pdf.PdfRenderer r = new android.graphics.pdf.PdfRenderer(pfd);
            int pages = r.getPageCount();
            JSObject ret = new JSObject();
            ret.put("pages", pages);
            if (page >= 0 && page < pages) {
                android.graphics.pdf.PdfRenderer.Page pg = r.openPage(page);
                int w = width < 1 ? 1080 : width;
                int h = (int) ((long) w * pg.getHeight() / Math.max(1, pg.getWidth()));
                if (h <= 0) h = w;
                if ((long) w * h > 12000000L) { h = (int) (12000000L / w); }
                Bitmap b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
                b.eraseColor(0xFFFFFFFF);
                pg.render(b, null, null, android.graphics.pdf.PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY);
                pg.close();
                ByteArrayOutputStream out = new ByteArrayOutputStream();
                b.compress(Bitmap.CompressFormat.JPEG, 80, out);
                b.recycle();
                ret.put("data", "data:image/jpeg;base64," + Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP));
                ret.put("w", w); ret.put("h", h);
            }
            r.close(); pfd.close();
            call.resolve(ret);
        } catch (Exception e) { call.reject(e.getMessage()); }
    }

    @PluginMethod
    public void pdfThumb(PluginCall call) {
        String uriStr = call.getString("uri");
        if (uriStr == null) { call.reject("no uri"); return; }
        try {
            File f = toFile(uriStr);
            android.os.ParcelFileDescriptor pfd = android.os.ParcelFileDescriptor.open(f, android.os.ParcelFileDescriptor.MODE_READ_ONLY);
            android.graphics.pdf.PdfRenderer r = new android.graphics.pdf.PdfRenderer(pfd);
            JSObject ret = new JSObject();
            if (r.getPageCount() > 0) {
                android.graphics.pdf.PdfRenderer.Page page = r.openPage(0);
                int w = 160, h = (int) (160f * page.getHeight() / Math.max(1, page.getWidth()));
                if (h <= 0) h = 200;
                Bitmap b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
                b.eraseColor(0xFFFFFFFF);
                page.render(b, null, null, android.graphics.pdf.PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY);
                page.close();
                ByteArrayOutputStream out = new ByteArrayOutputStream();
                b.compress(Bitmap.CompressFormat.PNG, 90, out);
                ret.put("thumb", "data:image/png;base64," + Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP));
            }
            r.close(); pfd.close();
            call.resolve(ret);
        } catch (Exception e) { call.reject(e.getMessage()); }
    }

    @PluginMethod
    public void saveSharedTemp(PluginCall call) {
        try {
            if (MainActivity.pendingShared.isEmpty()) { call.resolve(new JSObject()); return; }
            android.net.Uri u = MainActivity.pendingShared.get(0);
            String name = queryName(u);
            File dir = new File(android.os.Environment.getExternalStorageDirectory(), "Download/.yevtmp");
            if (!dir.exists()) dir.mkdirs();
            File out = new File(dir, name);
            java.io.InputStream in = getContext().getContentResolver().openInputStream(u);
            java.io.FileOutputStream fos = new java.io.FileOutputStream(out);
            byte[] buf = new byte[65536]; int r;
            while ((r = in.read(buf)) > 0) fos.write(buf, 0, r);
            fos.close(); in.close();
            MainActivity.pendingShared.clear();
            JSObject ret = new JSObject(); ret.put("uri", "file://" + out.getAbsolutePath()); ret.put("name", name); call.resolve(ret);
        } catch (Exception e) { call.reject(e.getMessage()); }
    }

    @PluginMethod
    public void getShared(PluginCall call) {
        try {
            JSArray arr = new JSArray();
            for (android.net.Uri u : MainActivity.pendingShared) {
                JSObject o = new JSObject();
                String name = queryName(u);
                o.put("name", name);
                o.put("mime", getContext().getContentResolver().getType(u));
                arr.put(o);
            }
            JSObject ret = new JSObject(); ret.put("files", arr); ret.put("mode", MainActivity.pendingMode);
            ret.put("pickMime", MainActivity.pickMime); ret.put("pickMulti", MainActivity.pickMultiple); call.resolve(ret);
        } catch (Exception e) { call.reject(e.getMessage()); }
    }

    @PluginMethod
    public void saveShared(PluginCall call) {
        String destDir = call.getString("dir");
        if (destDir == null) { call.reject("no dir"); return; }
        try {
            File dir = toFile(destDir);
            int ok = 0;
            for (android.net.Uri u : MainActivity.pendingShared) {
                String name = queryName(u);
                File out = new File(dir, name);
                int n = 0; String base = name, ext = "";
                int dot = name.lastIndexOf('.');
                if (dot > 0) { base = name.substring(0, dot); ext = name.substring(dot); }
                while (out.exists()) { n++; out = new File(dir, base + " (" + n + ")" + ext); }
                java.io.InputStream in = getContext().getContentResolver().openInputStream(u);
                java.io.FileOutputStream fos = new java.io.FileOutputStream(out);
                byte[] buf = new byte[65536]; int r;
                while ((r = in.read(buf)) > 0) fos.write(buf, 0, r);
                fos.close(); in.close(); ok++;
            }
            MainActivity.pendingShared.clear();
            JSObject ret = new JSObject(); ret.put("saved", ok); call.resolve(ret);
        } catch (Exception e) { call.reject(e.getMessage()); }
    }

    @PluginMethod
    public void clearShared(PluginCall call) {
        MainActivity.pendingShared.clear();
        call.resolve(new JSObject());
    }

    private String queryName(android.net.Uri u) {
        String name = null;
        try {
            android.database.Cursor c = getContext().getContentResolver().query(u, null, null, null, null);
            if (c != null) {
                int idx = c.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME);
                if (idx >= 0 && c.moveToFirst()) name = c.getString(idx);
                c.close();
            }
        } catch (Exception ignored) {}
        if (name == null) { name = u.getLastPathSegment(); if (name != null && name.contains("/")) name = name.substring(name.lastIndexOf('/') + 1); }
        if (name == null || name.isEmpty()) name = "shared_" + System.currentTimeMillis();
        return name;
    }

    private File reinstallFile;
    private boolean reinstallRegistered = false;

    @PluginMethod
    public void apkReinstall(PluginCall call) {
        String uriStr = call.getString("uri");
        String pkg = call.getString("package");
        if (uriStr == null || pkg == null) { call.reject("no args"); return; }
        File f = toFile(uriStr);
        if (f == null || !f.exists()) { call.reject("Файл не найден"); return; }
        reinstallFile = f;
        try {
            registerReinstallReceiver();
            PackageInstaller pi = getContext().getPackageManager().getPackageInstaller();
            Intent statusIntent = new Intent("leshugan.fm.UNINSTALL_RESULT").setPackage(getContext().getPackageName());
            int flags = PendingIntent.FLAG_UPDATE_CURRENT;
            if (Build.VERSION.SDK_INT >= 31) flags |= PendingIntent.FLAG_MUTABLE;
            PendingIntent pending = PendingIntent.getBroadcast(getContext(), 4242, statusIntent, flags);
            pi.uninstall(pkg, pending.getIntentSender());
            call.resolve();
        } catch (Exception e) { call.reject(e.getMessage()); }
    }

    private void registerReinstallReceiver() {
        if (reinstallRegistered) return;
        BroadcastReceiver r = new BroadcastReceiver() {
            @Override public void onReceive(Context c, Intent i) {
                int status = i.getIntExtra(PackageInstaller.EXTRA_STATUS, -1);
                if (status == PackageInstaller.STATUS_PENDING_USER_ACTION) {
                    Intent confirm = i.getParcelableExtra(Intent.EXTRA_INTENT);
                    if (confirm != null) { confirm.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); try { c.startActivity(confirm); } catch (Exception ignored) {} }
                } else if (status == PackageInstaller.STATUS_SUCCESS) {
                    File f = reinstallFile; reinstallFile = null;
                    if (f != null) { try { installApkFileInternal(f); } catch (Exception ignored) {} }
                }
            }
        };
        IntentFilter filter = new IntentFilter("leshugan.fm.UNINSTALL_RESULT");
        if (Build.VERSION.SDK_INT >= 33) getContext().registerReceiver(r, filter, Context.RECEIVER_NOT_EXPORTED);
        else getContext().registerReceiver(r, filter);
        reinstallRegistered = true;
    }

    private void installApkFileInternal(File f) throws Exception {
        registerInstallReceiver();
        PackageInstaller pi = getContext().getPackageManager().getPackageInstaller();
        PackageInstaller.SessionParams params = new PackageInstaller.SessionParams(PackageInstaller.SessionParams.MODE_FULL_INSTALL);
        int sessionId = pi.createSession(params);
        PackageInstaller.Session session = pi.openSession(sessionId);
        OutputStream out = session.openWrite("apk", 0, f.length());
        InputStream in = new FileInputStream(f);
        byte[] buf = new byte[65536]; int n;
        while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
        session.fsync(out); in.close(); out.close();
        Intent statusIntent = new Intent("leshugan.fm.INSTALL_RESULT").setPackage(getContext().getPackageName());
        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= 31) flags |= PendingIntent.FLAG_MUTABLE;
        PendingIntent pending = PendingIntent.getBroadcast(getContext(), sessionId, statusIntent, flags);
        session.commit(pending.getIntentSender());
        session.close();
    }

    // Метаданные по типу файла: размеры и EXIF для картинок, длительность/битрейт/кодек для аудио и видео
    @PluginMethod
    public void fileMeta(PluginCall call) {
        String uriStr = call.getString("uri");
        if (uriStr == null) { call.reject("no uri"); return; }
        try {
            File f = toFile(uriStr);
            if (!f.exists()) { call.reject("not found"); return; }
            String n = f.getName().toLowerCase();
            JSObject o = new JSObject();
            if (n.matches(".*\\.(png|jpg|jpeg|webp|gif|bmp|heic|heif|avif)$")) {
                android.graphics.BitmapFactory.Options bo = new android.graphics.BitmapFactory.Options();
                bo.inJustDecodeBounds = true;
                android.graphics.BitmapFactory.decodeFile(f.getAbsolutePath(), bo);
                if (bo.outWidth > 0) { o.put("w", bo.outWidth); o.put("h", bo.outHeight); }
                try {
                    androidx.exifinterface.media.ExifInterface ex = new androidx.exifinterface.media.ExifInterface(f.getAbsolutePath());
                    putIf(o, "camera", join(ex.getAttribute(androidx.exifinterface.media.ExifInterface.TAG_MAKE),
                                            ex.getAttribute(androidx.exifinterface.media.ExifInterface.TAG_MODEL)));
                    putIf(o, "lens", ex.getAttribute(androidx.exifinterface.media.ExifInterface.TAG_LENS_MODEL));
                    String exp = ex.getAttribute(androidx.exifinterface.media.ExifInterface.TAG_EXPOSURE_TIME);
                    if (exp != null) { try { double d = Double.parseDouble(exp); o.put("exposure", d >= 1 ? (trim(d) + " с") : ("1/" + Math.round(1 / d) + " с")); } catch (Exception ignored) {} }
                    String fn = ex.getAttribute(androidx.exifinterface.media.ExifInterface.TAG_F_NUMBER);
                    if (fn != null) { try { o.put("aperture", "f/" + trim(Double.parseDouble(fn))); } catch (Exception ignored) {} }
                    int iso = ex.getAttributeInt(androidx.exifinterface.media.ExifInterface.TAG_PHOTOGRAPHIC_SENSITIVITY, 0);
                    if (iso > 0) o.put("iso", "ISO " + iso);
                    String fl = ex.getAttribute(androidx.exifinterface.media.ExifInterface.TAG_FOCAL_LENGTH);
                    if (fl != null) { try { String[] pr = fl.split("/"); double v = pr.length == 2 ? Double.parseDouble(pr[0]) / Double.parseDouble(pr[1]) : Double.parseDouble(fl); o.put("focal", trim(v) + " мм"); } catch (Exception ignored) {} }
                    putIf(o, "taken", ex.getAttribute(androidx.exifinterface.media.ExifInterface.TAG_DATETIME_ORIGINAL));
                    double[] ll = ex.getLatLong();
                    if (ll != null) o.put("gps", String.format(java.util.Locale.US, "%.5f, %.5f", ll[0], ll[1]));
                    int rot = ex.getAttributeInt(androidx.exifinterface.media.ExifInterface.TAG_ORIENTATION, 0);
                    if ((rot == 6 || rot == 8) && bo.outWidth > 0) { o.put("w", bo.outHeight); o.put("h", bo.outWidth); }
                } catch (Exception ignored) {}
                o.put("kind", "image");
            } else if (n.matches(".*\\.(mp3|m4a|aac|flac|ogg|opus|wav|wma|mp4|m4v|mkv|webm|avi|mov|3gp|ts|flv|wmv|mpg|mpeg)$")) {
                android.media.MediaMetadataRetriever mmr = new android.media.MediaMetadataRetriever();
                try {
                    mmr.setDataSource(f.getAbsolutePath());
                    String dur = mmr.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_DURATION);
                    if (dur != null) { try { o.put("duration", fmtDur(Long.parseLong(dur))); } catch (Exception ignored) {} }
                    String br = mmr.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_BITRATE);
                    if (br != null) { try { o.put("bitrate", Math.round(Long.parseLong(br) / 1000.0) + " кбит/с"); } catch (Exception ignored) {} }
                    putIf(o, "title", mmr.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_TITLE));
                    putIf(o, "artist", mmr.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_ARTIST));
                    putIf(o, "album", mmr.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_ALBUM));
                    putIf(o, "year", mmr.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_YEAR));
                    String w = mmr.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH);
                    String h = mmr.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT);
                    if (w != null && h != null) { o.put("w", Integer.parseInt(w)); o.put("h", Integer.parseInt(h)); }
                    if (Build.VERSION.SDK_INT >= 23) {
                        putIf(o, "fps", mmr.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_CAPTURE_FRAMERATE));
                    }
                    putIf(o, "codec", mmr.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_MIMETYPE));
                    o.put("kind", w != null ? "video" : "audio");
                } catch (Exception ignored) { o.put("kind", "media"); }
                finally { try { mmr.release(); } catch (Exception ignored) {} }
            } else {
                o.put("kind", "other");
            }
            call.resolve(o);
        } catch (Exception e) { call.reject(e.getMessage()); }
    }

    private void putIf(JSObject o, String k, String v) { if (v != null && v.trim().length() > 0) o.put(k, v.trim()); }
    private String join(String a, String b) {
        if (a == null && b == null) return null;
        if (a == null) return b; if (b == null) return a;
        return b.toLowerCase().startsWith(a.toLowerCase()) ? b : (a + " " + b);
    }
    private String trim(double d) {
        String s = String.format(java.util.Locale.US, "%.2f", d);
        while (s.contains(".") && (s.endsWith("0") || s.endsWith("."))) s = s.substring(0, s.length() - 1);
        return s;
    }
    private String fmtDur(long ms) {
        long t = ms / 1000, h = t / 3600, m = (t % 3600) / 60, sec = t % 60;
        return h > 0 ? String.format(java.util.Locale.US, "%d:%02d:%02d", h, m, sec)
                     : String.format(java.util.Locale.US, "%d:%02d", m, sec);
    }

    @PluginMethod
    public void apkInfo(PluginCall call) {
        String uriStr = call.getString("uri");
        if (uriStr == null) { call.reject("no uri"); return; }
        try {
            File f = toFile(uriStr);
            String p = f.getAbsolutePath();
            String lower = f.getName().toLowerCase();
            boolean split = lower.endsWith(".apks") || lower.endsWith(".xapk") || lower.endsWith(".apkm") || lower.endsWith(".apkx");
            File tmpBase = null;
            if (split) { tmpBase = extractBaseApk(f); if (tmpBase != null) p = tmpBase.getAbsolutePath(); }
            PackageManager pm = getContext().getPackageManager();
            android.content.pm.PackageInfo pi = pm.getPackageArchiveInfo(p, 0);
            JSObject ret = new JSObject();
            if (pi != null) {
                pi.applicationInfo.sourceDir = p;
                pi.applicationInfo.publicSourceDir = p;
                ret.put("package", pi.packageName);
                ret.put("versionName", pi.versionName);
                ret.put("versionCode", android.os.Build.VERSION.SDK_INT >= 28 ? pi.getLongVersionCode() : pi.versionCode);
                ret.put("targetSdk", pi.applicationInfo.targetSdkVersion);
                if (android.os.Build.VERSION.SDK_INT >= 24) ret.put("minSdk", pi.applicationInfo.minSdkVersion);
                try { ret.put("label", pm.getApplicationLabel(pi.applicationInfo).toString()); } catch (Exception ignored) {}
                try { Drawable ic = pm.getApplicationIcon(pi.applicationInfo); ret.put("icon", drawableToBase64(ic)); } catch (Exception ignored) {}
                // подпись apk (из архива)
                String apkSig = null;
                try { android.content.pm.PackageInfo sp = pm.getPackageArchiveInfo(p, PackageManager.GET_SIGNATURES); apkSig = firstCertSha256(sp); } catch (Exception ignored) {}
                if (apkSig != null) ret.put("sig", apkSig);
                // установлена ли уже + версия + подпись установленной
                try {
                    android.content.pm.PackageInfo inst = pm.getPackageInfo(pi.packageName, 0);
                    ret.put("installedVersionName", inst.versionName);
                    ret.put("installedVersionCode", android.os.Build.VERSION.SDK_INT >= 28 ? inst.getLongVersionCode() : inst.versionCode);
                    ret.put("installed", true);
                    try {
                        android.content.pm.PackageInfo instSig = pm.getPackageInfo(pi.packageName, PackageManager.GET_SIGNATURES);
                        String is = firstCertSha256(instSig);
                        if (is != null) ret.put("installedSig", is);
                        if (apkSig != null && is != null) ret.put("sigMatch", apkSig.equals(is));
                    } catch (Exception ignored) {}
                } catch (Exception e) { ret.put("installed", false); }
            }
            if (tmpBase != null) try { tmpBase.delete(); } catch (Exception ignored) {}
            call.resolve(ret);
        } catch (Exception e) { call.reject(e.getMessage()); }
    }

    private String firstCertSha256(android.content.pm.PackageInfo pi) {
        try {
            android.content.pm.Signature[] sigs = pi.signatures;
            if (sigs == null || sigs.length == 0) return null;
            java.security.MessageDigest md = java.security.MessageDigest.getInstance("SHA-256");
            byte[] d = md.digest(sigs[0].toByteArray());
            StringBuilder sb = new StringBuilder();
            for (byte b : d) sb.append(String.format("%02X", b));
            return sb.toString();
        } catch (Exception e) { return null; }
    }

    private File extractBaseApk(File pkg) {
        try {
            ZipFile zf = new ZipFile(pkg);
            ZipEntry best = null; long bestSize = -1;
            Enumeration<? extends ZipEntry> en = zf.entries();
            while (en.hasMoreElements()) {
                ZipEntry e = en.nextElement();
                if (e.isDirectory()) continue;
                String nm = e.getName().toLowerCase();
                if (!nm.endsWith(".apk")) continue;
                long sz = e.getSize();
                // base обычно самый большой .apk (не config.* / split_*)
                boolean cfg = nm.contains("config.") || nm.contains("split_") || nm.contains("split.");
                if (!cfg && (best == null || sz > bestSize)) { best = e; bestSize = sz; }
                else if (best == null) { best = e; bestSize = sz; }
            }
            if (best == null) { zf.close(); return null; }
            File out = new File(getContext().getCacheDir(), "base_" + System.currentTimeMillis() + ".apk");
            InputStream in = zf.getInputStream(best);
            OutputStream os = new FileOutputStream(out);
            byte[] buf = new byte[65536]; int n; while ((n = in.read(buf)) > 0) os.write(buf, 0, n);
            os.close(); in.close(); zf.close();
            return out;
        } catch (Exception e) { return null; }
    }

    @PluginMethod
    public void apkIcon(PluginCall call) {
        String uriStr = call.getString("uri");
        if (uriStr == null) { call.reject("no uri"); return; }
        try {
            File f = toFile(uriStr);
            String p = f.getAbsolutePath();
            PackageManager pm = getContext().getPackageManager();
            android.content.pm.PackageInfo pi = pm.getPackageArchiveInfo(p, 0);
            JSObject ret = new JSObject();
            if (pi != null) {
                pi.applicationInfo.sourceDir = p;
                pi.applicationInfo.publicSourceDir = p;
                Drawable icon = pi.applicationInfo.loadIcon(pm);
                ret.put("icon", drawableToBase64(icon));
            }
            call.resolve(ret);
        } catch (Exception e) { call.reject(e.getMessage()); }
    }

    @PluginMethod
    public void delete(PluginCall call) {
        String uriStr = call.getString("uri");
        if (uriStr == null) { call.reject("no uri"); return; }
        File f = toFile(uriStr);
        boolean ok = deleteRecursive(f);
        JSObject ret = new JSObject();
        ret.put("deleted", ok || !f.exists());
        call.resolve(ret);
    }

    private int[] copyCounter = new int[2]; // [done, total]

    @PluginMethod
    public void copyTree(PluginCall call) {
        String fromStr = call.getString("from");
        String toStr = call.getString("to");
        if (fromStr == null || toStr == null) { call.reject("no from/to"); return; }
        try {
            File src = toFile(fromStr);
            File dst = toFile(toStr);
            String skip = dst.getCanonicalPath();
            copyCounter[0] = 0;
            copyCounter[1] = countFiles(src, skip);
            copyRecursive(src, dst, skip);
            JSObject ret = new JSObject(); ret.put("ok", true); ret.put("total", copyCounter[1]); call.resolve(ret);
        } catch (Exception e) { call.reject(e.getMessage()); }
    }

    private int countFiles(File src, String skipPath) {
        try { if (src.getCanonicalPath().equals(skipPath)) return 0; } catch (Exception e) { return 0; }
        if (src.isDirectory()) {
            int c = 0; File[] kids = src.listFiles();
            if (kids != null) for (File k : kids) c += countFiles(k, skipPath);
            return c;
        }
        return 1;
    }

    private void copyRecursive(File src, File dst, String skipPath) throws Exception {
        if (src.getCanonicalPath().equals(skipPath)) return;
        if (src.isDirectory()) {
            if (!dst.exists()) dst.mkdirs();
            File[] kids = src.listFiles();
            if (kids != null) for (File c : kids) {
                if (c.getCanonicalPath().equals(skipPath)) continue;
                copyRecursive(c, new File(dst, c.getName()), skipPath);
            }
        } else {
            java.io.FileInputStream in = new java.io.FileInputStream(src);
            java.io.FileOutputStream out = new java.io.FileOutputStream(dst);
            byte[] buf = new byte[65536]; int r;
            while ((r = in.read(buf)) > 0) out.write(buf, 0, r);
            in.close(); out.close();
            copyCounter[0]++;
            // событие прогресса в JS + уведомление Android
            JSObject ev = new JSObject(); ev.put("done", copyCounter[0]); ev.put("total", copyCounter[1]); ev.put("name", src.getName());
            notifyListeners("opProgress", ev);
            if (copyCounter[1] > 0) postProgressNotif("Копирование", src.getName(), copyCounter[0], copyCounter[1]);
        }
    }

    // Поток с прогрессом: крупный файл внутри архива теперь двигает полосу по байтам,
    // а не «замирает» на 1/1 до самого конца
    // ==================== распаковка: совпадения имён, ошибки, защита путей ====================
    // Вопросы уходят в приложение тем же каналом, что и у копирования («xferAsk»),
    // ответы приходят через xferResolve — то же окно, те же кнопки.

    // Наследуется от Error сознательно: ветки распаковки ловят Exception на каждом шагу,
    // а отмена должна пройти сквозь них до самого верха, не превратившись в «ошибку формата».
    static class ExCancel extends Error { ExCancel() { super("Отменено"); } }

    class ExCtx {
        String fileRule = "ask";     // skip | overwrite | overwriteDiff | keepBoth | ask
        String errRule = null;       // «пропустить все» после ответа на ошибку
        boolean quiet;               // тихий режим (временные распаковки): без вопросов, как раньше
        String arcName = "";
        int num = 0;
        long bytesTotal = 0;         // для скорости и остатка времени в окне хода
        volatile long bytesDone = 0;
        long lastBytesEv = 0;
        File destRoot;               // папка назначения всей распаковки
        String dirRule;              // «применить ко всем папкам»: merge | skip | replaceDir | keepBoth
        final java.util.HashMap<String, String> dirMap = new java.util.HashMap<>();   // папка верхнего уровня → как класть ("" = пропустить всю)
    }

    private final Object exAskLock = new Object();
    private volatile JSObject exPendingAsk = null;
    private volatile String exAnswer; private volatile boolean exAnsFiles; private volatile String exAnsName;

    boolean exHasPending() { return exPendingAsk != null; }

    void exDeliver(String action, boolean allFiles, String newName) {
        synchronized (exAskLock) { exAnswer = action; exAnsFiles = allFiles; exAnsName = newName; exAskLock.notifyAll(); }
    }

    private String exAsk(ExCtx cx, JSObject p) throws ExCancel {
        String a;
        synchronized (exAskLock) {
            exAnswer = null; exAnsName = null; exAnsFiles = false; exPendingAsk = p;
            notifyListeners("xferAsk", p);
            while (exAnswer == null) { try { exAskLock.wait(500); } catch (InterruptedException ignored) {} }
            a = exAnswer; exPendingAsk = null;
        }
        if (a == null || a.equals("cancel")) throw new ExCancel();
        return a;
    }

    /** Защита от «../» в имени записи: путь не должен выйти за папку назначения. */
    private File safeChild(File destDir, String entryName) throws java.io.IOException {
        String nm = entryName.replace('\\', '/');
        while (nm.startsWith("/")) nm = nm.substring(1);
        File out = new File(destDir, nm);
        String base = destDir.getCanonicalPath();
        String full = out.getCanonicalPath();
        if (!full.equals(base) && !full.startsWith(base + File.separator))
            throw new java.io.IOException("Опасный путь в архиве: " + entryName);
        return out;
    }

    /** Папки в списке «что достать» приходят с «/» на конце и означают всё их содержимое. */
    private static java.util.List<String> exOnlyPrefixes(java.util.Set<String> only) {
        if (only == null) return null;
        java.util.List<String> ps = new java.util.ArrayList<>();
        for (String s : only) if (s.endsWith("/")) ps.add(s);
        return ps.isEmpty() ? null : ps;
    }

    private static boolean exWanted(java.util.Set<String> only, java.util.List<String> ps, String nm) {
        if (only == null) return true;
        if (only.contains(nm)) return true;
        if (ps != null) for (String p : ps) if (nm.startsWith(p)) return true;
        return false;
    }

    private File exFree(File out, String want) {
        File dir = out.getParentFile() == null ? new File("/") : out.getParentFile();
        if (want != null) { want = want.replace('\\', '/').trim(); if (want.isEmpty() || want.contains("/") || want.equals(".") || want.equals("..")) want = null; }   // имя не должно быть путём
        if (want != null) { File w = new File(dir, want); if (!w.exists()) return w; }
        String name = out.getName(); int dot = name.lastIndexOf('.');
        String b = dot > 0 ? name.substring(0, dot) : name, e = dot > 0 ? name.substring(dot) : "";
        for (int i = 1; ; i++) { File c = new File(dir, b + " (" + i + ")" + e); if (!c.exists()) return c; }
    }

    /**
     * Папка верхнего уровня уже есть в назначении — вопрос, как при копировании:
     * объединить / пропустить / заменить / оставить обе. Решение запоминается на всю папку.
     * Возвращает имя, под которым класть («» — пропускать всё содержимое).
     */
    private String exTopDir(ExCtx cx, File destDir, String top) throws Exception {
        String got = cx.dirMap.get(top);
        if (got != null) return got;
        File d = new File(destDir, top);
        String mapped = top;
        if (d.exists()) {
            String a = cx.dirRule;
            if (a == null) {
                JSObject p = new JSObject();
                p.put("kind", "conflict"); p.put("name", top);
                p.put("isDir", true);
                p.put("srcSize", 0); p.put("srcMtime", 0);
                p.put("dstSize", d.isDirectory() ? 0 : d.length()); p.put("dstMtime", d.lastModified());
                p.put("same", false);
                p.put("srcPath", cx.arcName + "/" + top); p.put("dstPath", d.getAbsolutePath());
                p.put("num", ++cx.num); p.put("mode", "copy");
                a = exAsk(cx, p);
                if (exAnsFiles) cx.dirRule = a;
            }
            if (a.equals("skip")) mapped = "";
            else if (a.equals("replaceDir")) { deleteRecursive(d); }
            else if (a.equals("keepBoth") || a.equals("rename")) { String want = exAnsName; exAnsName = null; mapped = exFree(d, want).getName(); }
            else { if (d.isFile()) d.delete(); }   // объединить/перезаписать; файл на месте папки убираем
        }
        cx.dirMap.put(top, mapped);
        return mapped;
    }

    /** Применяет решение по папке верхнего уровня к пути записи. null — запись пропускается. */
    private String exApplyTop(ExCtx cx, File destDir, String entryName) throws Exception {
        String nm = entryName.replace('\\', '/');
        while (nm.startsWith("/")) nm = nm.substring(1);
        if (cx == null || cx.quiet) return nm;
        int slash = nm.indexOf('/');
        if (slash <= 0) return nm;
        String top = nm.substring(0, slash);
        String mapped = exTopDir(cx, destDir, top);
        if (mapped.isEmpty()) return null;
        return mapped.equals(top) ? nm : mapped + nm.substring(slash);
    }

    /** Папка из архива: те же решения по верхнему уровню, затем создание. null — пропущена. */
    private File exDirOut(ExCtx cx, File destDir, String entryName) throws Exception {
        String nm = exApplyTop(cx, destDir, entryName);
        if (nm == null) return null;
        File out = safeChild(destDir, nm);
        out.mkdirs();
        return out;
    }

    /**
     * Куда класть запись архива. Проверяет выход за папку, при совпадении имён задаёт вопрос
     * (перезаписать / пропустить / оставить оба / только если различаются, «ко всем»).
     * null — запись пропускается.
     */
    private File exOut(ExCtx cx, File destDir, String entryName, long size, long mtime) throws Exception {
        String nmR = exApplyTop(cx, destDir, entryName);
        if (nmR == null) return null;   // вся папка пропущена ответом
        File out = safeChild(destDir, nmR);
        if (cx == null || cx.quiet) { if (out.getParentFile() != null) out.getParentFile().mkdirs(); return out; }
        if (out.exists()) {
            boolean sameKnown = size >= 0 && out.length() == size && mtime > 0 && Math.abs(out.lastModified() - mtime) < 2000;
            String rule = cx.fileRule;
            if (rule.equals("ask")) {
                JSObject p = new JSObject();
                String nm = nmR;
                p.put("kind", "conflict"); p.put("name", nm.contains("/") ? nm.substring(nm.lastIndexOf('/') + 1) : nm);
                p.put("isDir", out.isDirectory());
                p.put("srcSize", size < 0 ? 0 : size); p.put("srcMtime", mtime > 0 ? mtime : 0);
                p.put("dstSize", out.isDirectory() ? 0 : out.length()); p.put("dstMtime", out.lastModified());
                p.put("same", sameKnown);
                p.put("srcPath", cx.arcName + "/" + nm); p.put("dstPath", out.getAbsolutePath());
                p.put("num", ++cx.num); p.put("mode", "copy");
                String a = exAsk(cx, p);
                if (a.equals("merge") || a.equals("replaceDir") || a.equals("resume")) a = "overwrite";
                if (exAnsFiles) cx.fileRule = a;
                rule = a;
            }
            if (rule.equals("overwriteDiff")) rule = sameKnown ? "skip" : "overwrite";
            if (rule.equals("skip")) return null;
            if (rule.equals("keepBoth")) { String want = exAnsName; exAnsName = null; out = exFree(out, want); }
            else if (out.isDirectory()) { deleteRecursive(out); }   // на месте файла оказалась папка — «перезаписать» её убирает
        }
        if (out.getParentFile() != null) out.getParentFile().mkdirs();
        return out;
    }

    /**
     * Ошибка на одном файле: вопрос «повторить / пропустить / пропустить все / отменить».
     * true — пропустить и идти дальше; false — повторить попытку.
     */
    private boolean exGuard(ExCtx cx, String nm, Exception e) throws Exception {
        if (cx == null || cx.quiet) throw e;
        if ("skip".equals(cx.errRule)) return true;
        JSObject p = new JSObject();
        p.put("kind", "error"); p.put("name", nm);
        p.put("msg", e.getMessage() == null ? e.toString() : e.getMessage());
        p.put("num", ++cx.num);
        String a = exAsk(cx, p);
        if (exAnsFiles && a.equals("skip")) cx.errRule = "skip";
        if (a.equals("retry")) return false;
        if (a.equals("skip")) return true;
        throw new ExCancel();
    }

    /** Байты для скорости в окне хода: добавляются в ближайшее событие opProgress. */
    private void exAddBytes(ExCtx cx, long n) { if (cx != null) cx.bytesDone += n; }

    private void exPutBytes(ExCtx cx, JSObject ev) {
        if (cx != null && cx.bytesTotal > 0) { ev.put("b", cx.bytesDone); ev.put("bt", cx.bytesTotal); }
    }

    // ---- кодировка имён в старых zip (CP866/CP1251 и т.п.) ----
    private final java.util.HashMap<String, String> zipCsCache = new java.util.HashMap<>();

    private int zipBadNames(File f, String cs) throws Exception {
        net.lingala.zip4j.ZipFile z = new net.lingala.zip4j.ZipFile(f);
        try {
            z.setCharset(java.nio.charset.Charset.forName(cs));
            int bad = 0;
            for (net.lingala.zip4j.model.FileHeader h : z.getFileHeaders()) if (h.getFileName().indexOf('\uFFFD') >= 0) bad++;
            return bad;
        } finally { try { z.close(); } catch (Exception ignored) {} }
    }

    /** Какой кодировкой читать имена в этом zip: UTF-8, а если имена «битые» — пробуем DOS/Windows русские и GBK. */
    private String zipCharsetName(File f) {
        String key = arcStamp(f);
        String c = zipCsCache.get(key);
        if (c != null) return c;
        String best = "UTF-8";
        try {
            int bestBad = zipBadNames(f, "UTF-8");
            if (bestBad > 0) for (String cand : new String[]{ "IBM866", "windows-1251", "GBK" }) {
                try { int b = zipBadNames(f, cand); if (b < bestBad) { bestBad = b; best = cand; if (b == 0) break; } } catch (Throwable ignored) {}
            }
        } catch (Throwable ignored) {}
        zipCsCache.put(key, best);
        return best;
    }

    private net.lingala.zip4j.ZipFile openZip4j(File f) {
        net.lingala.zip4j.ZipFile z = new net.lingala.zip4j.ZipFile(f);
        String cs = zipCharsetName(f);
        if (!cs.equals("UTF-8")) { try { z.setCharset(java.nio.charset.Charset.forName(cs)); } catch (Throwable ignored) {} }
        return z;
    }

    /** Обычный zip той же кодировкой, что и оглавление — иначе имена из списка не найдутся. */
    private ZipFile openZip(File f) throws Exception {
        String cs = zipCharsetName(f);
        if (android.os.Build.VERSION.SDK_INT >= 24) {
            try { return new ZipFile(f, java.nio.charset.Charset.forName(cs)); }
            catch (Throwable t) { try { return new ZipFile(f, java.nio.charset.Charset.forName("ISO-8859-1")); } catch (Throwable t2) { return new ZipFile(f); } }
        }
        return new ZipFile(f);
    }

    private class ProgOut extends OutputStream {
        private final OutputStream out; private final String name;
        private final int idx, total; private final long size;
        private long wrote = 0, lastEv = 0;
        private final boolean quiet;
        private final ExCtx cx;
        ProgOut(OutputStream out, String name, int idx, int total, long size) { this(out, name, idx, total, size, false, null); }
        ProgOut(OutputStream out, String name, int idx, int total, long size, boolean quiet) { this(out, name, idx, total, size, quiet, null); }
        ProgOut(OutputStream out, String name, int idx, int total, long size, boolean quiet, ExCtx cx) {
            this.out = out; this.name = name; this.idx = idx; this.total = Math.max(1, total); this.size = size; this.quiet = quiet; this.cx = cx;
        }
        private void tick(boolean force) {
            long now = System.currentTimeMillis();
            if (!force && now - lastEv < 120) return;
            lastEv = now;
            double frac = size > 0 ? Math.min(1.0, (double) wrote / size) : 1.0;
            int pct = (int) Math.round(((idx + frac) / total) * 100.0);
            if (pct > 100) pct = 100;
            JSObject ev = new JSObject(); ev.put("done", pct); ev.put("total", 100); ev.put("name", name);
            exPutBytes(cx, ev);
            notifyListeners("opProgress", ev);           // полоса в приложении идёт всегда
            if (!quiet) postProgressNotif("Распаковка", name, pct, 100);   // уведомление — только для настоящих операций
        }
        @Override public void write(int b) throws java.io.IOException { out.write(b); wrote++; exAddBytes(cx, 1); tick(false); }
        @Override public void write(byte[] b, int off, int len) throws java.io.IOException { out.write(b, off, len); wrote += len; exAddBytes(cx, len); tick(false); }
        @Override public void flush() throws java.io.IOException { out.flush(); }
        @Override public void close() throws java.io.IOException { out.close(); tick(true); }
    }

    private void postProgressNotif(String title, String text, int prog, int max) {
        try {
            NotificationManager nm = (NotificationManager) getContext().getSystemService(Context.NOTIFICATION_SERVICE);
            if (android.os.Build.VERSION.SDK_INT >= 26) {
                NotificationChannel ch = new NotificationChannel("yev_progress", "Операции с файлами", NotificationManager.IMPORTANCE_LOW);
                nm.createNotificationChannel(ch);
            }
            Notification.Builder b = android.os.Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(getContext(), "yev_progress") : new Notification.Builder(getContext());
            b.setContentTitle(title).setContentText(text).setSmallIcon(android.R.drawable.stat_sys_download)
             .setProgress(max, prog, false).setOngoing(prog < max).setOnlyAlertOnce(true);
            try {
                Intent li = getContext().getPackageManager().getLaunchIntentForPackage(getContext().getPackageName());
                if (li != null) {
                    li.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    int fl = Build.VERSION.SDK_INT >= 23 ? android.app.PendingIntent.FLAG_IMMUTABLE | android.app.PendingIntent.FLAG_UPDATE_CURRENT : android.app.PendingIntent.FLAG_UPDATE_CURRENT;
                    b.setContentIntent(android.app.PendingIntent.getActivity(getContext(), 0, li, fl));
                }
            } catch (Throwable ignored) {}
            nm.notify(777, b.build());
        } catch (Exception ignored) {}
    }

    // ---- Подключённые тома: внутренняя память, SD-карты, USB-флешки ----
    @PluginMethod
    public void storageVolumes(PluginCall call) {
        JSArray arr = new JSArray();
        java.util.LinkedHashMap<String, JSObject> seen = new java.util.LinkedHashMap<>();
        try {
            // 1) внутренняя память — всегда первой
            File primary = Environment.getExternalStorageDirectory();
            if (primary != null) {
                JSObject o = new JSObject();
                o.put("path", primary.getAbsolutePath());
                o.put("name", "Внутренняя память");
                o.put("primary", true);
                o.put("removable", false);
                seen.put(primary.getAbsolutePath(), o);
            }
            // 2) через StorageManager (Android 7+) — самые точные имена и признак съёмности
            if (Build.VERSION.SDK_INT >= 24) {
                android.os.storage.StorageManager sm = (android.os.storage.StorageManager) getContext().getSystemService(Context.STORAGE_SERVICE);
                if (sm != null) {
                    for (android.os.storage.StorageVolume v : sm.getStorageVolumes()) {
                        File dir = null;
                        if (Build.VERSION.SDK_INT >= 30) { try { dir = v.getDirectory(); } catch (Throwable ignored) {} }
                        if (dir == null) {
                            try {
                                java.lang.reflect.Method m = v.getClass().getMethod("getPathFile");
                                Object r = m.invoke(v); if (r instanceof File) dir = (File) r;
                            } catch (Throwable ignored) {}
                        }
                        if (dir == null) {
                            try {
                                java.lang.reflect.Method m = v.getClass().getMethod("getPath");
                                Object r = m.invoke(v); if (r instanceof String) dir = new File((String) r);
                            } catch (Throwable ignored) {}
                        }
                        if (dir == null || !dir.exists()) continue;
                        String path = dir.getAbsolutePath();
                        if (seen.containsKey(path)) { if (v.isRemovable()) seen.get(path).put("removable", true); continue; }
                        String desc = null;
                        try { desc = v.getDescription(getContext()); } catch (Throwable ignored) {}
                        JSObject o = new JSObject();
                        o.put("path", path);
                        o.put("name", desc != null && desc.length() > 0 ? desc : (v.isRemovable() ? "Съёмный носитель" : "Хранилище"));
                        o.put("primary", v.isPrimary());
                        o.put("removable", v.isRemovable());
                        seen.put(path, o);
                    }
                }
            }
            // 3) добор через /storage — ловит флешки, которые StorageManager не отдал
            File st = new File("/storage");
            File[] mounts = st.listFiles();
            if (mounts != null) {
                for (File m : mounts) {
                    String nm = m.getName();
                    if (nm.equals("self") || nm.equals("emulated") || nm.equals("enc_emulated") || nm.equals("knox-emulated")) continue;
                    String path = m.getAbsolutePath();
                    if (seen.containsKey(path)) continue;
                    if (!m.canRead()) continue;
                    File[] probe = m.listFiles();
                    if (probe == null) continue; // не смонтирован / нет доступа
                    JSObject o = new JSObject();
                    o.put("path", path);
                    boolean looksUsb = nm.matches("(?i).*(usb|otg).*");
                    o.put("name", looksUsb ? "USB-накопитель" : ("Носитель " + nm));
                    o.put("primary", false);
                    o.put("removable", true);
                    seen.put(path, o);
                }
            }
        } catch (Throwable ignored) {}
        // свободное/полное место каждого тома — для строки «свободно X из Y» в списке накопителей
        for (JSObject o : seen.values()) {
            try {
                android.os.StatFs fs = new android.os.StatFs(o.getString("path"));
                o.put("free", fs.getAvailableBytes());
                o.put("total", fs.getTotalBytes());
            } catch (Throwable ignored) {}
        }
        for (JSObject o : seen.values()) arr.put(o);
        JSObject ret = new JSObject();
        ret.put("volumes", arr);
        call.resolve(ret);
    }

    @PluginMethod
    public void hasAllFiles(PluginCall call) {
        boolean granted;
        if (Build.VERSION.SDK_INT >= 30) granted = Environment.isExternalStorageManager();
        else granted = true;
        JSObject ret = new JSObject();
        ret.put("granted", granted);
        call.resolve(ret);
    }

    @PluginMethod
    public void requestAllFiles(PluginCall call) {
        try {
            Intent i;
            if (Build.VERSION.SDK_INT >= 30) {
                i = new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION);
                i.setData(Uri.parse("package:" + getContext().getPackageName()));
            } else {
                i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                i.setData(Uri.parse("package:" + getContext().getPackageName()));
            }
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            getContext().startActivity(i);
            call.resolve();
        } catch (Exception e) {
            call.reject(e.getMessage());
        }
    }

    @PluginMethod
    public void installSplit(PluginCall call) {
        String uriStr = call.getString("uri");
        if (uriStr == null) { call.reject("no uri"); return; }
        try {
            File f = toFile(uriStr);
            if (!f.exists()) { call.reject("Файл не найден: " + f.getAbsolutePath()); return; }
            registerInstallReceiver();
            PackageInstaller pi = getContext().getPackageManager().getPackageInstaller();
            PackageInstaller.SessionParams params = new PackageInstaller.SessionParams(PackageInstaller.SessionParams.MODE_FULL_INSTALL);
            int sessionId = pi.createSession(params);
            PackageInstaller.Session session = pi.openSession(sessionId);
            ZipFile zf = new ZipFile(f);
            Enumeration<? extends ZipEntry> en = zf.entries();
            int idx = 0; boolean any = false;
            byte[] buf = new byte[65536];
            while (en.hasMoreElements()) {
                ZipEntry e = en.nextElement();
                if (e.isDirectory()) continue;
                String nm = e.getName().toLowerCase();
                if (!nm.endsWith(".apk")) continue;
                long sz = e.getSize();
                InputStream in = zf.getInputStream(e);
                if (sz <= 0) {
                    ByteArrayOutputStream bos = new ByteArrayOutputStream();
                    int m; while ((m = in.read(buf)) > 0) bos.write(buf, 0, m);
                    byte[] data = bos.toByteArray();
                    OutputStream out = session.openWrite("split" + idx, 0, data.length);
                    out.write(data); session.fsync(out); out.close();
                } else {
                    OutputStream out = session.openWrite("split" + idx, 0, sz);
                    int n; while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
                    session.fsync(out); out.close();
                }
                in.close(); idx++; any = true;
            }
            zf.close();
            if (!any) { session.abandon(); call.reject("В пакете нет apk"); return; }
            Intent statusIntent = new Intent("leshugan.fm.INSTALL_RESULT").setPackage(getContext().getPackageName());
            int flags = PendingIntent.FLAG_UPDATE_CURRENT;
            if (Build.VERSION.SDK_INT >= 31) flags |= PendingIntent.FLAG_MUTABLE;
            PendingIntent pending = PendingIntent.getBroadcast(getContext(), sessionId, statusIntent, flags);
            session.commit(pending.getIntentSender());
            session.close();
            call.resolve();
        } catch (Exception e) { call.reject(e.getMessage()); }
    }

    @PluginMethod
    public void installApk(PluginCall call) {
        String uriStr = call.getString("uri");
        if (uriStr == null) { call.reject("no uri"); return; }
        try {
            File f = toFile(uriStr);
            if (!f.exists()) { call.reject("Файл не найден: " + f.getAbsolutePath()); return; }
            registerInstallReceiver();
            PackageInstaller pi = getContext().getPackageManager().getPackageInstaller();
            PackageInstaller.SessionParams params = new PackageInstaller.SessionParams(PackageInstaller.SessionParams.MODE_FULL_INSTALL);
            int sessionId = pi.createSession(params);
            PackageInstaller.Session session = pi.openSession(sessionId);
            OutputStream out = session.openWrite("apk", 0, f.length());
            InputStream in = new FileInputStream(f);
            byte[] buf = new byte[65536];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            session.fsync(out);
            in.close();
            out.close();
            Intent statusIntent = new Intent("leshugan.fm.INSTALL_RESULT").setPackage(getContext().getPackageName());
            int flags = PendingIntent.FLAG_UPDATE_CURRENT;
            if (Build.VERSION.SDK_INT >= 31) flags |= PendingIntent.FLAG_MUTABLE;
            PendingIntent pending = PendingIntent.getBroadcast(getContext(), sessionId, statusIntent, flags);
            session.commit(pending.getIntentSender());
            session.close();
            call.resolve();
        } catch (Exception e) { call.reject(e.getMessage()); }
    }

    @PluginMethod
    public void uninstall(PluginCall call) {
        String uriStr = call.getString("uri");
        if (uriStr == null) { call.reject("no uri"); return; }
        try {
            File f = toFile(uriStr);
            PackageInfo info = getContext().getPackageManager().getPackageArchiveInfo(f.getAbsolutePath(), 0);
            if (info == null) { call.reject("Не удалось прочитать пакет"); return; }
            Intent i = new Intent(Intent.ACTION_DELETE, Uri.parse("package:" + info.packageName));
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            getContext().startActivity(i);
            call.resolve();
        } catch (Exception e) { call.reject(e.getMessage()); }
    }

    private void registerInstallReceiver() {
        if (instRegistered) return;
        BroadcastReceiver r = new BroadcastReceiver() {
            @Override public void onReceive(Context c, Intent i) {
                int status = i.getIntExtra(PackageInstaller.EXTRA_STATUS, -1);
                if (status == PackageInstaller.STATUS_PENDING_USER_ACTION) {
                    Intent confirm = i.getParcelableExtra(Intent.EXTRA_INTENT);
                    if (confirm != null) { confirm.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); c.startActivity(confirm); }
                }
            }
        };
        IntentFilter filter = new IntentFilter("leshugan.fm.INSTALL_RESULT");
        if (Build.VERSION.SDK_INT >= 33) getContext().registerReceiver(r, filter, Context.RECEIVER_NOT_EXPORTED);
        else getContext().registerReceiver(r, filter);
        instRegistered = true;
    }

    // Потоковая отдача файла из облака: плеер получает адрес и начинает играть сразу,
    // не дожидаясь полной загрузки; перемотка работает через запросы Range
    @PluginMethod
    public void streamGdrive(PluginCall call) {
        String id = call.getString("id");
        String mime = call.getString("mime", "video/*");
        long size = 0;
        try { size = Long.parseLong(call.getString("size", "0")); } catch (Exception ignored) {}
        if (id == null) { call.reject("no id"); return; }
        try {
            gdEnsure();
            String url = "https://www.googleapis.com/drive/v3/files/" + java.net.URLEncoder.encode(id, "UTF-8") + "?alt=media";
            String link = StreamServer.get().publish(StreamServer.httpSource(url, "Bearer " + gdToken, mime, size));
            JSObject r = new JSObject(); r.put("url", link); call.resolve(r);
        } catch (Exception e) { call.reject(e.getMessage()); }
    }

    @PluginMethod
    public void streamWebdav(PluginCall call) {
        String url = call.getString("url");
        String user = call.getString("user", ""), pass = call.getString("pass", "");
        String mime = call.getString("mime", "video/*");
        long size = 0;
        try { size = Long.parseLong(call.getString("size", "0")); } catch (Exception ignored) {}
        if (url == null) { call.reject("no url"); return; }
        try {
            String auth = "Basic " + android.util.Base64.encodeToString((user + ":" + pass).getBytes("UTF-8"), android.util.Base64.NO_WRAP);
            String link = StreamServer.get().publish(StreamServer.httpSource(url, auth, mime, size));
            JSObject r = new JSObject(); r.put("url", link); call.resolve(r);
        } catch (Exception e) { call.reject(e.getMessage()); }
    }

    // Долгая операция: держим приложение живым службой переднего плана
    @PluginMethod
    public void opBegin(PluginCall call) {
        try {
            OpService.start(getContext(), call.getString("title", "Операция с файлами"), call.getString("text", ""),
                    call.getInt("progress", 0), call.getInt("max", 100));
            call.resolve();
        } catch (Exception e) { call.reject(e.getMessage()); }
    }

    @PluginMethod
    public void opUpdate(PluginCall call) {
        try {
            if (OpService.isRunning())
                OpService.start(getContext(), call.getString("title", "Операция с файлами"), call.getString("text", ""),
                        call.getInt("progress", 0), call.getInt("max", 100));
            call.resolve();
        } catch (Exception e) { call.reject(e.getMessage()); }
    }

    @PluginMethod
    public void opEnd(PluginCall call) {
        try { OpService.stop(getContext()); call.resolve(); } catch (Exception e) { call.reject(e.getMessage()); }
    }

    @PluginMethod
    public void notifyProgress(PluginCall call) {
        String title = call.getString("title", "Операция");
        int progress = call.getInt("progress", 0);
        int max = call.getInt("max", 100);
        String text = call.getString("text", "");
        try {
            NotificationManager nm = (NotificationManager) getContext().getSystemService(Context.NOTIFICATION_SERVICE);
            String ch = "yev_progress";
            Notification.Builder b;
            if (Build.VERSION.SDK_INT >= 26) {
                NotificationChannel c = new NotificationChannel(ch, "Операции с файлами", NotificationManager.IMPORTANCE_LOW);
                nm.createNotificationChannel(c);
                b = new Notification.Builder(getContext(), ch);
            } else {
                b = new Notification.Builder(getContext());
            }
            b.setContentTitle(title).setContentText(text)
             .setSmallIcon(android.R.drawable.stat_sys_download)
             .setProgress(max, progress, false).setOngoing(true).setOnlyAlertOnce(true);
            nm.notify(777, b.build());
            call.resolve();
        } catch (Exception e) { call.reject(e.getMessage()); }
    }

    @PluginMethod
    public void cancelNotify(PluginCall call) {
        try { NotificationManager nm = (NotificationManager) getContext().getSystemService(Context.NOTIFICATION_SERVICE); nm.cancel(777); } catch (Exception ignored) {}
        call.resolve();
    }

    /** Что мы знаем про размеры файлов в наблюдаемой папке — чтобы считать разницу. */
    private final java.util.Map<String, Long> watchSizes = new java.util.concurrent.ConcurrentHashMap<>();

    @PluginMethod
    public void watch(PluginCall call) {
        String uriStr = call.getString("uri");
        if (uriStr == null) { call.reject("no uri"); return; }
        try {
            final String path = toFile(uriStr).getAbsolutePath();
            if (observer != null) { observer.stopWatching(); observer = null; }
            watchSizes.clear();
            int mask = FileObserver.CREATE | FileObserver.DELETE | FileObserver.MOVED_FROM | FileObserver.MOVED_TO | FileObserver.CLOSE_WRITE | FileObserver.ATTRIB | FileObserver.DELETE_SELF | FileObserver.MOVE_SELF;
            observer = new FileObserver(path, mask) {
                @Override public void onEvent(int event, String p) {
                    // событие с именем файла — интерфейс правит список точечно, без перечитки папки
                    JSObject ev = new JSObject();
                    int e = event & FileObserver.ALL_EVENTS;
                    String kind = (e & (FileObserver.DELETE_SELF | FileObserver.MOVE_SELF)) != 0 ? "self"
                            : (e & (FileObserver.DELETE | FileObserver.MOVED_FROM)) != 0 ? "gone"
                            : (e & (FileObserver.CREATE | FileObserver.MOVED_TO)) != 0 ? "new"
                            : "mod";
                    ev.put("ev", kind);
                    if (p != null) ev.put("name", p);
                    // вес папок правим на разницу прямо здесь — без обхода дерева
                    if (p != null && !"self".equals(kind)) {
                        try {
                            File chd = new File(path, p);
                            if ("gone".equals(kind)) {
                                Long known = watchSizes.remove(p);
                                if (known != null) core().addBytes(chd.getAbsolutePath(), -known, -1);
                            } else {
                                long now = chd.isFile() ? chd.length() : 0;
                                Long prev = watchSizes.put(p, now);
                                long delta = now - (prev == null ? 0 : prev);
                                if (delta != 0) core().addBytes(chd.getAbsolutePath(), delta, prev == null ? 1 : 0);
                            }
                        } catch (Throwable ignored) {}
                    }
                    notifyListeners("fschange", ev);
                }
            };
            observer.startWatching();
            call.resolve();
        } catch (Exception e) { call.reject(e.getMessage()); }
    }

    /** Форматы, которые прежние библиотеки читают плохо (или не расшифровывают) — их сразу отдаём движку 7-Zip. */
    private boolean engineFirst(String kind) {
        return SevenZipEngine.available() && (kind.equals("rar") || kind.equals("rar5") || kind.equals("7z") || kind.equals("bz2") || kind.equals("xz") || kind.equals("unknown"));
    }

    /** Оглавление движком 7-Zip. Возвращает null, если движок не смог (тогда работают прежние библиотеки). */
    private JSObject engineList(File f, String password, PluginCall call) {
        if (!SevenZipEngine.available()) return null;
        try {
            java.util.List<SevenZipEngine.Item> its = SevenZipEngine.list(f, password);
            JSArray arr = new JSArray();
            boolean enc = false;
            for (SevenZipEngine.Item it : its) {
                JSObject o = new JSObject();
                o.put("name", it.name); o.put("size", it.size); o.put("dir", it.dir);
                if (it.enc) { o.put("enc", true); enc = true; }
                arr.put(o);
            }
            JSObject ret = new JSObject();
            ret.put("entries", arr); ret.put("encrypted", enc); ret.put("src", "7zip");
            arcListPut(f, password, arr, enc);
            return ret;
        } catch (SevenZipEngine.NeedPassword np) {
            JSObject ret = new JSObject(); ret.put("entries", new JSArray()); ret.put("encrypted", true); ret.put("src", "7zip"); return ret;
        } catch (SevenZipEngine.WrongPassword wp) {
            JSObject ret = new JSObject(); ret.put("entries", new JSArray()); ret.put("encrypted", true); ret.put("src", "7zip"); return ret;
        } catch (Throwable t) { return null; }
    }

    /** Распаковка движком 7-Zip. true — сделано; false — движок не смог, пробуем прежние библиотеки. */
    private boolean engineExtract(File f, File destDir, java.util.Set<String> only, String password, boolean quiet, PluginCall call) throws SevenZipEngine.NeedPassword, SevenZipEngine.WrongPassword {
        try { return engineExtract(f, destDir, only, password, quiet, call, null); }
        catch (SevenZipEngine.NeedPassword np) { throw np; }
        catch (SevenZipEngine.WrongPassword wp) { throw wp; }
        catch (ExCancel ce) { return true; }   // без вопросов (cx нет) сюда не попадаем
        catch (Throwable t) { return false; }
    }

    private boolean engineExtract(File f, File destDir, java.util.Set<String> only, String password, boolean quiet, PluginCall call, final ExCtx cx)
            throws SevenZipEngine.NeedPassword, SevenZipEngine.WrongPassword, ExCancel {
        if (!SevenZipEngine.available()) return false;
        final boolean q = quiet;
        final File dd = destDir;
        try {
            if (cx != null && cx.bytesTotal <= 0) {
                try {
                    long bt = 0;
                    java.util.List<String> psB = exOnlyPrefixes(only);
                    for (SevenZipEngine.Item it : SevenZipEngine.list(f, password))
                        if (!it.dir && it.size > 0 && exWanted(only, psB, it.name)) bt += it.size;
                    cx.bytesTotal = bt;
                } catch (Throwable ignored) {}
            }
            SevenZipEngine.Resolver res = (cx == null || cx.quiet) ? null : new SevenZipEngine.Resolver() {
                @Override public File out(String name, long size) throws Exception { return exOut(cx, dd, name, size, 0); }
                @Override public boolean err(String name, String code) throws Exception {
                    // сплошной поток движка не перечитать — «повторить» здесь равно «пропустить»
                    Exception e = new Exception(code);
                    exGuard(cx, name, e);
                    return true;
                }
                @Override public void bytes(int n) { exAddBytes(cx, n); }
            };
            SevenZipEngine.extract(f, destDir, only, password, new SevenZipEngine.Progress() {
                @Override public void on(String name, int done, int total) {
                    JSObject ev = new JSObject();
                    int pct = total > 0 ? (int) (done * 100.0 / total) : 100;
                    ev.put("done", pct); ev.put("total", 100); ev.put("name", name);
                    exPutBytes(cx, ev);
                    notifyListeners("opProgress", ev);
                    if (!q) postProgressNotif("Распаковка", name, pct, 100);
                }
            }, res);
            return true;
        } catch (SevenZipEngine.NeedPassword np) { throw np;
        } catch (SevenZipEngine.WrongPassword wp) { throw wp;
        } catch (ExCancel ce) { throw ce;
        } catch (Throwable t) { return false; }
    }

    /** Копирование файла целиком (используется после распаковки во временную папку). */
    private void copyFileTo(File from, File to) throws java.io.IOException {
        InputStream is = new FileInputStream(from);
        OutputStream os = new FileOutputStream(to);
        try { byte[] bb = new byte[65536]; int rr; while ((rr = is.read(bb)) > 0) os.write(bb, 0, rr); }
        finally { try { is.close(); } catch (Exception ignored) {} try { os.close(); } catch (Exception ignored) {} }
    }

    /** Список имён записей из вызова интерфейса (null — весь архив). */
    private java.util.Set<String> namesSet(JSArray names) throws org.json.JSONException {
        if (names == null) return null;
        java.util.Set<String> out = new java.util.HashSet<>();
        for (int i = 0; i < names.length(); i++) out.add(String.valueOf(names.get(i)));
        return out;
    }

    /** Открытие RAR через junrar с паролем (конструктор ищем отражением — он есть не во всех версиях). */
    private com.github.junrar.Archive rarOpen(File f, String password) throws Exception {
        if (password != null && !password.isEmpty()) {
            try {
                java.lang.reflect.Constructor<com.github.junrar.Archive> c = com.github.junrar.Archive.class.getConstructor(File.class, String.class);
                return c.newInstance(f, password);
            } catch (NoSuchMethodException ignored) {
            } catch (java.lang.reflect.InvocationTargetException ite) {
                Throwable cz = ite.getCause();
                if (cz instanceof Exception) throw (Exception) cz;
                throw ite;
            }
        }
        return new com.github.junrar.Archive(f);
    }

    /**
     * junrar и пароли (проверено на живых архивах):
     *   пароль не задан      → InitDeciphererFailedException («password should be specified»)
     *   пароль неверный      → CrcErrorException (данные) или CorruptHeaderException (скрытые имена)
     *   пароль верный        → распаковывается
     * CRC-ошибка бывает и у битого архива без пароля, поэтому её считаем «паролем» только там,
     * где мы уже знаем, что архив под паролем.
     */
    private boolean rarPassErr(Throwable t) {
        for (Throwable e = t; e != null; e = e.getCause()) {
            String n = e.getClass().getSimpleName();
            if (n.contains("Password") || n.contains("Crypt") || n.contains("Decipherer") || n.contains("CrcError") || n.contains("CorruptHeader")) return true;
            String m = e.getMessage();
            if (m != null && (m.toLowerCase().contains("password") || m.toLowerCase().contains("encrypt"))) return true;
        }
        return false;
    }

    /** Нужен ли этому RAR пароль (имена или данные зашифрованы). */
    private boolean rarProtected(File f, String password) {
        try {
            com.github.junrar.Archive a = rarOpen(f, password);
            try { return a.isPasswordProtected(); } finally { try { a.close(); } catch (Exception ignored) {} }
        } catch (Throwable t) { return rarPassErr(t); }
    }

    /** Ответ интерфейсу по ошибке RAR: нужен пароль / неверный пароль / обычная ошибка. */
    private void rejectRar(PluginCall call, File f, String password, Exception e) {
        boolean prot = rarProtected(f, password);
        if (prot && rarPassErr(e)) {
            if (password == null || password.isEmpty()) call.reject("Требуется пароль", "ENCRYPTED");
            else call.reject("Неверный пароль", "BADPASS");
            return;
        }
        if (prot && (password == null || password.isEmpty())) { call.reject("Требуется пароль", "ENCRYPTED"); return; }
        call.reject("RAR: " + (e.getMessage() != null ? e.getMessage() : e.getClass().getSimpleName()));
    }

    private boolean zipIsEncrypted(File f) {
        try { net.lingala.zip4j.ZipFile z = new net.lingala.zip4j.ZipFile(f); boolean e = z.isEncrypted(); z.close(); return e; }
        catch (Exception ex) { return false; }
    }

    /** zip4j: именно неверный пароль (а не любая ошибка). */
    private boolean zipWrongPass(Exception e) {
        if (e instanceof net.lingala.zip4j.exception.ZipException) {
            net.lingala.zip4j.exception.ZipException ze = (net.lingala.zip4j.exception.ZipException) e;
            if (ze.getType() == net.lingala.zip4j.exception.ZipException.Type.WRONG_PASSWORD) return true;
        }
        String m = e.getMessage();
        return m != null && (m.contains("Wrong password") || m.contains("Wrong Password") || m.contains("wrong password"));
    }

    /** Одну запись ZIP — ровно в указанный файл (без вложенных папок из архива). */
    private void zip4jExtractOne(File src, String entry, File dest, String password) throws Exception {
        net.lingala.zip4j.ZipFile z = openZip4j(src);
        if (password != null && password.length() > 0) z.setPassword(password.toCharArray());
        try {
            net.lingala.zip4j.model.FileHeader h = z.getFileHeader(entry);
            if (h == null) h = z.getFileHeader(entry.replace('/', '\\'));
            if (h == null) throw new java.io.FileNotFoundException("entry not found");
            File parent = dest.getParentFile() != null ? dest.getParentFile() : new File("/");
            parent.mkdirs();
            z.extractFile(h, parent.getAbsolutePath(), dest.getName());
        } finally { try { z.close(); } catch (Exception ignored) {} }
    }

    /**
     * 7z: зашифрованы ли данные. Оглавление про это не говорит (список способов сжатия пустой),
     * поэтому пробуем прочитать один байт первой записи без пароля: у зашифрованного архива
     * библиотека сразу сообщает, что без пароля нельзя.
     */
    private boolean sevenHasEnc(File f, String password) {
        try {
            org.apache.commons.compress.archivers.sevenz.SevenZFile z = open7z(f, null);
            try {
                org.apache.commons.compress.archivers.sevenz.SevenZArchiveEntry e;
                while ((e = z.getNextEntry()) != null) {
                    if (e.isDirectory() || !e.hasStream() || e.getSize() == 0) continue;
                    z.read();
                    return false;
                }
                return false;
            } finally { try { z.close(); } catch (Exception ignored) {} }
        } catch (org.apache.commons.compress.PasswordRequiredException pe) { return true;
        } catch (Throwable t) { String m = String.valueOf(t.getMessage()); return m.contains("assword") || m.contains("ncrypt"); }
    }

    /** libarchive: зашифрованный RAR5 — она такие не расшифровывает (сообщения у неё разные). */
    private boolean rar5EncErr(Throwable t) {
        for (Throwable e = t; e != null; e = e.getCause()) {
            String m = e.getMessage();
            if (m == null) continue;
            if (m.contains("ncrypt") || m.contains("assphrase") || m.contains("assword")) return true;
            if (m.contains("Unsupported block header size")) return true;   // так она падает на RAR5 с зашифрованными данными
        }
        return false;
    }

    /** 7z: ошибка распаковки похожа на неверный пароль (испорченный поток после расшифровки). */
    private boolean sevenPassErr(Exception e) {
        if (e instanceof org.apache.commons.compress.PasswordRequiredException) return true;
        String m = e.getMessage();
        return m != null && (m.contains("assword") || m.contains("hecksum") || m.contains("CRC") || m.contains("orrupt") || m.contains("LZMA") || m.contains("header") || m.contains("Header"));
    }

    private void zip4jExtract(File src, String destDir, java.util.List<String> names, String password) throws Exception {
        zip4jExtract(src, destDir, names, password, null);
    }

    private void zip4jExtract(File src, String destDir, java.util.List<String> names, String password, ExCtx cx) throws Exception {
        net.lingala.zip4j.ZipFile z = openZip4j(src);
        if (password != null) z.setPassword(password.toCharArray());
        try {
            File dd = new File(destDir);
            java.util.Set<String> onlyN = null;
            if (names != null && !names.isEmpty()) { onlyN = new java.util.HashSet<>(); for (String nm : names) onlyN.add(String.valueOf(nm).replace('\\', '/')); }
            java.util.List<String> ps = exOnlyPrefixes(onlyN);
            // список к распаковке: фильтруем всё оглавление (папка в списке означает всё её содержимое)
            java.util.List<net.lingala.zip4j.model.FileHeader> hs = new java.util.ArrayList<>();
            for (net.lingala.zip4j.model.FileHeader h : z.getFileHeaders()) {
                String nm = h.getFileName().replace('\\', '/');
                if (onlyN == null || exWanted(onlyN, ps, nm)) hs.add(h);
            }
            final boolean allMode = onlyN == null;
            int total = 0; long bt = 0;
            for (net.lingala.zip4j.model.FileHeader h : hs) if (!h.isDirectory()) { total++; bt += Math.max(0, h.getUncompressedSize()); }
            if (cx != null && cx.bytesTotal <= 0) cx.bytesTotal = bt;
            int done = 0;
            for (net.lingala.zip4j.model.FileHeader h : hs) {
                String nm = h.getFileName().replace('\\', '/');
                if (h.isDirectory()) { if (allMode || exWanted(onlyN, ps, nm)) exDirOut(cx, dd, nm); continue; }
                File out = exOut(cx, dd, nm, h.getUncompressedSize(), 0);
                if (out == null) { done++; continue; }   // ответ «пропустить»
                for (;;) {
                    try {
                        // zip4j кладёт файл сам: даём ему папку и итоговое имя (учитывает «оставить оба»)
                        File par = out.getParentFile() != null ? out.getParentFile() : dd;
                        z.extractFile(h, par.getAbsolutePath(), out.getName());
                        exAddBytes(cx, Math.max(0, h.getUncompressedSize()));
                        break;
                    } catch (Exception oe) {
                        try { out.delete(); } catch (Throwable ignored) {}
                        if (zipWrongPass(oe)) throw oe;             // неверный пароль — общий отказ, не по-файловый
                        if (exGuard(cx, nm, oe)) break;             // пропустить
                    }
                }
                done++;
                JSObject ev = new JSObject(); ev.put("done", done); ev.put("total", Math.max(1, total)); ev.put("name", nm);
                exPutBytes(cx, ev);
                notifyListeners("opProgress", ev);
            }
        } finally { try { z.close(); } catch (Exception ignored) {} }
    }

    // ==== gz / tar / tgz поддержка (без внешних библиотек) ====
    // Определение формата по сигнатуре (первые байты), расширение — только запасной вариант.
    // Значения сигнатур — публичные факты из спецификаций форматов.
    private String sniffKind(File f) {
        byte[] h = new byte[8];
        int n = -1;
        InputStream is = null;
        try { is = new FileInputStream(f); n = is.read(h); } catch (Exception ignored) {}
        finally { if (is != null) try { is.close(); } catch (Exception ignored) {} }
        if (n >= 4 && h[0] == 0x50 && h[1] == 0x4B) {          // "PK" — ZIP (в т.ч. apk/jar/docx)
            return "zip";
        }
        if (n >= 7 && h[0] == 0x52 && h[1] == 0x61 && h[2] == 0x72 && h[3] == 0x21
                && h[4] == 0x1A && h[5] == 0x07) {              // "Rar!\x1A\x07"
            return h[6] == 0x00 ? "rar" : "rar5";               // 0x00 — RAR4, 0x01 — RAR5
        }
        if (n >= 2 && (h[0] & 0xFF) == 0x1F && (h[1] & 0xFF) == 0x8B) return "gz";
        if (n >= 6 && (h[0] & 0xFF) == 0x37 && (h[1] & 0xFF) == 0x7A
                && (h[2] & 0xFF) == 0xBC && (h[3] & 0xFF) == 0xAF) return "7z";
        if (n >= 3 && h[0] == 0x42 && h[1] == 0x5A && h[2] == 0x68) return "bz2";   // "BZh"
        if (n >= 6 && (h[0] & 0xFF) == 0xFD && h[1] == 0x37 && h[2] == 0x7A
                && h[3] == 0x58 && h[4] == 0x5A) return "xz";
        // TAR: метка "ustar" по смещению 257
        try {
            java.io.RandomAccessFile ra = new java.io.RandomAccessFile(f, "r");
            try {
                if (ra.length() > 262) {
                    byte[] u = new byte[5];
                    ra.seek(257); ra.readFully(u);
                    if (u[0] == 'u' && u[1] == 's' && u[2] == 't' && u[3] == 'a' && u[4] == 'r') return "tar";
                }
            } finally { ra.close(); }
        } catch (Exception ignored) {}
        return null;
    }

    // Тип архива и список записей кэшируются по «путь|дата|размер» —
    // раньше каждый показ архива заново разбирал его оглавление по нескольку раз
    private final java.util.HashMap<String, String> arcKindCache = new java.util.HashMap<>();
    private final java.util.LinkedHashMap<String, String> arcListCache = new java.util.LinkedHashMap<>();

    private String arcStamp(File f) { return f.getAbsolutePath() + "|" + f.lastModified() + "|" + f.length(); }

    private String arcListKey(File f, String pw) { return arcStamp(f) + "|" + (pw != null && pw.length() > 0 ? "p" : "-"); }

    private String arcListGet(File f, String pw) { return arcListCache.get(arcListKey(f, pw)); }

    private void arcListPut(File f, String pw, JSArray arr, boolean enc) {
        try {
            org.json.JSONObject o = new org.json.JSONObject();
            o.put("entries", arr);            // JSArray и есть JSONArray — лишняя пересборка не нужна
            o.put("encrypted", enc);
            if (arcListCache.size() > 12) { java.util.Iterator<String> it = arcListCache.keySet().iterator(); it.next(); it.remove(); }
            arcListCache.put(arcListKey(f, pw), o.toString());
        } catch (Exception ignored) {}
    }

    private String arcKindCached(File f) {
        String k = arcStamp(f);
        String v = arcKindCache.get(k);
        if (v != null) return v;
        v = arcKind(f);
        if (arcKindCache.size() > 64) arcKindCache.clear();
        arcKindCache.put(k, v);
        return v;
    }

    private String arcKind(File f) {
        String n = f.getName().toLowerCase();
        // .tar.gz / .tgz — двухслойный, по сигнатуре виден только gz, поэтому решаем по имени
        if (n.endsWith(".tar.gz") || n.endsWith(".tgz")) return "tgz";
        String sniff = sniffKind(f);
        if (sniff != null) {
            if (sniff.equals("gz") && (n.endsWith(".tgz") || n.endsWith(".tar.gz"))) return "tgz";
            return sniff;
        }
        if (n.endsWith(".tar")) return "tar";
        if (n.endsWith(".gz")) return "gz";
        if (n.endsWith(".rar")) return "rar";
        return "zip";
    }

    // ---- Многотомные архивы ----
    // .001/.002…  — файл разрезан на куски, склеиваются побайтово
    // .zip + .z01… — разрезанный ZIP, собирается средствами zip4j
    // .rar + .r00… и .partN.rar — тома RAR, их читает сам junrar, начиная с первого тома
    private boolean isVolumeFirst(File f) {
        return f.getName().toLowerCase().matches(".*\\.001$");
    }

    // Если открыт НЕ первый том — возвращает имя первого, иначе null
    private String notFirstVolume(File f) {
        String n = f.getName(), l = n.toLowerCase();
        java.util.regex.Matcher m;
        m = java.util.regex.Pattern.compile("^(.*)\\.(\\d{3})$").matcher(l);
        if (m.matches() && !m.group(2).equals("001")) return m.group(1) + ".001";
        m = java.util.regex.Pattern.compile("^(.*)\\.z(\\d{2,})$").matcher(l);
        if (m.matches()) return m.group(1) + ".zip";
        m = java.util.regex.Pattern.compile("^(.*)\\.r(\\d{2,})$").matcher(l);
        if (m.matches()) return m.group(1) + ".rar";
        m = java.util.regex.Pattern.compile("^(.*)\\.part(\\d+)\\.rar$").matcher(l);
        if (m.matches() && Integer.parseInt(m.group(2)) != 1) {
            int w = m.group(2).length();
            return m.group(1) + ".part" + String.format(java.util.Locale.US, "%0" + w + "d", 1) + ".rar";
        }
        return null;
    }

    private File joinVolumes(File first) throws Exception {
        if (!isVolumeFirst(first)) return first;
        String n = first.getName();
        String base = n.substring(0, n.length() - 4);
        File dir = first.getParentFile();
        java.util.List<File> vols = new java.util.ArrayList<>();
        long total = 0;
        for (int i = 1; i < 1000; i++) {
            File v = new File(dir, base + "." + String.format(java.util.Locale.US, "%03d", i));
            if (!v.exists()) break;
            vols.add(v); total += v.length();
        }
        if (vols.isEmpty()) return first;
        File cacheDir = new File(getContext().getCacheDir(), "joined");
        if (!cacheDir.exists()) cacheDir.mkdirs();
        File out = new File(cacheDir, Integer.toHexString((first.getAbsolutePath() + "|" + total).hashCode()) + "_" + base);
        if (out.exists() && out.length() == total) return out;
        for (File old : cacheDir.listFiles() != null ? cacheDir.listFiles() : new File[0]) { try { old.delete(); } catch (Exception ignored) {} }
        OutputStream os = new FileOutputStream(out);
        byte[] buf = new byte[262144];
        int done = 0;
        for (File v : vols) {
            InputStream is = new FileInputStream(v);
            int r; while ((r = is.read(buf)) > 0) os.write(buf, 0, r);
            is.close(); done++;
            JSObject ev = new JSObject(); ev.put("done", (int) (done * 100.0 / vols.size())); ev.put("total", 100); ev.put("name", base); notifyListeners("opProgress", ev);
        }
        os.close();
        return out;
    }

    // Разрезанный ZIP (.zip + .z01…): собираем цельный файл средствами zip4j
    private boolean looksSplitZip(File f) {
        // разрезанный zip: рядом есть .z01 либо файл начинается с метки PK\x07\x08
        String n = f.getName();
        int d = n.lastIndexOf('.');
        if (d > 0) { File z01 = new File(f.getParentFile(), n.substring(0, d) + ".z01"); if (z01.exists()) return true; }
        byte[] h = new byte[4]; int r = -1; InputStream is = null;
        try { is = new FileInputStream(f); r = is.read(h); } catch (Exception ignored) {}
        finally { if (is != null) try { is.close(); } catch (Exception ignored) {} }
        return r == 4 && (h[0] & 0xFF) == 0x50 && (h[1] & 0xFF) == 0x4B && (h[2] & 0xFF) == 0x07 && (h[3] & 0xFF) == 0x08;
    }

    private File mergeSplitZip(File f) {
        if (!looksSplitZip(f)) return f; // обычный zip — не трогаем zip4j вовсе
        try {
            net.lingala.zip4j.ZipFile z = new net.lingala.zip4j.ZipFile(f);
            if (!z.isSplitArchive()) return f;
            File cacheDir = new File(getContext().getCacheDir(), "joined");
            if (!cacheDir.exists()) cacheDir.mkdirs();
            File out = new File(cacheDir, Integer.toHexString((f.getAbsolutePath() + "|" + f.lastModified()).hashCode()) + "_" + f.getName());
            if (out.exists() && out.length() > 0) return out;
            z.mergeSplitFiles(out);
            return out.exists() && out.length() > 0 ? out : f;
        } catch (Exception e) { return f; }
    }

    // Файл архива для чтения: склеенный том или сам файл
    /**
     * Расширения браузеров (.crx) — это обычный zip, перед которым дописана служебная приставка.
     * Отрезаем её во временный файл, дальше архив читается как всегда.
     */
    private File crxUnwrap(File src) {
        try {
            java.io.RandomAccessFile r = new java.io.RandomAccessFile(src, "r");
            try {
                byte[] magic = new byte[4];
                if (r.read(magic) != 4) return null;
                if (!(magic[0] == 'C' && magic[1] == 'r' && magic[2] == '2' && magic[3] == '4')) return null;
                int ver = Integer.reverseBytes(r.readInt());
                long start;
                if (ver == 2) {
                    long pk = Integer.reverseBytes(r.readInt()) & 0xffffffffL;
                    long sg = Integer.reverseBytes(r.readInt()) & 0xffffffffL;
                    start = 16 + pk + sg;
                } else {
                    long hdr = Integer.reverseBytes(r.readInt()) & 0xffffffffL;
                    start = 12 + hdr;
                }
                if (start <= 0 || start >= src.length()) return null;
                File out = new File(getContext().getCacheDir(), "crx_" + Math.abs(src.getAbsolutePath().hashCode()) + "_" + src.lastModified() + ".zip");
                if (out.exists() && out.length() == src.length() - start) return out;
                r.seek(start);
                OutputStream os = new java.io.FileOutputStream(out);
                try {
                    byte[] buf = new byte[262144];
                    int n;
                    while ((n = r.read(buf)) > 0) os.write(buf, 0, n);
                } finally { try { os.close(); } catch (Exception ignored) {} }
                return out;
            } finally { try { r.close(); } catch (Exception ignored) {} }
        } catch (Throwable t) { return null; }
    }

    private File arcFile(String uriStr) throws Exception {
        File f = toFile(uriStr);
        File crx = crxUnwrap(f);
        if (crx != null) return crx;                      // .crx — zip с приставкой
        String other = notFirstVolume(f);
        if (other != null) {
            File first = new File(f.getParentFile(), other);
            if (first.exists()) f = first; // открыт средний том — работаем с набором от первого, как WinRAR
            else throw new Exception("Это один из томов архива, а первый том (" + other + ") не найден рядом");
        }
        File joined = joinVolumes(f);
        if (joined != f) return joined;
        if (arcKindCached(f).equals("zip")) return mergeSplitZip(f);
        return f;
    }

    // ---- RAR5 (libarchive, чтение): junrar умеет только RAR4 ----
    private static class La { long a; android.os.ParcelFileDescriptor pfd; }

    // тома .part1.rar/.part2.rar… — libarchive должен получить их все сразу
    private java.util.List<File> laVolumes(File f) {
        java.util.regex.Matcher m = java.util.regex.Pattern.compile("(?i)^(.*\\.part)(\\d+)(\\.rar)$").matcher(f.getName());
        if (!m.matches()) return null;
        String pre = m.group(1), suf = m.group(3);
        int width = m.group(2).length();
        java.util.List<File> out = new java.util.ArrayList<>();
        for (int i = 1; i < 1000; i++) {
            String num = String.valueOf(i);
            while (num.length() < width) num = "0" + num;
            File v = new File(f.getParentFile(), pre + num + suf);
            if (!v.exists() && width > 1) { // возможен .part1 без нулей
                String alt = String.valueOf(i);
                File v2 = new File(f.getParentFile(), pre + alt + suf);
                if (v2.exists()) v = v2;
            }
            if (!v.exists()) break;
            out.add(v);
        }
        return out.size() > 1 ? out : null;
    }

    private La laOpen(File f, String password) throws Exception {
        La la = new La();
        la.a = me.zhanghai.android.libarchive.Archive.readNew();
        try {
            me.zhanghai.android.libarchive.Archive.setCharset(la.a, "UTF-8".getBytes("UTF-8"));
            me.zhanghai.android.libarchive.Archive.readSupportFilterAll(la.a);
            me.zhanghai.android.libarchive.Archive.readSupportFormatAll(la.a);
            if (password != null && password.length() > 0)
                me.zhanghai.android.libarchive.Archive.readAddPassphrase(la.a, password.getBytes("UTF-8"));
            java.util.List<File> vols = laVolumes(f);
            if (vols != null) {
                byte[][] names = new byte[vols.size()][];
                for (int i = 0; i < vols.size(); i++) names[i] = vols.get(i).getAbsolutePath().getBytes("UTF-8");
                me.zhanghai.android.libarchive.Archive.readOpenFileNames(la.a, names, 262144);
            } else {
                la.pfd = android.os.ParcelFileDescriptor.open(f, android.os.ParcelFileDescriptor.MODE_READ_ONLY);
                me.zhanghai.android.libarchive.Archive.readOpenFd(la.a, la.pfd.getFd(), 262144);
            }
            return la;
        } catch (Exception e) { laClose(la); throw e; }
    }

    private void laClose(La la) {
        if (la == null) return;
        try { me.zhanghai.android.libarchive.Archive.free(la.a); } catch (Throwable ignored) {}
        try { if (la.pfd != null) la.pfd.close(); } catch (Throwable ignored) {}
    }

    private String laName(long entry) {
        String n = me.zhanghai.android.libarchive.ArchiveEntry.pathnameUtf8(entry);
        if (n == null) {
            byte[] b = me.zhanghai.android.libarchive.ArchiveEntry.pathname(entry);
            try { n = b != null ? new String(b, "UTF-8") : ""; } catch (Exception e) { n = ""; }
        }
        return n.replace('\\', '/');
    }

    private boolean laEncErr(Exception e) {
        String m = e.getMessage();
        return m != null && (m.contains("assphrase") || m.contains("ncrypt") || m.contains("password") || m.contains("Password"));
    }

    private JSArray laEntries(File f, String password) throws Exception {
        JSArray arr = new JSArray();
        La la = laOpen(f, password);
        try {
            long entry;
            while ((entry = me.zhanghai.android.libarchive.Archive.readNextHeader(la.a)) != 0) {
                String nm = laName(entry);
                if (nm.isEmpty()) { me.zhanghai.android.libarchive.Archive.readDataSkip(la.a); continue; }
                boolean dir = me.zhanghai.android.libarchive.ArchiveEntry.filetype(entry) == me.zhanghai.android.libarchive.ArchiveEntry.AE_IFDIR;
                JSObject o = new JSObject();
                o.put("name", nm);
                o.put("size", dir ? 0 : me.zhanghai.android.libarchive.ArchiveEntry.size(entry));
                o.put("dir", dir);
                arr.put(o);
                me.zhanghai.android.libarchive.Archive.readDataSkip(la.a);
            }
        } finally { laClose(la); }
        return arr;
    }

    private void laExtract(File f, File destDir, java.util.Set<String> only, String password) throws Exception { laExtract(f, destDir, only, password, false); }

    private long laLastEv = 0; private int laScanned = 0;

    private void laExtract(File f, File destDir, java.util.Set<String> only, String password, boolean quiet) throws Exception {
        laExtract(f, destDir, only, password, quiet, null);
    }

    private void laExtract(File f, File destDir, java.util.Set<String> only, String password, boolean quiet, ExCtx cx) throws Exception {
        laLastEv = 0; laScanned = 0;
        java.util.List<String> ps = exOnlyPrefixes(only);
        int total = 0;
        if (only != null && ps == null) total = only.size();
        else {
            JSArray pre = laEntries(f, password);
            long bt = 0;
            for (int i = 0; i < pre.length(); i++) {
                org.json.JSONObject o = pre.getJSONObject(i);
                if (o.optBoolean("dir")) continue;
                if (!exWanted(only, ps, o.optString("name"))) continue;
                total++; bt += o.optLong("size", 0);
            }
            if (cx != null && cx.bytesTotal <= 0) cx.bytesTotal = bt;
        }
        La la = laOpen(f, password);
        try {
            long entry; int done = 0;
            while ((entry = me.zhanghai.android.libarchive.Archive.readNextHeader(la.a)) != 0) {
                String nm = laName(entry);
                boolean dir = me.zhanghai.android.libarchive.ArchiveEntry.filetype(entry) == me.zhanghai.android.libarchive.ArchiveEntry.AE_IFDIR;
                if (dir) { if (!nm.isEmpty() && (only == null || exWanted(only, ps, nm))) exDirOut(cx, destDir, nm); me.zhanghai.android.libarchive.Archive.readDataSkip(la.a); continue; }
                if (nm.isEmpty() || !exWanted(only, ps, nm)) {
                    me.zhanghai.android.libarchive.Archive.readDataSkip(la.a);
                    long now = System.currentTimeMillis();
                    if (only != null && now - laLastEv >= 150) {
                        laLastEv = now; laScanned++;
                        JSObject ev = new JSObject(); ev.put("done", Math.min(95, laScanned * 2)); ev.put("total", 100); ev.put("name", nm);
                        notifyListeners("opProgress", ev);
                    }
                    continue;
                }
                File out = exOut(cx, destDir, nm, -1, 0);
                if (out == null) { me.zhanghai.android.libarchive.Archive.readDataSkip(la.a); continue; }   // ответ «пропустить»
                android.os.ParcelFileDescriptor po = android.os.ParcelFileDescriptor.open(out,
                        android.os.ParcelFileDescriptor.MODE_WRITE_ONLY | android.os.ParcelFileDescriptor.MODE_CREATE | android.os.ParcelFileDescriptor.MODE_TRUNCATE);
                boolean okOne = true;
                try { me.zhanghai.android.libarchive.Archive.readDataIntoFd(la.a, po.getFd()); }
                catch (Exception oe) {
                    okOne = false;
                    try { po.close(); } catch (Exception ignored) {}
                    try { out.delete(); } catch (Throwable ignored) {}
                    // поток архива после сбоя продолжать нельзя — повтор невозможен, только пропустить или отменить
                    exGuard(cx, nm, oe);
                }
                finally { try { po.close(); } catch (Exception ignored) {} }
                if (okOne) { done++; exAddBytes(cx, out.length()); }
                if (!quiet) {
                    int pct = total > 0 ? (int) (done * 100.0 / total) : 100;
                    JSObject ev = new JSObject(); ev.put("done", pct); ev.put("total", 100); ev.put("name", nm);
                    exPutBytes(cx, ev);
                    notifyListeners("opProgress", ev);
                    postProgressNotif("Распаковка", nm, pct, 100);
                }
                if (only != null && done >= total) break;   // нужное достали
            }
        } finally { laClose(la); }
    }

    // ---- 7z (Apache Commons Compress) ----
    private org.apache.commons.compress.archivers.sevenz.SevenZFile open7z(File f, String password) throws Exception {
        org.apache.commons.compress.archivers.sevenz.SevenZFile.Builder b = org.apache.commons.compress.archivers.sevenz.SevenZFile.builder().setFile(f);
        if (password != null && password.length() > 0) b.setPassword(password.toCharArray());
        return b.get();
    }

    private boolean sevenIsEnc(org.apache.commons.compress.archivers.sevenz.SevenZArchiveEntry e) {
        try {
            Iterable<? extends org.apache.commons.compress.archivers.sevenz.SevenZMethodConfiguration> ms = e.getContentMethods();
            if (ms != null) for (org.apache.commons.compress.archivers.sevenz.SevenZMethodConfiguration m : ms) {
                if (m.getMethod() != null && String.valueOf(m.getMethod()).contains("AES")) return true;
            }
        } catch (Throwable ignored) {}
        return false;
    }

    private JSArray sevenEntries(File f, String password) throws Exception {
        JSArray arr = new JSArray();
        org.apache.commons.compress.archivers.sevenz.SevenZFile z = open7z(f, password);
        try {
            for (org.apache.commons.compress.archivers.sevenz.SevenZArchiveEntry e : z.getEntries()) {
                JSObject o = new JSObject();
                o.put("name", e.getName().replace('\\', '/'));
                o.put("size", e.isDirectory() ? 0 : e.getSize());
                o.put("dir", e.isDirectory());
                o.put("enc", sevenIsEnc(e));
                arr.put(o);
            }
        } finally { try { z.close(); } catch (Exception ignored) {} }
        return arr;
    }

    private void sevenExtract(File f, File destDir, java.util.Set<String> only, String password) throws Exception {
        sevenExtract(f, destDir, only, password, false);
    }

    private void sevenExtract(File f, File destDir, java.util.Set<String> only, String password, boolean quiet) throws Exception {
        sevenExtract(f, destDir, only, password, quiet, null);
    }

    private void sevenExtract(File f, File destDir, java.util.Set<String> only, String password, boolean quiet, ExCtx cx) throws Exception {
        org.apache.commons.compress.archivers.sevenz.SevenZFile z = open7z(f, password);
        java.util.List<String> ps = exOnlyPrefixes(only);
        try {
            int total = 0, done = 0; long bt = 0;
            for (org.apache.commons.compress.archivers.sevenz.SevenZArchiveEntry e : z.getEntries()) {
                if (e.isDirectory()) continue;
                String nm = e.getName().replace('\\', '/');
                if (exWanted(only, ps, nm)) { total++; bt += Math.max(0, e.getSize()); }
            }
            if (cx != null && cx.bytesTotal <= 0) cx.bytesTotal = bt;
            // сколько записей всего — по ним показываем ход пролистывания блока
            int allCnt = 0;
            for (org.apache.commons.compress.archivers.sevenz.SevenZArchiveEntry e0 : z.getEntries()) allCnt++;
            int scanned = 0; long lastScanEv = 0;
            org.apache.commons.compress.archivers.sevenz.SevenZArchiveEntry e;
            byte[] buf = new byte[262144];
            while ((e = z.getNextEntry()) != null) {
                scanned++;
                String nm = e.getName().replace('\\', '/');
                if (e.isDirectory()) { if (only == null || exWanted(only, ps, nm)) exDirOut(cx, destDir, nm); continue; }
                if (!exWanted(only, ps, nm)) {
                    // в 7z файлы лежат одним куском: до нужного приходится пролистать предыдущие.
                    // Показываем этот этап, иначе полоса стоит на нуле и кажется, что всё зависло.
                    long now = System.currentTimeMillis();
                    if (now - lastScanEv >= 150) {
                        lastScanEv = now;
                        int pct = allCnt > 0 ? (int) Math.min(95, scanned * 95.0 / allCnt) : 0;
                        JSObject ev = new JSObject(); ev.put("done", pct); ev.put("total", 100); ev.put("name", nm);
                        notifyListeners("opProgress", ev);
                    }
                    continue;
                }
                long mt = 0;
                try { if (e.getHasLastModifiedDate()) mt = e.getLastModifiedDate().getTime(); } catch (Throwable ignored) {}
                File out = exOut(cx, destDir, nm, e.getSize(), mt);
                if (out == null) { done++; continue; }      // ответ «пропустить» (запись всё равно уже пролистана потоком)
                boolean okOne = true;
                OutputStream os = new ProgOut(new FileOutputStream(out), nm, done, total, e.getSize(), quiet, cx);
                try { int r; while ((r = z.read(buf)) > 0) os.write(buf, 0, r); }
                catch (Exception oe) {
                    okOne = false;
                    try { os.close(); } catch (Exception ignored) {}
                    try { out.delete(); } catch (Throwable ignored) {}
                    // сплошной поток 7z после сбоя не перечитать — повтор невозможен, только пропустить или отменить
                    exGuard(cx, nm, oe);
                }
                finally { try { os.close(); } catch (Exception ignored) {} }
                done++;
                if (only != null && done >= total) break;   // всё нужное достали — дальше архив не читаем
            }
        } finally { try { z.close(); } catch (Exception ignored) {} }
    }

    private boolean rarLastEnc = false;

    private JSArray rarEntries(File f, String password) throws Exception {
        JSArray arr = new JSArray();
        rarLastEnc = false;
        com.github.junrar.Archive a = rarOpen(f, password);
        try {
            for (com.github.junrar.rarfile.FileHeader h : a.getFileHeaders()) {
                JSObject o = new JSObject();
                o.put("name", h.getFileName().replace('\\', '/'));
                o.put("size", h.getFullUnpackSize());
                o.put("dir", h.isDirectory());
                boolean enc = false;
                try { enc = h.isEncrypted(); } catch (Throwable ignored) {}
                if (enc) { o.put("enc", true); rarLastEnc = true; }
                arr.put(o);
            }
        } finally { try { a.close(); } catch (Exception ignored) {} }
        return arr;
    }

    private boolean rarQuiet = false;

    private void rarExtract(File f, File destDir, java.util.Set<String> only) throws Exception { rarExtract(f, destDir, only, null); }

    private void rarExtract(File f, File destDir, java.util.Set<String> only, String password) throws Exception {
        rarExtract(f, destDir, only, password, null);
    }

    private void rarExtract(File f, File destDir, java.util.Set<String> only, String password, ExCtx cx) throws Exception {
        com.github.junrar.Archive a = rarOpen(f, password);
        java.util.List<String> ps = exOnlyPrefixes(only);
        try {
            java.util.List<com.github.junrar.rarfile.FileHeader> hs = a.getFileHeaders();
            int total = 0; long bt = 0;
            for (com.github.junrar.rarfile.FileHeader h : hs) {
                if (h.isDirectory()) continue;
                String nm = h.getFileName().replace('\\', '/');
                if (exWanted(only, ps, nm)) { total++; bt += Math.max(0, h.getFullUnpackSize()); }
            }
            if (cx != null && cx.bytesTotal <= 0) cx.bytesTotal = bt;
            int done = 0;
            for (com.github.junrar.rarfile.FileHeader h : hs) {
                if (h.isDirectory()) continue;
                String nm = h.getFileName().replace('\\', '/');
                if (!exWanted(only, ps, nm)) continue;
                long mt = 0;
                try { if (h.getMTime() != null) mt = h.getMTime().getTime(); } catch (Throwable ignored) {}
                File out = exOut(cx, destDir, nm, h.getFullUnpackSize(), mt);
                if (out == null) { done++; continue; }      // ответ «пропустить»
                for (;;) {
                    boolean okOne = true;
                    OutputStream os = new ProgOut(new FileOutputStream(out), nm, done, total, h.getFullUnpackSize(), rarQuiet, cx);
                    try { a.extractFile(h, os); }
                    catch (Exception oe) {
                        okOne = false;
                        try { os.close(); } catch (Exception ignored) {}
                        try { out.delete(); } catch (Throwable ignored) {}
                        if (exGuard(cx, nm, oe)) break;     // пропустить
                        continue;                            // повторить
                    }
                    finally { try { os.close(); } catch (Exception ignored) {} }
                    if (okOne) break;
                }
                done++;
            }
        } finally { try { a.close(); } catch (Exception ignored) {} }
    }
    private String gzBase(File f) {
        String n = f.getName(); String low = n.toLowerCase();
        if (low.endsWith(".tar.gz")) return n.substring(0, n.length() - 3);
        if (low.endsWith(".tgz")) return n.substring(0, n.length() - 4) + ".tar";
        if (low.endsWith(".gz")) return n.substring(0, n.length() - 3);
        return n;
    }
    private void gzExtract(File f, File outFile) throws Exception {
        if (outFile.getParentFile() != null) outFile.getParentFile().mkdirs();
        InputStream in = new java.util.zip.GZIPInputStream(new FileInputStream(f));
        OutputStream os = new FileOutputStream(outFile);
        byte[] buf = new byte[65536]; int n; while ((n = in.read(buf)) > 0) os.write(buf, 0, n);
        os.close(); in.close();
    }
    private InputStream tarStream(File f, String kind) throws Exception {
        return kind.equals("tgz") ? new java.util.zip.GZIPInputStream(new FileInputStream(f)) : new FileInputStream(f);
    }
    private int readFully(InputStream in, byte[] b, int len) throws Exception { int off = 0; while (off < len) { int r = in.read(b, off, len - off); if (r < 0) break; off += r; } return off; }
    private void skipFully(InputStream in, long n) throws Exception { byte[] t = new byte[8192]; while (n > 0) { int want = (int) Math.min(t.length, n); int r = in.read(t, 0, want); if (r < 0) break; n -= r; } }
    private String tarStr(byte[] b, int off, int len) { int end = off; while (end < off + len && b[end] != 0) end++; return new String(b, off, end - off).trim(); }
    private long tarOctal(byte[] b, int off, int len) { long v = 0; for (int i = off; i < off + len; i++) { int c = b[i] & 0xff; if (c == 0 || c == ' ') continue; if (c < '0' || c > '7') continue; v = v * 8 + (c - '0'); } return v; }

    // Длинные имена в tar хранятся тремя способами: отдельной записью GNU («L»),
    // расширенным заголовком PAX («x», запись path=…) и парой «prefix + имя» формата ustar.
    // Без их поддержки имена длиннее ~100 знаков обрезались.
    private String tarLongData(InputStream in, long size) throws Exception {
        int want = (int) Math.min(size, 1 << 20);
        byte[] d = new byte[want];
        int got = readFully(in, d, want);
        skipFully(in, ((size + 511) / 512) * 512 - got);
        int end = got; while (end > 0 && d[end - 1] == 0) end--;
        return new String(d, 0, end, java.nio.charset.StandardCharsets.UTF_8);
    }

    private String tarPaxPath(InputStream in, long size) throws Exception {
        int want = (int) Math.min(size, 1 << 20);
        byte[] d = new byte[want];
        int got = readFully(in, d, want);
        skipFully(in, ((size + 511) / 512) * 512 - got);
        String path = null; int i = 0;
        while (i < got) {
            int sp = i; while (sp < got && d[sp] != ' ') sp++;
            if (sp >= got) break;
            int len = 0; boolean ok = sp > i;
            for (int k = i; k < sp; k++) { int c = d[k] & 0xff; if (c < '0' || c > '9') { ok = false; break; } len = len * 10 + (c - '0'); }
            if (!ok || len <= 0 || i + len > got) break;
            int recEnd = i + len; if (recEnd > 0 && d[recEnd - 1] == '\n') recEnd--;
            String rec = new String(d, sp + 1, Math.max(0, recEnd - sp - 1), java.nio.charset.StandardCharsets.UTF_8);
            int eq = rec.indexOf('=');
            if (eq > 0 && rec.substring(0, eq).equals("path")) path = rec.substring(eq + 1);
            i += len;
        }
        return path;
    }

    private String tarFullName(byte[] hdr, String gnuLong, String paxPath) {
        if (gnuLong != null && !gnuLong.isEmpty()) return gnuLong;
        if (paxPath != null && !paxPath.isEmpty()) return paxPath;
        String name = tarStr(hdr, 0, 100);
        if (hdr[257] == 'u' && hdr[258] == 's' && hdr[259] == 't' && hdr[260] == 'a' && hdr[261] == 'r') {
            String pre = tarStr(hdr, 345, 155);
            if (!pre.isEmpty()) name = pre + "/" + name;
        }
        return name;
    }

    private java.util.List<String[]> tarEntries(InputStream in) throws Exception {
        java.util.List<String[]> out = new java.util.ArrayList<>(); byte[] hdr = new byte[512];
        String gnuLong = null, paxPath = null;
        while (true) {
            if (readFully(in, hdr, 512) < 512) break;
            boolean zero = true; for (byte b : hdr) if (b != 0) { zero = false; break; } if (zero) break;
            long size = tarOctal(hdr, 124, 12); char type = (char) hdr[156];
            if (type == 'L') { gnuLong = tarLongData(in, size); continue; }
            if (type == 'K') { skipFully(in, ((size + 511) / 512) * 512); continue; }
            if (type == 'x') { paxPath = tarPaxPath(in, size); continue; }
            if (type == 'g') { skipFully(in, ((size + 511) / 512) * 512); continue; }
            String name = tarFullName(hdr, gnuLong, paxPath);
            gnuLong = null; paxPath = null;
            if (name.isEmpty()) break;
            out.add(new String[]{ name, String.valueOf(size), String.valueOf(type) });
            skipFully(in, ((size + 511) / 512) * 512);
        }
        return out;
    }
    private void tarExtract(InputStream in, File destDir, java.util.Set<String> only, File singleOut, int total) throws Exception {
        tarExtract(in, destDir, only, singleOut, total, null);
    }

    private void tarExtract(InputStream in, File destDir, java.util.Set<String> only, File singleOut, int total, ExCtx cx) throws Exception {
        byte[] hdr = new byte[512]; byte[] buf = new byte[65536]; int done = 0;
        java.util.List<String> ps = exOnlyPrefixes(only);
        String gnuLong = null, paxPath = null;
        while (true) {
            if (readFully(in, hdr, 512) < 512) break;
            boolean zero = true; for (byte b : hdr) if (b != 0) { zero = false; break; } if (zero) break;
            long size = tarOctal(hdr, 124, 12); char type = (char) hdr[156];
            if (type == 'L') { gnuLong = tarLongData(in, size); continue; }
            if (type == 'K') { skipFully(in, ((size + 511) / 512) * 512); continue; }
            if (type == 'x') { paxPath = tarPaxPath(in, size); continue; }
            if (type == 'g') { skipFully(in, ((size + 511) / 512) * 512); continue; }
            String name = tarFullName(hdr, gnuLong, paxPath);
            gnuLong = null; paxPath = null;
            if (name.isEmpty()) break;
            boolean isDir = type == '5' || name.endsWith("/");
            long pad = ((size + 511) / 512) * 512 - size;
            boolean take = !isDir && exWanted(only, ps, name);
            if (take) {
                File out;
                if (singleOut != null) out = singleOut;
                else {
                    long mt = tarOctal(hdr, 136, 12) * 1000L;
                    out = exOut(cx, destDir, name, size, mt);
                }
                if (out == null) { skipFully(in, size + pad); continue; }   // ответ «пропустить»
                OutputStream fos = new ProgOut(new FileOutputStream(out), name, done, total, size, cx != null && cx.quiet, cx);
                boolean okOne = true; long rem = size;
                try { while (rem > 0) { int want = (int) Math.min(buf.length, rem); int got = in.read(buf, 0, want); if (got < 0) break; fos.write(buf, 0, got); rem -= got; } }
                catch (Exception oe) {
                    okOne = false;
                    try { fos.close(); } catch (Exception ignored) {}
                    try { out.delete(); } catch (Throwable ignored) {}
                    skipFully(in, rem);   // дочитываем остаток записи, чтобы поток не сломался
                    // лента tar читается один раз — повтор невозможен, только пропустить или отменить
                    exGuard(cx, name, oe);
                }
                finally { try { fos.close(); } catch (Exception ignored) {} }
                skipFully(in, pad);
                if (okOne) done++;
                if (singleOut != null) return;
            } else { skipFully(in, size + pad); }
        }
    }

    @PluginMethod
    public void zipList(PluginCall call) {
        String uriStr = call.getString("uri");
        if (uriStr == null) { call.reject("no uri"); return; }
        final long t0 = System.currentTimeMillis();
        try {
            File f = arcFile(uriStr);
            final long tOpen = System.currentTimeMillis();
            String cached = arcListGet(f, call.getString("password"));
            if (cached != null) {
                org.json.JSONObject co = new org.json.JSONObject(cached);
                JSObject ret = new JSObject();
                ret.put("entries", new JSArray(co.getJSONArray("entries").toString()));
                ret.put("encrypted", co.optBoolean("encrypted"));
                ret.put("ms", System.currentTimeMillis() - t0); ret.put("msOpen", tOpen - t0); ret.put("src", "cache");
                call.resolve(ret); return;
            }
            String kind = arcKindCached(f);
            // Движок 7-Zip (как в MT Manager) читает любой формат и знает про пароли — для «слабых» форматов он первый
            if (engineFirst(kind)) {
                JSObject er = engineList(f, call.getString("password"), call);
                if (er != null) { er.put("ms", System.currentTimeMillis() - t0); er.put("msOpen", tOpen - t0); call.resolve(er); return; }
            }
            if (kind.equals("rar5")) {
                try {
                    JSArray arr = laEntries(f, call.getString("password"));
                    JSObject ret = new JSObject(); ret.put("entries", arr); ret.put("encrypted", false);
                    ret.put("ms", System.currentTimeMillis() - t0); ret.put("msOpen", tOpen - t0); ret.put("count", arr.length()); ret.put("src", "rar5");
                    arcListPut(f, call.getString("password"), arr, false);
                    call.resolve(ret); return;
                } catch (Exception le) {
                    if (rar5EncErr(le)) { call.reject("RAR5 с паролем: нужен движок 7-Zip", "UNSUPPORTED"); return; }
                    call.reject("RAR5: " + (le.getMessage() != null ? le.getMessage() : "не удалось прочитать")); return;
                }
            }
            if (kind.equals("7z")) {
                // читаем нативной libarchive (C) — она в разы быстрее Java-разбора
                try {
                    JSArray arr = laEntries(f, call.getString("password"));
                    if (arr.length() > 0) {
                        boolean encQ = sevenHasEnc(f, call.getString("password"));
                        JSObject ret = new JSObject(); ret.put("entries", arr); ret.put("encrypted", encQ);
                        arcListPut(f, call.getString("password"), arr, encQ);
                        call.resolve(ret); return;
                    }
                } catch (Exception le) {
                    // libarchive не умеет шифрованные 7z: без пароля сразу просим его, с паролем читаем ниже другой библиотекой
                    String pw0 = call.getString("password");
                    if (laEncErr(le) && (pw0 == null || pw0.isEmpty())) { JSObject ret = new JSObject(); ret.put("entries", new JSArray()); ret.put("encrypted", true); call.resolve(ret); return; }
                }
                try {
                    JSArray arr = sevenEntries(f, call.getString("password"));
                    boolean anyEnc = false;
                    for (int i = 0; i < arr.length(); i++) { if (arr.getJSONObject(i).optBoolean("enc")) { anyEnc = true; break; } }
                    JSObject ret = new JSObject(); ret.put("entries", arr); ret.put("encrypted", anyEnc);
                    ret.put("ms", System.currentTimeMillis() - t0); ret.put("msOpen", tOpen - t0); ret.put("count", arr.length()); ret.put("src", "7z");
                    arcListPut(f, call.getString("password"), arr, anyEnc);
                    call.resolve(ret); return;
                } catch (org.apache.commons.compress.PasswordRequiredException pe) {
                    JSObject ret = new JSObject(); ret.put("entries", new JSArray()); ret.put("encrypted", true); call.resolve(ret); return;
                } catch (Exception se) {
                    String m = se.getMessage();
                    if (m != null && (m.contains("password") || m.contains("Password") || m.contains("Checksum"))) {
                        JSObject ret = new JSObject(); ret.put("entries", new JSArray()); ret.put("encrypted", true); call.resolve(ret); return;
                    }
                    call.reject("7z: " + (m != null ? m : "не удалось прочитать")); return;
                }
            }
            if (kind.equals("bz2")) { call.reject("Формат bzip2 пока не поддерживается"); return; }
            if (kind.equals("xz")) { call.reject("Формат xz пока не поддерживается"); return; }
            if (kind.equals("rar")) {
                try {
                    JSArray arr = rarEntries(f, call.getString("password"));
                    boolean enc = rarLastEnc || rarProtected(f, call.getString("password"));
                    JSObject ret = new JSObject(); ret.put("entries", arr); ret.put("encrypted", enc);
                    ret.put("ms", System.currentTimeMillis() - t0); ret.put("msOpen", tOpen - t0); ret.put("count", arr.length()); ret.put("src", "rar");
                    arcListPut(f, call.getString("password"), arr, enc);
                    call.resolve(ret); return;
                } catch (Exception re) {
                    // имена в архиве тоже зашифрованы — без пароля оглавление не прочитать
                    if (rarPassErr(re)) { JSObject ret = new JSObject(); ret.put("entries", new JSArray()); ret.put("encrypted", true); call.resolve(ret); return; }
                    call.reject("RAR: " + (re.getMessage() != null ? re.getMessage() : "не удалось прочитать")); return;
                }
            }
            if (kind.equals("gz")) {
                JSArray arr = new JSArray(); JSObject o = new JSObject(); o.put("name", gzBase(f)); o.put("size", 0); o.put("dir", false); arr.put(o);
                JSObject ret = new JSObject(); ret.put("entries", arr); ret.put("encrypted", false); call.resolve(ret); return;
            }
            if (kind.equals("tar") || kind.equals("tgz")) {
                InputStream in = tarStream(f, kind); java.util.List<String[]> es = tarEntries(in); in.close();
                JSArray arr = new JSArray();
                for (String[] e : es) { JSObject o = new JSObject(); o.put("name", e[0]); o.put("size", Long.parseLong(e[1])); o.put("dir", e[2].equals("5") || e[0].endsWith("/")); arr.put(o); }
                JSObject ret = new JSObject(); ret.put("entries", arr); ret.put("encrypted", false);
                ret.put("ms", System.currentTimeMillis() - t0); ret.put("msOpen", tOpen - t0); ret.put("count", arr.length()); ret.put("src", kind);
                arcListPut(f, null, arr, false);
                call.resolve(ret); return;
            }
            // ОДИН разбор оглавления: имена, размеры и признак шифрования берём разом
            boolean enc = false;
            JSArray arr = new JSArray();
            try {
                net.lingala.zip4j.ZipFile probe = new net.lingala.zip4j.ZipFile(f);
                try { probe.getFileHeaders(); } finally { try { probe.close(); } catch (Exception ignored) {} }
            } catch (Exception zle) {
                // zip4j не осилил (например, скрытые имена) — пробуем движком 7-Zip
                JSObject er = engineList(f, call.getString("password"), call);
                if (er != null) { call.resolve(er); return; }
                throw zle;
            }
            net.lingala.zip4j.ZipFile z = openZip4j(f);
            try {
                for (net.lingala.zip4j.model.FileHeader h : z.getFileHeaders()) {
                    JSObject o = new JSObject();
                    o.put("name", h.getFileName());
                    o.put("size", h.getUncompressedSize());
                    o.put("dir", h.isDirectory());
                    if (h.isEncrypted()) enc = true;
                    arr.put(o);
                }
            } finally { try { z.close(); } catch (Exception ignored) {} }
            JSObject ret = new JSObject();
            ret.put("entries", arr);
            ret.put("encrypted", enc);
            ret.put("ms", System.currentTimeMillis() - t0); ret.put("msOpen", tOpen - t0); ret.put("count", arr.length()); ret.put("src", "zip");
            arcListPut(f, call.getString("password"), arr, enc);
            call.resolve(ret);
        } catch (Exception e) { call.reject(e.getMessage()); }
    }

    @PluginMethod
    public void zipExtract(PluginCall call) {
        String uriStr = call.getString("uri");
        String entry = call.getString("entry");
        String dest = call.getString("dest");
        if (uriStr == null || entry == null || dest == null) { call.reject("bad args"); return; }
        String password = call.getString("password");
        File src0;
        try { src0 = arcFile(uriStr); } catch (Exception ve) { call.reject(ve.getMessage()); return; }
        String k0 = arcKindCached(src0);
        // Движок 7-Zip (как в MT Manager): один движок на все форматы и все пароли
        if (engineFirst(k0)) {
            File tmpE = new File(getContext().getCacheDir(), "sz7"); if (!tmpE.exists()) tmpE.mkdirs();
            java.util.Set<String> onlyE = new java.util.HashSet<>(); onlyE.add(entry);
            try {
                if (engineExtract(src0, tmpE, onlyE, password, Boolean.TRUE.equals(call.getBoolean("quiet", false)), call)) {
                    File got = safeChild(tmpE, entry);
                    if (got.exists()) {
                        File out = new File(dest);
                        if (out.getParentFile() != null) out.getParentFile().mkdirs();
                        copyFileTo(got, out);
                        got.delete();
                        JSObject ret = new JSObject(); ret.put("path", out.getAbsolutePath()); call.resolve(ret); return;
                    }
                }
            } catch (SevenZipEngine.NeedPassword np) { call.reject("Требуется пароль", "ENCRYPTED"); return;
            } catch (SevenZipEngine.WrongPassword wp) { call.reject("Неверный пароль", "BADPASS"); return;
            } catch (Exception ee) { /* движок не смог — идём прежними библиотеками */ }
        }
        if (k0.equals("rar5")) {
            try {
                File out = new File(dest);
                File parent = out.getParentFile() != null ? out.getParentFile() : new File(dest);
                java.util.Set<String> only = new java.util.HashSet<>(); only.add(entry);
                File tmp = new File(getContext().getCacheDir(), "la1"); if (!tmp.exists()) tmp.mkdirs();
                laExtract(src0, tmp, only, password, call.getBoolean("quiet", false));
                File got = safeChild(tmp, entry);
                if (!got.exists()) { call.reject("entry not found"); return; }
                parent.mkdirs();
                InputStream is = new FileInputStream(got); OutputStream os = new FileOutputStream(out);
                byte[] bb = new byte[65536]; int rr; while ((rr = is.read(bb)) > 0) os.write(bb, 0, rr);
                is.close(); os.close(); got.delete();
                JSObject ret = new JSObject(); ret.put("path", out.getAbsolutePath()); call.resolve(ret); return;
            } catch (Exception e) {
                if (rar5EncErr(e)) { call.reject("RAR5 с паролем: нужен движок 7-Zip", "UNSUPPORTED"); return; }
                call.reject("RAR5: " + (e.getMessage() != null ? e.getMessage() : "ошибка")); return;
            }
        }
        if (k0.equals("7z")) {
            try {
                File out = new File(dest);
                File parent = out.getParentFile() != null ? out.getParentFile() : new File(dest);
                java.util.Set<String> only = new java.util.HashSet<>(); only.add(entry);
                File tmp = new File(getContext().getCacheDir(), "sz1"); if (!tmp.exists()) tmp.mkdirs();
                boolean laOk = false;
                // libarchive быстрее, но шифрованные 7z не умеет — тогда распаковываем второй библиотекой с паролем
                try { laExtract(src0, tmp, only, password, call.getBoolean("quiet", false)); laOk = safeChild(tmp, entry).exists(); }
                catch (Exception le) { laOk = false; }
                if (!laOk) {
                    boolean enc = sevenHasEnc(src0, password);
                    if (enc && (password == null || password.isEmpty())) { call.reject("Требуется пароль", "ENCRYPTED"); return; }
                    try { sevenExtract(src0, tmp, only, password, call.getBoolean("quiet", false)); }
                    catch (Exception se) {
                        if (enc && sevenPassErr(se)) { call.reject("Неверный пароль", "BADPASS"); return; }
                        throw se;
                    }
                }
                File got = safeChild(tmp, entry);
                if (!got.exists()) { call.reject("entry not found"); return; }
                parent.mkdirs();
                InputStream is = new FileInputStream(got); OutputStream os = new FileOutputStream(out);
                byte[] bb = new byte[65536]; int rr; while ((rr = is.read(bb)) > 0) os.write(bb, 0, rr);
                is.close(); os.close(); got.delete();
                JSObject ret = new JSObject(); ret.put("path", out.getAbsolutePath()); call.resolve(ret); return;
            } catch (Exception e) { call.reject("7z: " + (e.getMessage() != null ? e.getMessage() : "ошибка")); return; }
        }
        if (k0.equals("bz2") || k0.equals("xz")) { call.reject("Формат " + k0 + " пока не поддерживается"); return; }
        if (k0.equals("rar")) {
            try {
                File out = new File(dest);
                File parent = out.getParentFile() != null ? out.getParentFile() : new File(dest);
                java.util.Set<String> only = new java.util.HashSet<>(); only.add(entry);
                File tmp = new File(getContext().getCacheDir(), "rar1"); if (!tmp.exists()) tmp.mkdirs();
                // архив под паролем, а пароля нет — спрашиваем сразу: иначе библиотека молча отдаёт пустой файл
                if ((password == null || password.isEmpty()) && rarProtected(src0, null)) { call.reject("Требуется пароль", "ENCRYPTED"); return; }
                rarQuiet = call.getBoolean("quiet", false);
                try { rarExtract(src0, tmp, only, password); } finally { rarQuiet = false; }
                File got = safeChild(tmp, entry);
                if (!got.exists()) { call.reject("entry not found"); return; }
                parent.mkdirs();
                InputStream is = new FileInputStream(got); OutputStream os = new FileOutputStream(out);
                byte[] bb = new byte[65536]; int rr; while ((rr = is.read(bb)) > 0) os.write(bb, 0, rr);
                is.close(); os.close(); got.delete();
                JSObject ret = new JSObject(); ret.put("path", out.getAbsolutePath()); call.resolve(ret); return;
            } catch (Exception e) { rejectRar(call, src0, password, e); return; }
        }
        if (!k0.equals("zip")) {
            try {
                if (k0.equals("gz")) { gzExtract(src0, new File(dest)); }
                else { InputStream in = tarStream(src0, k0); java.util.Set<String> only = new java.util.HashSet<>(); only.add(entry); tarExtract(in, null, only, new File(dest), 1); in.close(); }
                JSObject ret = new JSObject(); ret.put("path", dest); call.resolve(ret); return;
            } catch (Exception e) { call.reject(e.getMessage()); return; }
        }
        boolean encZ = zipIsEncrypted(src0);
        if (encZ || (password != null && !password.isEmpty())) {
            if (encZ && (password == null || password.isEmpty())) { call.reject("Требуется пароль", "ENCRYPTED"); return; }
            try {
                zip4jExtractOne(src0, entry, new File(dest), password);
                JSObject ret = new JSObject(); ret.put("path", dest); call.resolve(ret); return;
            } catch (Exception e) {
                if (zipWrongPass(e)) { call.reject("Неверный пароль", "BADPASS"); return; }
                call.reject("ZIP: " + (e.getMessage() != null ? e.getMessage() : "ошибка")); return;
            }
        }
        ZipFile zf = null;
        try {
            zf = openZip(src0);   // та же кодировка имён, что и в списке — иначе запись не найдётся
            ZipEntry ze = zf.getEntry(entry);
            if (ze == null) { call.reject("entry not found"); return; }
            File out = new File(dest);
            if (out.getParentFile() != null) out.getParentFile().mkdirs();
            InputStream in = zf.getInputStream(ze);
            OutputStream fos = new FileOutputStream(out);
            byte[] buf = new byte[65536];
            int n;
            while ((n = in.read(buf)) > 0) fos.write(buf, 0, n);
            fos.close(); in.close();
            JSObject ret = new JSObject();
            ret.put("path", out.getAbsolutePath());
            call.resolve(ret);
        } catch (Exception e) {
            String m = e.getMessage();
            if (m != null && m.toLowerCase().contains("encrypt")) { call.reject("Требуется пароль", "ENCRYPTED"); return; }
            call.reject(m);
        }
        finally { if (zf != null) try { zf.close(); } catch (Exception ignored) {} }
    }

    @PluginMethod
    public void zipExtractAll(final PluginCall call) {
        // Вопросы про совпадения/ошибки ждут ответа из приложения, поэтому работа идёт в отдельном
        // потоке — иначе ответ не сможет дойти (вызовы приложения исполняются по одному).
        new Thread(() -> {
            ExCtx cx = new ExCtx();
            cx.quiet = Boolean.TRUE.equals(call.getBoolean("quiet", false));
            try {
                String d0 = call.getString("dest");
                if (d0 != null) cx.destRoot = new File(d0);
                zipExtractAllBody(call, cx);
            } catch (ExCancel ce) {
                try { android.app.NotificationManager nm = (android.app.NotificationManager) getContext().getSystemService(Context.NOTIFICATION_SERVICE); nm.cancel(777); } catch (Throwable ignored) {}
                call.reject("Отменено");
            } catch (Throwable t) {
                call.reject(t.getMessage() != null ? t.getMessage() : String.valueOf(t));
            }
        }, "yev-extract").start();
    }

    private void zipExtractAllBody(PluginCall call, ExCtx cx) {
        String uriStr = call.getString("uri");
        String destDir = call.getString("dest");
        if (uriStr == null || destDir == null) { call.reject("bad args"); return; }
        JSArray names = call.getArray("entries");
        String password = call.getString("password");
        File src;
        try { src = arcFile(uriStr); } catch (Exception ve) { call.reject(ve.getMessage()); return; }
        cx.arcName = src.getName();
        // в списке может быть папка (имя с «/» на конце) — разворачиваем её во все записи внутри
        try {
            if (names != null) {
                boolean hasDir = false;
                for (Object o : names.toList()) if (String.valueOf(o).endsWith("/")) { hasDir = true; break; }
                if (hasDir) {
                    java.util.LinkedHashSet<String> full = new java.util.LinkedHashSet<>();
                    java.util.List<String> all = arcNames(src, password);
                    for (Object o : names.toList()) {
                        String n = String.valueOf(o);
                        if (!n.endsWith("/")) { full.add(n); continue; }
                        for (String x : all) if (x.startsWith(n) && !x.equals(n)) full.add(x);
                    }
                    JSArray ex = new JSArray();
                    for (String n : full) ex.put(n);
                    names = ex;
                }
            }
        } catch (Exception ignored) {}
        String kA = arcKindCached(src);
        if (engineFirst(kA)) {
            File dd = new File(destDir); dd.mkdirs();
            try {
                java.util.Set<String> onlyE = namesSet(names);
                if (engineExtract(src, dd, onlyE, password, cx.quiet, call, cx)) { JSObject ret = new JSObject(); ret.put("done", true); call.resolve(ret); return; }
            } catch (SevenZipEngine.NeedPassword np) { call.reject("Требуется пароль", "ENCRYPTED"); return;
            } catch (SevenZipEngine.WrongPassword wp) { call.reject("Неверный пароль", "BADPASS"); return;
            } catch (Exception ee) { /* движок не смог — идём прежними библиотеками */ }
        }
        if (kA.equals("rar5")) {
            try {
                File dd = new File(destDir); dd.mkdirs();
                java.util.Set<String> onlyR = names != null ? new java.util.HashSet<String>() : null;
                if (onlyR != null) for (int i = 0; i < names.length(); i++) onlyR.add(String.valueOf(names.get(i)));
                laExtract(src, dd, onlyR, password, cx.quiet, cx);
                call.resolve(); return;
            } catch (Exception e) {
                if (rar5EncErr(e)) { call.reject("RAR5 с паролем: нужен движок 7-Zip", "UNSUPPORTED"); return; }
                call.reject("RAR5: " + (e.getMessage() != null ? e.getMessage() : "ошибка")); return;
            }
        }
        if (kA.equals("7z")) {
            try {
                File dd = new File(destDir); dd.mkdirs();
                java.util.Set<String> onlyA = names != null ? new java.util.HashSet<String>() : null;
                if (onlyA != null) for (int i = 0; i < names.length(); i++) onlyA.add(String.valueOf(names.get(i)));
                boolean laOk = true;
                // libarchive не умеет шифрованные 7z — тогда вторая библиотека с паролем
                try { laExtract(src, dd, onlyA, password, cx.quiet, cx); }
                catch (Exception le) { laOk = false; }
                if (!laOk) {
                    boolean enc = sevenHasEnc(src, password);
                    if (enc && (password == null || password.isEmpty())) { call.reject("Требуется пароль", "ENCRYPTED"); return; }
                    try { sevenExtract(src, dd, onlyA, password, cx.quiet, cx); }
                    catch (Exception se) {
                        if (enc && sevenPassErr(se)) { call.reject("Неверный пароль", "BADPASS"); return; }
                        throw se;
                    }
                }
                call.resolve(); return;
            } catch (Exception e) { call.reject("7z: " + (e.getMessage() != null ? e.getMessage() : "ошибка")); return; }
        }
        if (kA.equals("bz2") || kA.equals("xz")) { call.reject("Формат " + kA + " пока не поддерживается"); return; }
        if (kA.equals("rar")) {
            try {
                java.util.Set<String> only = null;
                if (names != null) { only = new java.util.HashSet<>(); for (int i = 0; i < names.length(); i++) only.add(names.getString(i)); }
                if ((password == null || password.isEmpty()) && rarProtected(src, null)) { call.reject("Требуется пароль", "ENCRYPTED"); return; }
                rarExtract(src, new File(destDir), only, password, cx);
                JSObject ret = new JSObject(); ret.put("done", true); call.resolve(ret); return;
            } catch (Exception e) { rejectRar(call, src, password, e); return; }
        }
        if (!kA.equals("zip")) {
            try {
                if (kA.equals("gz")) {
                    File out = exOut(cx, new File(destDir), gzBase(src), -1, 0);
                    if (out != null) {
                        gzExtract(src, out);
                        exAddBytes(cx, out.length());
                        JSObject ev = new JSObject(); ev.put("done", 1); ev.put("total", 1); ev.put("name", gzBase(src)); exPutBytes(cx, ev); notifyListeners("opProgress", ev);
                    }
                } else {
                    java.util.Set<String> only = null; int total = 0; long bt = 0;
                    if (names != null) { only = new java.util.HashSet<>(); for (int i = 0; i < names.length(); i++) only.add(names.getString(i)); }
                    java.util.List<String> psT = exOnlyPrefixes(only);
                    InputStream cin = tarStream(src, kA); java.util.List<String[]> es = tarEntries(cin); cin.close();
                    for (String[] e : es) {
                        if (e[2].equals("5") || e[0].endsWith("/")) continue;
                        if (!exWanted(only, psT, e[0])) continue;
                        total++; try { bt += Long.parseLong(e[1]); } catch (Throwable ignored) {}
                    }
                    if (cx.bytesTotal <= 0) cx.bytesTotal = bt;
                    InputStream in = tarStream(src, kA); tarExtract(in, new File(destDir), only, null, total, cx); in.close();
                }
                JSObject ret = new JSObject(); ret.put("done", true); call.resolve(ret); return;
            } catch (Exception e) { call.reject(e.getMessage()); return; }
        }
        // архивы с паролем — через zip4j
        boolean encA = zipIsEncrypted(src);
        if (encA || (password != null && !password.isEmpty())) {
            if (encA && (password == null || password.isEmpty())) { call.reject("Требуется пароль", "ENCRYPTED"); return; }
            try {
                java.util.List<String> list = null;
                if (names != null) { list = new java.util.ArrayList<>(); for (int i = 0; i < names.length(); i++) list.add(names.getString(i)); }
                zip4jExtract(src, destDir, list, password, cx);
                JSObject ret = new JSObject(); ret.put("done", true); call.resolve(ret); return;
            } catch (Exception e) {
                if (zipWrongPass(e)) { call.reject("Неверный пароль", "BADPASS"); return; }
                call.reject("ZIP: " + (e.getMessage() != null ? e.getMessage() : "ошибка")); return;
            }
        }
        ZipFile zf = null;
        try {
            zf = openZip(src);   // кодировка имён подобрана заранее — старые архивы с русскими именами читаются правильно
            java.util.Set<String> onlyZ = namesSet(names);
            java.util.List<String> psZ = exOnlyPrefixes(onlyZ);
            java.util.List<String> list = new java.util.ArrayList<>();
            {
                Enumeration<? extends ZipEntry> en = zf.entries();
                while (en.hasMoreElements()) {
                    ZipEntry e = en.nextElement();
                    String nm = e.getName().replace('\\', '/');
                    if (onlyZ != null && !exWanted(onlyZ, psZ, nm)) continue;
                    list.add(e.getName());
                }
            }
            long bt = 0; int totalF = 0;
            for (String nm : list) { ZipEntry z0 = zf.getEntry(nm); if (z0 != null && !z0.isDirectory()) { totalF++; if (z0.getSize() > 0) bt += z0.getSize(); } }
            if (cx.bytesTotal <= 0) cx.bytesTotal = bt;
            int total = Math.max(1, totalF), done = 0;
            byte[] buf = new byte[65536];
            File dd = new File(destDir);
            for (String nm : list) {
                ZipEntry ze = zf.getEntry(nm);
                if (ze == null) continue;
                if (ze.isDirectory()) { exDirOut(cx, dd, nm); continue; }
                File out = exOut(cx, dd, nm, ze.getSize(), ze.getTime());
                if (out == null) { done++; continue; }   // ответ «пропустить»
                for (;;) {
                    InputStream in = null; OutputStream fos = null;
                    try {
                        in = zf.getInputStream(ze);
                        fos = new ProgOut(new FileOutputStream(out), nm, done, total, ze.getSize(), cx.quiet, cx);
                        int n;
                        while ((n = in.read(buf)) > 0) fos.write(buf, 0, n);
                        fos.close(); fos = null; in.close(); in = null;
                        break;
                    } catch (Exception oe) {
                        try { if (fos != null) fos.close(); } catch (Exception ignored) {}
                        try { if (in != null) in.close(); } catch (Exception ignored) {}
                        try { out.delete(); } catch (Throwable ignored) {}
                        String m0 = oe.getMessage();
                        if (m0 != null && m0.toLowerCase().contains("encrypt")) throw oe;   // пароль — общий отказ
                        if (exGuard(cx, nm, oe)) break;   // пропустить; zip читается с любого места — «повторить» тоже работает
                    }
                }
                done++;
            }
            call.resolve();
        } catch (Exception e) {
            String m = e.getMessage();
            if (m != null && m.toLowerCase().contains("encrypt")) { call.reject("Требуется пароль", "ENCRYPTED"); return; }
            call.reject(m);
        }
        finally { if (zf != null) try { zf.close(); } catch (Exception ignored) {} }
    }

    // Пересоздание архива с изменениями: RAR/7z менять нельзя, поэтому распаковываем всё,
    // применяем удаление/переименование и собираем ZIP рядом (как делают другие архиваторы)
    @PluginMethod
    public void arcRebuild(final PluginCall call) {
        final String uriStr = call.getString("uri");
        final JSArray remove = call.getArray("remove");     // имена записей на удаление
        final String renFrom = call.getString("renameFrom");
        final String renTo = call.getString("renameTo");
        if (uriStr == null) { call.reject("no uri"); return; }
        new Thread(() -> {
            File work = null;
            try {
                File src = arcFile(uriStr);
                String pw = call.getString("password");
                java.util.Set<String> drop = new java.util.HashSet<>();
                JSArray rem2 = expandDirKeys(uriStr, pw, remove);
                if (rem2 != null) for (Object o : rem2.toList()) {
                    String n = String.valueOf(o);
                    drop.add(n);
                    if (n.endsWith("/")) drop.add(n.substring(0, n.length() - 1)); else drop.add(n + "/");   // 7z хранит папки без слэша
                }

                work = new File(getContext().getCacheDir(), "rebuild_" + System.currentTimeMillis());
                work.mkdirs();
                postProgressNotif("Пересборка архива", src.getName(), 5, 100);
                notifyRebuild(5, "распаковка");

                String kind = arcKindCached(src);
                if (kind.equals("7z")) sevenExtract(src, work, null, pw, true);
                else if (kind.equals("rar5")) laExtract(src, work, null, pw, true);
                else if (kind.equals("rar")) { rarQuiet = true; try { rarExtract(src, work, null, pw); } finally { rarQuiet = false; } }
                else { net.lingala.zip4j.ZipFile z = openZip4j(src); if (pw != null && pw.length() > 0) z.setPassword(pw.toCharArray()); z.extractAll(work.getAbsolutePath()); z.close(); }

                notifyRebuild(55, "изменения");
                for (String nm : drop) { File d = new File(work, nm); if (d.exists()) deleteRecursive(d); }
                if (renFrom != null && renTo != null) {
                    File a = new File(work, renFrom);
                    File b = new File(work, renTo);
                    if (a.exists()) { if (b.getParentFile() != null) b.getParentFile().mkdirs(); a.renameTo(b); }
                }

                notifyRebuild(65, "сборка");
                String base = src.getName().replaceAll("(?i)\\.(7z|rar|zip|tar|tgz|gz)$", "");
                File out = new File(src.getParentFile(), base + ".zip");
                if (out.getAbsolutePath().equals(src.getAbsolutePath())) out = new File(src.getParentFile(), base + "_new.zip");
                if (out.exists()) out.delete();
                net.lingala.zip4j.ZipFile nz = new net.lingala.zip4j.ZipFile(out);
                net.lingala.zip4j.model.ZipParameters zp = new net.lingala.zip4j.model.ZipParameters();
                File[] kids = work.listFiles();
                if (kids != null) for (File k : kids) { if (k.isDirectory()) nz.addFolder(k, zp); else nz.addFile(k, zp); }
                nz.close();

                arcListCache.clear(); arcKindCache.clear();
                notifyRebuild(100, "готово");
                try { NotificationManager nm = (NotificationManager) getContext().getSystemService(Context.NOTIFICATION_SERVICE); nm.cancel(777); } catch (Exception ignored) {}
                JSObject r = new JSObject(); r.put("ok", true); r.put("path", out.getAbsolutePath()); r.put("name", out.getName());
                call.resolve(r);
            } catch (Exception e) {
                try { NotificationManager nm = (NotificationManager) getContext().getSystemService(Context.NOTIFICATION_SERVICE); nm.cancel(777); } catch (Exception ignored) {}
                call.reject(e.getMessage() != null ? e.getMessage() : "не удалось пересобрать");
            } finally { if (work != null) deleteRecursive(work); }
        }).start();
    }

    private void notifyRebuild(int pct, String stage) {
        JSObject ev = new JSObject(); ev.put("done", pct); ev.put("total", 100); ev.put("name", stage);
        notifyListeners("opProgress", ev);
        postProgressNotif("Пересборка архива", stage, pct, 100);
    }

    /** Переписать 7z своей библиотекой: читаем записи и пишем новый архив с изменениями. */
    private void sevenRewrite(File src, File tmpOut, java.util.Set<String> drop, String renFrom, String renTo, String pw) throws Exception {
        java.util.Map<String, String> ren = new java.util.HashMap<>();
        if (renFrom != null && renTo != null) ren.put(renFrom, renTo);
        sevenRewrite(src, tmpOut, drop, ren, null, pw);
    }

    private void sevenRewrite(File src, File tmpOut, java.util.Set<String> drop, java.util.Map<String, String> ren, java.util.Map<String, File> add, String pw) throws Exception {
        sevenRewrite(src, tmpOut, drop, ren, add, pw, null);
    }

    private void sevenRewrite(File src, File tmpOut, java.util.Set<String> drop, java.util.Map<String, String> ren, java.util.Map<String, File> add, String pw, java.util.Set<String> keepDirs) throws Exception {
        org.apache.commons.compress.archivers.sevenz.SevenZFile in = open7z(src, pw);
        org.apache.commons.compress.archivers.sevenz.SevenZOutputFile out =
                new org.apache.commons.compress.archivers.sevenz.SevenZOutputFile(tmpOut);
        try {
            int total = 0, done = 0;
            for (org.apache.commons.compress.archivers.sevenz.SevenZArchiveEntry q : in.getEntries()) total++;
            byte[] buf = new byte[262144];
            org.apache.commons.compress.archivers.sevenz.SevenZArchiveEntry e;
            while ((e = in.getNextEntry()) != null) {
                String nm = e.getName().replace('\\', '/');
                if (drop.contains(nm)) { done++; continue; }
                if (ren != null && ren.containsKey(nm)) nm = ren.get(nm);
                org.apache.commons.compress.archivers.sevenz.SevenZArchiveEntry ne =
                        new org.apache.commons.compress.archivers.sevenz.SevenZArchiveEntry();
                ne.setName(nm);
                ne.setDirectory(e.isDirectory());
                try { if (e.getHasLastModifiedDate()) ne.setLastModifiedDate(e.getLastModifiedDate()); } catch (Throwable ignored) {}
                out.putArchiveEntry(ne);
                if (!e.isDirectory()) { int r; while ((r = in.read(buf)) > 0) out.write(buf, 0, r); }
                out.closeArchiveEntry();
                done++;
                int pct = total > 0 ? (int) (done * 100.0 / total) : 100;
                JSObject ev = new JSObject(); ev.put("done", pct); ev.put("total", 100); ev.put("name", nm); notifyListeners("opProgress", ev);
                postProgressNotif("Изменение архива", nm, pct, 100);
            }
            if (keepDirs != null) for (String d : keepDirs) {
                org.apache.commons.compress.archivers.sevenz.SevenZArchiveEntry nd =
                        new org.apache.commons.compress.archivers.sevenz.SevenZArchiveEntry();
                nd.setName(d.endsWith("/") ? d.substring(0, d.length() - 1) : d);
                nd.setDirectory(true);
                out.putArchiveEntry(nd); out.closeArchiveEntry();
            }
            if (add != null) for (java.util.Map.Entry<String, File> ae : add.entrySet()) {
                org.apache.commons.compress.archivers.sevenz.SevenZArchiveEntry ne =
                        new org.apache.commons.compress.archivers.sevenz.SevenZArchiveEntry();
                ne.setName(ae.getKey()); ne.setDirectory(false);
                try { ne.setLastModifiedDate(new java.util.Date(ae.getValue().lastModified())); } catch (Throwable ignored) {}
                out.putArchiveEntry(ne);
                InputStream fin = new FileInputStream(ae.getValue());
                try { byte[] b2 = new byte[262144]; int r; while ((r = fin.read(b2)) > 0) out.write(b2, 0, r); }
                finally { try { fin.close(); } catch (Exception ignored) {} }
                out.closeArchiveEntry();
            }
        } finally {
            try { out.close(); } catch (Exception ignored) {}
            try { in.close(); } catch (Exception ignored) {}
        }
    }

    /**
     * Запасной путь для 7z, которые наша библиотека читать не умеет (сцепка упаковщиков — так пакуют exe и dll):
     * распаковываем всё быстрой библиотекой во временную папку и собираем архив заново.
     */
    private void sevenRewriteViaLa(File src, File tmpOut, java.util.Set<String> drop, String renFrom, String renTo, String pw) throws Exception {
        java.util.Map<String, String> ren = new java.util.HashMap<>();
        if (renFrom != null && renTo != null) ren.put(renFrom, renTo);
        sevenRewriteViaLa(src, tmpOut, drop, ren, null, pw);
    }

    private void sevenRewriteViaLa(File src, File tmpOut, java.util.Set<String> drop, java.util.Map<String, String> ren, java.util.Map<String, File> add, String pw) throws Exception {
        sevenRewriteViaLa(src, tmpOut, drop, ren, add, pw, null);
    }

    private void sevenRewriteViaLa(File src, File tmpOut, java.util.Set<String> drop, java.util.Map<String, String> ren, java.util.Map<String, File> add, String pw, java.util.Set<String> keepDirs) throws Exception {
        File work = new File(getContext().getCacheDir(), "sevenmod");
        deleteTreeQuiet(work);
        if (!work.mkdirs() && !work.isDirectory()) throw new Exception("нет места для распаковки");
        try {
            postProgressNotif("Изменение архива", "распаковка", 5, 100);
            laExtract(src, work, null, pw, true);

            java.util.List<File> files = new java.util.ArrayList<>();
            collectFiles(work, files);
            org.apache.commons.compress.archivers.sevenz.SevenZOutputFile out =
                    new org.apache.commons.compress.archivers.sevenz.SevenZOutputFile(tmpOut);
            try {
                byte[] buf = new byte[262144];
                int total = files.size(), done = 0;
                String base = work.getAbsolutePath() + "/";
                for (File f : files) {
                    String nm = f.getAbsolutePath().startsWith(base) ? f.getAbsolutePath().substring(base.length()) : f.getName();
                    if (drop.contains(nm)) { done++; continue; }
                    if (ren != null && ren.containsKey(nm)) nm = ren.get(nm);
                    org.apache.commons.compress.archivers.sevenz.SevenZArchiveEntry ne =
                            new org.apache.commons.compress.archivers.sevenz.SevenZArchiveEntry();
                    ne.setName(nm);
                    ne.setDirectory(f.isDirectory());
                    try { ne.setLastModifiedDate(new java.util.Date(f.lastModified())); } catch (Throwable ignored) {}
                    out.putArchiveEntry(ne);
                    if (!f.isDirectory()) {
                        InputStream fin = new FileInputStream(f);
                        try { int r; while ((r = fin.read(buf)) > 0) out.write(buf, 0, r); } finally { try { fin.close(); } catch (Exception ignored) {} }
                    }
                    out.closeArchiveEntry();
                    done++;
                    int pct = total > 0 ? (int) (done * 100.0 / total) : 100;
                    JSObject ev = new JSObject(); ev.put("done", pct); ev.put("total", 100); ev.put("name", nm); notifyListeners("opProgress", ev);
                    postProgressNotif("Изменение архива", nm, pct, 100);
                }
                if (keepDirs != null) for (String d : keepDirs) {
                    String dn = d.endsWith("/") ? d.substring(0, d.length() - 1) : d;
                    boolean already = false;
                    for (File f : files) { String nm2 = f.getAbsolutePath().startsWith(base) ? f.getAbsolutePath().substring(base.length()) : f.getName(); if (nm2.equals(dn)) { already = true; break; } }
                    if (already) continue;
                    org.apache.commons.compress.archivers.sevenz.SevenZArchiveEntry nd =
                            new org.apache.commons.compress.archivers.sevenz.SevenZArchiveEntry();
                    nd.setName(dn); nd.setDirectory(true);
                    out.putArchiveEntry(nd); out.closeArchiveEntry();
                }
                if (add != null) for (java.util.Map.Entry<String, File> ae : add.entrySet()) {
                    org.apache.commons.compress.archivers.sevenz.SevenZArchiveEntry ne =
                            new org.apache.commons.compress.archivers.sevenz.SevenZArchiveEntry();
                    ne.setName(ae.getKey()); ne.setDirectory(false);
                    try { ne.setLastModifiedDate(new java.util.Date(ae.getValue().lastModified())); } catch (Throwable ignored) {}
                    out.putArchiveEntry(ne);
                    InputStream fin = new FileInputStream(ae.getValue());
                    try { int r; while ((r = fin.read(buf)) > 0) out.write(buf, 0, r); }
                    finally { try { fin.close(); } catch (Exception ignored) {} }
                    out.closeArchiveEntry();
                }
            } finally { try { out.close(); } catch (Exception ignored) {} }
        } finally { deleteTreeQuiet(work); }
    }

    private void collectFiles(File dir, java.util.List<File> out) {
        File[] kids = dir.listFiles();
        if (kids == null) return;
        java.util.Arrays.sort(kids);
        for (File k : kids) {
            if (k.isDirectory()) { out.add(k); collectFiles(k, out); }
            else out.add(k);
        }
    }

    private void deleteTreeQuiet(File f) {
        try {
            if (f.isDirectory()) { File[] k = f.listFiles(); if (k != null) for (File x : k) deleteTreeQuiet(x); }
            f.delete();
        } catch (Throwable ignored) {}
    }

    /** Ключ папки («Data/») превращаем в список всех записей внутри неё. */
    private JSArray expandDirKeys(String uriStr, String pw, JSArray names) {
        if (names == null) return null;
        try {
            boolean hasDir = false;
            for (Object o : names.toList()) if (String.valueOf(o).endsWith("/")) { hasDir = true; break; }
            if (!hasDir) return names;
            File src = arcFile(uriStr);
            java.util.List<String> all = arcNames(src, pw);
            java.util.LinkedHashSet<String> out = new java.util.LinkedHashSet<>();
            for (Object o : names.toList()) {
                String n = String.valueOf(o);
                out.add(n);
                if (!n.endsWith("/")) continue;
                String bare = n.substring(0, n.length() - 1);
                for (String x : all) if (x.startsWith(n) || x.equals(bare)) out.add(x);
            }
            JSArray ex = new JSArray();
            for (String n : out) ex.put(n);
            return ex;
        } catch (Exception e) { return names; }
    }

    /** Все имена записей архива — нужно, чтобы разворачивать папки в список файлов. */
    private java.util.List<String> arcNames(File src, String pw) {
        java.util.List<String> out = new java.util.ArrayList<>();
        String kind = arcKindCached(src);
        if (kind.equals("zip")) {
            try {
                net.lingala.zip4j.ZipFile z = new net.lingala.zip4j.ZipFile(src);
                try { for (net.lingala.zip4j.model.FileHeader h : z.getFileHeaders()) out.add(h.getFileName().replace('\\', '/')); }
                finally { try { z.close(); } catch (Exception ignored) {} }
                return out;
            } catch (Exception ignored) {}
        }
        try {
            JSArray arr = laEntries(src, pw);
            for (int i = 0; i < arr.length(); i++) out.add(String.valueOf(((JSObject) arr.get(i)).getString("name")));
            if (!out.isEmpty()) return out;
        } catch (Exception ignored) {}
        try {
            org.apache.commons.compress.archivers.sevenz.SevenZFile z = open7z(src, pw);
            try { for (org.apache.commons.compress.archivers.sevenz.SevenZArchiveEntry e : z.getEntries()) out.add(e.getName().replace('\\', '/')); }
            finally { try { z.close(); } catch (Exception ignored) {} }
        } catch (Exception ignored) {}
        return out;
    }

    /**
     * Разворачивает выбор в точный список «старое имя → новое имя».
     * Папку (имя заканчивается на «/») превращаем в переименование всего, что лежит внутри.
     */
    private java.util.Map<String, String> expandPairs(File src, String pw, JSArray from, JSArray to) throws Exception {
        java.util.Map<String, String> out = new java.util.LinkedHashMap<>();
        java.util.List<String> all = null;
        for (int i = 0; i < from.length() && i < to.length(); i++) {
            String f = String.valueOf(from.get(i)).replace('\\', '/');
            String t = String.valueOf(to.get(i)).replace('\\', '/');
            if (f.endsWith("/")) {
                if (all == null) all = arcNames(src, pw);
                String tt = t.isEmpty() ? "" : (t.endsWith("/") ? t : t + "/");   // корень архива — без ведущего слэша
                for (String n : all) {
                    if (!n.startsWith(f)) continue;
                    String nn = tt + n.substring(f.length());
                    if (!nn.equals(n)) out.put(n, nn);
                }
            } else if (!f.equals(t)) out.put(f, t);
        }
        return out;
    }

    /** Папки, которые опустеют после переноса — их нужно оставить в архиве. */
    private java.util.Set<String> emptiedDirs(java.util.List<String> all, java.util.Map<String, String> ren) {
        java.util.Set<String> cand = new java.util.LinkedHashSet<>();
        for (String f : ren.keySet()) {
            String x = f.endsWith("/") ? f.substring(0, f.length() - 1) : f;
            int sl = x.lastIndexOf('/');
            if (sl > 0) cand.add(x.substring(0, sl + 1));
        }
        java.util.Set<String> out = new java.util.LinkedHashSet<>();
        for (String d : cand) {
            boolean left = false;
            for (String n : all) {
                if (ren.containsKey(n)) continue;                 // эта запись уезжает
                if (n.equals(d) || n.equals(d.substring(0, d.length() - 1))) continue;  // сама папка
                if (n.startsWith(d)) { left = true; break; }
            }
            if (!left) out.add(d);
        }
        return out;
    }

    /** Добавить в архив пустые папки (чтобы они не пропали после переноса содержимого). */
    private void addEmptyDirs(File src, String kind, java.util.Set<String> dirs, String pw) {
        if (dirs.isEmpty()) return;
        try {
            if (kind.equals("zip")) {
                net.lingala.zip4j.ZipFile z = new net.lingala.zip4j.ZipFile(src);
                if (pw != null && pw.length() > 0) z.setPassword(pw.toCharArray());
                try {
                    for (String d : dirs) {
                        net.lingala.zip4j.model.ZipParameters zp = new net.lingala.zip4j.model.ZipParameters();
                        zp.setFileNameInZip(d.endsWith("/") ? d : d + "/");
                        z.addStream(new java.io.ByteArrayInputStream(new byte[0]), zp);
                    }
                } finally { try { z.close(); } catch (Exception ignored) {} }
            }
            // для 7z папки дописываются прямо при пересборке (см. sevenRewrite)
        } catch (Throwable ignored) {}
    }

    /**
     * Создание внутри архива: имя с «/» на конце — пустая папка, иначе пустой файл.
     * ZIP правим на месте, 7z пересобираем с тем же набором записей плюс новая.
     */
    @PluginMethod
    public void arcCreate(final PluginCall call) {
        final String uriStr = call.getString("uri");
        final String name = call.getString("name");
        final String pw = call.getString("password");
        if (uriStr == null || name == null || name.isEmpty()) { call.reject("bad args"); return; }
        new Thread(() -> {
            File tmpOut = null;
            File empty = null;
            try {
                File src = arcFile(uriStr);
                String kind = arcKindCached(src);
                boolean isDir = name.endsWith("/");
                String nm = name.replace('\\', '/').replaceAll("^/+", "");
                for (String ex : arcNames(src, pw)) {
                    String a = ex.endsWith("/") ? ex : ex + "/";
                    if (ex.equals(nm) || (isDir && a.equals(nm))) { call.reject("Здесь уже есть «" + nm + "»"); return; }
                }
                if (kind.equals("zip")) {
                    net.lingala.zip4j.ZipFile z = new net.lingala.zip4j.ZipFile(src);
                    if (pw != null && pw.length() > 0) z.setPassword(pw.toCharArray());
                    try {
                        net.lingala.zip4j.model.ZipParameters zp = new net.lingala.zip4j.model.ZipParameters();
                        zp.setFileNameInZip(nm);
                        z.addStream(new java.io.ByteArrayInputStream(new byte[0]), zp);
                    } finally { try { z.close(); } catch (Exception ignored) {} }
                } else if (kind.equals("7z")) {
                    if (sevenHasEnc(src, pw)) { call.reject("Архив с паролем нельзя изменить на месте", "ENCRYPTED"); return; }
                    tmpOut = new File(src.getParentFile(), "." + src.getName() + ".tmp7z");
                    if (tmpOut.exists()) tmpOut.delete();
                    java.util.Set<String> keepDirs = new java.util.LinkedHashSet<>();
                    java.util.Map<String, File> add = null;
                    if (isDir) keepDirs.add(nm);
                    else {
                        empty = new File(getContext().getCacheDir(), "arcnew_" + System.currentTimeMillis());
                        new FileOutputStream(empty).close();
                        add = new java.util.LinkedHashMap<>();
                        add.put(nm, empty);
                    }
                    try { sevenRewrite(src, tmpOut, new java.util.HashSet<String>(), null, add, pw, keepDirs); }
                    catch (Exception re) { if (tmpOut.exists()) tmpOut.delete(); sevenRewriteViaLa(src, tmpOut, new java.util.HashSet<String>(), null, add, pw, keepDirs); }
                    if (!swapArchive(src, tmpOut)) throw new Exception("не удалось записать архив");
                    tmpOut = null;
                } else { call.reject("В этом формате создавать нельзя"); return; }
                arcListCache.clear(); arcKindCache.clear();
                JSObject r = new JSObject(); r.put("ok", true); call.resolve(r);
            } catch (Exception e) {
                call.reject(e.getMessage() != null ? e.getMessage() : "не удалось");
            } finally {
                if (tmpOut != null && tmpOut.exists()) tmpOut.delete();
                if (empty != null) empty.delete();
            }
        }).start();
    }

    /** Перемещение записей внутри архива (без распаковки): zip — переименованием, 7z — пересборкой. */
    @PluginMethod
    public void arcMove(final PluginCall call) {
        final String uriStr = call.getString("uri");
        final JSArray from = call.getArray("from");
        final JSArray to = call.getArray("to");
        final String pw = call.getString("password");
        if (uriStr == null || from == null || to == null) { call.reject("bad args"); return; }
        new Thread(() -> {
            File tmpOut = null;
            try {
                File src = arcFile(uriStr);
                java.util.Map<String, String> ren = expandPairs(src, pw, from, to);
                if (ren.isEmpty()) { JSObject r = new JSObject(); r.put("ok", true); call.resolve(r); return; }
                String kind = arcKindCached(src);
                java.util.Set<String> keepDirs = emptiedDirs(arcNames(src, pw), ren);
                if (kind.equals("zip")) {
                    net.lingala.zip4j.ZipFile z = new net.lingala.zip4j.ZipFile(src);
                    if (pw != null && pw.length() > 0) z.setPassword(pw.toCharArray());
                    z.renameFiles(ren);
                    z.close();
                    addEmptyDirs(src, kind, keepDirs, pw);
                } else if (kind.equals("7z")) {
                    if (sevenHasEnc(src, pw)) { call.reject("Архив с паролем нельзя изменить на месте", "ENCRYPTED"); return; }
                    tmpOut = new File(src.getParentFile(), "." + src.getName() + ".tmp7z");
                    if (tmpOut.exists()) tmpOut.delete();
                    try { sevenRewrite(src, tmpOut, new java.util.HashSet<String>(), ren, null, pw, keepDirs); }
                    catch (Exception re) { if (tmpOut.exists()) tmpOut.delete(); sevenRewriteViaLa(src, tmpOut, new java.util.HashSet<String>(), ren, null, pw, keepDirs); }
                    if (!swapArchive(src, tmpOut)) throw new Exception("не удалось записать архив");
                    tmpOut = null;
                } else { call.reject("Этот формат нельзя изменять"); return; }
                arcListCache.clear(); arcKindCache.clear();
                try { NotificationManager nm = (NotificationManager) getContext().getSystemService(Context.NOTIFICATION_SERVICE); nm.cancel(777); } catch (Exception ignored) {}
                JSObject r = new JSObject(); r.put("ok", true); call.resolve(r);
            } catch (Exception e) {
                try { NotificationManager nm = (NotificationManager) getContext().getSystemService(Context.NOTIFICATION_SERVICE); nm.cancel(777); } catch (Exception ignored) {}
                call.reject(e.getMessage() != null ? e.getMessage() : "не удалось");
            } finally { if (tmpOut != null && tmpOut.exists()) tmpOut.delete(); }
        }).start();
    }

    /** Копирование записей внутри архива: содержимое достаём во временную папку и добавляем под новыми именами. */
    @PluginMethod
    public void arcCopyInside(final PluginCall call) {
        final String uriStr = call.getString("uri");
        final JSArray from = call.getArray("from");
        final JSArray to = call.getArray("to");
        final String pw = call.getString("password");
        if (uriStr == null || from == null || to == null) { call.reject("bad args"); return; }
        new Thread(() -> {
            File work = new File(getContext().getCacheDir(), "arccopy");
            File tmpOut = null;
            try {
                File src = arcFile(uriStr);
                String kind = arcKindCached(src);
                if (!kind.equals("zip") && !kind.equals("7z")) { call.reject("Этот формат нельзя изменять"); return; }
                deleteTreeQuiet(work);
                if (!work.mkdirs() && !work.isDirectory()) throw new Exception("нет места для распаковки");
                java.util.Map<String, String> pairs = expandPairs(src, pw, from, to);
                java.util.Set<String> only = new java.util.HashSet<>(pairs.keySet());
                if (pairs.isEmpty()) { JSObject r = new JSObject(); r.put("ok", true); call.resolve(r); return; }
                // достаём нужные записи
                if (kind.equals("zip") && zipIsEncrypted(src)) zip4jExtract(src, work.getAbsolutePath(), new java.util.ArrayList<>(only), pw);
                else {
                    try { laExtract(src, work, only, pw, true); }
                    catch (Exception le) { if (kind.equals("7z")) sevenExtract(src, work, only, pw, true); else throw le; }
                }
                // файлы кладём как файлы, папки — как записи-папки (иначе попытка читать папку как файл)
                java.util.Map<String, File> add = new java.util.LinkedHashMap<>();
                java.util.Set<String> addDirs = new java.util.LinkedHashSet<>();
                for (java.util.Map.Entry<String, String> e : pairs.entrySet()) {
                    File got = new File(work, e.getKey().endsWith("/") ? e.getKey().substring(0, e.getKey().length() - 1) : e.getKey());
                    if (!got.exists()) {
                        if (e.getKey().endsWith("/")) { addDirs.add(e.getValue()); continue; }   // пустая папка
                        throw new Exception("не удалось прочитать: " + e.getKey());
                    }
                    if (got.isDirectory()) addDirs.add(e.getValue());
                    else add.put(e.getValue(), got);
                }
                if (kind.equals("zip")) {
                    net.lingala.zip4j.ZipFile z = new net.lingala.zip4j.ZipFile(src);
                    if (pw != null && pw.length() > 0) z.setPassword(pw.toCharArray());
                    for (String d : addDirs) {
                        net.lingala.zip4j.model.ZipParameters zd = new net.lingala.zip4j.model.ZipParameters();
                        zd.setFileNameInZip(d.endsWith("/") ? d : d + "/");
                        z.addStream(new java.io.ByteArrayInputStream(new byte[0]), zd);
                    }
                    for (java.util.Map.Entry<String, File> ae : add.entrySet()) {
                        net.lingala.zip4j.model.ZipParameters zp = new net.lingala.zip4j.model.ZipParameters();
                        zp.setFileNameInZip(ae.getKey());
                        z.addFile(ae.getValue(), zp);
                    }
                    z.close();
                } else {
                    if (sevenHasEnc(src, pw)) { call.reject("Архив с паролем нельзя изменить на месте", "ENCRYPTED"); return; }
                    tmpOut = new File(src.getParentFile(), "." + src.getName() + ".tmp7z");
                    if (tmpOut.exists()) tmpOut.delete();
                    try { sevenRewrite(src, tmpOut, new java.util.HashSet<String>(), null, add, pw, addDirs); }
                    catch (Exception re) { if (tmpOut.exists()) tmpOut.delete(); sevenRewriteViaLa(src, tmpOut, new java.util.HashSet<String>(), null, add, pw, addDirs); }
                    if (!swapArchive(src, tmpOut)) throw new Exception("не удалось записать архив");
                    tmpOut = null;
                }
                arcListCache.clear(); arcKindCache.clear();
                try { NotificationManager nm = (NotificationManager) getContext().getSystemService(Context.NOTIFICATION_SERVICE); nm.cancel(777); } catch (Exception ignored) {}
                JSObject r = new JSObject(); r.put("ok", true); call.resolve(r);
            } catch (Exception e) {
                try { NotificationManager nm = (NotificationManager) getContext().getSystemService(Context.NOTIFICATION_SERVICE); nm.cancel(777); } catch (Exception ignored) {}
                call.reject(e.getMessage() != null ? e.getMessage() : "не удалось");
            } finally { if (tmpOut != null && tmpOut.exists()) tmpOut.delete(); deleteTreeQuiet(work); }
        }).start();
    }

    /** Подменить архив собранным заново (через резервную копию, чтобы не потерять при сбое). */
    private boolean swapArchive(File src, File tmpOut) {
        File bak = new File(src.getParentFile(), "." + src.getName() + ".bak");
        if (bak.exists()) bak.delete();
        if (!src.renameTo(bak)) return false;
        if (!tmpOut.renameTo(src)) { bak.renameTo(src); return false; }
        bak.delete();
        return true;
    }

    // Изменение 7z на месте: читаем записи и пишем новый 7z с изменениями,
    // формат сохраняется — пересборка в ZIP больше не нужна
    @PluginMethod
    public void sevenModify(final PluginCall call) {
        final String uriStr = call.getString("uri");
        final JSArray remove = call.getArray("remove");
        final String renFrom = call.getString("renameFrom");
        final String renTo = call.getString("renameTo");
        final String pw = call.getString("password");
        if (uriStr == null) { call.reject("no uri"); return; }
        new Thread(() -> {
            File tmpOut = null;
            try {
                File src = arcFile(uriStr);
                if (!arcKindCached(src).equals("7z")) { call.reject("не 7z"); return; }

                // ключ папки разворачиваем в список записей и учитываем оба написания имени
                java.util.Set<String> drop = new java.util.HashSet<>();
                JSArray rem7 = expandDirKeys(uriStr, pw, remove);
                if (rem7 != null) for (Object o : rem7.toList()) {
                    String n = String.valueOf(o);
                    drop.add(n);
                    if (n.endsWith("/")) drop.add(n.substring(0, n.length() - 1)); else drop.add(n + "/");
                }

                // зашифрованный 7z переписать нельзя — пусть идёт обычной пересборкой
                if (sevenHasEnc(src, pw)) { call.reject("Архив с паролем нельзя изменить на месте", "ENCRYPTED"); return; }

                tmpOut = new File(src.getParentFile(), "." + src.getName() + ".tmp7z");
                if (tmpOut.exists()) tmpOut.delete();

                boolean rewritten = false;
                try {
                    sevenRewrite(src, tmpOut, drop, renFrom, renTo, pw);
                    rewritten = true;
                } catch (Exception re) {
                    // архивы со сцепкой упаковщиков (так пакуют exe и dll) наша библиотека читать не умеет —
                    // тогда распаковываем всё быстрой библиотекой и собираем архив заново
                    if (tmpOut.exists()) tmpOut.delete();
                    sevenRewriteViaLa(src, tmpOut, drop, renFrom, renTo, pw);
                    rewritten = true;
                }
                if (!rewritten) throw new Exception("не удалось изменить архив");
                File bak = new File(src.getParentFile(), "." + src.getName() + ".bak");
                if (bak.exists()) bak.delete();
                if (!src.renameTo(bak)) throw new Exception("не удалось заменить архив");
                if (!tmpOut.renameTo(src)) { bak.renameTo(src); throw new Exception("не удалось записать архив"); }
                bak.delete();
                tmpOut = null;

                arcListCache.clear(); arcKindCache.clear();
                try { NotificationManager nm = (NotificationManager) getContext().getSystemService(Context.NOTIFICATION_SERVICE); nm.cancel(777); } catch (Exception ignored) {}
                JSObject r = new JSObject(); r.put("ok", true); call.resolve(r);
            } catch (Exception ex) {
                try { NotificationManager nm = (NotificationManager) getContext().getSystemService(Context.NOTIFICATION_SERVICE); nm.cancel(777); } catch (Exception ignored) {}
                call.reject(ex.getMessage() != null ? ex.getMessage() : "не удалось изменить архив");
            } finally { if (tmpOut != null && tmpOut.exists()) tmpOut.delete(); }
        }).start();
    }

    // Можно ли менять этот архив на месте (ZIP — да, RAR/7z — нет)
    @PluginMethod
    public void zipEditable(PluginCall call) {
        String uriStr = call.getString("uri");
        if (uriStr == null) { call.reject("no uri"); return; }
        try {
            File f = arcFile(uriStr);
            String k = arcKindCached(f);
            boolean enc = false;
            if (k.equals("7z")) enc = sevenHasEnc(f, call.getString("password"));
            JSObject r = new JSObject();
            r.put("kind", k);
            r.put("encrypted", enc);
            r.put("editable", k.equals("zip") || (k.equals("7z") && !enc));
            call.resolve(r);
        } catch (Exception e) { call.reject(e.getMessage()); }
    }

    // Переименование записи внутри ZIP
    @PluginMethod
    public void zipRenameEntry(final PluginCall call) {
        final String uriStr = call.getString("uri");
        final String from = call.getString("from");
        final String to = call.getString("to");
        if (uriStr == null || from == null || to == null) { call.reject("bad args"); return; }
        new Thread(() -> {
            try {
                File f = arcFile(uriStr);
                if (!arcKindCached(f).equals("zip")) { call.reject("Этот формат нельзя изменять"); return; }
                net.lingala.zip4j.ZipFile z = new net.lingala.zip4j.ZipFile(f);
                String pw = call.getString("password");
                if (pw != null && pw.length() > 0) z.setPassword(pw.toCharArray());
                z.renameFile(from, to);
                z.close();
                arcListCache.clear(); arcKindCache.clear();
                JSObject r = new JSObject(); r.put("ok", true); call.resolve(r);
            } catch (Exception e) { call.reject(e.getMessage() != null ? e.getMessage() : "не удалось"); }
        }).start();
    }

    // Удаление записей из ZIP (для «вырезать» из архива). RAR/7z менять нельзя — вернём отказ.
    @PluginMethod
    public void zipDeleteEntries(final PluginCall call) {
        final String uriStr = call.getString("uri");
        final JSArray names = expandDirKeys(call.getString("uri"), call.getString("password"), call.getArray("entries"));
        if (uriStr == null || names == null) { call.reject("bad args"); return; }
        new Thread(() -> {
            try {
                File f = arcFile(uriStr);
                if (!arcKindCached(f).equals("zip")) { call.reject("Этот формат нельзя изменять"); return; }
                java.util.LinkedHashSet<String> list = new java.util.LinkedHashSet<>();
                for (Object o : names.toList()) {
                    String n = String.valueOf(o);
                    list.add(n);
                    if (n.endsWith("/")) list.add(n.substring(0, n.length() - 1)); else list.add(n + "/");
                }
                net.lingala.zip4j.ZipFile z = new net.lingala.zip4j.ZipFile(f);
                String pw = call.getString("password");
                if (pw != null && pw.length() > 0) z.setPassword(pw.toCharArray());
                z.removeFiles(new java.util.ArrayList<>(list));
                z.close();
                arcListCache.clear(); arcKindCache.clear();
                JSObject r = new JSObject(); r.put("ok", true); call.resolve(r);
            } catch (Exception e) { call.reject(e.getMessage() != null ? e.getMessage() : "не удалось"); }
        }).start();
    }

    @PluginMethod
    public void zipCreate(final PluginCall call) {
        final String dir = call.getString("dir");
        final String name = call.getString("name");
        final com.getcapacitor.JSArray uris = call.getArray("uris");
        if (dir == null || name == null || uris == null) { call.reject("no args"); return; }
        final String fmt = call.getString("format", "zip");
        new Thread(() -> {
            if (fmt.equals("tar") || fmt.equals("tgz") || fmt.equals("7z")) { createNonZip(call, fmt); return; }
            try {
                File out = new File(toFile(dir), name);
                if (out.exists()) out.delete();
                net.lingala.zip4j.ZipFile z = new net.lingala.zip4j.ZipFile(out);
                net.lingala.zip4j.model.ZipParameters pp = new net.lingala.zip4j.model.ZipParameters();
                z.setRunInThread(true);
                net.lingala.zip4j.progress.ProgressMonitor pm = z.getProgressMonitor();
                java.util.List<Object> list = uris.toList();
                java.util.List<File> files = new java.util.ArrayList<>();
                java.util.List<File> folders = new java.util.ArrayList<>();
                for (Object o : list) { File f = toFile(String.valueOf(o)); if (f != null && f.exists()) { if (f.isDirectory()) folders.add(f); else files.add(f); } }
                int ops = (files.isEmpty() ? 0 : 1) + folders.size(), done = 0;
                if (!files.isEmpty()) { z.addFiles(files, pp); waitZipOp(pm, name, done, ops); done++; }
                for (File folder : folders) { z.addFolder(folder, pp); waitZipOp(pm, name, done, ops); done++; }
                z.close();
                try { NotificationManager nm = (NotificationManager) getContext().getSystemService(Context.NOTIFICATION_SERVICE); nm.cancel(777); } catch (Exception ignored) {}
                JSObject fin = new JSObject(); fin.put("done", 100); fin.put("total", 100); fin.put("name", name); notifyListeners("opProgress", fin);
                JSObject r = new JSObject(); r.put("ok", true); r.put("dest", out.getAbsolutePath());
                call.resolve(r);
            } catch (Exception e) { try { NotificationManager nm = (NotificationManager) getContext().getSystemService(Context.NOTIFICATION_SERVICE); nm.cancel(777); } catch (Exception ignored) {} call.reject(e.getMessage()); }
        }).start();
    }

    private void waitZipOp(net.lingala.zip4j.progress.ProgressMonitor pm, String name, int opIndex, int ops) throws Exception {
        while (pm.getState() == net.lingala.zip4j.progress.ProgressMonitor.State.BUSY) {
            int pct = pm.getPercentDone();
            int overall = ops > 0 ? (int) ((opIndex * 100.0 + pct) / ops) : pct;
            if (overall > 99) overall = 99;
            postProgressNotif("Архивирование", name, overall, 100);
            JSObject ev = new JSObject(); ev.put("done", overall); ev.put("total", 100); ev.put("name", name); notifyListeners("opProgress", ev);
            Thread.sleep(120);
        }
        if (pm.getException() != null) throw pm.getException();
    }

    // ===== создание tar / tar.gz / 7z (zip остаётся на прежней библиотеке) =====

    private void createNonZip(PluginCall call, String fmt) {
        try {
            File dirF = toFile(call.getString("dir"));
            String name = call.getString("name");
            File out = new File(dirF, name);
            if (out.exists()) out.delete();
            java.util.List<File> tops = new java.util.ArrayList<>();
            for (Object o : call.getArray("uris").toList()) { File f = toFile(String.valueOf(o)); if (f != null && f.exists()) tops.add(f); }
            long totalB = 0;
            for (File t : tops) totalB += packSize(t);
            long[] st = { 0, 0 };   // сделано байтов, время последнего события
            if (fmt.equals("7z")) {
                org.apache.commons.compress.archivers.sevenz.SevenZOutputFile z = new org.apache.commons.compress.archivers.sevenz.SevenZOutputFile(out);
                try { byte[] buf = new byte[65536]; for (File t : tops) sevenAdd(z, t, t.getName(), buf, name, totalB, st); }
                finally { z.close(); }
            } else {
                OutputStream raw = new FileOutputStream(out);
                OutputStream os = fmt.equals("tgz") ? new java.util.zip.GZIPOutputStream(raw, 65536) : raw;
                try { byte[] buf = new byte[65536]; for (File t : tops) tarAdd(os, t, t.getName(), buf, name, totalB, st); os.write(new byte[1024]); }
                finally { try { os.close(); } catch (Exception ignored) {} try { raw.close(); } catch (Exception ignored) {} }
            }
            try { NotificationManager nm = (NotificationManager) getContext().getSystemService(Context.NOTIFICATION_SERVICE); nm.cancel(777); } catch (Exception ignored) {}
            JSObject fin = new JSObject(); fin.put("done", 100); fin.put("total", 100); fin.put("name", name); notifyListeners("opProgress", fin);
            JSObject r = new JSObject(); r.put("ok", true); r.put("dest", out.getAbsolutePath());
            call.resolve(r);
        } catch (Exception e) {
            try { NotificationManager nm = (NotificationManager) getContext().getSystemService(Context.NOTIFICATION_SERVICE); nm.cancel(777); } catch (Exception ignored) {}
            call.reject(e.getMessage() != null ? e.getMessage() : String.valueOf(e));
        }
    }

    /** Общий вес для процентов; в ссылки-папки не заходим. */
    private long packSize(File f) {
        if (f.isDirectory()) {
            if (YevXfer.isLink(f)) return 0;
            long s = 0; File[] k = f.listFiles(); if (k != null) for (File x : k) s += packSize(x);
            return s;
        }
        return Math.max(0, f.length());
    }

    private void packTick(String name, long doneB, long totalB, long[] st, boolean force) {
        long now = System.currentTimeMillis();
        if (!force && now - st[1] < 120) return;
        st[1] = now;
        int pct = totalB > 0 ? (int) Math.min(99, doneB * 100 / totalB) : 0;
        postProgressNotif("Архивирование", name, pct, 100);
        JSObject ev = new JSObject(); ev.put("done", pct); ev.put("total", 100); ev.put("name", name);
        if (totalB > 0) { ev.put("b", doneB); ev.put("bt", totalB); }
        notifyListeners("opProgress", ev);
    }

    private void putOct(byte[] h, int off, int len, long v) {
        String s = Long.toOctalString(Math.max(0, v));
        while (s.length() < len - 1) s = "0" + s;
        byte[] b = s.getBytes();
        System.arraycopy(b, Math.max(0, b.length - (len - 1)), h, off, Math.min(len - 1, b.length));
        h[off + len - 1] = 0;
    }

    private byte[] tarHdr(byte[] nameBytes, long size, long mtimeSec, char type) {
        byte[] h = new byte[512];
        System.arraycopy(nameBytes, 0, h, 0, Math.min(100, nameBytes.length));
        putOct(h, 100, 8, type == '5' ? 0755 : 0644);
        putOct(h, 108, 8, 0); putOct(h, 116, 8, 0);
        putOct(h, 124, 12, size);
        putOct(h, 136, 12, mtimeSec);
        for (int i = 148; i < 156; i++) h[i] = ' ';
        h[156] = (byte) type;
        h[257] = 'u'; h[258] = 's'; h[259] = 't'; h[260] = 'a'; h[261] = 'r'; h[262] = 0; h[263] = '0'; h[264] = '0';
        long sum = 0; for (byte b : h) sum += b & 0xff;
        putOct(h, 148, 7, sum); h[155] = ' ';
        return h;
    }

    /** Заголовок записи; имя длиннее 100 байт уходит отдельной записью GNU «L» — как пишут обычные архиваторы. */
    private void tarHeader(OutputStream os, String name, long size, long mtimeSec, char type) throws Exception {
        byte[] nb = name.getBytes(java.nio.charset.StandardCharsets.UTF_8);
        if (nb.length > 100) {
            os.write(tarHdr("././@LongLink".getBytes(java.nio.charset.StandardCharsets.UTF_8), nb.length + 1, mtimeSec, 'L'));
            os.write(nb); os.write(0);
            int pad = (int) ((512 - ((nb.length + 1) % 512)) % 512);
            if (pad > 0) os.write(new byte[pad]);
        }
        os.write(tarHdr(nb, size, mtimeSec, type));
    }

    private void tarAdd(OutputStream os, File f, String arcName, byte[] buf, String outName, long totalB, long[] st) throws Exception {
        if (f.isDirectory()) {
            if (YevXfer.isLink(f)) return;   // ссылка-на-папку — не разворачиваем, иначе можно зациклиться
            tarHeader(os, arcName + "/", 0, f.lastModified() / 1000, '5');
            File[] kids = f.listFiles();
            if (kids != null) for (File k : kids) tarAdd(os, k, arcName + "/" + k.getName(), buf, outName, totalB, st);
            return;
        }
        long size = f.length();
        tarHeader(os, arcName, size, f.lastModified() / 1000, '0');
        InputStream in = new FileInputStream(f);
        long wrote = 0;
        try {
            int n;
            while ((n = in.read(buf)) > 0) { os.write(buf, 0, n); wrote += n; st[0] += n; packTick(outName, st[0], totalB, st, false); }
        } finally { try { in.close(); } catch (Exception ignored) {} }
        // размер в заголовке уже записан — добиваем файл нулями, если он усох по ходу
        while (wrote < size) { long need = Math.min(buf.length, size - wrote); os.write(new byte[(int) need]); wrote += need; }
        int pad = (int) ((512 - (size % 512)) % 512);
        if (pad > 0) os.write(new byte[pad]);
    }

    private void sevenAdd(org.apache.commons.compress.archivers.sevenz.SevenZOutputFile z, File f, String arcName, byte[] buf, String outName, long totalB, long[] st) throws Exception {
        if (f.isDirectory()) {
            if (YevXfer.isLink(f)) return;
            org.apache.commons.compress.archivers.sevenz.SevenZArchiveEntry e = z.createArchiveEntry(f, arcName + "/");
            z.putArchiveEntry(e); z.closeArchiveEntry();
            File[] kids = f.listFiles();
            if (kids != null) for (File k : kids) sevenAdd(z, k, arcName + "/" + k.getName(), buf, outName, totalB, st);
            return;
        }
        org.apache.commons.compress.archivers.sevenz.SevenZArchiveEntry e = z.createArchiveEntry(f, arcName);
        z.putArchiveEntry(e);
        InputStream in = new FileInputStream(f);
        try {
            int n;
            while ((n = in.read(buf)) > 0) { z.write(buf, 0, n); st[0] += n; packTick(outName, st[0], totalB, st, false); }
        } finally { try { in.close(); } catch (Exception ignored) {} }
        z.closeArchiveEntry();
    }

    // ===== WebDAV (аккаунты в приватном getFilesDir — data/data, без рута недоступно) =====
    private File wdFile() { return new File(getContext().getFilesDir(), "webdav.json"); }
    private static String wdAuth(String u, String p) { return "Basic " + android.util.Base64.encodeToString((u + ":" + p).getBytes(), android.util.Base64.NO_WRAP); }
    private static void wdMethod(java.net.HttpURLConnection c, String m) {
        try { c.setRequestMethod(m); return; } catch (Exception e) {}
        try {
            Object t = c;
            try { java.lang.reflect.Field d = c.getClass().getDeclaredField("delegate"); d.setAccessible(true); Object dv = d.get(c); if (dv instanceof java.net.HttpURLConnection) t = dv; } catch (Exception ig) {}
            Class<?> k = t.getClass();
            while (k != null) { try { java.lang.reflect.Field mf = k.getDeclaredField("method"); mf.setAccessible(true); mf.set(t, m); return; } catch (Exception ig) { k = k.getSuperclass(); } }
        } catch (Exception e) {}
    }
    @PluginMethod
    public void webdavGetAccounts(PluginCall call) {
        JSObject o = new JSObject();
        try { File f = wdFile(); o.put("json", f.exists() ? new String(readAll(new java.io.FileInputStream(f)), "UTF-8") : "[]"); } catch (Exception e) { o.put("json", "[]"); }
        call.resolve(o);
    }
    @PluginMethod
    public void webdavSetAccounts(PluginCall call) {
        try { java.io.FileOutputStream fo = new java.io.FileOutputStream(wdFile()); fo.write(call.getString("json", "[]").getBytes("UTF-8")); fo.close(); call.resolve(); } catch (Exception e) { call.reject(e.getMessage()); }
    }
    @PluginMethod
    public void webdavList(PluginCall call) {
        try {
            String url = call.getString("url"), user = call.getString("user", ""), pass = call.getString("pass", "");
            java.net.HttpURLConnection c = (java.net.HttpURLConnection) new java.net.URL(url).openConnection();
            wdMethod(c, "PROPFIND");
            c.setRequestProperty("Depth", "1");
            c.setRequestProperty("Authorization", wdAuth(user, pass));
            c.setRequestProperty("Content-Type", "text/xml; charset=utf-8");
            c.setDoOutput(true); c.setConnectTimeout(15000); c.setReadTimeout(20000);
            byte[] body = "<?xml version=\"1.0\"?><d:propfind xmlns:d=\"DAV:\"><d:prop><d:resourcetype/><d:getcontentlength/></d:prop></d:propfind>".getBytes("UTF-8");
            c.getOutputStream().write(body); c.getOutputStream().close();
            int code = c.getResponseCode();
            if (code >= 400) { call.reject("HTTP " + code); return; }
            String xml = new String(readAll(c.getInputStream()), "UTF-8");
            com.getcapacitor.JSArray arr = new com.getcapacitor.JSArray();
            java.net.URL base = new java.net.URL(url);
            java.util.regex.Matcher rm = java.util.regex.Pattern.compile("(?is)<[a-z0-9]*:?response[ >](.*?)</[a-z0-9]*:?response>").matcher(xml);
            boolean first = true;
            while (rm.find()) {
                String blk = rm.group(1);
                java.util.regex.Matcher hm = java.util.regex.Pattern.compile("(?is)<[a-z0-9]*:?href[^>]*>(.*?)</[a-z0-9]*:?href>").matcher(blk);
                if (!hm.find()) continue;
                String href = hm.group(1).trim();
                boolean coll = java.util.regex.Pattern.compile("(?is)<[a-z0-9]*:?collection").matcher(blk).find();
                long size = 0;
                java.util.regex.Matcher sm = java.util.regex.Pattern.compile("(?is)<[a-z0-9]*:?getcontentlength[^>]*>(\\d+)").matcher(blk);
                if (sm.find()) size = Long.parseLong(sm.group(1));
                String full = href.startsWith("http") ? href : new java.net.URL(base, href).toString();
                String dec = java.net.URLDecoder.decode(href, "UTF-8").replaceAll("/+$", "");
                String name = dec.substring(dec.lastIndexOf('/') + 1);
                if (first) { first = false; continue; }
                if (name.isEmpty()) continue;
                JSObject o = new JSObject(); o.put("name", name); o.put("url", full); o.put("type", coll ? "directory" : "file"); o.put("size", size);
                arr.put(o);
            }
            JSObject r = new JSObject(); r.put("files", arr); call.resolve(r);
        } catch (Exception e) { call.reject(e.getMessage()); }
    }
    @PluginMethod
    public void webdavGet(PluginCall call) {
        try {
            String url = call.getString("url"), user = call.getString("user", ""), pass = call.getString("pass", ""), name = call.getString("name", "file"), dest = call.getString("dest", "");
            java.net.HttpURLConnection c = (java.net.HttpURLConnection) new java.net.URL(url).openConnection();
            c.setRequestProperty("Authorization", wdAuth(user, pass));
            c.setConnectTimeout(15000); c.setReadTimeout(30000);
            int code = c.getResponseCode();
            if (code >= 400) { call.reject("HTTP " + code); return; }
            File dl;
            if ("temp".equals(dest)) { File dir = new File(android.os.Environment.getExternalStorageDirectory(), "Download/.yevtmp"); if (!dir.exists()) dir.mkdirs(); dl = new File(dir, name); }
            else dl = new File(android.os.Environment.getExternalStoragePublicDirectory(android.os.Environment.DIRECTORY_DOWNLOADS), name);
            java.io.InputStream in = c.getInputStream(); java.io.FileOutputStream fo = new java.io.FileOutputStream(dl);
            byte[] buf = new byte[8192]; int n; while ((n = in.read(buf)) > 0) fo.write(buf, 0, n);
            fo.close(); in.close();
            JSObject r = new JSObject(); r.put("path", dl.getAbsolutePath()); r.put("uri", "file://" + dl.getAbsolutePath()); call.resolve(r);
        } catch (Exception e) { call.reject(e.getMessage()); }
    }

    // ===== Google Drive (OAuth PKCE, токен в приватном getFilesDir) =====
    private static final String GD_CID = "589335091963-6n9ss077f7htshue4vd288eb2t2jduhb.apps.googleusercontent.com";
    private static final String GD_REDIR = "com.googleusercontent.apps.589335091963-6n9ss077f7htshue4vd288eb2t2jduhb:/oauth";
    private String gdToken, gdRefresh; private long gdExp;
    private File gdFile() { return new File(getContext().getFilesDir(), "gdrive.json"); }
    private void gdLoad() {
        if (gdRefresh != null) return;
        try { File f = gdFile(); if (f.exists()) { org.json.JSONObject o = new org.json.JSONObject(new String(readAll(new java.io.FileInputStream(f)), "UTF-8")); gdToken = o.optString("access", null); gdRefresh = o.optString("refresh", null); gdExp = o.optLong("exp", 0); } } catch (Exception e) {}
    }
    private void gdSave() { try { org.json.JSONObject o = new org.json.JSONObject(); o.put("access", gdToken); o.put("refresh", gdRefresh); o.put("exp", gdExp); java.io.FileOutputStream fo = new java.io.FileOutputStream(gdFile()); fo.write(o.toString().getBytes("UTF-8")); fo.close(); } catch (Exception e) {} }
    private String httpPostForm(String url, String body) throws Exception {
        java.net.HttpURLConnection c = (java.net.HttpURLConnection) new java.net.URL(url).openConnection();
        c.setRequestMethod("POST"); c.setDoOutput(true); c.setRequestProperty("Content-Type", "application/x-www-form-urlencoded"); c.setConnectTimeout(15000); c.setReadTimeout(20000);
        c.getOutputStream().write(body.getBytes("UTF-8")); c.getOutputStream().close();
        int code = c.getResponseCode();
        String r = new String(readAll(code >= 400 ? c.getErrorStream() : c.getInputStream()), "UTF-8");
        if (code >= 400) throw new Exception(r);
        return r;
    }
    private void gdEnsure() throws Exception {
        gdLoad();
        if (gdToken != null && System.currentTimeMillis() < gdExp - 60000) return;
        if (gdRefresh == null) throw new Exception("not_authed");
        String body = "client_id=" + java.net.URLEncoder.encode(GD_CID, "UTF-8") + "&grant_type=refresh_token&refresh_token=" + java.net.URLEncoder.encode(gdRefresh, "UTF-8");
        org.json.JSONObject o = new org.json.JSONObject(httpPostForm("https://oauth2.googleapis.com/token", body));
        gdToken = o.getString("access_token"); gdExp = System.currentTimeMillis() + o.optLong("expires_in", 3600) * 1000; gdSave();
    }
    private String httpGetAuth(String url) throws Exception {
        gdEnsure();
        java.net.HttpURLConnection c = (java.net.HttpURLConnection) new java.net.URL(url).openConnection();
        c.setRequestProperty("Authorization", "Bearer " + gdToken); c.setConnectTimeout(15000); c.setReadTimeout(20000);
        int code = c.getResponseCode();
        String r = new String(readAll(code >= 400 ? c.getErrorStream() : c.getInputStream()), "UTF-8");
        if (code >= 400) throw new Exception(r);
        return r;
    }
    /** Запрос к Диску с телом (PATCH/POST) и ответом строкой. */
    private String httpJsonAuth(String url, String method, String body) throws Exception {
        gdEnsure();
        java.net.HttpURLConnection c = (java.net.HttpURLConnection) new java.net.URL(url).openConnection();
        c.setRequestMethod("POST");
        if (!"POST".equals(method)) c.setRequestProperty("X-HTTP-Method-Override", method);   // PATCH ходит так
        c.setDoOutput(true);
        c.setRequestProperty("Authorization", "Bearer " + gdToken);
        c.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
        c.setConnectTimeout(15000); c.setReadTimeout(30000);
        OutputStream os = c.getOutputStream();
        os.write((body == null ? "{}" : body).getBytes("UTF-8"));
        os.close();
        int code = c.getResponseCode();
        String r = new String(readAll(code >= 400 ? c.getErrorStream() : c.getInputStream()), "UTF-8");
        if (code >= 400) throw new Exception(r);
        return r;
    }

    @PluginMethod
    public void openExternalUrl(PluginCall call) {
        try { Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(call.getString("url"))); i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); getContext().startActivity(i); call.resolve(); } catch (Exception e) { call.reject(e.getMessage()); }
    }
    @PluginMethod
    public void oauthConsume(PluginCall call) { JSObject o = new JSObject(); o.put("code", MainActivity.oauthCode); MainActivity.oauthCode = null; call.resolve(o); }
    @PluginMethod
    public void gdriveToken(PluginCall call) {
        try {
            String code = call.getString("code"), verifier = call.getString("verifier");
            String body = "client_id=" + java.net.URLEncoder.encode(GD_CID, "UTF-8") + "&code=" + java.net.URLEncoder.encode(code, "UTF-8") + "&code_verifier=" + java.net.URLEncoder.encode(verifier, "UTF-8") + "&grant_type=authorization_code&redirect_uri=" + java.net.URLEncoder.encode(GD_REDIR, "UTF-8");
            org.json.JSONObject o = new org.json.JSONObject(httpPostForm("https://oauth2.googleapis.com/token", body));
            gdToken = o.getString("access_token"); gdRefresh = o.optString("refresh_token", gdRefresh); gdExp = System.currentTimeMillis() + o.optLong("expires_in", 3600) * 1000; gdSave();
            JSObject r = new JSObject(); r.put("ok", true); call.resolve(r);
        } catch (Exception e) { call.reject(e.getMessage()); }
    }
    @PluginMethod
    public void gdriveLoggedIn(PluginCall call) { gdLoad(); JSObject o = new JSObject(); o.put("yes", gdRefresh != null); call.resolve(o); }
    @PluginMethod
    public void gdriveLogout(PluginCall call) { gdToken = null; gdRefresh = null; gdExp = 0; try { gdFile().delete(); } catch (Exception e) {} call.resolve(); }
    @PluginMethod
    public void gdriveDelete(PluginCall call) {
        String id = call.getString("id");
        if (id == null) { call.reject("no id"); return; }
        try {
            gdEnsure();
            java.net.HttpURLConnection c = (java.net.HttpURLConnection) new java.net.URL("https://www.googleapis.com/drive/v3/files/" + java.net.URLEncoder.encode(id, "UTF-8")).openConnection();
            c.setRequestMethod("DELETE");
            c.setRequestProperty("Authorization", "Bearer " + gdToken);
            c.setConnectTimeout(15000); c.setReadTimeout(20000);
            int code = c.getResponseCode();
            if (code >= 400) {
                String r = new String(readAll(c.getErrorStream()), "UTF-8");
                call.reject(r); return;
            }
            JSObject ret = new JSObject(); ret.put("ok", true); call.resolve(ret);
        } catch (Exception e) { call.reject(e.getMessage()); }
    }

    @PluginMethod
    public void gdriveMkdir(PluginCall call) {
        try {
            String parent = call.getString("folder", "root");
            String name = call.getString("name", "Новая папка");
            gdEnsure();
            java.net.HttpURLConnection c = (java.net.HttpURLConnection) new java.net.URL("https://www.googleapis.com/drive/v3/files?fields=id,name,mimeType").openConnection();
            c.setRequestMethod("POST");
            c.setRequestProperty("Authorization", "Bearer " + gdToken);
            c.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
            c.setConnectTimeout(15000); c.setReadTimeout(20000); c.setDoOutput(true);
            org.json.JSONObject body = new org.json.JSONObject();
            body.put("name", name);
            body.put("mimeType", "application/vnd.google-apps.folder");
            body.put("parents", new org.json.JSONArray().put(parent));
            OutputStream os = c.getOutputStream(); os.write(body.toString().getBytes("UTF-8")); os.close();
            int code = c.getResponseCode();
            String r = new String(readAll(code >= 400 ? c.getErrorStream() : c.getInputStream()), "UTF-8");
            if (code >= 400) { call.reject(r); return; }
            org.json.JSONObject f = new org.json.JSONObject(r);
            JSObject ret = new JSObject(); ret.put("id", f.optString("id")); ret.put("name", f.optString("name"));
            call.resolve(ret);
        } catch (Exception e) { call.reject(e.getMessage()); }
    }

    @PluginMethod
    public void gdriveThumb(PluginCall call) {
        String id = call.getString("id");
        String link = call.getString("link");
        int want = call.getInt("size", 0) == null ? 0 : call.getInt("size", 0);
        // Диск отдаёт превью любого размера: в ссылке достаточно поменять «=s220»
        if (link != null && want > 0) link = link.replaceAll("=s\\d+", "=s" + want);
        if (id == null || link == null) { call.reject("no args"); return; }
        try {
            File cf = new File(thumbDir(), "gd_" + Integer.toHexString(id.hashCode()) + (want > 400 ? "_b" : "") + ".t");
            if (cf.exists() && cf.length() > 0) {
                byte[] b = new byte[(int) cf.length()];
                InputStream in = new FileInputStream(cf); int off = 0; while (off < b.length) { int r = in.read(b, off, b.length - off); if (r < 0) break; off += r; } in.close();
                JSObject ret = new JSObject(); ret.put("thumb", "data:image/jpeg;base64," + android.util.Base64.encodeToString(b, android.util.Base64.NO_WRAP)); call.resolve(ret); return;
            }
            gdEnsure();
            java.net.HttpURLConnection c = (java.net.HttpURLConnection) new java.net.URL(link).openConnection();
            c.setRequestProperty("Authorization", "Bearer " + gdToken);
            c.setConnectTimeout(15000); c.setReadTimeout(20000); c.setInstanceFollowRedirects(true);
            int code = c.getResponseCode();
            byte[] b = readAll(code >= 400 ? c.getErrorStream() : c.getInputStream());
            if (code >= 400) { call.reject("thumb " + code); return; }
            try { OutputStream os = new FileOutputStream(cf); os.write(b); os.close(); } catch (Exception ignored) {}
            JSObject ret = new JSObject(); ret.put("thumb", "data:image/jpeg;base64," + android.util.Base64.encodeToString(b, android.util.Base64.NO_WRAP));
            call.resolve(ret);
        } catch (Exception e) { call.reject(e.getMessage()); }
    }

    /** Поля, которые просим у Диска: дата, хеш, ярлыки, общий доступ. */
    private static final String GD_FIELDS =
            "files(id,name,mimeType,size,modifiedTime,md5Checksum,parents,shared,starred,trashed,shortcutDetails,thumbnailLink),nextPageToken";

    private static long gdTime(String iso) {
        if (iso == null || iso.isEmpty()) return 0;
        try {
            java.text.SimpleDateFormat f = new java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", java.util.Locale.US);
            f.setTimeZone(java.util.TimeZone.getTimeZone("UTC"));
            return f.parse(iso.length() > 19 ? iso.substring(0, 19) : iso).getTime();
        } catch (Throwable t) { return 0; }
    }

    private static String gdIso(long ms) {
        java.text.SimpleDateFormat f = new java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", java.util.Locale.US);
        f.setTimeZone(java.util.TimeZone.getTimeZone("UTC"));
        return f.format(new java.util.Date(ms));
    }

    /** Одна запись Диска в наш вид; ярлык подменяется тем, на что он указывает. */
    private JSObject gdEntry(org.json.JSONObject f) {
        String mime = f.optString("mimeType");
        String id = f.optString("id");
        org.json.JSONObject sc = f.optJSONObject("shortcutDetails");
        if (sc != null) {                                   // ярлык Диска — показываем настоящую цель
            String tid = sc.optString("targetId", null);
            String tmime = sc.optString("targetMimeType", null);
            if (tid != null && !tid.isEmpty()) { id = tid; if (tmime != null && !tmime.isEmpty()) mime = tmime; }
        }
        boolean dir = "application/vnd.google-apps.folder".equals(mime);
        JSObject e = new JSObject();
        e.put("id", id);
        e.put("name", f.optString("name"));
        e.put("type", dir ? "directory" : "file");
        e.put("size", f.optLong("size", 0));
        e.put("mime", mime);
        e.put("mtime", gdTime(f.optString("modifiedTime", null)));
        String md5 = f.optString("md5Checksum", null);
        if (md5 != null && !md5.isEmpty()) e.put("md5", md5);
        if (f.optBoolean("shared", false)) e.put("shared", true);
        if (f.optBoolean("starred", false)) e.put("starred", true);
        if (sc != null) e.put("shortcut", true);
        String tl = f.optString("thumbnailLink", null);
        if (tl != null && !tl.isEmpty()) e.put("thumb", tl);
        return e;
    }

    @PluginMethod
    public void gdriveList(PluginCall call) {
        try {
            String folder = call.getString("folder", "root");
            String section = call.getString("section", "");     // "", trash, starred, shared, drives
            com.getcapacitor.JSArray arr = new com.getcapacitor.JSArray();

            if ("drives".equals(section)) {                     // общие диски
                String u = "https://www.googleapis.com/drive/v3/drives?fields=" + java.net.URLEncoder.encode("drives(id,name),nextPageToken", "UTF-8") + "&pageSize=100";
                String token = null;
                do {
                    org.json.JSONObject o = new org.json.JSONObject(httpGetAuth(u + (token == null ? "" : "&pageToken=" + token)));
                    org.json.JSONArray ds = o.optJSONArray("drives");
                    if (ds != null) for (int i = 0; i < ds.length(); i++) {
                        org.json.JSONObject d = ds.getJSONObject(i);
                        JSObject e = new JSObject();
                        e.put("id", d.optString("id")); e.put("name", d.optString("name"));
                        e.put("type", "directory"); e.put("size", 0); e.put("mime", "application/vnd.google-apps.folder");
                        arr.put(e);
                    }
                    token = o.optString("nextPageToken", null);
                    if (token != null && token.isEmpty()) token = null;
                } while (token != null);
                JSObject r = new JSObject(); r.put("files", arr); call.resolve(r); return;
            }

            String qs;
            if ("trash".equals(section)) qs = "trashed=true";
            else if ("starred".equals(section)) qs = "starred=true and trashed=false";
            else if ("shared".equals(section)) qs = "sharedWithMe=true and trashed=false";
            else qs = "'" + folder + "' in parents and trashed=false";

            String base = "https://www.googleapis.com/drive/v3/files?q=" + java.net.URLEncoder.encode(qs, "UTF-8")
                    + "&fields=" + java.net.URLEncoder.encode(GD_FIELDS, "UTF-8")
                    + "&pageSize=1000&orderBy=folder,name"
                    + "&supportsAllDrives=true&includeItemsFromAllDrives=true&corpora=allDrives";
            String token = null;
            do {
                org.json.JSONObject o = new org.json.JSONObject(httpGetAuth(base + (token == null ? "" : "&pageToken=" + token)));
                org.json.JSONArray files = o.optJSONArray("files");
                if (files != null) for (int i = 0; i < files.length(); i++) arr.put(gdEntry(files.getJSONObject(i)));
                token = o.optString("nextPageToken", null);
                if (token != null && token.isEmpty()) token = null;
            } while (token != null);                            // длинные папки дочитываем до конца

            JSObject r = new JSObject(); r.put("files", arr); call.resolve(r);
        } catch (Exception e) { call.reject(e.getMessage()); }
    }
    /**
     * Загрузка на Диск. Мелкое отправляем одним куском, крупное — по частям,
     * чтобы обрыв связи не сбрасывал всё в начало.
     */
    @PluginMethod
    public void gdrivePut(final PluginCall call) {
        new Thread(() -> {
            try {
                gdEnsure();
                File src = toFile(call.getString("uri"));
                if (!src.isFile()) { call.reject("Файл не найден"); return; }
                String parent = call.getString("folder", "root");
                String name = call.getString("name", src.getName());
                String mime = call.getString("mime", "application/octet-stream");
                long total = src.length();

                org.json.JSONObject meta = new org.json.JSONObject();
                meta.put("name", name);
                meta.put("modifiedTime", gdIso(src.lastModified()));
                org.json.JSONArray par = new org.json.JSONArray(); par.put(parent);
                meta.put("parents", par);

                if (total <= 5 * 1024 * 1024) {                       // мелочь — одним куском
                    String boundary = "yev" + System.currentTimeMillis();
                    java.net.HttpURLConnection c = (java.net.HttpURLConnection) new java.net.URL(
                            "https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart&supportsAllDrives=true&fields=id,name,size,modifiedTime").openConnection();
                    c.setRequestMethod("POST");
                    c.setDoOutput(true);
                    c.setRequestProperty("Authorization", "Bearer " + gdToken);
                    c.setRequestProperty("Content-Type", "multipart/related; boundary=" + boundary);
                    OutputStream os = c.getOutputStream();
                    os.write(("--" + boundary + "\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n" + meta + "\r\n").getBytes("UTF-8"));
                    os.write(("--" + boundary + "\r\nContent-Type: " + mime + "\r\n\r\n").getBytes("UTF-8"));
                    InputStream in = new FileInputStream(src);
                    byte[] buf = new byte[262144]; int n; long done = 0;
                    while ((n = in.read(buf)) > 0) { os.write(buf, 0, n); done += n; gdProgress(name, done, total); }
                    in.close();
                    os.write(("\r\n--" + boundary + "--\r\n").getBytes("UTF-8"));
                    os.close();
                    int code = c.getResponseCode();
                    String body = new String(readAll(code >= 400 ? c.getErrorStream() : c.getInputStream()), "UTF-8");
                    if (code >= 400) { call.reject("Диск: " + code + " " + body); return; }
                    JSObject r = new JSObject(); r.put("ok", true); r.put("id", new org.json.JSONObject(body).optString("id"));
                    call.resolve(r); return;
                }

                // крупное: сперва просим адрес для загрузки, потом шлём кусками
                java.net.HttpURLConnection st = (java.net.HttpURLConnection) new java.net.URL(
                        "https://www.googleapis.com/upload/drive/v3/files?uploadType=resumable&supportsAllDrives=true&fields=id,name,size").openConnection();
                st.setRequestMethod("POST");
                st.setDoOutput(true);
                st.setRequestProperty("Authorization", "Bearer " + gdToken);
                st.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
                st.setRequestProperty("X-Upload-Content-Type", mime);
                st.setRequestProperty("X-Upload-Content-Length", String.valueOf(total));
                OutputStream so = st.getOutputStream(); so.write(meta.toString().getBytes("UTF-8")); so.close();
                int sc = st.getResponseCode();
                if (sc >= 400) { call.reject("Диск: " + sc + " " + new String(readAll(st.getErrorStream()), "UTF-8")); return; }
                String session = st.getHeaderField("Location");
                if (session == null) { call.reject("Диск не дал адрес для загрузки"); return; }

                final int CHUNK = 8 * 1024 * 1024;                    // 8 МБ за раз
                long sent = 0;
                java.io.RandomAccessFile raf = new java.io.RandomAccessFile(src, "r");
                try {
                    while (sent < total) {
                        int part = (int) Math.min(CHUNK, total - sent);
                        byte[] chunk = new byte[part];
                        raf.seek(sent);
                        raf.readFully(chunk);
                        int tries = 0;
                        while (true) {
                            tries++;
                            java.net.HttpURLConnection u = (java.net.HttpURLConnection) new java.net.URL(session).openConnection();
                            u.setRequestMethod("PUT");
                            u.setDoOutput(true);
                            u.setFixedLengthStreamingMode(part);
                            u.setRequestProperty("Content-Range", "bytes " + sent + "-" + (sent + part - 1) + "/" + total);
                            OutputStream uo = u.getOutputStream(); uo.write(chunk); uo.close();
                            int uc = u.getResponseCode();
                            if (uc == 308) {                           // кусок принят, ждём следующий
                                String range = u.getHeaderField("Range");
                                if (range != null && range.contains("-")) {
                                    try { sent = Long.parseLong(range.substring(range.lastIndexOf('-') + 1)) + 1; }
                                    catch (Throwable t) { sent += part; }
                                } else sent += part;
                                break;
                            }
                            if (uc >= 200 && uc < 300) {               // последний кусок — готово
                                sent = total;
                                String body = new String(readAll(u.getInputStream()), "UTF-8");
                                JSObject r = new JSObject(); r.put("ok", true); r.put("id", new org.json.JSONObject(body).optString("id"));
                                gdProgress(name, total, total);
                                call.resolve(r); return;
                            }
                            if (tries >= 3) { call.reject("Диск: " + uc + " " + new String(readAll(u.getErrorStream()), "UTF-8")); return; }
                            try { Thread.sleep(1000L * tries); } catch (InterruptedException ie) { call.reject("прервано"); return; }
                        }
                        gdProgress(name, sent, total);
                    }
                } finally { try { raf.close(); } catch (Throwable ignored) {} }
                JSObject r = new JSObject(); r.put("ok", true); call.resolve(r);
            } catch (Exception e) { call.reject(e.getMessage()); }
        }).start();
    }

    private void gdProgress(String name, long done, long total) {
        JSObject ev = new JSObject();
        ev.put("name", name); ev.put("done", done); ev.put("total", total);
        notifyListeners("gdProgress", ev);
    }

    /** Перенос и переименование на Диске — одним запросом, без скачивания. */
    @PluginMethod
    public void gdriveMove(PluginCall call) {
        try {
            gdEnsure();
            String id = call.getString("id");
            String name = call.getString("name", null);
            String addParent = call.getString("addParent", null);
            String removeParent = call.getString("removeParent", null);
            StringBuilder u = new StringBuilder("https://www.googleapis.com/drive/v3/files/" + id + "?supportsAllDrives=true&fields=id,name");
            if (addParent != null && !addParent.isEmpty()) u.append("&addParents=").append(addParent);
            if (removeParent != null && !removeParent.isEmpty()) u.append("&removeParents=").append(removeParent);
            org.json.JSONObject body = new org.json.JSONObject();
            if (name != null && !name.isEmpty()) body.put("name", name);
            String res = httpJsonAuth(u.toString(), "PATCH", body.toString());
            JSObject r = new JSObject(); r.put("ok", true); r.put("id", new org.json.JSONObject(res).optString("id"));
            call.resolve(r);
        } catch (Exception e) { call.reject(e.getMessage()); }
    }

    /** Копирование внутри Диска — силами самого Диска. */
    @PluginMethod
    public void gdriveCopy(PluginCall call) {
        try {
            gdEnsure();
            String id = call.getString("id");
            String parent = call.getString("folder", null);
            String name = call.getString("name", null);
            org.json.JSONObject body = new org.json.JSONObject();
            if (name != null && !name.isEmpty()) body.put("name", name);
            if (parent != null && !parent.isEmpty()) { org.json.JSONArray p = new org.json.JSONArray(); p.put(parent); body.put("parents", p); }
            String res = httpJsonAuth("https://www.googleapis.com/drive/v3/files/" + id + "/copy?supportsAllDrives=true&fields=id,name", "POST", body.toString());
            JSObject r = new JSObject(); r.put("ok", true); r.put("id", new org.json.JSONObject(res).optString("id"));
            call.resolve(r);
        } catch (Exception e) { call.reject(e.getMessage()); }
    }

    /** Сколько места занято на Диске. */
    @PluginMethod
    public void gdriveQuota(PluginCall call) {
        try {
            org.json.JSONObject o = new org.json.JSONObject(httpGetAuth(
                    "https://www.googleapis.com/drive/v3/about?fields=" + java.net.URLEncoder.encode("storageQuota(limit,usage)", "UTF-8")));
            org.json.JSONObject q = o.optJSONObject("storageQuota");
            JSObject r = new JSObject();
            r.put("used", q == null ? 0 : q.optLong("usage", 0));
            r.put("total", q == null ? 0 : q.optLong("limit", 0));
            call.resolve(r);
        } catch (Exception e) { call.reject(e.getMessage()); }
    }

    @PluginMethod
    public void gdriveGet(final PluginCall call) {
        new Thread(() -> {
        try {
            gdEnsure();
            String id = call.getString("id"), name = call.getString("name", "file"), mime = call.getString("mime", ""), dest = call.getString("dest", "");
            boolean gdoc = mime.startsWith("application/vnd.google-apps");
            // документ Google выгружаем в тот вид, который попросили; по умолчанию — по типу документа
            String as = call.getString("exportAs", null);
            if (gdoc && (as == null || as.isEmpty())) {
                as = mime.endsWith(".spreadsheet") ? "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                        : mime.endsWith(".presentation") ? "application/vnd.openxmlformats-officedocument.presentationml.presentation"
                        : mime.endsWith(".drawing") ? "image/png"
                        : "application/vnd.openxmlformats-officedocument.wordprocessingml.document";
            }
            String url = gdoc
                    ? "https://www.googleapis.com/drive/v3/files/" + id + "/export?mimeType=" + java.net.URLEncoder.encode(as, "UTF-8")
                    : "https://www.googleapis.com/drive/v3/files/" + id + "?alt=media&acknowledgeAbuse=true&supportsAllDrives=true";
            java.net.HttpURLConnection c = (java.net.HttpURLConnection) new java.net.URL(url).openConnection();
            c.setRequestProperty("Authorization", "Bearer " + gdToken); c.setConnectTimeout(15000); c.setReadTimeout(60000);
            int code = c.getResponseCode(); if (code >= 400) { call.reject("HTTP " + code); return; }
            if (gdoc) {                                        // расширение — под выбранный вид выгрузки
                String ext = as.contains("spreadsheetml") ? ".xlsx" : as.contains("presentationml") ? ".pptx"
                        : as.contains("wordprocessingml") ? ".docx" : as.contains("pdf") ? ".pdf"
                        : as.startsWith("image/png") ? ".png" : as.startsWith("text/plain") ? ".txt" : "";
                if (!ext.isEmpty() && !name.toLowerCase().endsWith(ext)) name = name + ext;
            }
            File dl;
            if ("temp".equals(dest)) { File dir = new File(android.os.Environment.getExternalStorageDirectory(), "Download/.yevtmp"); if (!dir.exists()) dir.mkdirs(); dl = new File(dir, name); }
            else dl = new File(android.os.Environment.getExternalStoragePublicDirectory(android.os.Environment.DIRECTORY_DOWNLOADS), name);
            long full = c.getContentLength();                       // сколько всего качать
            java.io.InputStream in = c.getInputStream(); java.io.FileOutputStream fo = new java.io.FileOutputStream(dl);
            byte[] buf = new byte[262144]; int n; long done = 0; long lastTick = 0;
            while ((n = in.read(buf)) > 0) {
                fo.write(buf, 0, n); done += n;
                long now = System.currentTimeMillis();
                if (now - lastTick > 150) { lastTick = now; gdProgress(name, done, full); }   // ход видно в окне
            }
            fo.close(); in.close();
            gdProgress(name, done, full > 0 ? full : done);
            JSObject r = new JSObject(); r.put("path", dl.getAbsolutePath()); r.put("uri", "file://" + dl.getAbsolutePath()); r.put("name", name); call.resolve(r);
        } catch (Exception e) { call.reject(e.getMessage()); }
        }).start();
    }

    private org.json.JSONObject gdJson(String url) throws Exception {
        java.net.HttpURLConnection c = (java.net.HttpURLConnection) new java.net.URL(url).openConnection();
        c.setRequestProperty("Authorization", "Bearer " + gdToken); c.setConnectTimeout(15000); c.setReadTimeout(30000);
        int code = c.getResponseCode();
        java.io.InputStream is = code >= 400 ? c.getErrorStream() : c.getInputStream();
        String body = new String(readAll(is), "UTF-8");
        if (code >= 400) throw new Exception("HTTP " + code);
        return new org.json.JSONObject(body);
    }

    @PluginMethod
    public void gdriveChanges(PluginCall call) {
        try {
            gdEnsure();
            String token = call.getString("token", "");
            JSObject res = new JSObject();
            if (token == null || token.isEmpty()) {
                org.json.JSONObject o = gdJson("https://www.googleapis.com/drive/v3/changes/startPageToken");
                res.put("changed", false); res.put("token", o.optString("startPageToken", "")); call.resolve(res); return;
            }
            boolean changed = false; String page = token, next = token;
            for (int guard = 0; guard < 50 && page != null && !page.isEmpty(); guard++) {
                org.json.JSONObject o = gdJson("https://www.googleapis.com/drive/v3/changes?pageToken=" + page + "&pageSize=200&fields=newStartPageToken,nextPageToken,changes(fileId)");
                org.json.JSONArray ch = o.optJSONArray("changes");
                if (ch != null && ch.length() > 0) changed = true;
                String np = o.optString("nextPageToken", "");
                if (!np.isEmpty()) page = np;
                else { next = o.optString("newStartPageToken", token); page = null; }
            }
            res.put("changed", changed); res.put("token", next); call.resolve(res);
        } catch (Exception e) { call.reject(e.getMessage()); }
    }

    @PluginMethod
    public void openUrl(PluginCall call) {
        String url = call.getString("url");
        String mime = call.getString("mime", "*/*");
        if (url == null) { call.reject("no url"); return; }
        try {
            Uri data = Uri.parse(url);
            Intent i = new Intent(Intent.ACTION_VIEW);
            if (mime != null && !mime.isEmpty()) i.setDataAndType(data, mime); else i.setData(data);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            Intent chooser = Intent.createChooser(i, "Открыть");
            chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            getContext().startActivity(chooser);
            call.resolve();
        } catch (Exception e) { call.reject(e.getMessage()); }
    }

    @PluginMethod
    public void gdriveLink(PluginCall call) {
        try {
            gdEnsure();
            String id = call.getString("id");
            String url = "https://www.googleapis.com/drive/v3/files/" + id + "?alt=media&acknowledgeAbuse=true&access_token=" + gdToken;
            JSObject r = new JSObject(); r.put("url", url); call.resolve(r);
        } catch (Exception e) { call.reject(e.getMessage()); }
    }

    @PluginMethod
    public void copyText(PluginCall call) {
        try {
            String text = call.getString("text", "");
            android.content.ClipboardManager cm = (android.content.ClipboardManager) getContext().getSystemService(android.content.Context.CLIPBOARD_SERVICE);
            cm.setPrimaryClip(android.content.ClipData.newPlainText("text", text));
            call.resolve();
        } catch (Exception e) { call.reject(e.getMessage()); }
    }

    @PluginMethod
    public void pathSize(final PluginCall call) {
        String uriStr = call.getString("uri");
        if (uriStr == null) { call.reject("no uri"); return; }
        final File root = toFile(uriStr);
        new Thread(new Runnable() {
            public void run() {
                final long[] acc = { 0L, 0L };
                boolean fast = false;
                if (Build.VERSION.SDK_INT >= 26) {
                    // системный обход: атрибуты берём из самого обхода, а не отдельными запросами на каждый файл
                    try {
                        java.nio.file.Files.walkFileTree(root.toPath(), new java.nio.file.SimpleFileVisitor<java.nio.file.Path>() {
                            @Override public java.nio.file.FileVisitResult visitFile(java.nio.file.Path p, java.nio.file.attribute.BasicFileAttributes a) {
                                acc[0] += a.size(); acc[1]++; return java.nio.file.FileVisitResult.CONTINUE;
                            }
                            @Override public java.nio.file.FileVisitResult visitFileFailed(java.nio.file.Path p, java.io.IOException e) { return java.nio.file.FileVisitResult.CONTINUE; }
                        });
                        fast = true;
                    } catch (Throwable ignored) { acc[0] = 0; acc[1] = 0; }
                }
                if (!fast) sizeRecursive(root, acc);
                try { getActivity().runOnUiThread(new Runnable() { public void run() {
                    JSObject r = new JSObject(); r.put("bytes", acc[0]); r.put("count", acc[1]); call.resolve(r);
                } }); } catch (Exception e) { JSObject r = new JSObject(); r.put("bytes", acc[0]); r.put("count", acc[1]); call.resolve(r); }
            }
        }).start();
    }

    private void sizeRecursive(File f, long[] acc) {
        try {
            if (f.isDirectory()) {
                File[] kids = f.listFiles();
                if (kids != null) for (File k : kids) sizeRecursive(k, acc);
            } else { acc[0] += f.length(); acc[1]++; }
        } catch (Exception ignored) {}
    }

    @PluginMethod
    public void deletePath(final PluginCall call) {
        String uriStr = call.getString("uri");
        if (uriStr == null) { call.reject("no uri"); return; }
        final File root = toFile(uriStr);
        new Thread(new Runnable() {
            public void run() {
                delDone = 0; delLastEv = 0;
                delTotal = root.isDirectory() ? delCount(root) : 1;
                final boolean ok;
                if (Build.VERSION.SDK_INT >= 26) ok = deleteNio(root);
                else ok = deleteRecursiveCounted(root);
                try { getActivity().runOnUiThread(new Runnable() { public void run() {
                    JSObject r = new JSObject(); r.put("ok", ok); call.resolve(r);
                } }); } catch (Exception e) { JSObject r = new JSObject(); r.put("ok", ok); call.resolve(r); }
            }
        }).start();
    }

    private long delDone = 0, delTotal = 0, delLastEv = 0;

    private long delCount(File f) {
        if (Build.VERSION.SDK_INT >= 26) {
            // системный обход дерева: заметно быстрее на папках с тысячами мелких файлов
            try {
                final long[] n = { 0 };
                java.nio.file.Files.walkFileTree(f.toPath(), new java.nio.file.SimpleFileVisitor<java.nio.file.Path>() {
                    @Override public java.nio.file.FileVisitResult visitFile(java.nio.file.Path p, java.nio.file.attribute.BasicFileAttributes a) { n[0]++; return java.nio.file.FileVisitResult.CONTINUE; }
                    @Override public java.nio.file.FileVisitResult postVisitDirectory(java.nio.file.Path p, java.io.IOException e) { n[0]++; return java.nio.file.FileVisitResult.CONTINUE; }
                    @Override public java.nio.file.FileVisitResult visitFileFailed(java.nio.file.Path p, java.io.IOException e) { n[0]++; return java.nio.file.FileVisitResult.CONTINUE; }
                });
                return Math.max(1, n[0]);
            } catch (Throwable ignored) {}
        }
        long n = 1;
        if (f.isDirectory()) { String[] k = f.list(); if (k != null) for (String x : k) n += delCount(new File(f, x)); }
        return n;
    }

    private void delTick(String name) {
        delDone++;
        long now = System.currentTimeMillis();
        if (now - delLastEv >= 90 || delDone >= delTotal) {
            delLastEv = now;
            JSObject ev = new JSObject();
            ev.put("done", (int) Math.min(2147483647L, delDone));
            ev.put("total", (int) Math.min(2147483647L, delTotal));
            ev.put("name", name != null ? name : "");
            notifyListeners("opProgress", ev);
        }
    }

    private boolean deleteRecursiveCounted(File f) {
        if (f.isDirectory()) {
            File[] kids = f.listFiles();
            if (kids != null) for (File k : kids) deleteRecursiveCounted(k);
        }
        boolean ok = f.delete();
        delTick(f.getName());
        return ok;
    }

    // мелкие файлы пачками быстрее через nio: меньше объектов, один системный обход
    private boolean deleteNio(File root) {
        try {
            java.nio.file.Files.walkFileTree(root.toPath(), new java.nio.file.SimpleFileVisitor<java.nio.file.Path>() {
                @Override public java.nio.file.FileVisitResult visitFile(java.nio.file.Path file, java.nio.file.attribute.BasicFileAttributes attrs) {
                    try { java.nio.file.Files.delete(file); } catch (Exception ignored) {}
                    delTick(file.getFileName() != null ? file.getFileName().toString() : "");
                    return java.nio.file.FileVisitResult.CONTINUE;
                }
                @Override public java.nio.file.FileVisitResult postVisitDirectory(java.nio.file.Path dir, java.io.IOException exc) {
                    try { java.nio.file.Files.delete(dir); } catch (Exception ignored) {}
                    delTick(dir.getFileName() != null ? dir.getFileName().toString() : "");
                    return java.nio.file.FileVisitResult.CONTINUE;
                }
                @Override public java.nio.file.FileVisitResult visitFileFailed(java.nio.file.Path file, java.io.IOException exc) {
                    return java.nio.file.FileVisitResult.CONTINUE;
                }
            });
        } catch (Exception ignored) {}
        return !root.exists();
    }

    @PluginMethod
    public void share(PluginCall call) {
        String uriStr = call.getString("uri");
        String mime = call.getString("mime", "*/*");
        if (uriStr == null) { call.reject("no uri"); return; }
        try {
            File f = toFile(uriStr);
            if (!f.exists()) { call.reject("Файл не найден"); return; }
            try { StrictMode.setVmPolicy(new StrictMode.VmPolicy.Builder().build()); } catch (Exception ignored) {}
            Intent i = new Intent(Intent.ACTION_SEND);
            i.setType(mime);
            i.putExtra(Intent.EXTRA_STREAM, contentUriFor(f));
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            Intent ch = Intent.createChooser(i, "Поделиться");
            ch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            getContext().startActivity(ch);
            call.resolve();
        } catch (Exception e) { call.reject(e.getMessage()); }
    }

    /** Открыть родной просмотрщик снимков: без веб-части, поэтому ничего не мерцает. */
    @PluginMethod
    public void viewPhotos(PluginCall call) {
        try {
            JSArray a = call.getArray("uris");
            JSArray nm = call.getArray("names");
            java.util.List<String> list = new java.util.ArrayList<>();
            java.util.List<String> names = new java.util.ArrayList<>();
            if (a != null) for (Object o : a.toList()) {
                String u = String.valueOf(o);
                if (u.startsWith("gd:") || u.startsWith("arc:")) { list.add(u); continue; }   // облако и архив — потоком
                File f = toFile(u);
                if (f != null) list.add(f.getAbsolutePath());
            }
            if (nm != null) for (Object o : nm.toList()) names.add(String.valueOf(o));
            if (list.isEmpty()) { call.reject("нет снимков"); return; }
            // откуда брать байты для несуществующих на диске снимков
            PhotoActivity.streamer = key -> {
                if (key.startsWith("gd:")) return gdriveStream(key.substring(3));
                if (key.startsWith("arc:")) {
                    int bar = key.indexOf('|');
                    if (bar < 0) return null;
                    return arcEntryStream(key.substring(4, bar), key.substring(bar + 1));
                }
                return null;
            };
            int idx = call.getInt("index", 0) == null ? 0 : call.getInt("index", 0);
            Intent i = new Intent(getContext(), PhotoActivity.class);
            i.putExtra(PhotoActivity.EXTRA_LIST, list.toArray(new String[0]));
            if (!names.isEmpty()) i.putExtra(PhotoActivity.EXTRA_NAMES, names.toArray(new String[0]));
            i.putExtra(PhotoActivity.EXTRA_INDEX, idx);
            i.putExtra(PhotoActivity.EXTRA_DEBUG, Boolean.TRUE.equals(call.getBoolean("debug", false)));
            startActivityForResult(call, i, "photoResult");
        } catch (Exception e) { call.reject(e.getMessage()); }
    }

    @ActivityCallback
    private void photoResult(PluginCall call, androidx.activity.result.ActivityResult res) {
        if (call == null) return;
        JSObject r = new JSObject();
        Intent d = res.getData();
        if (d != null) {
            r.put("action", d.getStringExtra("action"));
            String p = d.getStringExtra("path");
            if (p != null) { r.put("path", p); r.put("uri", "file://" + p); }
        }
        call.resolve(r);
    }

    /** Поток файла с Диска — читаем прямо в память, без временных файлов. */
    private InputStream gdriveStream(String id) throws Exception {
        gdEnsure();
        java.net.HttpURLConnection c = (java.net.HttpURLConnection) new java.net.URL(
                "https://www.googleapis.com/drive/v3/files/" + id + "?alt=media&acknowledgeAbuse=true&supportsAllDrives=true").openConnection();
        c.setRequestProperty("Authorization", "Bearer " + gdToken);
        c.setConnectTimeout(15000); c.setReadTimeout(30000);
        int code = c.getResponseCode();
        if (code >= 400) throw new Exception("Диск: " + code);
        return c.getInputStream();
    }

    /** Поток записи из архива — тоже без распаковки на диск. */
    private InputStream arcEntryStream(String archUri, String entry) throws Exception {
        File f = arcFile(archUri);
        String kind = arcKindCached(f);
        if ("zip".equals(kind)) {
            net.lingala.zip4j.ZipFile z = new net.lingala.zip4j.ZipFile(f);
            net.lingala.zip4j.model.FileHeader h = z.getFileHeader(entry);
            if (h == null) return null;
            return z.getInputStream(h);
        }
        return null;
    }

    /** Поставить снимок на обои — системным окном выбора. */
    @PluginMethod
    public void setWallpaper(PluginCall call) {
        String uriStr = call.getString("uri");
        if (uriStr == null) { call.reject("no uri"); return; }
        try {
            File f = toFile(uriStr);
            if (!f.exists()) { call.reject("Файл не найден"); return; }
            Uri u = contentUriFor(f);
            Intent i = new Intent(Intent.ACTION_ATTACH_DATA);
            i.addCategory(Intent.CATEGORY_DEFAULT);
            i.setDataAndType(u, "image/*");
            i.putExtra("mimeType", "image/*");
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            Intent ch = Intent.createChooser(i, "Установить как обои");
            ch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            getContext().startActivity(ch);
            call.resolve();
        } catch (Exception e) { call.reject(e.getMessage()); }
    }

    @PluginMethod
    public void editImage(PluginCall call) {
        String uriStr = call.getString("uri");
        String mime = call.getString("mime", "image/*");
        if (uriStr == null) { call.reject("no uri"); return; }
        try {
            File f = toFile(uriStr);
            if (!f.exists()) { call.reject("Файл не найден"); return; }
            try { StrictMode.setVmPolicy(new StrictMode.VmPolicy.Builder().build()); } catch (Exception ignored) {}
            Intent i = new Intent(Intent.ACTION_EDIT);
            Uri u = contentUriFor(f);
            i.setDataAndType(u, mime);
            i.setClipData(android.content.ClipData.newRawUri("", u));
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
            Intent ch = Intent.createChooser(i, "Изменить через");
            ch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            getContext().startActivity(ch);
            call.resolve();
        } catch (Exception e) { call.reject(e.getMessage()); }
    }

    /**
     * Полноэкранный просмотр: окно уходит под системные полосы, а сами полосы
     * прячутся и показываются вместе с панелями приложения.
     */
    @PluginMethod
    public void setFullscreen(PluginCall call) {
        final boolean on = Boolean.TRUE.equals(call.getBoolean("on", true));
        final boolean showBars = Boolean.TRUE.equals(call.getBoolean("showBars", true));
        try {
            getActivity().runOnUiThread(() -> {
                try {
                    Window w = getActivity().getWindow();
                    // раскладку окна не трогаем: иначе панели приложения прыгают при входе и выходе.
                    // Полосы и фон окна красим в чёрный, чтобы по краям не проступал серый.
                    if (on) {
                        w.setStatusBarColor(Color.BLACK);
                        w.setNavigationBarColor(Color.BLACK);
                        try { w.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(Color.BLACK)); } catch (Throwable ignored) {}
                        applyBars(w, !showBars, !showBars);
                    } else {
                        applyBars(w, false, false);
                    }
                } catch (Throwable ignored) {}
            });
        } catch (Throwable ignored) {}
        call.resolve();
    }

    /** Что именно скрыто прямо сейчас: верхняя полоса, нижняя, обе. */
    private void applyBars(Window w, boolean hideStatus, boolean hideNav) {
        try {
            if (Build.VERSION.SDK_INT >= 30) {
                android.view.WindowInsetsController c = w.getInsetsController();
                if (c == null) return;
                c.setSystemBarsBehavior(android.view.WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
                int show = 0, hide = 0;
                if (hideStatus) hide |= android.view.WindowInsets.Type.statusBars(); else show |= android.view.WindowInsets.Type.statusBars();
                if (hideNav) hide |= android.view.WindowInsets.Type.navigationBars(); else show |= android.view.WindowInsets.Type.navigationBars();
                if (hide != 0) c.hide(hide);
                if (show != 0) c.show(show);
            } else {
                View dv = w.getDecorView();
                int f = dv.getSystemUiVisibility();
                if (hideStatus) f |= View.SYSTEM_UI_FLAG_FULLSCREEN; else f &= ~View.SYSTEM_UI_FLAG_FULLSCREEN;
                if (hideNav) f |= View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY;
                else f &= ~(View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
                dv.setSystemUiVisibility(f);
            }
        } catch (Throwable ignored) {}
    }

    @PluginMethod
    public void setBars(PluginCall call) {
        final String color = call.getString("color", "#000000");
        final boolean light = call.getBoolean("light", false);
        try {
            getActivity().runOnUiThread(() -> {
                try {
                    Window w = getActivity().getWindow();
                    int c = Color.parseColor(color);
                    w.setStatusBarColor(c);
                    w.setNavigationBarColor(c);
                    try { w.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(c)); } catch (Throwable ignored) {}
                    View dv = w.getDecorView();
                    int flags = dv.getSystemUiVisibility();
                    if (Build.VERSION.SDK_INT >= 23) {
                        if (light) flags |= View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
                        else flags &= ~View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
                    }
                    if (Build.VERSION.SDK_INT >= 26) {
                        if (light) flags |= View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
                        else flags &= ~View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
                    }
                    dv.setSystemUiVisibility(flags);
                } catch (Exception ignored) {}
            });
        } catch (Exception ignored) {}
        call.resolve();
    }

    @PluginMethod
    public void unwatch(PluginCall call) {
        if (observer != null) { observer.stopWatching(); observer = null; }
        call.resolve();
    }

    private boolean deleteRecursive(File f) {
        // в ссылку-на-папку не заходим: удаляется сама ссылка, а не содержимое цели
        if (f.isDirectory() && !YevXfer.isLink(f)) {
            File[] kids = f.listFiles();
            if (kids != null) for (File k : kids) deleteRecursive(k);
        }
        return f.delete();
    }

    private File toFile(String u) {
        String p = u;
        if (p.startsWith("file://")) p = p.substring(7);
        if (p.indexOf('%') >= 0) { try { p = java.net.URLDecoder.decode(p, "UTF-8"); } catch (Exception ignored) {} }
        return new File(p);
    }

    private Uri contentUriFor(File f) {
        String pkg = getContext().getPackageName();
        // основной: провайдер Capacitor (.fileprovider) — он гарантированно зарегистрирован;
        // его пути переопределены нашим file_paths.xml (весь storage)
        try { return FileProvider.getUriForFile(getContext(), pkg + ".fileprovider", f); } catch (Exception ignored) {}
        try { return FileProvider.getUriForFile(getContext(), pkg + ".appsfp", f); } catch (Exception ignored) {}
        try { StrictMode.setVmPolicy(new StrictMode.VmPolicy.Builder().build()); } catch (Exception ignored) {}
        return Uri.fromFile(f);
    }

    private String drawableToBase64(Drawable d) {
        Bitmap b = drawableToBitmap(d);
        if (b == null) return null;
        int mx = Math.max(b.getWidth(), b.getHeight());
        if (mx > 144) { float sc = 144f / mx; b = Bitmap.createScaledBitmap(b, Math.max(1, Math.round(b.getWidth() * sc)), Math.max(1, Math.round(b.getHeight() * sc)), true); }
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        b.compress(Bitmap.CompressFormat.PNG, 100, out);
        return "data:image/png;base64," + Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP);
    }

    // ===== АУДИОПЛЕЕР =====
    private android.media.MediaPlayer amp;
    private final java.util.List<String> plUris = new java.util.ArrayList<>();
    private final java.util.List<String> plNames = new java.util.ArrayList<>();
    private int plIdx = 0;
    private boolean autoNext = false;
    private android.media.session.MediaSession aSession;
    private BroadcastReceiver aRcv;
    private static final int A_NOTIF = 47110;
    private static final String A_ACT = "leshugan.fm.AUDIO_CMD";

    private void aEnsureReceiver() {
        if (aRcv != null) return;
        aRcv = new BroadcastReceiver() {
            public void onReceive(android.content.Context c, Intent i) {
                String cmd = i.getStringExtra("cmd");
                if ("toggle".equals(cmd)) aToggleInternal();
                else if ("next".equals(cmd)) aPlayIndex(plIdx + 1);
                else if ("prev".equals(cmd)) aPlayIndex(plIdx - 1);
                else if ("close".equals(cmd)) aStopInternal();
            }
        };
        android.content.IntentFilter f = new android.content.IntentFilter(A_ACT);
        if (android.os.Build.VERSION.SDK_INT >= 33) getContext().registerReceiver(aRcv, f, android.content.Context.RECEIVER_NOT_EXPORTED);
        else getContext().registerReceiver(aRcv, f);
    }

    private android.app.PendingIntent aPI(String cmd) {
        Intent i = new Intent(A_ACT).setPackage(getContext().getPackageName());
        i.putExtra("cmd", cmd);
        int fl = android.app.PendingIntent.FLAG_UPDATE_CURRENT | (android.os.Build.VERSION.SDK_INT >= 23 ? android.app.PendingIntent.FLAG_IMMUTABLE : 0);
        return android.app.PendingIntent.getBroadcast(getContext(), cmd.hashCode(), i, fl);
    }

    private void aNotify() {
        try {
            android.app.NotificationManager nm = (android.app.NotificationManager) getContext().getSystemService(android.content.Context.NOTIFICATION_SERVICE);
            if (android.os.Build.VERSION.SDK_INT >= 26 && nm.getNotificationChannel("audio") == null) {
                android.app.NotificationChannel ch = new android.app.NotificationChannel("audio", "Плеер", android.app.NotificationManager.IMPORTANCE_LOW);
                ch.setShowBadge(false); nm.createNotificationChannel(ch);
            }
            boolean playing = amp != null && amp.isPlaying();
            String name = plIdx >= 0 && plIdx < plNames.size() ? plNames.get(plIdx) : "";
            aEnsureSession();
            Intent open = getContext().getPackageManager().getLaunchIntentForPackage(getContext().getPackageName());
            android.app.PendingIntent contentPI = android.app.PendingIntent.getActivity(getContext(), 0, open, android.os.Build.VERSION.SDK_INT >= 23 ? android.app.PendingIntent.FLAG_IMMUTABLE : 0);
            android.app.Notification.Builder b = android.os.Build.VERSION.SDK_INT >= 26 ? new android.app.Notification.Builder(getContext(), "audio") : new android.app.Notification.Builder(getContext());
            b.setSmallIcon(android.R.drawable.ic_media_play).setContentTitle(name).setContentText("YevFiles").setContentIntent(contentPI).setOngoing(playing).setVisibility(android.app.Notification.VISIBILITY_PUBLIC);
            b.addAction(new android.app.Notification.Action.Builder(android.graphics.drawable.Icon.createWithResource(getContext(), android.R.drawable.ic_media_previous), "prev", aPI("prev")).build());
            b.addAction(new android.app.Notification.Action.Builder(android.graphics.drawable.Icon.createWithResource(getContext(), playing ? android.R.drawable.ic_media_pause : android.R.drawable.ic_media_play), "toggle", aPI("toggle")).build());
            b.addAction(new android.app.Notification.Action.Builder(android.graphics.drawable.Icon.createWithResource(getContext(), android.R.drawable.ic_media_next), "next", aPI("next")).build());
            b.addAction(new android.app.Notification.Action.Builder(android.graphics.drawable.Icon.createWithResource(getContext(), android.R.drawable.ic_menu_close_clear_cancel), "close", aPI("close")).build());
            android.app.Notification.MediaStyle st = new android.app.Notification.MediaStyle().setShowActionsInCompactView(0, 1, 2);
            st.setMediaSession(aSession.getSessionToken());
            b.setStyle(st);
            nm.notify(A_NOTIF, b.build());
        } catch (Exception ignored) {}
    }

    private android.media.AudioManager aAM;
    private android.media.AudioManager.OnAudioFocusChangeListener aFocus;
    private android.content.BroadcastReceiver aNoisy;

    // Сеанс воспроизведения: обложка и название на экране блокировки, кнопки гарнитуры
    private void aEnsureSession() {
        if (aSession == null) {
            aSession = new android.media.session.MediaSession(getContext(), "yevfm");
            aSession.setCallback(new android.media.session.MediaSession.Callback() {
                @Override public void onPlay() { aToggleInternal(); }
                @Override public void onPause() { aToggleInternal(); }
                @Override public void onSkipToNext() { aPlayIndex(plIdx + 1); }
                @Override public void onSkipToPrevious() { aPlayIndex(plIdx - 1); }
                @Override public void onStop() { aStopInternal(); }
                @Override public void onSeekTo(long pos) { try { if (amp != null) amp.seekTo((int) pos); } catch (Exception ignored) {} aSessionState(); }
            });
            if (Build.VERSION.SDK_INT < 26) {
                try { aSession.setFlags(android.media.session.MediaSession.FLAG_HANDLES_MEDIA_BUTTONS | android.media.session.MediaSession.FLAG_HANDLES_TRANSPORT_CONTROLS); } catch (Throwable ignored) {}
            }
        }
        try { aSession.setActive(true); } catch (Throwable ignored) {}
        aSessionMeta();
        aSessionState();
    }

    private void aSessionMeta() {
        try {
            String name = plIdx >= 0 && plIdx < plNames.size() ? plNames.get(plIdx) : "";
            long dur = 0;
            try { if (amp != null) dur = amp.getDuration(); } catch (Exception ignored) {}
            android.media.MediaMetadata.Builder mb = new android.media.MediaMetadata.Builder();
            mb.putString(android.media.MediaMetadata.METADATA_KEY_TITLE, name);
            mb.putString(android.media.MediaMetadata.METADATA_KEY_ARTIST, "YevFiles");
            if (dur > 0) mb.putLong(android.media.MediaMetadata.METADATA_KEY_DURATION, dur);
            // обложка из самого файла, если есть
            try {
                if (plIdx >= 0 && plIdx < plUris.size()) {
                    android.media.MediaMetadataRetriever mmr = new android.media.MediaMetadataRetriever();
                    try {
                        String u = plUris.get(plIdx);
                        if (u.startsWith("content://")) mmr.setDataSource(getContext(), android.net.Uri.parse(u));
                        else mmr.setDataSource(toFile(u).getAbsolutePath());
                        byte[] art = mmr.getEmbeddedPicture();
                        if (art != null) {
                            Bitmap bmp = android.graphics.BitmapFactory.decodeByteArray(art, 0, art.length);
                            if (bmp != null) mb.putBitmap(android.media.MediaMetadata.METADATA_KEY_ALBUM_ART, bmp);
                        }
                    } finally { try { mmr.release(); } catch (Exception ignored) {} }
                }
            } catch (Throwable ignored) {}
            aSession.setMetadata(mb.build());
        } catch (Throwable ignored) {}
    }

    private void aSessionState() {
        try {
            boolean playing = amp != null && amp.isPlaying();
            long pos = 0;
            try { if (amp != null) pos = amp.getCurrentPosition(); } catch (Exception ignored) {}
            android.media.session.PlaybackState.Builder pb = new android.media.session.PlaybackState.Builder();
            pb.setActions(android.media.session.PlaybackState.ACTION_PLAY | android.media.session.PlaybackState.ACTION_PAUSE
                    | android.media.session.PlaybackState.ACTION_PLAY_PAUSE | android.media.session.PlaybackState.ACTION_SKIP_TO_NEXT
                    | android.media.session.PlaybackState.ACTION_SKIP_TO_PREVIOUS | android.media.session.PlaybackState.ACTION_SEEK_TO
                    | android.media.session.PlaybackState.ACTION_STOP);
            pb.setState(playing ? android.media.session.PlaybackState.STATE_PLAYING : android.media.session.PlaybackState.STATE_PAUSED, pos, 1.0f);
            aSession.setPlaybackState(pb.build());
        } catch (Throwable ignored) {}
    }

    // Звонок или другой плеер — ставим паузу; наушники выдернули — тоже
    private void aFocusGain() {
        try {
            if (aAM == null) aAM = (android.media.AudioManager) getContext().getSystemService(Context.AUDIO_SERVICE);
            if (aFocus == null) aFocus = new android.media.AudioManager.OnAudioFocusChangeListener() {
                public void onAudioFocusChange(int f) {
                    if (f == android.media.AudioManager.AUDIOFOCUS_LOSS || f == android.media.AudioManager.AUDIOFOCUS_LOSS_TRANSIENT) {
                        try { if (amp != null && amp.isPlaying()) { amp.pause(); aNotify(); aSessionState(); } } catch (Exception ignored) {}
                    }
                }
            };
            aAM.requestAudioFocus(aFocus, android.media.AudioManager.STREAM_MUSIC, android.media.AudioManager.AUDIOFOCUS_GAIN);
        } catch (Throwable ignored) {}
        try {
            if (aNoisy == null) {
                aNoisy = new android.content.BroadcastReceiver() {
                    public void onReceive(Context c, Intent i) {
                        try { if (amp != null && amp.isPlaying()) { amp.pause(); aNotify(); aSessionState(); } } catch (Exception ignored) {}
                    }
                };
                getContext().registerReceiver(aNoisy, new android.content.IntentFilter(android.media.AudioManager.ACTION_AUDIO_BECOMING_NOISY));
            }
        } catch (Throwable ignored) {}
    }

    private void aPlayIndex(int idx) {
        if (idx < 0) return;
        if (idx >= plUris.size()) { aStopInternal(); return; }
        plIdx = idx;
        try {
            if (amp == null) amp = new android.media.MediaPlayer();
            else amp.reset();
            String uri = plUris.get(idx);
            if (uri.startsWith("content://")) amp.setDataSource(getContext(), android.net.Uri.parse(uri));
            else amp.setDataSource(toFile(uri).getAbsolutePath());
            amp.setOnCompletionListener(new android.media.MediaPlayer.OnCompletionListener() {
                public void onCompletion(android.media.MediaPlayer m) { if (autoNext) aPlayIndex(plIdx + 1); else aNotify(); }
            });
            amp.prepare();
            aFocusGain();
            amp.start();
            aEnsureReceiver();
            aEnsureSession();
            aNotify();
        } catch (Exception e) {}
    }

    private void aToggleInternal() {
        if (amp == null) return;
        try { if (amp.isPlaying()) amp.pause(); else { aFocusGain(); amp.start(); } } catch (Exception e) {}
        aSessionState();
        aNotify();
    }

    private void aStopInternal() {
        try { if (amp != null) { amp.stop(); amp.release(); } } catch (Exception e) {}
        amp = null;
        try { if (aSession != null) { aSession.setActive(false); aSession.release(); aSession = null; } } catch (Throwable ignored) {}
        try { if (aAM != null && aFocus != null) aAM.abandonAudioFocus(aFocus); } catch (Throwable ignored) {}
        try { if (aNoisy != null) { getContext().unregisterReceiver(aNoisy); aNoisy = null; } } catch (Throwable ignored) {}
        try { ((android.app.NotificationManager) getContext().getSystemService(android.content.Context.NOTIFICATION_SERVICE)).cancel(A_NOTIF); } catch (Exception e) {}
    }

    @PluginMethod
    public void audioOpen(PluginCall call) {
        try {
            plUris.clear(); plNames.clear();
            JSArray us = call.getArray("uris"), ns = call.getArray("names");
            for (int i = 0; i < us.length(); i++) plUris.add(us.getString(i));
            for (int i = 0; i < ns.length(); i++) plNames.add(ns.getString(i));
            autoNext = call.getBoolean("autoNext", false);
            aPlayIndex(call.getInt("index", 0));
            call.resolve();
        } catch (Exception e) { call.reject(e.getMessage()); }
    }

    @PluginMethod public void audioToggle(PluginCall call) { aToggleInternal(); call.resolve(); }
    @PluginMethod public void audioNext(PluginCall call) { aPlayIndex(plIdx + 1); call.resolve(); }
    @PluginMethod public void audioPrev(PluginCall call) { aPlayIndex(plIdx - 1); call.resolve(); }
    @PluginMethod public void audioSeek(PluginCall call) { try { if (amp != null) amp.seekTo(call.getInt("ms", 0)); } catch (Exception e) {} call.resolve(); }
    @PluginMethod public void audioClose(PluginCall call) { aStopInternal(); call.resolve(); }
    @PluginMethod public void audioConfig(PluginCall call) { autoNext = call.getBoolean("autoNext", autoNext); call.resolve(); }

    @PluginMethod
    public void audioState(PluginCall call) {
        JSObject o = new JSObject();
        try {
            o.put("playing", amp != null && amp.isPlaying());
            o.put("pos", amp != null ? amp.getCurrentPosition() : 0);
            o.put("dur", amp != null ? amp.getDuration() : 0);
            o.put("idx", plIdx);
            o.put("count", plUris.size());
            o.put("name", plIdx >= 0 && plIdx < plNames.size() ? plNames.get(plIdx) : "");
            o.put("alive", amp != null);
        } catch (Exception e) { o.put("alive", amp != null); }
        call.resolve(o);
    }

    @PluginMethod
    public void audioSetAs(PluginCall call) {
        try {
            String uri = call.getString("uri");
            String type = call.getString("type", "ringtone");
            if (android.os.Build.VERSION.SDK_INT >= 23 && !android.provider.Settings.System.canWrite(getContext())) {
                Intent i = new Intent(android.provider.Settings.ACTION_MANAGE_WRITE_SETTINGS);
                i.setData(android.net.Uri.parse("package:" + getContext().getPackageName()));
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                getContext().startActivity(i);
                call.reject("need_write_settings");
                return;
            }
            File f = toFile(uri);
            boolean alarm = "alarm".equals(type);
            android.net.Uri base = android.provider.MediaStore.Audio.Media.getContentUriForPath(f.getAbsolutePath());
            android.net.Uri newUri = null;
            try {
                android.database.Cursor c = getContext().getContentResolver().query(base, new String[]{ android.provider.MediaStore.MediaColumns._ID }, android.provider.MediaStore.MediaColumns.DATA + "=?", new String[]{ f.getAbsolutePath() }, null);
                if (c != null) { if (c.moveToFirst()) newUri = android.net.Uri.withAppendedPath(base, c.getString(0)); c.close(); }
            } catch (Exception ignored) {}
            android.content.ContentValues cv = new android.content.ContentValues();
            cv.put(android.provider.MediaStore.Audio.Media.IS_RINGTONE, !alarm);
            cv.put(android.provider.MediaStore.Audio.Media.IS_ALARM, alarm);
            cv.put(android.provider.MediaStore.Audio.Media.IS_NOTIFICATION, false);
            if (newUri != null) {
                getContext().getContentResolver().update(newUri, cv, null, null);
            } else {
                cv.put(android.provider.MediaStore.MediaColumns.DATA, f.getAbsolutePath());
                cv.put(android.provider.MediaStore.MediaColumns.TITLE, f.getName());
                cv.put(android.provider.MediaStore.MediaColumns.MIME_TYPE, "audio/mpeg");
                newUri = getContext().getContentResolver().insert(base, cv);
            }
            android.media.RingtoneManager.setActualDefaultRingtoneUri(getContext(), alarm ? android.media.RingtoneManager.TYPE_ALARM : android.media.RingtoneManager.TYPE_RINGTONE, newUri);
            JSObject o = new JSObject(); o.put("ok", true); call.resolve(o);
        } catch (Exception e) { call.reject(e.getMessage()); }
    }
}
