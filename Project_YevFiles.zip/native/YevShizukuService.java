package leshugan.fm;

import android.os.ParcelFileDescriptor;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;

/**
 * Работает ВНУТРИ процесса Shizuku с правами оболочки.
 * Только файловые операции — ничего из приложения сюда не тянем.
 */
public class YevShizukuService extends IYevShizuku.Stub {

    public YevShizukuService() {}

    @Override
    public void destroy() {
        System.exit(0);
    }

    @Override
    public String list(String path) {
        JSONArray arr = new JSONArray();
        try {
            File dir = new File(path);
            File[] kids = dir.listFiles();
            if (kids != null) {
                for (File k : kids) {
                    JSONObject o = new JSONObject();
                    o.put("name", k.getName());
                    boolean isDir = k.isDirectory();
                    o.put("type", isDir ? "directory" : "file");
                    o.put("size", isDir ? 0 : k.length());
                    o.put("mtime", k.lastModified());
                    o.put("uri", k.getAbsolutePath());
                    arr.put(o);
                }
            }
        } catch (Exception ignored) {}
        return arr.toString();
    }

    @Override
    public boolean mkdirs(String path) {
        try { File f = new File(path); return f.exists() || f.mkdirs(); } catch (Exception e) { return false; }
    }

    @Override
    public boolean delete(String path) {
        try { return deleteRec(new File(path)); } catch (Exception e) { return false; }
    }

    private boolean deleteRec(File f) {
        if (f.isDirectory()) {
            File[] kids = f.listFiles();
            if (kids != null) for (File k : kids) deleteRec(k);
        }
        return f.delete();
    }

    @Override
    public boolean rename(String from, String to) {
        try {
            File a = new File(from), b = new File(to);
            if (a.renameTo(b)) return true;
            // разные тома — копируем и убираем исходник
            if (a.isDirectory()) { if (!copyDir(a, b)) return false; return deleteRec(a); }
            if (!copyFile(a, b)) return false;
            return a.delete();
        } catch (Exception e) { return false; }
    }

    private boolean copyDir(File src, File dst) {
        if (!dst.exists() && !dst.mkdirs()) return false;
        File[] kids = src.listFiles();
        if (kids != null) for (File k : kids) {
            File t = new File(dst, k.getName());
            boolean ok = k.isDirectory() ? copyDir(k, t) : copyFile(k, t);
            if (!ok) return false;
        }
        return true;
    }

    private boolean copyFile(File src, File dst) {
        InputStream in = null; OutputStream out = null;
        try {
            File p = dst.getParentFile();
            if (p != null && !p.exists()) p.mkdirs();
            in = new FileInputStream(src);
            out = new FileOutputStream(dst);
            byte[] buf = new byte[65536];
            int r;
            while ((r = in.read(buf)) > 0) out.write(buf, 0, r);
            return true;
        } catch (Exception e) {
            return false;
        } finally {
            try { if (in != null) in.close(); } catch (Exception ignored) {}
            try { if (out != null) out.close(); } catch (Exception ignored) {}
        }
    }

    @Override
    public ParcelFileDescriptor open(String path, String mode) {
        try {
            int m = "w".equals(mode)
                    ? (ParcelFileDescriptor.MODE_CREATE | ParcelFileDescriptor.MODE_TRUNCATE | ParcelFileDescriptor.MODE_WRITE_ONLY)
                    : ParcelFileDescriptor.MODE_READ_ONLY;
            File f = new File(path);
            if ("w".equals(mode)) {
                File p = f.getParentFile();
                if (p != null && !p.exists()) p.mkdirs();
            }
            return ParcelFileDescriptor.open(f, m);
        } catch (Exception e) {
            return null;
        }
    }
}
