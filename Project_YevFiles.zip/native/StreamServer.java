package leshugan.fm;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Крошечный локальный сервер: отдаёт файл по адресу http://127.0.0.1:порт/id
 * с поддержкой перемотки (запрос Range). Нужен, чтобы плеер начинал играть
 * сразу, а не после полного скачивания файла из облака.
 */
public class StreamServer {

    public interface Source {
        long length();                                  // -1 если размер неизвестен
        String mime();
        InputStream open(long offset) throws Exception; // поток с нужного места
    }

    private static StreamServer instance;
    private ServerSocket server;
    private int port = -1;
    private final Map<String, Source> items = new HashMap<>();
    private final AtomicInteger seq = new AtomicInteger(1);

    public static synchronized StreamServer get() {
        if (instance == null) instance = new StreamServer();
        return instance;
    }

    public synchronized String publish(Source src) throws Exception {
        ensureStarted();
        String id = "s" + seq.getAndIncrement();
        items.put(id, src);
        return "http://127.0.0.1:" + port + "/" + id;
    }

    public synchronized void clear() { items.clear(); }

    private void ensureStarted() throws Exception {
        if (server != null && !server.isClosed()) return;
        server = new ServerSocket(0, 8, java.net.InetAddress.getByName("127.0.0.1"));
        port = server.getLocalPort();
        Thread t = new Thread(new Runnable() {
            public void run() {
                while (server != null && !server.isClosed()) {
                    try {
                        final Socket sock = server.accept();
                        new Thread(new Runnable() { public void run() { serve(sock); } }).start();
                    } catch (Throwable ignored) { break; }
                }
            }
        });
        t.setDaemon(true);
        t.start();
    }

    private void serve(Socket sock) {
        InputStream data = null;
        try {
            sock.setSoTimeout(20000);
            InputStream in = sock.getInputStream();
            OutputStream out = sock.getOutputStream();
            StringBuilder head = new StringBuilder();
            int c, prevN = 0;
            while ((c = in.read()) != -1) {
                head.append((char) c);
                if (c == '\n') { if (prevN == 1) break; prevN = 1; } else if (c != '\r') prevN = 0;
                if (head.length() > 8192) break;
            }
            String req = head.toString();
            String first = req.split("\r\n", 2)[0];
            String path = first.split(" ").length > 1 ? first.split(" ")[1] : "/";
            String id = path.startsWith("/") ? path.substring(1) : path;
            int qm = id.indexOf('?'); if (qm > 0) id = id.substring(0, qm);

            Source src = items.get(id);
            if (src == null) { write(out, "HTTP/1.1 404 Not Found\r\nContent-Length: 0\r\nConnection: close\r\n\r\n"); sock.close(); return; }

            long total = src.length();
            long start = 0, end = total > 0 ? total - 1 : -1;
            boolean partial = false;
            for (String line : req.split("\r\n")) {
                if (line.toLowerCase().startsWith("range:")) {
                    String r = line.substring(6).trim().replace("bytes=", "");
                    String[] pr = r.split("-", 2);
                    try {
                        if (pr[0].length() > 0) start = Long.parseLong(pr[0].trim());
                        if (pr.length > 1 && pr[1].trim().length() > 0) end = Long.parseLong(pr[1].trim());
                    } catch (Exception ignored) {}
                    partial = true;
                }
            }
            if (total > 0 && (end < 0 || end >= total)) end = total - 1;

            StringBuilder h = new StringBuilder();
            h.append(partial && total > 0 ? "HTTP/1.1 206 Partial Content\r\n" : "HTTP/1.1 200 OK\r\n");
            h.append("Content-Type: ").append(src.mime() == null ? "application/octet-stream" : src.mime()).append("\r\n");
            h.append("Accept-Ranges: bytes\r\n");
            if (total > 0) {
                long len = end - start + 1;
                h.append("Content-Length: ").append(len).append("\r\n");
                if (partial) h.append("Content-Range: bytes ").append(start).append("-").append(end).append("/").append(total).append("\r\n");
            }
            h.append("Connection: close\r\n\r\n");
            write(out, h.toString());

            if (first.startsWith("HEAD")) { out.flush(); sock.close(); return; }

            data = src.open(start);
            byte[] buf = new byte[262144];
            long remain = total > 0 ? (end - start + 1) : Long.MAX_VALUE;
            int n;
            while (remain > 0 && (n = data.read(buf, 0, (int) Math.min(buf.length, remain))) > 0) {
                out.write(buf, 0, n);
                remain -= n;
            }
            out.flush();
        } catch (Throwable ignored) {
        } finally {
            try { if (data != null) data.close(); } catch (Throwable ignored) {}
            try { sock.close(); } catch (Throwable ignored) {}
        }
    }

    private void write(OutputStream out, String s) throws Exception {
        out.write(s.getBytes("UTF-8"));
    }

    /** Источник — обычный файл на диске. */
    public static Source fileSource(final File f, final String mime) {
        return new Source() {
            public long length() { return f.length(); }
            public String mime() { return mime; }
            public InputStream open(long offset) throws Exception {
                FileInputStream is = new FileInputStream(f);
                if (offset > 0) is.skip(offset);
                return is;
            }
        };
    }

    /** Источник — файл в интернете (Google Диск и т.п.) с заголовком авторизации. */
    public static Source httpSource(final String url, final String auth, final String mime, final long size) {
        return new Source() {
            public long length() { return size; }
            public String mime() { return mime; }
            public InputStream open(long offset) throws Exception {
                java.net.HttpURLConnection c = (java.net.HttpURLConnection) new java.net.URL(url).openConnection();
                if (auth != null) c.setRequestProperty("Authorization", auth);
                if (offset > 0) c.setRequestProperty("Range", "bytes=" + offset + "-");
                c.setConnectTimeout(15000);
                c.setReadTimeout(30000);
                return c.getInputStream();
            }
        };
    }
}
