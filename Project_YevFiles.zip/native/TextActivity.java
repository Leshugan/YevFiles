package leshugan.fm;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;

/**
 * Просмотр и правка текста — родным окном.
 * Большой файл читается кусками, поэтому не подвешивает приложение.
 */
public class TextActivity extends Activity {

    public static final String EXTRA_PATH = "path";
    public static final String EXTRA_THEME = "theme";

    private static final int PREVIEW_LIMIT = 512 * 1024;    // столько показываем сразу

    private YevTheme t;
    private float d;
    private File file;
    private EditText edit;
    private TextView title;
    private boolean readOnly = false;
    private boolean dirty = false;

    private int dp(float v) { return Math.round(d * v); }

    @Override
    protected void onCreate(Bundle st) {
        super.onCreate(st);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        d = getResources().getDisplayMetrics().density;
        t = YevTheme.of(getIntent().getStringExtra(EXTRA_THEME));

        Window w = getWindow();
        w.setStatusBarColor(t.bg);
        w.setNavigationBarColor(t.bg);

        String p = getIntent().getStringExtra(EXTRA_PATH);
        file = p == null ? null : new File(p);
        if (file == null || !file.isFile()) { finish(); return; }

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(t.bg);

        // шапка: имя файла и кнопки
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        GradientDrawable bbg = new GradientDrawable();
        bbg.setColor(t.bar);
        bbg.setCornerRadius(dp(26));
        bar.setBackground(bbg);
        bar.setElevation(dp(6));
        LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(-1, dp(50));
        blp.setMargins(dp(8), dp(8), dp(8), dp(6));
        bar.setLayoutParams(blp);

        title = new TextView(this);
        title.setText(file.getName());
        title.setTextColor(t.txt);
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        title.setSingleLine(true);
        title.setEllipsize(android.text.TextUtils.TruncateAt.MIDDLE);
        title.setPadding(dp(16), 0, dp(8), 0);
        bar.addView(title, new LinearLayout.LayoutParams(0, -2, 1f));

        bar.addView(barButton("Сохранить", () -> save()));
        bar.addView(barButton("Закрыть", () -> finish()));
        root.addView(bar);

        ScrollView sv = new ScrollView(this);
        edit = new EditText(this);
        edit.setBackgroundColor(0);
        edit.setTextColor(t.txt);
        edit.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        edit.setTypeface(android.graphics.Typeface.MONOSPACE);
        edit.setPadding(dp(14), dp(10), dp(14), dp(20));
        edit.setGravity(Gravity.TOP | Gravity.START);
        edit.addTextChangedListener(new android.text.TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) {}
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) { dirty = true; }
            @Override public void afterTextChanged(android.text.Editable s) {}
        });
        sv.addView(edit, new LinearLayout.LayoutParams(-1, -2));
        root.addView(sv, new LinearLayout.LayoutParams(-1, 0, 1f));

        setContentView(root);

        root.setOnApplyWindowInsetsListener((v, ins) -> {
            int top = 0, bot = 0;
            try {
                if (Build.VERSION.SDK_INT >= 30) {
                    android.graphics.Insets in = ins.getInsets(android.view.WindowInsets.Type.systemBars());
                    top = in.top; bot = in.bottom;
                } else { top = ins.getSystemWindowInsetTop(); bot = ins.getSystemWindowInsetBottom(); }
            } catch (Throwable ignored) {}
            root.setPadding(0, top, 0, bot);
            return ins;
        });

        load();
    }

    private View barButton(String label, final Runnable fn) {
        TextView tv = new TextView(this);
        tv.setText(label);
        tv.setTextColor(t.acc);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        tv.setPadding(dp(12), dp(8), dp(12), dp(8));
        tv.setOnClickListener(v -> fn.run());
        return tv;
    }

    /** Читаем файл: целиком, если он небольшой, иначе только начало. */
    private void load() {
        edit.setText("Открываю…");
        new Thread(() -> {
            String text = "";
            boolean cut = false;
            try {
                long len = file.length();
                cut = len > PREVIEW_LIMIT;
                java.io.InputStream in = new java.io.FileInputStream(file);
                byte[] buf = new byte[(int) Math.min(len, PREVIEW_LIMIT)];
                int read = 0, n;
                while (read < buf.length && (n = in.read(buf, read, buf.length - read)) > 0) read += n;
                in.close();
                text = new String(buf, 0, read, "UTF-8");
            } catch (Throwable t2) { text = "Не удалось прочитать файл"; readOnly = true; }
            final String shown = text + (cut ? "\n\n… файл больше, показано начало. Правка выключена." : "");
            final boolean ro = cut || readOnly;
            runOnUiThread(() -> {
                readOnly = ro;
                edit.setText(shown);
                edit.setFocusable(!ro);
                edit.setFocusableInTouchMode(!ro);
                if (ro) title.setText(file.getName() + "  ·  только чтение");
                dirty = false;
            });
        }).start();
    }

    private void save() {
        if (readOnly) { Toast.makeText(this, "Только чтение", Toast.LENGTH_SHORT).show(); return; }
        final String text = edit.getText().toString();
        new Thread(() -> {
            boolean ok = false;
            try {
                java.io.OutputStream out = new java.io.FileOutputStream(file);
                out.write(text.getBytes("UTF-8"));
                out.close();
                ok = true;
            } catch (Throwable ignored) {}
            final boolean res = ok;
            runOnUiThread(() -> {
                Toast.makeText(this, res ? "Сохранено" : "Не сохранилось", Toast.LENGTH_SHORT).show();
                if (res) dirty = false;
            });
        }).start();
    }

    @Override
    public void onBackPressed() {
        if (dirty && !readOnly) {
            new android.app.AlertDialog.Builder(this)
                    .setMessage("Сохранить изменения?")
                    .setNegativeButton("Нет", (d2, w) -> finish())
                    .setPositiveButton("Сохранить", (d2, w) -> { save(); finish(); })
                    .show();
            return;
        }
        super.onBackPressed();
    }
}
