package leshugan.fm;

import java.util.HashMap;
import java.util.Map;

/** Очертания значков — ровно те же, что в веб-части приложения. */
public final class YevIcons {
    private static final Map<String, String[]> M = new HashMap<>();
    /** Эти значки в вебе залиты, а не нарисованы линией. */
    private static final java.util.Set<String> FILLED = new java.util.HashSet<>(java.util.Arrays.asList("dots"));
    static {
        M.put("android", new String[]{ "M7 6 L5.6 4.2" });
        M.put("apk", new String[]{ "M7 6 L5.6 4.2", "M17 6 L18.4 4.2", "M5.5 12a6.5 6.5 0 0 1 13 0z", "M7.6 12.4h8.8a1.6 1.6 0 0 1 1.6 1.6v4.0a1.6 1.6 0 0 1 -1.6 1.6h-8.8a1.6 1.6 0 0 1 -1.6 -1.6v-4.0a1.6 1.6 0 0 1 1.6 -1.6z", "M4.2 12.6h0.0a1.2 1.2 0 0 1 1.2 1.2v4.0a1.2 1.2 0 0 1 -1.2 1.2h-0.0a1.2 1.2 0 0 1 -1.2 -1.2v-4.0a1.2 1.2 0 0 1 1.2 -1.2z", "M19.8 12.6h0.0a1.2 1.2 0 0 1 1.2 1.2v4.0a1.2 1.2 0 0 1 -1.2 1.2h-0.0a1.2 1.2 0 0 1 -1.2 -1.2v-4.0a1.2 1.2 0 0 1 1.2 -1.2z", "M8.75 8.8a0.85 0.85 0 1 0 1.7 0a0.85 0.85 0 1 0 -1.7 0z", "M13.55 8.8a0.85 0.85 0 1 0 1.7 0a0.85 0.85 0 1 0 -1.7 0z" });
        M.put("archive", new String[]{ "M12 3v18M9 7h6M9 11h6", "M5.0 3.0h14.0a2.0 2.0 0 0 1 2.0 2.0v14.0a2.0 2.0 0 0 1 -2.0 2.0h-14.0a2.0 2.0 0 0 1 -2.0 -2.0v-14.0a2.0 2.0 0 0 1 2.0 -2.0z" });
        M.put("audio", new String[]{ "M9 18V5l10-2v13", "M3.0 18.0a3.0 3.0 0 1 0 6.0 0a3.0 3.0 0 1 0 -6.0 0z", "M13.0 16.0a3.0 3.0 0 1 0 6.0 0a3.0 3.0 0 1 0 -6.0 0z" });
        M.put("back", new String[]{ "M15 18l-6-6 6-6" });
        M.put("bars", new String[]{ "M4 6h16M4 12h16M4 18h16" });
        M.put("book", new String[]{ "M4 4h11a3 3 0 0 1 3 3v13H7a3 3 0 0 0-3 3z", "M4 4v16" });
        M.put("cam", new String[]{ "M3 8a2 2 0 0 1 2-2h2l1.5-2h7L19 6h0a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z", "M8.5 12.5a3.5 3.5 0 1 0 7.0 0a3.5 3.5 0 1 0 -7.0 0z" });
        M.put("check", new String[]{ "M5 12l4 4 10-11" });
        M.put("chev", new String[]{ "M6 9l6 6 6-6" });
        M.put("code", new String[]{ "M8 9l-4 3 4 3", "M16 9l4 3-4 3" });
        M.put("copy", new String[]{ "M5 15V5a2 2 0 0 1 2-2h8", "M11.0 9.0h7.0a2.0 2.0 0 0 1 2.0 2.0v7.0a2.0 2.0 0 0 1 -2.0 2.0h-7.0a2.0 2.0 0 0 1 -2.0 -2.0v-7.0a2.0 2.0 0 0 1 2.0 -2.0z" });
        M.put("cut", new String[]{ "M20 4L8.5 15.5", "M20 20L8.5 8.5", "M3.0 6.0a3.0 3.0 0 1 0 6.0 0a3.0 3.0 0 1 0 -6.0 0z", "M3.0 18.0a3.0 3.0 0 1 0 6.0 0a3.0 3.0 0 1 0 -6.0 0z" });
        M.put("dl", new String[]{ "M12 3v12", "M7 11l5 5 5-5", "M5 21h14" });
        M.put("dots", new String[]{ "M10.0 5.0a2.0 2.0 0 1 0 4.0 0a2.0 2.0 0 1 0 -4.0 0z", "M10.0 12.0a2.0 2.0 0 1 0 4.0 0a2.0 2.0 0 1 0 -4.0 0z", "M10.0 19.0a2.0 2.0 0 1 0 4.0 0a2.0 2.0 0 1 0 -4.0 0z" });
        M.put("file", new String[]{ "M6 2h9l5 5v15H6z", "M14 2v6h6" });
        M.put("folder", new String[]{ "M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z" });
        M.put("fontA", new String[]{ "M5 19l5-13 5 13M7 14h6", "M17 19V9M17 9c2 0 3 1 3 2s-1 2-3 2" });
        M.put("home", new String[]{ "M3 11l9-7 9 7", "M5 10v9a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-9", "M10 20v-6h4v6" });
        M.put("img", new String[]{ "M21 15l-5-5L5 21", "M5.0 3.0h14.0a2.0 2.0 0 0 1 2.0 2.0v14.0a2.0 2.0 0 0 1 -2.0 2.0h-14.0a2.0 2.0 0 0 1 -2.0 -2.0v-14.0a2.0 2.0 0 0 1 2.0 -2.0z", "M7.0 8.5a1.5 1.5 0 1 0 3.0 0a1.5 1.5 0 1 0 -3.0 0z" });
        M.put("info", new String[]{ "M12 11v5M12 8h.01", "M3.0 12.0a9.0 9.0 0 1 0 18.0 0a9.0 9.0 0 1 0 -18.0 0z" });
        M.put("lnk", new String[]{ "M9 15l6-6M10.5 9H15v4.5", "M6.0 4.0h12.0a2.0 2.0 0 0 1 2.0 2.0v12.0a2.0 2.0 0 0 1 -2.0 2.0h-12.0a2.0 2.0 0 0 1 -2.0 -2.0v-12.0a2.0 2.0 0 0 1 2.0 -2.0z" });
        M.put("menu", new String[]{ "M4 6h16M4 12h16M4 18h16" });
        M.put("moon", new String[]{ "M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z" });
        M.put("paste", new String[]{ "M9 4h6v3H9z", "M8.0 4.0h8.0a2.0 2.0 0 0 1 2.0 2.0v12.0a2.0 2.0 0 0 1 -2.0 2.0h-8.0a2.0 2.0 0 0 1 -2.0 -2.0v-12.0a2.0 2.0 0 0 1 2.0 -2.0z" });
        M.put("pdf", new String[]{ "M6 2h9l5 5v15H6z", "M14 2v6h6", "M9 12h6M9 15h6M9 18h3" });
        M.put("pinB", new String[]{ "M12 21v-8M8 17l4 4 4-4", "M5 10h14M5 10V4h14v6" });
        M.put("pinT", new String[]{ "M12 3v8M8 7l4-4 4 4", "M5 14h14M5 14v6h14v-6" });
        M.put("plus", new String[]{ "M12 5v14", "M5 12h14" });
        M.put("rename", new String[]{ "M12 20h9", "M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4z" });
        M.put("search", new String[]{ "M21 21l-4-4", "M4.0 11.0a7.0 7.0 0 1 0 14.0 0a7.0 7.0 0 1 0 -14.0 0z" });
        M.put("selectAll", new String[]{ "M8.5 12l2.5 2.5 4.5-5", "M8.0 4.0h8.0a4.0 4.0 0 0 1 4.0 4.0v8.0a4.0 4.0 0 0 1 -4.0 4.0h-8.0a4.0 4.0 0 0 1 -4.0 -4.0v-8.0a4.0 4.0 0 0 1 4.0 -4.0z" });
        M.put("share", new String[]{ "M8.6 13.5l6.8 4M15.4 6.5l-6.8 4", "M15.0 5.0a3.0 3.0 0 1 0 6.0 0a3.0 3.0 0 1 0 -6.0 0z", "M3.0 12.0a3.0 3.0 0 1 0 6.0 0a3.0 3.0 0 1 0 -6.0 0z", "M15.0 19.0a3.0 3.0 0 1 0 6.0 0a3.0 3.0 0 1 0 -6.0 0z" });
        M.put("sort", new String[]{ "M7 4v16M7 20l-3-3M7 4l3 3", "M17 20V4M17 4l3 3M17 20l-3-3" });
        M.put("star", new String[]{ "M12 3l2.9 5.9 6.5.9-4.7 4.6 1.1 6.5L12 18.8 6.2 21.8l1.1-6.5L2.6 10.7l6.5-.9z" });
        M.put("sun", new String[]{ "M12 2v2M12 20v2M4.2 4.2l1.4 1.4M18.4 18.4l1.4 1.4M2 12h2M20 12h2M4.2 19.8l1.4-1.4M18.4 5.6l1.4-1.4", "M7.5 12.0a4.5 4.5 0 1 0 9.0 0a4.5 4.5 0 1 0 -9.0 0z" });
        M.put("trash", new String[]{ "M3 6h18", "M8 6V4h8v2", "M6 6l1 14h10l1-14" });
        M.put("txt", new String[]{ "M6 2h9l5 5v15H6z", "M14 2v6h6", "M9 13h6M9 16h6M9 10h3" });
        M.put("video", new String[]{ "M16 10l6-3v10l-6-3z", "M4.0 5.0h10.0a2.0 2.0 0 0 1 2.0 2.0v10.0a2.0 2.0 0 0 1 -2.0 2.0h-10.0a2.0 2.0 0 0 1 -2.0 -2.0v-10.0a2.0 2.0 0 0 1 2.0 -2.0z" });
        M.put("x", new String[]{ "M6 6l12 12", "M18 6L6 18" });
    }

    public static String[] get(String key) {
        String[] p = M.get(key);
        return p != null ? p : M.get("file");
    }

    public static boolean filled(String key) { return FILLED.contains(key); }
}
