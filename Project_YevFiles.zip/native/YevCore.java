package leshugan.fm;

import android.content.ContentResolver;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.net.Uri;
import android.provider.MediaStore;
import android.system.ErrnoException;
import android.system.Os;
import android.system.OsConstants;
import android.system.StructStat;

import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.LinkedBlockingDeque;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.regex.Pattern;

/**
 * Ядро чтения папок.
 *  - readDir: один системный запрос (lstat) на элемент вместо трёх, без обхода подпапок
 *  - DirStats: число объектов и обложка каждой папки хранятся в базе и не пересчитываются,
 *    пока не изменилась сама папка (её дата изменения)
 *  - folderSizes: полный размер подпапок одним запросом к индексу файлов Android
 *  - search: два слоя — мгновенный ответ индекса Android, затем обход диска несколькими потоками
 */
public final class YevCore {

    public interface Emitter { void emit(String event, JSObject data); }

    public static final class Ent {
        public final String name; public final boolean dir; public final long size; public final long mtime; public final boolean link;
        Ent(String name, boolean dir, long size, long mtime, boolean link) { this.name = name; this.dir = dir; this.size = size; this.mtime = mtime; this.link = link; }
    }

    private static final Pattern IMG = Pattern.compile(".*\\.(jpg|jpeg|png|webp|gif|bmp|avif|heic|heif)$", Pattern.CASE_INSENSITIVE);

    private final Context ctx;
    private final Emitter em;
    private final DirStats db;
    private final ExecutorService statsWorker = Executors.newSingleThreadExecutor(r -> { Thread t = new Thread(r, "yev-dirstats"); t.setPriority(Thread.MIN_PRIORITY + 1); t.setDaemon(true); return t; });
    private final ExecutorService sizesWorker = Executors.newSingleThreadExecutor(r -> { Thread t = new Thread(r, "yev-foldersizes"); t.setPriority(Thread.MIN_PRIORITY + 1); t.setDaemon(true); return t; });
    private final Set<String> statsPending = Collections.newSetFromMap(new ConcurrentHashMap<String, Boolean>());
    private final Map<String, Long> sizesRecent = new ConcurrentHashMap<>();
    private volatile String wantedDir = "";      // папка, которая сейчас на экране — её задачи важнее

    public YevCore(Context ctx, Emitter em) {
        this.ctx = ctx.getApplicationContext();
        this.em = em;
        this.db = new DirStats(this.ctx);
    }

    // ---------- одно чтение папки ----------

    /** Список папки: имя, тип, размер, дата за один запрос на элемент. null — прочитать нельзя. */
    public static List<Ent> readDir(File dir) { return readDir(dir, dir.list()); }

    public static List<Ent> readDir(File dir, String[] names) {
        if (names == null) return null;
        List<Ent> out = new ArrayList<>(names.length);
        String base = dir.getAbsolutePath();
        if (!base.endsWith("/")) base += "/";
        for (String n : names) out.add(statOne(base + n, n));
        return out;
    }

    public static Ent statOne(String full, String name) {
        try {
            StructStat st = Os.lstat(full);
            boolean link = OsConstants.S_ISLNK(st.st_mode);
            if (link) { try { st = Os.stat(full); } catch (ErrnoException ignored) {} }
            boolean d = OsConstants.S_ISDIR(st.st_mode);
            return new Ent(name, d, d ? 0L : st.st_size, st.st_mtime * 1000L, link);
        } catch (Throwable t) {
            File f = new File(full);
            boolean d = f.isDirectory();
            return new Ent(name, d, d ? 0L : f.length(), f.lastModified(), false);
        }
    }

    public static JSObject entJson(Ent e, String base) {
        JSObject o = new JSObject();
        o.put("name", e.name);
        o.put("type", e.dir ? "directory" : "file");
        o.put("size", e.size);
        o.put("mtime", e.mtime);
        o.put("uri", "file://" + base + e.name);
        if (e.link) o.put("link", true);
        return o;
    }

    // ---------- база: число объектов и обложка папки ----------

    static final class Row { long mtime; int cnt; String thumb; long tmt; }

    private static final class DirStats extends SQLiteOpenHelper {
        DirStats(Context c) { super(c, "yev_dirstats.db", null, 1); }
        @Override public void onCreate(SQLiteDatabase d) {
            d.execSQL("CREATE TABLE IF NOT EXISTS ds(path TEXT PRIMARY KEY, mtime INTEGER, cnt INTEGER, thumb TEXT, tmt INTEGER)");
        }
        @Override public void onUpgrade(SQLiteDatabase d, int a, int b) { d.execSQL("DROP TABLE IF EXISTS ds"); onCreate(d); }

        /** Все сохранённые записи прямых подпапок parent. */
        Map<String, Row> children(String parent) {
            Map<String, Row> m = new HashMap<>();
            String p = parent.endsWith("/") ? parent : parent + "/";
            Cursor c = null;
            try {
                c = getReadableDatabase().query("ds", new String[]{"path", "mtime", "cnt", "thumb", "tmt"}, "path >= ? AND path < ?", new String[]{p, p + "\uffff"}, null, null, null);
                while (c.moveToNext()) {
                    String path = c.getString(0);
                    if (path.indexOf('/', p.length()) >= 0) continue;   // глубже одного уровня
                    Row r = new Row(); r.mtime = c.getLong(1); r.cnt = c.getInt(2); r.thumb = c.isNull(3) ? null : c.getString(3); r.tmt = c.getLong(4);
                    m.put(path.substring(p.length()), r);
                }
            } catch (Throwable ignored) {
            } finally { if (c != null) try { c.close(); } catch (Throwable ignored) {} }
            return m;
        }

        void put(String path, long mtime, int cnt, String thumb, long tmt) {
            try {
                android.content.ContentValues v = new android.content.ContentValues();
                v.put("path", path); v.put("mtime", mtime); v.put("cnt", cnt); v.put("thumb", thumb); v.put("tmt", tmt);
                getWritableDatabase().insertWithOnConflict("ds", null, v, SQLiteDatabase.CONFLICT_REPLACE);
            } catch (Throwable ignored) {}
        }
    }

    /** Заполняет count/thumb из базы там, где папка не менялась; остальное ставит в очередь пересчёта. */
    public void fillDirStats(String parentPath, List<Ent> ents, JSArray out) {
        String base = parentPath.endsWith("/") ? parentPath : parentPath + "/";
        Map<String, Row> cache = db.children(parentPath);
        List<String> todo = new ArrayList<>();
        try {
            for (int i = 0; i < ents.size(); i++) {
                Ent e = ents.get(i);
                if (!e.dir) continue;
                Row r = cache.get(e.name);
                JSObject o = (JSObject) out.get(i);
                if (r != null && r.mtime == e.mtime) {
                    o.put("count", r.cnt);
                    if (r.thumb != null) o.put("thumb", "file://" + r.thumb);
                } else todo.add(base + e.name);
            }
        } catch (Throwable ignored) {}
        wantedDir = parentPath;
        if (!todo.isEmpty()) scheduleStats(parentPath, todo);
        scheduleSizes(parentPath);
    }

    private void scheduleStats(final String parent, final List<String> dirs) {
        final List<String> fresh = new ArrayList<>();
        for (String d : dirs) if (statsPending.add(d)) fresh.add(d);
        if (fresh.isEmpty()) return;
        statsWorker.execute(() -> {
            JSArray items = new JSArray();
            long lastFlush = System.currentTimeMillis();
            for (String d : fresh) {
                try {
                    JSObject it = computeOne(d);
                    if (it != null) items.put(it);
                } catch (Throwable ignored) {
                } finally { statsPending.remove(d); }
                long now = System.currentTimeMillis();
                if (items.length() > 0 && (now - lastFlush > 180 || items.length() >= 60)) {
                    JSObject ev = new JSObject(); ev.put("dir", parent); ev.put("items", items); em.emit("dirStats", ev);
                    items = new JSArray(); lastFlush = now;
                }
            }
            if (items.length() > 0) { JSObject ev = new JSObject(); ev.put("dir", parent); ev.put("items", items); em.emit("dirStats", ev); }
        });
    }

    /** Считает объекты и обложку одной папки; пишет в базу; возвращает запись для события. */
    private JSObject computeOne(String path) {
        File f = new File(path);
        long mt;
        try { mt = Os.lstat(path).st_mtime * 1000L; } catch (Throwable t) { mt = f.lastModified(); }
        String[] kids = f.list();
        if (kids == null) return null;
        int cnt = 0; String thumb = null; long tmt = -1;
        String base = path.endsWith("/") ? path : path + "/";
        for (String k : kids) {
            if (k.startsWith(".")) continue;
            cnt++;
            if (IMG.matcher(k).matches()) {
                try {
                    StructStat st = Os.lstat(base + k);
                    if (!OsConstants.S_ISDIR(st.st_mode) && st.st_mtime * 1000L >= tmt) { tmt = st.st_mtime * 1000L; thumb = base + k; }
                } catch (Throwable ignored) {}
            }
        }
        db.put(path, mt, cnt, thumb, tmt);
        JSObject o = new JSObject();
        o.put("name", f.getName()); o.put("count", cnt);
        if (thumb != null) o.put("thumb", "file://" + thumb);
        return o;
    }

    /** Полный вес и число файлов каждой подпапки — из индекса файлов Android, без обхода диска. */
    private void scheduleSizes(final String parent) {
        Long last = sizesRecent.get(parent);
        long now = System.currentTimeMillis();
        if (last != null && now - last < 45000) return;     // недавно считали — ничего не менялось настолько, чтобы гонять индекс заново
        if (!parent.startsWith("/storage/")) return;
        sizesWorker.execute(() -> {
            if (!parent.equals(wantedDir)) return;           // уже ушли из папки
            Map<String, long[]> m = folderSizes(parent);
            if (m == null) return;
            sizesRecent.put(parent, System.currentTimeMillis());
            JSObject sizes = new JSObject();
            for (Map.Entry<String, long[]> e : m.entrySet()) {
                JSObject v = new JSObject(); v.put("bytes", e.getValue()[0]); v.put("files", e.getValue()[1]);
                sizes.put(e.getKey(), v);
            }
            JSObject ev = new JSObject(); ev.put("dir", parent); ev.put("sizes", sizes);
            em.emit("dirStats", ev);
        });
    }

    /** name -> {bytes, files} для прямых подпапок dir (рекурсивно по содержимому). */
    public Map<String, long[]> folderSizes(String dir) {
        String d = dir.endsWith("/") ? dir.substring(0, dir.length() - 1) : dir;
        Map<String, long[]> m = new HashMap<>();
        Cursor c = null;
        try {
            ContentResolver cr = ctx.getContentResolver();
            Uri u = MediaStore.Files.getContentUri("external");
            c = cr.query(u, new String[]{"_data", "_size"}, "_data LIKE ?", new String[]{d + "/%/%"}, null);
            if (c == null) return null;
            if (c.getCount() > 400000) return null;          // корень с сотнями тысяч файлов — не грузим
            int off = d.length() + 1;
            while (c.moveToNext()) {
                String p = c.getString(0);
                if (p == null || p.length() <= off) continue;
                int slash = p.indexOf('/', off);
                if (slash < 0) continue;                      // файл лежит прямо в dir — не подпапка
                String name = p.substring(off, slash);
                long sz = c.getLong(1);
                long[] acc = m.get(name);
                if (acc == null) { acc = new long[2]; m.put(name, acc); }
                acc[0] += Math.max(0, sz); acc[1]++;
            }
        } catch (Throwable t) {
            return null;
        } finally { if (c != null) try { c.close(); } catch (Throwable ignored) {} }
        return m;
    }

    /** Точечное чтение нескольких элементов папки (для событий «файл появился/изменился»). */
    public JSArray statMany(String dirPath, List<String> names) {
        String base = dirPath.endsWith("/") ? dirPath : dirPath + "/";
        JSArray arr = new JSArray();
        List<Ent> ents = new ArrayList<>();
        for (String n : names) {
            File f = new File(base + n);
            if (!f.exists()) continue;
            Ent e = statOne(base + n, n);
            ents.add(e);
            arr.put(entJson(e, base));
        }
        try {
            // папки: число объектов и обложка сразу из базы либо пересчёт в фоне
            Map<String, Row> cache = db.children(dirPath);
            List<String> todo = new ArrayList<>();
            for (int i = 0; i < ents.size(); i++) {
                Ent e = ents.get(i);
                if (!e.dir) continue;
                Row r = cache.get(e.name);
                JSObject o = (JSObject) arr.get(i);
                if (r != null && r.mtime == e.mtime) { o.put("count", r.cnt); if (r.thumb != null) o.put("thumb", "file://" + r.thumb); }
                else todo.add(base + e.name);
            }
            if (!todo.isEmpty()) scheduleStats(dirPath, todo);
        } catch (Throwable ignored) {}
        return arr;
    }

    /** Папка изменилась (наша операция) — сбросить кэш размеров, чтобы следующий заход пересчитал. */
    public void invalidateSizes(String dir) { if (dir != null) sizesRecent.remove(dir); }

    // ---------- поиск в два слоя ----------

    public static final class SearchOpts {
        public String query = "";
        public String types = "all";      // all|img|vid|aud|doc|apk|dir
        public long minSize = -1, maxSize = -1;
        public long from = -1, to = -1;   // мс
        public boolean hidden = false;
    }

    private final Map<String, SearchRun> searches = new ConcurrentHashMap<>();

    private static final Set<String> EXT_IMG = new HashSet<>(java.util.Arrays.asList("jpg","jpeg","png","webp","gif","bmp","avif","heic","heif","tif","tiff","jxl","dng","cr2","cr3","nef","nrw","arw","orf","rw2","pef","srw","raf","x3f","svg","ico","psd","tga","apng"));
    private static final Set<String> EXT_VID = new HashSet<>(java.util.Arrays.asList("mp4","m4v","mkv","webm","avi","mov","qt","wmv","flv","f4v","3gp","3g2","mpg","mpeg","mpe","m2v","ts","m2ts","mts","vob","ogv","divx","asf"));
    private static final Set<String> EXT_AUD = new HashSet<>(java.util.Arrays.asList("mp3","flac","wav","ogg","oga","opus","m4a","aac","wma","alac","aiff","aif","ape","mid","midi","amr","mka","dsf"));
    private static final Set<String> EXT_DOC = new HashSet<>(java.util.Arrays.asList("pdf","txt","md","csv","log","json","xml","html","htm","doc","docx","xls","xlsx","ppt","pptx","odt","ods","odp","rtf","epub","fb2","mobi","djvu","tex"));
    private static final Set<String> EXT_APK = new HashSet<>(java.util.Arrays.asList("apk","aab","apks","apkm","xapk"));

    private static String extOf(String n) { int d = n.lastIndexOf('.'); return d < 0 ? "" : n.substring(d + 1).toLowerCase(Locale.ROOT); }

    static boolean typeOk(String types, String name, boolean dir) {
        if (types == null || types.equals("all")) return true;
        if (types.equals("dir")) return dir;
        if (dir) return false;
        String e = extOf(name);
        switch (types) {
            case "img": return EXT_IMG.contains(e);
            case "vid": return EXT_VID.contains(e);
            case "aud": return EXT_AUD.contains(e);
            case "doc": return EXT_DOC.contains(e);
            case "apk": return EXT_APK.contains(e);
            default: return true;
        }
    }

    /** Маска имени: * и ? как в обычных масках; без них — «содержит». */
    static Pattern namePattern(String q) {
        String s = q == null ? "" : q.trim();
        if (s.isEmpty()) return Pattern.compile(".*");
        if (s.indexOf('*') < 0 && s.indexOf('?') < 0) return Pattern.compile(".*" + Pattern.quote(s) + ".*", Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);
        StringBuilder sb = new StringBuilder();
        for (char ch : s.toCharArray()) {
            if (ch == '*') sb.append(".*");
            else if (ch == '?') sb.append('.');
            else sb.append(Pattern.quote(String.valueOf(ch)));
        }
        return Pattern.compile(sb.toString(), Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);
    }

    private final class SearchRun {
        final String id; final List<String> roots; final SearchOpts o; final Pattern pat;
        final AtomicBoolean cancelled = new AtomicBoolean(false);
        final AtomicInteger pending = new AtomicInteger(0);
        final Set<String> seen = Collections.newSetFromMap(new ConcurrentHashMap<String, Boolean>());
        final List<JSObject> buf = new ArrayList<>();
        final ThreadPoolExecutor pool;
        final AtomicInteger total = new AtomicInteger(0);
        volatile long lastFlush = System.currentTimeMillis();
        final Object flushLock = new Object();
        Thread flusher;

        SearchRun(String id, List<String> roots, SearchOpts o) {
            this.id = id; this.roots = roots; this.o = o; this.pat = namePattern(o.query);
            this.pool = new ThreadPoolExecutor(4, 4, 30, TimeUnit.SECONDS, new LinkedBlockingDeque<Runnable>());
            this.pool.allowCoreThreadTimeOut(true);
        }

        boolean matches(String name, boolean dir, long size, long mtime) {
            if (!o.hidden && name.startsWith(".")) return false;
            if (!pat.matcher(name).matches()) return false;
            if (!typeOk(o.types, name, dir)) return false;
            if (!dir) {
                if (o.minSize >= 0 && size < o.minSize) return false;
                if (o.maxSize >= 0 && size > o.maxSize) return false;
            }
            if (o.from >= 0 && mtime < o.from) return false;
            if (o.to >= 0 && mtime > o.to) return false;
            return true;
        }

        void found(String full, String name, boolean dir, long size, long mtime) {
            if (!seen.add(full)) return;
            JSObject it = new JSObject();
            it.put("name", name); it.put("type", dir ? "directory" : "file"); it.put("size", size); it.put("mtime", mtime);
            it.put("uri", "file://" + full);
            int slash = full.lastIndexOf('/');
            it.put("dir", slash > 0 ? full.substring(0, slash) : "/");
            total.incrementAndGet();
            synchronized (buf) { buf.add(it); }
            maybeFlush(false);
        }

        void maybeFlush(boolean force) {
            long now = System.currentTimeMillis();
            List<JSObject> take = null;
            synchronized (buf) {
                if (buf.isEmpty()) return;
                if (force || now - lastFlush > 600 || buf.size() >= 300) { take = new ArrayList<>(buf); buf.clear(); lastFlush = now; }
            }
            if (take == null) return;
            JSArray arr = new JSArray(); for (JSObject j : take) arr.put(j);
            JSObject ev = new JSObject(); ev.put("id", id); ev.put("items", arr); ev.put("total", total.get());
            em.emit("searchFound", ev);
        }

        void start() {
            // слой 1: индекс файлов Android — ответ за доли секунды
            pending.incrementAndGet();
            pool.execute(() -> { try { indexLayer(); } catch (Throwable ignored) {} finally { done(); } });
            // слой 2: обход диска
            for (String r : roots) submitDir(new File(r), 0);
            flusher = new Thread(() -> {
                try { while (!cancelled.get() && pending.get() > 0) { Thread.sleep(500); maybeFlush(true); } } catch (InterruptedException ignored) {}
            }, "yev-search-flush");
            flusher.setDaemon(true); flusher.start();
        }

        void indexLayer() {
            if (cancelled.get()) return;
            Cursor c = null;
            try {
                StringBuilder where = new StringBuilder();
                List<String> args = new ArrayList<>();
                String q = o.query == null ? "" : o.query.trim();
                if (!q.isEmpty()) {
                    String like = q.replace("%", "\\%").replace("_", "\\_").replace('*', '%').replace('?', '_');
                    if (q.indexOf('*') < 0 && q.indexOf('?') < 0) like = "%" + like + "%";
                    where.append("_display_name LIKE ? ESCAPE '\\'"); args.add(like);
                }
                if (roots.size() == 1) {
                    if (where.length() > 0) where.append(" AND ");
                    String r = roots.get(0); if (r.endsWith("/")) r = r.substring(0, r.length() - 1);
                    where.append("_data LIKE ?"); args.add(r + "/%");
                }
                if (o.minSize >= 0) { if (where.length() > 0) where.append(" AND "); where.append("_size >= ?"); args.add(String.valueOf(o.minSize)); }
                if (o.maxSize >= 0) { if (where.length() > 0) where.append(" AND "); where.append("_size <= ?"); args.add(String.valueOf(o.maxSize)); }
                if (o.from >= 0) { if (where.length() > 0) where.append(" AND "); where.append("date_modified >= ?"); args.add(String.valueOf(o.from / 1000)); }
                if (o.to >= 0) { if (where.length() > 0) where.append(" AND "); where.append("date_modified <= ?"); args.add(String.valueOf(o.to / 1000)); }
                if (where.length() == 0) where.append("1=1");
                c = ctx.getContentResolver().query(MediaStore.Files.getContentUri("external"), new String[]{"_data", "_display_name", "_size", "date_modified", "media_type"},
                        where.toString(), args.toArray(new String[0]), "date_modified DESC");
                if (c == null) return;
                int n = 0;
                while (c.moveToNext() && !cancelled.get() && n < 5000) {
                    String p = c.getString(0); if (p == null) continue;
                    String name = c.getString(1); if (name == null) { int s = p.lastIndexOf('/'); name = s >= 0 ? p.substring(s + 1) : p; }
                    boolean dir = false;
                    try { dir = c.getInt(4) == 0 && new File(p).isDirectory(); } catch (Throwable ignored) {}
                    if (dir && !o.hidden) { /* папки из индекса — только по имени */ }
                    long size = c.getLong(2), mt = c.getLong(3) * 1000L;
                    if (!matches(name, dir, size, mt)) continue;
                    if (!new File(p).exists()) continue;       // индекс может отставать
                    found(p, name, dir, size, mt); n++;
                }
            } catch (Throwable ignored) {
            } finally { if (c != null) try { c.close(); } catch (Throwable ignored) {} }
        }

        void submitDir(final File d, final int depth) {
            if (cancelled.get() || depth > 40) return;
            pending.incrementAndGet();
            try {
                pool.execute(() -> {
                    try { walk(d, depth); } catch (Throwable ignored) {} finally { done(); }
                });
            } catch (Throwable t) { done(); }
        }

        void walk(File d, int depth) {
            if (cancelled.get()) return;
            List<Ent> ents = readDir(d);
            if (ents == null) return;
            String base = d.getAbsolutePath(); if (!base.endsWith("/")) base += "/";
            for (Ent e : ents) {
                if (cancelled.get()) return;
                if (matches(e.name, e.dir, e.size, e.mtime)) found(base + e.name, e.name, e.dir, e.size, e.mtime);
                if (e.dir && !e.link) {
                    if (!o.hidden && e.name.startsWith(".")) continue;
                    submitDir(new File(base + e.name), depth + 1);
                }
            }
        }

        void done() {
            if (pending.decrementAndGet() <= 0) {
                maybeFlush(true);
                JSObject ev = new JSObject(); ev.put("id", id); ev.put("total", total.get()); ev.put("cancelled", cancelled.get());
                em.emit("searchDone", ev);
                searches.remove(id);
                pool.shutdown();
            }
        }

        void cancel() {
            cancelled.set(true);
            try { pool.shutdownNow(); } catch (Throwable ignored) {}
            searches.remove(id);
            JSObject ev = new JSObject(); ev.put("id", id); ev.put("total", total.get()); ev.put("cancelled", true);
            em.emit("searchDone", ev);
        }
    }

    public void startSearch(String id, List<String> roots, SearchOpts o) {
        SearchRun old = searches.remove(id);
        if (old != null) old.cancelled.set(true);
        SearchRun r = new SearchRun(id, roots, o);
        searches.put(id, r);
        r.start();
    }

    public void stopSearch(String id) {
        SearchRun r = searches.get(id);
        if (r != null) r.cancel();
    }

    public void stopAllSearches() { for (SearchRun r : new ArrayList<>(searches.values())) r.cancel(); }
}
