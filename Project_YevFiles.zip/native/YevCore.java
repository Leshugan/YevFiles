package leshugan.fm;

import android.content.ContentResolver;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.net.Uri;
import android.provider.MediaStore;
import android.system.ErrnoException;
import android.system.Os;
import android.system.OsConstants;
import android.system.StructStat;

import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.LinkedBlockingDeque;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.regex.Pattern;

/**
 * Ядро чтения папок.
 *  - readDir: один системный запрос (lstat) на элемент вместо трёх, без обхода подпапок
 *  - DirStats: число объектов и обложка каждой папки хранятся в базе и не пересчитываются,
 *    пока не изменилась сама папка (её дата изменения)
 *  - folderSizes: полный размер подпапок одним запросом к индексу файлов Android
 *  - search: два слоя — мгновенный ответ индекса Android, затем обход диска несколькими потоками
 */
public final class YevCore {

    public interface Emitter { void emit(String event, JSObject data); }

    public static final class Ent {
        public final String name; public final boolean dir; public final long size; public final long mtime; public final boolean link;
        Ent(String name, boolean dir, long size, long mtime, boolean link) { this.name = name; this.dir = dir; this.size = size; this.mtime = mtime; this.link = link; }
    }

    private static final Pattern IMG = Pattern.compile(".*\\.(jpg|jpeg|png|webp|gif|bmp|avif|heic|heif|jfif)$", Pattern.CASE_INSENSITIVE);
    private static final Pattern VID = Pattern.compile(".*\\.(mp4|mkv|webm|avi|mov|3gp|m4v|ts|flv|wmv|mpg|mpeg)$", Pattern.CASE_INSENSITIVE);

    private final Context ctx;
    private final Emitter em;
    private final DirStats db;
    private final ExecutorService statsWorker = Executors.newSingleThreadExecutor(r -> { Thread t = new Thread(r, "yev-dirstats"); t.setPriority(Thread.MIN_PRIORITY + 1); t.setDaemon(true); return t; });
    private final ExecutorService sizesWorker = Executors.newSingleThreadExecutor(r -> { Thread t = new Thread(r, "yev-foldersizes"); t.setPriority(Thread.MIN_PRIORITY + 1); t.setDaemon(true); return t; });
    private volatile boolean sizesOn = false;             // считать ли вес папок
    public void setSizesOn(boolean on) {
        boolean was = sizesOn;
        sizesOn = on;
        if (on && !was) {                       // раньше вес не считали — просим пересчитать всё, что без него
            try { db.getWritableDatabase().execSQL("UPDATE ds SET mtime = -1 WHERE bytes IS NULL OR bytes < 0"); } catch (Throwable ignored) {}
        }
    }
    private final Map<String, Long> verifiedAt = new java.util.concurrent.ConcurrentHashMap<>();
    private final Set<String> statsPending = Collections.newSetFromMap(new ConcurrentHashMap<String, Boolean>());
    private final Map<String, Long> sizesRecent = new ConcurrentHashMap<>();
    private volatile String wantedDir = "";      // папка, которая сейчас на экране — её задачи важнее

    public YevCore(Context ctx, Emitter em) {
        this.ctx = ctx.getApplicationContext();
        this.em = em;
        this.db = new DirStats(this.ctx);
    }

    // ---------- одно чтение папки ----------

    /** Список папки: имя, тип, размер, дата за один запрос на элемент. null — прочитать нельзя. */
    public static List<Ent> readDir(File dir) { return readDir(dir, dir.list()); }

    public static List<Ent> readDir(File dir, String[] names) {
        if (names == null) return null;
        List<Ent> out = new ArrayList<>(names.length);
        String base = dir.getAbsolutePath();
        if (!base.endsWith("/")) base += "/";
        for (String n : names) out.add(statOne(base + n, n));
        return out;
    }

    public static Ent statOne(String full, String name) {
        try {
            StructStat st = Os.lstat(full);
            boolean link = OsConstants.S_ISLNK(st.st_mode);
            if (link) { try { st = Os.stat(full); } catch (ErrnoException ignored) {} }
            boolean d = OsConstants.S_ISDIR(st.st_mode);
            return new Ent(name, d, d ? 0L : st.st_size, st.st_mtime * 1000L, link);
        } catch (Throwable t) {
            File f = new File(full);
            boolean d = f.isDirectory();
            return new Ent(name, d, d ? 0L : f.length(), f.lastModified(), false);
        }
    }

    public static JSObject entJson(Ent e, String base) {
        JSObject o = new JSObject();
        o.put("name", e.name);
        o.put("type", e.dir ? "directory" : "file");
        o.put("size", e.size);
        o.put("mtime", e.mtime);
        o.put("uri", "file://" + base + e.name);
        if (e.link) o.put("link", true);
        return o;
    }

    // ---------- база: число объектов и обложка папки ----------

    static final class Row { long mtime; int cnt; String thumb; long tmt; long bytes; long deep; }

    private static final class DirStats extends SQLiteOpenHelper {
        DirStats(Context c) { super(c, "yev_dirstats.db", null, 3); }
        @Override public void onCreate(SQLiteDatabase d) {
            d.execSQL("CREATE TABLE IF NOT EXISTS ds(path TEXT PRIMARY KEY, mtime INTEGER, cnt INTEGER, thumb TEXT, tmt INTEGER, bytes INTEGER, deep INTEGER)");
        }
        @Override public void onUpgrade(SQLiteDatabase d, int a, int b) { d.execSQL("DROP TABLE IF EXISTS ds"); onCreate(d); }

        /** Поправить вес и число объектов на разницу — без обхода. */
        void bump(String path, long delta, int fileDelta) {
            try {
                getWritableDatabase().execSQL(
                        "UPDATE ds SET bytes = CASE WHEN bytes >= 0 THEN MAX(0, bytes + ?) ELSE bytes END" +
                        (fileDelta != 0 ? ", cnt = MAX(0, cnt + ?)" : "") + " WHERE path = ?",
                        fileDelta != 0 ? new Object[]{ delta, fileDelta, path } : new Object[]{ delta, path });
            } catch (Throwable ignored) {}
        }

        /** Все сохранённые записи прямых подпапок parent. */
        Map<String, Row> children(String parent) {
            Map<String, Row> m = new HashMap<>();
            String p = parent.endsWith("/") ? parent : parent + "/";
            Cursor c = null;
            try {
                c = getReadableDatabase().query("ds", new String[]{"path", "mtime", "cnt", "thumb", "tmt", "bytes", "deep"}, "path >= ? AND path < ?", new String[]{p, p + "\uffff"}, null, null, null);
                while (c.moveToNext()) {
                    String path = c.getString(0);
                    if (path.indexOf('/', p.length()) >= 0) continue;   // глубже одного уровня
                    Row r = new Row(); r.mtime = c.getLong(1); r.cnt = c.getInt(2); r.thumb = c.isNull(3) ? null : c.getString(3); r.tmt = c.getLong(4); r.bytes = c.isNull(5) ? -1 : c.getLong(5); r.deep = c.isNull(6) ? -1 : c.getLong(6);
                    m.put(path.substring(p.length()), r);
                }
            } catch (Throwable ignored) {
            } finally { if (c != null) try { c.close(); } catch (Throwable ignored) {} }
            return m;
        }

        void put(String path, long mtime, int cnt, String thumb, long tmt, long bytes, long deep) {
            try {
                android.content.ContentValues v = new android.content.ContentValues();
                v.put("path", path); v.put("mtime", mtime); v.put("cnt", cnt); v.put("thumb", thumb); v.put("tmt", tmt); v.put("bytes", bytes); v.put("deep", deep);
                getWritableDatabase().insertWithOnConflict("ds", null, v, SQLiteDatabase.CONFLICT_REPLACE);
            } catch (Throwable ignored) {}
        }
    }

    /** Заполняет count/thumb из базы там, где папка не менялась; остальное ставит в очередь пересчёта. */
    public void fillDirStats(String parentPath, List<Ent> ents, JSArray out) {
        String base = parentPath.endsWith("/") ? parentPath : parentPath + "/";
        Map<String, Row> cache = db.children(parentPath);
        List<String> todo = new ArrayList<>();
        List<Object[]> check = new ArrayList<>();
        try {
            for (int i = 0; i < ents.size(); i++) {
                Ent e = ents.get(i);
                if (!e.dir) continue;
                Row r = cache.get(e.name);
                JSObject o = (JSObject) out.get(i);
                if (r != null && r.mtime == e.mtime) {
                    o.put("count", r.cnt);
                    if (r.bytes >= 0) o.put("bytes", r.bytes);
                    if (r.thumb != null) o.put("thumb", "file://" + r.thumb);
                    if (sizesOn && r.deep > 0) check.add(new Object[]{ base + e.name, r.deep });   // сверим, не трогали ли внутри
                } else todo.add(base + e.name);
            }
        } catch (Throwable ignored) {}
        wantedDir = parentPath;
        if (sizesOn) scheduleSizes(parentPath);            // мгновенные цифры из индекса, точный обход уточнит следом
        if (!todo.isEmpty()) scheduleStats(parentPath, todo);
        if (!check.isEmpty()) scheduleVerify(parentPath, check);
    }

    /**
     * Тихая сверка: обходим только папки внутри (файлы не читаем) и берём самую свежую отметку.
     * Совпала с сохранённой — внутри ничего не меняли, вес верен. Разошлась — пересчитываем эту ветку.
     */
    private void scheduleVerify(final String parent, final List<Object[]> items) {
        // За один заход проверяем ОДНУ папку — ту, что дольше всех не проверялась.
        // Так расхождения сами вычищаются со временем, а телефон не греется.
        Object[] pick = null; long oldest = Long.MAX_VALUE;
        for (Object[] it : items) {
            String path = (String) it[0];
            Long last = verifiedAt.get(path);
            long t = last == null ? 0 : last;
            if (t < oldest) { oldest = t; pick = it; }
        }
        if (pick == null) return;
        final String path = (String) pick[0];
        final long known = (Long) pick[1];
        if (System.currentTimeMillis() - oldest < 60000) return;    // недавно смотрели — не трогаем
        verifiedAt.put(path, System.currentTimeMillis());
        statsWorker.execute(() -> {
            if (!parent.equals(wantedDir)) return;                  // ушли из папки — бросаем
            try {
                if (deepMark(new File(path)) != known && parent.equals(wantedDir)) {
                    scheduleStats(parent, java.util.Collections.singletonList(path));
                }
            } catch (Throwable ignored) {}
        });
    }

    private void scheduleStats(final String parent, final List<String> dirs) {
        final List<String> fresh = new ArrayList<>();
        for (String d : dirs) if (statsPending.add(d)) fresh.add(d);
        if (fresh.isEmpty()) return;
        statsWorker.execute(() -> {
            JSArray items = new JSArray();
            long lastFlush = System.currentTimeMillis();
            for (String d : fresh) {
                try {
                    JSObject it = computeOne(d);
                    if (it != null) items.put(it);
                } catch (Throwable ignored) {
                } finally { statsPending.remove(d); }
                long now = System.currentTimeMillis();
                if (items.length() > 0 && (now - lastFlush > 180 || items.length() >= 60)) {
                    JSObject ev = new JSObject(); ev.put("dir", parent); ev.put("items", items); em.emit("dirStats", ev);
                    items = new JSArray(); lastFlush = now;
                }
            }
            if (items.length() > 0) { JSObject ev = new JSObject(); ev.put("dir", parent); ev.put("items", items); em.emit("dirStats", ev); }
        });
    }

    /** Считает объекты и обложку одной папки; пишет в базу; возвращает запись для события. */
    private JSObject computeOne(String path) {
        File f = new File(path);
        long mt;
        try { mt = Os.lstat(path).st_mtime * 1000L; } catch (Throwable t) { mt = f.lastModified(); }
        String[] kids = f.list();
        if (kids == null) return null;
        int cnt = 0; String thumb = null; long tmt = -1;
        String vidThumb = null; long vmt = -1;
        java.util.List<String> subDirs = new ArrayList<>();
        String base = path.endsWith("/") ? path : path + "/";
        for (String k : kids) {
            cnt++;                                   // скрытые входят в число объектов — вес их тоже считает
            if (k.startsWith(".")) continue;         // но обложку из скрытых не берём
            boolean img = IMG.matcher(k).matches(), vid = VID.matcher(k).matches();
            if (!img && !vid) {
                if (subDirs.size() < 6 && new File(base + k).isDirectory()) subDirs.add(base + k);
                continue;
            }
            try {
                StructStat st = Os.lstat(base + k);
                if (OsConstants.S_ISDIR(st.st_mode)) continue;
                long kt = st.st_mtime * 1000L;
                if (img) { if (kt >= tmt) { tmt = kt; thumb = base + k; } }
                else if (kt >= vmt) { vmt = kt; vidThumb = base + k; }
            } catch (Throwable ignored) {}
        }
        // ничего не нашли рядом — заглянем на уровень ниже, чтобы у папки с подпапками тоже была картинка
        if (thumb == null && vidThumb == null) {
            for (String sd : subDirs) {
                String[] inner = new File(sd).list();
                if (inner == null) continue;
                String ib = sd.endsWith("/") ? sd : sd + "/";
                for (String k : inner) {
                    if (k.startsWith(".")) continue;
                    boolean img = IMG.matcher(k).matches(), vid = VID.matcher(k).matches();
                    if (!img && !vid) continue;
                    File f2 = new File(ib + k);
                    if (!f2.isFile()) continue;
                    if (img) { thumb = ib + k; break; }
                    if (vidThumb == null) vidThumb = ib + k;
                }
                if (thumb != null) break;
            }
        }
        if (thumb == null) thumb = vidThumb;
        long bytes = -1, deep = -1;
        if (sizesOn) { long[] sum = folderSum(f); bytes = sum[0]; deep = sum[1]; }   // выключено — диск не обходим
        db.put(path, mt, cnt, thumb, tmt, bytes, deep);
        JSObject o = new JSObject();
        o.put("name", f.getName()); o.put("count", cnt);
        if (bytes >= 0) o.put("bytes", bytes);
        if (thumb != null) o.put("thumb", "file://" + thumb);
        return o;
    }

    /**
     * Вес папки — настоящим обходом (индекс Android знает не про все файлы и врёт).
     * У обхода есть предел по времени и числу файлов, чтобы не подвиснуть на огромном дереве.
     */
    private static long[] folderSum(File dir) {
        final long[] acc = new long[]{ 0, 0, 0 };       // вес, число файлов, отметка глубокой правки
        try {
            if (android.os.Build.VERSION.SDK_INT >= 26) {
                java.nio.file.Files.walkFileTree(dir.toPath(), java.util.EnumSet.noneOf(java.nio.file.FileVisitOption.class), 40,
                        new java.nio.file.SimpleFileVisitor<java.nio.file.Path>() {
                    @Override public java.nio.file.FileVisitResult preVisitDirectory(java.nio.file.Path p, java.nio.file.attribute.BasicFileAttributes a) {
                        long m = a.lastModifiedTime().toMillis();
                        if (m > acc[2]) acc[2] = m;
                        return java.nio.file.FileVisitResult.CONTINUE;
                    }
                    @Override public java.nio.file.FileVisitResult visitFile(java.nio.file.Path p, java.nio.file.attribute.BasicFileAttributes a) {
                        if (!a.isDirectory()) { acc[0] += a.size(); acc[1]++; }
                        return java.nio.file.FileVisitResult.CONTINUE;
                    }
                    @Override public java.nio.file.FileVisitResult visitFileFailed(java.nio.file.Path p, java.io.IOException e) { return java.nio.file.FileVisitResult.CONTINUE; }
                });
                return new long[]{ acc[0], acc[2] };
            }
            walkOld(dir, acc);
            return new long[]{ acc[0], acc[2] };
        } catch (Throwable t) { return new long[]{ acc[0], acc[2] }; }
    }

    private static void walkOld(File dir, long[] acc) { walkOld(dir, acc, 0); }

    private static void walkOld(File dir, long[] acc, int depth) {
        if (depth > 40) return;
        long m = dir.lastModified();
        if (m > acc[2]) acc[2] = m;
        File[] kids = dir.listFiles();
        if (kids == null) return;
        for (File k : kids) {
            if (k.isDirectory()) { if (!YevXfer.isLink(k)) walkOld(k, acc, depth + 1); }   // в ссылку-папку не заходим — иначе двойной счёт и круги
            else { acc[0] += k.length(); acc[1]++; }
        }
    }

    /** Отметка о самой глубокой правке сейчас: обходим только папки, файлы не трогаем. */
    private static long deepMark(File dir) {
        final long[] acc = new long[]{ 0 };
        try {
            if (android.os.Build.VERSION.SDK_INT >= 26) {
                java.nio.file.Files.walkFileTree(dir.toPath(), java.util.EnumSet.noneOf(java.nio.file.FileVisitOption.class), 40,
                        new java.nio.file.SimpleFileVisitor<java.nio.file.Path>() {
                    @Override public java.nio.file.FileVisitResult preVisitDirectory(java.nio.file.Path p, java.nio.file.attribute.BasicFileAttributes a) {
                        long m = a.lastModifiedTime().toMillis();
                        if (m > acc[0]) acc[0] = m;
                        return java.nio.file.FileVisitResult.CONTINUE;
                    }
                    @Override public java.nio.file.FileVisitResult visitFile(java.nio.file.Path p, java.nio.file.attribute.BasicFileAttributes a) { return java.nio.file.FileVisitResult.CONTINUE; }
                    @Override public java.nio.file.FileVisitResult visitFileFailed(java.nio.file.Path p, java.io.IOException e) { return java.nio.file.FileVisitResult.CONTINUE; }
                });
                return acc[0];
            }
            deepOld(dir, acc);
            return acc[0];
        } catch (Throwable t) { return acc[0]; }
    }

    private static void deepOld(File dir, long[] acc) { deepOld(dir, acc, 0); }

    private static void deepOld(File dir, long[] acc, int depth) {
        if (depth > 40) return;
        long m = dir.lastModified();
        if (m > acc[0]) acc[0] = m;
        File[] kids = dir.listFiles();
        if (kids == null) return;
        for (File k : kids) if (k.isDirectory() && !YevXfer.isLink(k)) deepOld(k, acc, depth + 1);
    }

    /** Полный вес и число файлов каждой подпапки — из индекса файлов Android, без обхода диска. */
    private void scheduleSizes(final String parent) {
        Long last = sizesRecent.get(parent);
        long now = System.currentTimeMillis();
        if (last != null && now - last < 45000) return;     // недавно считали — ничего не менялось настолько, чтобы гонять индекс заново
        if (!parent.startsWith("/storage/")) return;
        sizesWorker.execute(() -> {
            if (!parent.equals(wantedDir)) return;           // уже ушли из папки
            Map<String, long[]> m = folderSizes(parent);
            if (m == null) return;
            long now2 = System.currentTimeMillis();
            sizesRecent.put(parent, now2);
            Map<String, Row> cache = db.children(parent);
            String base2 = parent.endsWith("/") ? parent : parent + "/";
            int kicked = 0;
            JSObject sizes = new JSObject();
            for (Map.Entry<String, long[]> e : m.entrySet()) {
                JSObject v = new JSObject(); v.put("bytes", e.getValue()[0]); v.put("files", e.getValue()[1]);
                sizes.put(e.getKey(), v);
                // Книжка сильно разошлась с индексом: дозапись в файлы отметками времени не видна,
                // поэтому такую папку отправляем на честный пересчёт — не чаще раза в минуту, по паре за заход.
                Row r = cache.get(e.getKey());
                if (r != null && r.bytes >= 0 && kicked < 2) {
                    long diff = Math.abs(r.bytes - e.getValue()[0]);
                    if (diff > Math.max(1000000L, r.bytes / 50)) {
                        String full = base2 + e.getKey();
                        Long last = verifiedAt.get(full);
                        if (last == null || now2 - last > 60000) {
                            verifiedAt.put(full, now2); kicked++;
                            scheduleStats(parent, java.util.Collections.singletonList(full));
                        }
                    }
                }
            }
            JSObject ev = new JSObject(); ev.put("dir", parent); ev.put("sizes", sizes);
            em.emit("dirStats", ev);
        });
    }

    /** name -> {bytes, files} для прямых подпапок dir (рекурсивно по содержимому). */
    public Map<String, long[]> folderSizes(String dir) {
        String d = dir.endsWith("/") ? dir.substring(0, dir.length() - 1) : dir;
        Map<String, long[]> m = new HashMap<>();
        Cursor c = null;
        try {
            ContentResolver cr = ctx.getContentResolver();
            Uri u = MediaStore.Files.getContentUri("external");
            c = cr.query(u, new String[]{"_data", "_size"}, "_data LIKE ?", new String[]{d + "/%/%"}, null);
            if (c == null) return null;
            if (c.getCount() > 400000) return null;          // корень с сотнями тысяч файлов — не грузим
            int off = d.length() + 1;
            while (c.moveToNext()) {
                String p = c.getString(0);
                if (p == null || p.length() <= off) continue;
                int slash = p.indexOf('/', off);
                if (slash < 0) continue;                      // файл лежит прямо в dir — не подпапка
                String name = p.substring(off, slash);
                long sz = c.getLong(1);
                long[] acc = m.get(name);
                if (acc == null) { acc = new long[2]; m.put(name, acc); }
                acc[0] += Math.max(0, sz); acc[1]++;
            }
        } catch (Throwable t) {
            return null;
        } finally { if (c != null) try { c.close(); } catch (Throwable ignored) {} }
        return m;
    }

    /** Точечное чтение нескольких элементов папки (для событий «файл появился/изменился»). */
    public JSArray statMany(String dirPath, List<String> names) {
        String base = dirPath.endsWith("/") ? dirPath : dirPath + "/";
        JSArray arr = new JSArray();
        List<Ent> ents = new ArrayList<>();
        for (String n : names) {
            File f = new File(base + n);
            if (!f.exists()) continue;
            Ent e = statOne(base + n, n);
            ents.add(e);
            arr.put(entJson(e, base));
        }
        try {
            // папки: число объектов и обложка сразу из базы либо пересчёт в фоне
            Map<String, Row> cache = db.children(dirPath);
            List<String> todo = new ArrayList<>();
            for (int i = 0; i < ents.size(); i++) {
                Ent e = ents.get(i);
                if (!e.dir) continue;
                Row r = cache.get(e.name);
                JSObject o = (JSObject) arr.get(i);
                if (r != null && r.mtime == e.mtime) { o.put("count", r.cnt); if (r.bytes >= 0) o.put("bytes", r.bytes); if (r.thumb != null) o.put("thumb", "file://" + r.thumb); }
                else todo.add(base + e.name);
            }
            if (!todo.isEmpty()) scheduleStats(dirPath, todo);
        } catch (Throwable ignored) {}
        return arr;
    }

    /** Папка изменилась (наша операция) — сбросить кэш размеров, чтобы следующий заход пересчитал. */
    public void invalidateSizes(String dir) { if (dir != null) sizesRecent.remove(dir); }

    /**
     * Прибавить (или отнять) вес по всей цепочке папок вверх — так вес остаётся верным
     * после наших операций и после чужих изменений, замеченных на лету, без единого обхода.
     */
    /** Пометить папку и всю цепочку родителей «пересчитать при следующем заходе» (после операций, где разницу не посчитать точно). */
    public void invalidate(String path) {
        try {
            File p = new File(path);
            if (!p.isDirectory()) p = p.getParentFile();
            for (int d = 0; p != null && d < 40; d++, p = p.getParentFile()) {
                try { db.getWritableDatabase().execSQL("UPDATE ds SET mtime = -1 WHERE path = ?", new Object[]{ p.getAbsolutePath() }); } catch (Throwable ignored) {}
                String ap = p.getAbsolutePath();
                if ("/storage/emulated".equals(ap) || "/storage".equals(ap) || "/".equals(ap)) break;
            }
        } catch (Throwable ignored) {}
    }

    public void addBytes(String path, long delta, int fileDelta) {
        if (!sizesOn || path == null || (delta == 0 && fileDelta == 0)) return;
        try {
            File f = new File(path);
            File p = f.isDirectory() ? f : f.getParentFile();
            for (int depth = 0; p != null && depth < 40; depth++, p = p.getParentFile()) {
                // вес правим по всей цепочке, число объектов — только у ближайшей папки
                db.bump(p.getAbsolutePath(), delta, depth == 0 ? fileDelta : 0);
                if ("/storage/emulated".equals(p.getAbsolutePath()) || "/storage".equals(p.getAbsolutePath()) || "/".equals(p.getAbsolutePath())) break;
            }
        } catch (Throwable ignored) {}
    }

    // ---------- поиск в два слоя ----------

    public static final class SearchOpts {
        public String query = "";
        public String types = "all";      // all|img|vid|aud|doc|apk|dir
        public long minSize = -1, maxSize = -1;
        public long from = -1, to = -1;   // мс
        public boolean hidden = false;
        public boolean deep = true;       // false — только сама папка, без подпапок
    }

    private final Map<String, SearchRun> searches = new ConcurrentHashMap<>();

    private static final Set<String> EXT_IMG = new HashSet<>(java.util.Arrays.asList("jpg","jpeg","png","webp","gif","bmp","avif","heic","heif","tif","tiff","jxl","dng","cr2","cr3","nef","nrw","arw","orf","rw2","pef","srw","raf","x3f","svg","ico","psd","tga","apng"));
    private static final Set<String> EXT_VID = new HashSet<>(java.util.Arrays.asList("mp4","m4v","mkv","webm","avi","mov","qt","wmv","flv","f4v","3gp","3g2","mpg","mpeg","mpe","m2v","ts","m2ts","mts","vob","ogv","divx","asf"));
    private static final Set<String> EXT_AUD = new HashSet<>(java.util.Arrays.asList("mp3","flac","wav","ogg","oga","opus","m4a","aac","wma","alac","aiff","aif","ape","mid","midi","amr","mka","dsf"));
    private static final Set<String> EXT_DOC = new HashSet<>(java.util.Arrays.asList("pdf","txt","md","csv","log","json","xml","html","htm","doc","docx","xls","xlsx","ppt","pptx","odt","ods","odp","rtf","epub","fb2","mobi","djvu","tex"));
    private static final Set<String> EXT_APK = new HashSet<>(java.util.Arrays.asList("apk","aab","apks","apkm","xapk"));

    private static String extOf(String n) { int d = n.lastIndexOf('.'); return d < 0 ? "" : n.substring(d + 1).toLowerCase(Locale.ROOT); }

    static boolean typeOk(String types, String name, boolean dir) {
        if (types == null || types.equals("all")) return true;
        if (types.equals("dir")) return dir;
        if (dir) return false;
        String e = extOf(name);
        switch (types) {
            case "img": return EXT_IMG.contains(e);
            case "vid": return EXT_VID.contains(e);
            case "aud": return EXT_AUD.contains(e);
            case "doc": return EXT_DOC.contains(e);
            case "apk": return EXT_APK.contains(e);
            default: return true;
        }
    }

    /** Маска имени: * и ? как в обычных масках; без них — «содержит». */
    static Pattern namePattern(String q) {
        String s = q == null ? "" : q.trim();
        if (s.isEmpty()) return Pattern.compile(".*");
        if (s.indexOf('*') < 0 && s.indexOf('?') < 0) return Pattern.compile(".*" + Pattern.quote(s) + ".*", Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);
        StringBuilder sb = new StringBuilder();
        for (char ch : s.toCharArray()) {
            if (ch == '*') sb.append(".*");
            else if (ch == '?') sb.append('.');
            else sb.append(Pattern.quote(String.valueOf(ch)));
        }
        return Pattern.compile(sb.toString(), Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);
    }

    private final class SearchRun {
        final String id; final List<String> roots; final SearchOpts o; final Pattern pat;
        final AtomicBoolean cancelled = new AtomicBoolean(false);
        final AtomicInteger pending = new AtomicInteger(0);
        final Set<String> seen = Collections.newSetFromMap(new ConcurrentHashMap<String, Boolean>());
        final List<JSObject> buf = new ArrayList<>();
        final ThreadPoolExecutor pool;
        final AtomicInteger total = new AtomicInteger(0);
        volatile long lastFlush = System.currentTimeMillis();
        final Object flushLock = new Object();
        Thread flusher;

        SearchRun(String id, List<String> roots, SearchOpts o) {
            this.id = id; this.roots = roots; this.o = o; this.pat = namePattern(o.query);
            this.pool = new ThreadPoolExecutor(4, 4, 30, TimeUnit.SECONDS, new LinkedBlockingDeque<Runnable>());
            this.pool.allowCoreThreadTimeOut(true);
        }

        boolean matches(String name, boolean dir, long size, long mtime) {
            if (!o.hidden && name.startsWith(".")) return false;
            if (!pat.matcher(name).matches()) return false;
            if (!typeOk(o.types, name, dir)) return false;
            if (!dir) {
                if (o.minSize >= 0 && size < o.minSize) return false;
                if (o.maxSize >= 0 && size > o.maxSize) return false;
            }
            if (o.from >= 0 && mtime < o.from) return false;
            if (o.to >= 0 && mtime > o.to) return false;
            return true;
        }

        void found(String full, String name, boolean dir, long size, long mtime) {
            if (!seen.add(full)) return;
            JSObject it = new JSObject();
            it.put("name", name); it.put("type", dir ? "directory" : "file"); it.put("size", size); it.put("mtime", mtime);
            it.put("uri", "file://" + full);
            int slash = full.lastIndexOf('/');
            it.put("dir", slash > 0 ? full.substring(0, slash) : "/");
            total.incrementAndGet();
            synchronized (buf) { buf.add(it); }
            maybeFlush(false);
        }

        void maybeFlush(boolean force) {
            long now = System.currentTimeMillis();
            List<JSObject> take = null;
            synchronized (buf) {
                if (buf.isEmpty()) return;
                if (force || now - lastFlush > 600 || buf.size() >= 300) { take = new ArrayList<>(buf); buf.clear(); lastFlush = now; }
            }
            if (take == null) return;
            JSArray arr = new JSArray(); for (JSObject j : take) arr.put(j);
            JSObject ev = new JSObject(); ev.put("id", id); ev.put("items", arr); ev.put("total", total.get());
            em.emit("searchFound", ev);
        }

        void start() {
            // слой 1: индекс файлов Android — ответ за доли секунды
            pending.incrementAndGet();
            pool.execute(() -> { try { indexLayer(); } catch (Throwable ignored) {} finally { done(); } });
            // слой 2: обход диска
            for (String r : roots) submitDir(new File(r), 0);
            flusher = new Thread(() -> {
                try { while (!cancelled.get() && pending.get() > 0) { Thread.sleep(500); maybeFlush(true); } } catch (InterruptedException ignored) {}
            }, "yev-search-flush");
            flusher.setDaemon(true); flusher.start();
        }

        void indexLayer() {
            if (cancelled.get()) return;
            if (!o.deep) return;   // без подпапок индекс не нужен: одна папка читается мгновенно
            Cursor c = null;
            try {
                StringBuilder where = new StringBuilder();
                List<String> args = new ArrayList<>();
                String q = o.query == null ? "" : o.query.trim();
                if (!q.isEmpty()) {
                    String like = q.replace("%", "\\%").replace("_", "\\_").replace('*', '%').replace('?', '_');
                    if (q.indexOf('*') < 0 && q.indexOf('?') < 0) like = "%" + like + "%";
                    where.append("_display_name LIKE ? ESCAPE '\\'"); args.add(like);
                }
                if (!roots.isEmpty()) {
                    if (where.length() > 0) where.append(" AND ");
                    where.append("(");
                    for (int ri = 0; ri < roots.size(); ri++) {
                        if (ri > 0) where.append(" OR ");
                        String r = roots.get(ri); if (r.endsWith("/")) r = r.substring(0, r.length() - 1);
                        where.append("_data LIKE ?"); args.add(r + "/%");
                    }
                    where.append(")");
                }
                if (o.minSize >= 0) { if (where.length() > 0) where.append(" AND "); where.append("_size >= ?"); args.add(String.valueOf(o.minSize)); }
                if (o.maxSize >= 0) { if (where.length() > 0) where.append(" AND "); where.append("_size <= ?"); args.add(String.valueOf(o.maxSize)); }
                if (o.from >= 0) { if (where.length() > 0) where.append(" AND "); where.append("date_modified >= ?"); args.add(String.valueOf(o.from / 1000)); }
                if (o.to >= 0) { if (where.length() > 0) where.append(" AND "); where.append("date_modified <= ?"); args.add(String.valueOf(o.to / 1000)); }
                if (where.length() == 0) where.append("1=1");
                c = ctx.getContentResolver().query(MediaStore.Files.getContentUri("external"), new String[]{"_data", "_display_name", "_size", "date_modified", "media_type"},
                        where.toString(), args.toArray(new String[0]), "date_modified DESC");
                if (c == null) return;
                int n = 0;
                while (c.moveToNext() && !cancelled.get() && n < 5000) {
                    String p = c.getString(0); if (p == null) continue;
                    String name = c.getString(1); if (name == null) { int s = p.lastIndexOf('/'); name = s >= 0 ? p.substring(s + 1) : p; }
                    boolean dir = false;
                    try { dir = c.getInt(4) == 0 && new File(p).isDirectory(); } catch (Throwable ignored) {}
                    if (dir && !o.hidden) { /* папки из индекса — только по имени */ }
                    long size = c.getLong(2), mt = c.getLong(3) * 1000L;
                    if (!matches(name, dir, size, mt)) continue;
                    if (!new File(p).exists()) continue;       // индекс может отставать
                    found(p, name, dir, size, mt); n++;
                }
            } catch (Throwable ignored) {
            } finally { if (c != null) try { c.close(); } catch (Throwable ignored) {} }
        }

        void submitDir(final File d, final int depth) {
            if (cancelled.get() || depth > 40) return;
            pending.incrementAndGet();
            try {
                pool.execute(() -> {
                    try { walk(d, depth); } catch (Throwable ignored) {} finally { done(); }
                });
            } catch (Throwable t) { done(); }
        }

        void walk(File d, int depth) {
            if (cancelled.get()) return;
            List<Ent> ents = readDir(d);
            if (ents == null) return;
            String base = d.getAbsolutePath(); if (!base.endsWith("/")) base += "/";
            for (Ent e : ents) {
                if (cancelled.get()) return;
                if (matches(e.name, e.dir, e.size, e.mtime)) found(base + e.name, e.name, e.dir, e.size, e.mtime);
                if (e.dir && !e.link && o.deep) {
                    if (!o.hidden && e.name.startsWith(".")) continue;
                    submitDir(new File(base + e.name), depth + 1);
                }
            }
        }

        void done() {
            if (pending.decrementAndGet() <= 0) {
                maybeFlush(true);
                JSObject ev = new JSObject(); ev.put("id", id); ev.put("total", total.get()); ev.put("cancelled", cancelled.get());
                em.emit("searchDone", ev);
                searches.remove(id);
                pool.shutdown();
            }
        }

        void cancel() {
            cancelled.set(true);
            try { pool.shutdownNow(); } catch (Throwable ignored) {}
            searches.remove(id);
            JSObject ev = new JSObject(); ev.put("id", id); ev.put("total", total.get()); ev.put("cancelled", true);
            em.emit("searchDone", ev);
        }
    }

    public void startSearch(String id, List<String> roots, SearchOpts o) {
        SearchRun old = searches.remove(id);
        if (old != null) old.cancelled.set(true);
        SearchRun r = new SearchRun(id, roots, o);
        searches.put(id, r);
        r.start();
    }

    public void stopSearch(String id) {
        SearchRun r = searches.get(id);
        if (r != null) r.cancel();
    }

    public void stopAllSearches() { for (SearchRun r : new ArrayList<>(searches.values())) r.cancel(); }
}
