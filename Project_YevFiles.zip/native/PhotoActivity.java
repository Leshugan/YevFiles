package leshugan.fm;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.RectF;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.GestureDetector;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Родной просмотрщик снимков: рисует картинку сам, без веб-части.
 * Ничего не мерцает и не перерисовывается кусками — кадр готовится заранее
 * и выводится одной операцией.
 */
public class PhotoActivity extends Activity {

    public static final String EXTRA_LIST = "list";
    public static final String EXTRA_INDEX = "index";

    private final List<String> paths = new ArrayList<>();
    private int idx;
    private Stage stage;
    private TextView title;
    private LinearLayout bar;
    private View topWrap;
    private boolean barsShown = true;

    /** Разобранные снимки: текущий и соседи. */
    private int SW = 0, SH = 0;                 // размеры экрана, снятые один раз при открытии
    private final Map<String, Bitmap> cache = new HashMap<>();
    private final java.util.concurrent.ExecutorService pool = java.util.concurrent.Executors.newFixedThreadPool(2);

    @Override
    protected void onCreate(Bundle st) {
        super.onCreate(st);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        Window w = getWindow();
        w.setStatusBarColor(Color.BLACK);
        w.setNavigationBarColor(Color.BLACK);
        w.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(Color.BLACK));
        // окно всегда во весь экран: тогда скрытие полос не меняет ни размер, ни положение
        if (Build.VERSION.SDK_INT >= 30) w.setDecorFitsSystemWindows(false);
        else w.getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
        w.addFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS);
        // у MiXplorer при скрытии полос всегда стоят «устойчивые» флаги раскладки — повторяем
        try {
            View dv = w.getDecorView();
            dv.setSystemUiVisibility(dv.getSystemUiVisibility()
                    | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
            if (Build.VERSION.SDK_INT >= 28) w.getAttributes().layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
        } catch (Throwable ignored) {}

        String[] arr = getIntent().getStringArrayExtra(EXTRA_LIST);
        if (arr != null) for (String s : arr) paths.add(s);
        idx = getIntent().getIntExtra(EXTRA_INDEX, 0);
        if (paths.isEmpty()) { finish(); return; }
        if (idx < 0 || idx >= paths.size()) idx = 0;

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);

        stage = new Stage(this);
        int[] sc = screenSize();
        SW = sc[0]; SH = sc[1];
        FrameLayout.LayoutParams slp = new FrameLayout.LayoutParams(sc[0], sc[1], Gravity.TOP | Gravity.START);
        root.addView(stage, slp);            // размер сцены равен экрану и не зависит от полос

        title = new TextView(this);
        title.setTextColor(Color.WHITE);
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        title.setPadding(dp(16), dp(38), dp(16), dp(12));      // до первого сообщения от системы
        title.setSingleLine(true);
        title.setEllipsize(android.text.TextUtils.TruncateAt.MIDDLE);
        title.setBackgroundColor(0x99000000);
        root.addView(title, new FrameLayout.LayoutParams(-1, -2, Gravity.TOP));
        topWrap = title;

        bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setBackgroundColor(0x99000000);
        bar.setPadding(dp(8), dp(12), dp(8), dp(30));          // до первого сообщения от системы
        addAction("Обои", "img", false, () -> sendAction("wallpaper"));
        addAction("Свойства", "info", false, () -> sendAction("props"));
        addAction("Поделиться", "share", false, () -> sendAction("share"));
        addAction("Изменить", "edit", false, () -> sendAction("edit"));
        addAction("Удалить", "trash", true, this::confirmDelete);
        root.addView(bar, new FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM));

        // окно рисуется под системными полосами — отступы берём у самой системы,
        // иначе имя уезжает под часы, а кнопки под навигацию
        root.setOnApplyWindowInsetsListener((v, ins) -> {
            int top = 0, bottom = 0;
            try {
                if (Build.VERSION.SDK_INT >= 30) {
                    android.graphics.Insets in = ins.getInsets(android.view.WindowInsets.Type.systemBars());
                    top = in.top; bottom = in.bottom;
                } else {
                    top = ins.getSystemWindowInsetTop(); bottom = ins.getSystemWindowInsetBottom();
                }
            } catch (Throwable ignored) {}
            title.setPadding(dp(16), top + dp(10), dp(16), dp(12));
            bar.setPadding(dp(8), dp(12), dp(8), bottom + dp(12));
            return ins;
        });
        root.requestApplyInsets();

        setContentView(root);
        showBars(true);
        updateTitle();
        preload();
    }

    private int dp(int v) { return Math.round(getResources().getDisplayMetrics().density * v); }

    /** Настоящий размер экрана — он одинаков и со скрытыми полосами, и без них. */
    private int[] screenSize() {
        int w = 0, h = 0;
        try {
            android.view.WindowManager wm = (android.view.WindowManager) getSystemService(WINDOW_SERVICE);
            if (Build.VERSION.SDK_INT >= 30) {
                android.graphics.Rect r = wm.getCurrentWindowMetrics().getBounds();
                w = r.width(); h = r.height();
            } else {
                android.graphics.Point p = new android.graphics.Point();
                wm.getDefaultDisplay().getRealSize(p);
                w = p.x; h = p.y;
            }
        } catch (Throwable ignored) {}
        if (w <= 0 || h <= 0) { w = getResources().getDisplayMetrics().widthPixels; h = getResources().getDisplayMetrics().heightPixels; }
        return new int[]{ w, h };
    }

    /** Поворот экрана: пересобираем размеры сцены. */
    @Override public void onConfigurationChanged(android.content.res.Configuration cfg) {
        super.onConfigurationChanged(cfg);
        if (stage == null) return;
        int[] sc = screenSize();
        SW = sc[0]; SH = sc[1];
        ViewGroup.LayoutParams lp = stage.getLayoutParams();
        lp.width = sc[0]; lp.height = sc[1];
        stage.setLayoutParams(lp);
        stage.reset();
    }

    /** Значок теми же линиями, что и в приложении: рисуем по описанию контуров. */
    private static class LineIcon extends android.graphics.drawable.Drawable {
        private final String[] paths;
        private final int color;
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        LineIcon(int color, String... paths) {
            this.color = color; this.paths = paths;
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeCap(Paint.Cap.ROUND);
            p.setStrokeJoin(Paint.Join.ROUND);
            p.setColor(color);
        }
        @Override public void draw(Canvas c) {
            android.graphics.Rect b = getBounds();
            float k = Math.min(b.width(), b.height()) / 24f;
            p.setStrokeWidth(1.9f);          // толщина в единицах рисунка: холст уже масштабирован
            c.save();
            c.translate(b.left, b.top);
            c.scale(k, k);
            for (String d : paths) {
                try {
                    android.graphics.Path path = androidx.core.graphics.PathParser.createPathFromPathData(d);
                    if (path != null) c.drawPath(path, p);
                } catch (Throwable ignored) {}
            }
            c.restore();
        }
        @Override public void setAlpha(int a) { p.setAlpha(a); }
        @Override public void setColorFilter(android.graphics.ColorFilter f) { p.setColorFilter(f); }
        @Override public int getOpacity() { return android.graphics.PixelFormat.TRANSLUCENT; }
    }

    /** Описания значков — те же, что в интерфейсе приложения. */
    private static String[] iconPaths(String key) {
        if ("img".equals(key)) return new String[]{
                "M5 3h14a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2z",
                "M8.5 7a1.5 1.5 0 1 0 0 3 1.5 1.5 0 0 0 0-3z",
                "M21 15l-5-5L5 21" };
        if ("info".equals(key)) return new String[]{
                "M12 3a9 9 0 1 0 0 18 9 9 0 0 0 0-18z", "M12 11v5", "M12 8h.01" };
        if ("share".equals(key)) return new String[]{
                "M18 2a3 3 0 1 0 0 6 3 3 0 0 0 0-6z",
                "M6 9a3 3 0 1 0 0 6 3 3 0 0 0 0-6z",
                "M18 16a3 3 0 1 0 0 6 3 3 0 0 0 0-6z",
                "M8.6 13.5l6.8 4", "M15.4 6.5l-6.8 4" };
        if ("edit".equals(key)) return new String[]{
                "M12 20h9", "M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4z" };
        return new String[]{ "M3 6h18", "M8 6V4h8v2", "M6 6l1 14h10l1-14" };
    }

    private void addAction(String label, String iconKey, boolean red, final Runnable fn) {
        TextView t = new TextView(this);
        t.setText(label);
        int color = red ? 0xFFFF6B6B : Color.WHITE;
        t.setTextColor(color);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(4), dp(8), dp(4), dp(8));
        t.setCompoundDrawablePadding(dp(5));
        try {
            LineIcon d = new LineIcon(color, iconPaths(iconKey));
            int sz = dp(23);
            d.setBounds(0, 0, sz, sz);
            t.setCompoundDrawables(null, d, null, null);
        } catch (Throwable ignored) {}
        t.setOnClickListener(v -> fn.run());
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1f);
        bar.addView(t, lp);
    }

    private String cur() { return paths.get(idx); }

    private void updateTitle() {
        String p = cur();
        String nm = p.substring(p.lastIndexOf('/') + 1);
        title.setText(nm + "    " + (idx + 1) + "/" + paths.size());
    }

    private void showBars(boolean on) {
        barsShown = on;
        fade(title, on, -1);
        fade(bar, on, 1);
        Window w = getWindow();
        try {
            if (Build.VERSION.SDK_INT >= 30) {
                android.view.WindowInsetsController c = w.getInsetsController();
                if (c != null) {
                    c.setSystemBarsBehavior(android.view.WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
                    int bars = android.view.WindowInsets.Type.statusBars() | android.view.WindowInsets.Type.navigationBars();
                    if (on) c.show(bars); else c.hide(bars);
                }
            } else {
                int f = w.getDecorView().getSystemUiVisibility();
                int hide = View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY;
                if (on) f &= ~hide; else f |= hide;
                w.getDecorView().setSystemUiVisibility(f);
            }
        } catch (Throwable ignored) {}
    }

    /** Плавное появление и уход панели: резкое включение выглядит дёрганым. */
    private void fade(final View v, final boolean on, int dir) {
        v.animate().cancel();
        if (on) {
            v.setVisibility(View.VISIBLE);
            v.setAlpha(0f);
            v.setTranslationY(dir * dp(12));
            v.animate().alpha(1f).translationY(0).setDuration(150).start();
        } else {
            v.animate().alpha(0f).translationY(dir * dp(12)).setDuration(150)
                    .withEndAction(() -> v.setVisibility(View.INVISIBLE)).start();
        }
    }

    /** Готовим текущий снимок и соседей заранее, чтобы листалось без задержек. */
    private void preload() {
        for (int d = 0; d <= 1; d++) {
            for (int s = -1; s <= 1; s += 2) {
                final int i = idx + d * s;
                if (i < 0 || i >= paths.size()) continue;
                final String p = paths.get(i);
                if (cache.containsKey(p)) continue;
                cache.put(p, null);
                pool.execute(() -> {
                    Bitmap b = decode(p);
                    runOnUiThread(() -> { cache.put(p, b); stage.invalidate(); });
                });
            }
            if (d == 0 && cache.get(cur()) == null) { /* текущий в первую очередь */ }
        }
        // память не копим: держим только пять ближайших
        List<String> keep = new ArrayList<>();
        for (int i = idx - 2; i <= idx + 2; i++) if (i >= 0 && i < paths.size()) keep.add(paths.get(i));
        List<String> drop = new ArrayList<>();
        for (String k : cache.keySet()) if (!keep.contains(k)) drop.add(k);
        for (String k : drop) { Bitmap b = cache.remove(k); if (b != null) b.recycle(); }
    }

    private Bitmap decode(String path) {
        try {
            int wantW = getResources().getDisplayMetrics().widthPixels;
            int wantH = getResources().getDisplayMetrics().heightPixels;
            int want = Math.max(wantW, wantH) * 2;                 // запас на приближение
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inJustDecodeBounds = true;
            BitmapFactory.decodeFile(path, o);
            if (o.outWidth <= 0) return null;
            int mx = Math.max(o.outWidth, o.outHeight);
            BitmapFactory.Options o2 = new BitmapFactory.Options();
            o2.inPreferredConfig = Bitmap.Config.RGB_565;          // вдвое меньше памяти, глазу незаметно
            int s = 1; while (mx / s > want) s *= 2;
            o2.inSampleSize = s;
            Bitmap b = BitmapFactory.decodeFile(path, o2);
            return rotate(b, path);
        } catch (Throwable t) { return null; }
    }

    private Bitmap rotate(Bitmap b, String path) {
        if (b == null) return null;
        try {
            androidx.exifinterface.media.ExifInterface ex = new androidx.exifinterface.media.ExifInterface(path);
            int or = ex.getAttributeInt(androidx.exifinterface.media.ExifInterface.TAG_ORIENTATION, 1);
            int deg = or == 6 ? 90 : or == 3 ? 180 : or == 8 ? 270 : 0;
            if (deg == 0) return b;
            Matrix m = new Matrix(); m.postRotate(deg);
            Bitmap r = Bitmap.createBitmap(b, 0, 0, b.getWidth(), b.getHeight(), m, true);
            if (r != b) b.recycle();
            return r;
        } catch (Throwable t) { return b; }
    }

    private void go(int d) {
        int ni = idx + d;
        if (ni < 0 || ni >= paths.size()) return;
        idx = ni;
        stage.reset();
        updateTitle();
        preload();
    }

    private void confirmDelete() {
        new android.app.AlertDialog.Builder(this)
                .setMessage("Удалить " + cur().substring(cur().lastIndexOf('/') + 1) + "?")
                .setNegativeButton("Отмена", null)
                .setPositiveButton("Удалить", (d, wch) -> {
                    String p = cur();
                    boolean ok = false;
                    try { ok = new File(p).delete(); } catch (Throwable ignored) {}
                    if (ok) {
                        Bitmap b = cache.remove(p); if (b != null) b.recycle();
                        paths.remove(idx);
                        if (paths.isEmpty()) { done("deleted", p); return; }
                        if (idx >= paths.size()) idx = paths.size() - 1;
                        stage.reset(); updateTitle(); preload();
                    }
                }).show();
    }

    /** Действие уходит обратно в приложение — там уже готовы окна и обработчики. */
    private void sendAction(String what) { done(what, cur()); }

    private void done(String what, String path) {
        Intent r = new Intent();
        r.putExtra("action", what);
        r.putExtra("path", path);
        setResult(RESULT_OK, r);
        finish();
        overridePendingTransition(0, android.R.anim.fade_out);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        pool.shutdownNow();
        for (Bitmap b : cache.values()) if (b != null) b.recycle();
        cache.clear();
    }

    /** Сама сцена: рисует кадры и обрабатывает жесты. */
    private class Stage extends View {
        private final Paint paint = new Paint(Paint.FILTER_BITMAP_FLAG | Paint.ANTI_ALIAS_FLAG);
        private final Matrix m = new Matrix();
        private float scale = 1f, tx = 0, ty = 0;
        private float dragX = 0, dragY = 0;
        private int mode = 0;                     // 0 нет, 1 листание, 2 закрытие, 3 перенос, 4 щипок
        private float sx, sy, bTx, bTy;
        private long downAt;
        private final ScaleGestureDetector sgd;
        private final GestureDetector gd;
        private android.animation.ValueAnimator anim;

        Stage(android.content.Context c) {
            super(c);
            sgd = new ScaleGestureDetector(c, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
                @Override public boolean onScale(ScaleGestureDetector d) {
                    float ns = Math.max(1f, Math.min(6f, scale * d.getScaleFactor()));
                    float k = ns / scale;
                    tx = d.getFocusX() - k * (d.getFocusX() - tx);
                    ty = d.getFocusY() - k * (d.getFocusY() - ty);
                    scale = ns;
                    mode = 4;
                    clamp();
                    invalidate();
                    return true;
                }
            });
            gd = new GestureDetector(c, new GestureDetector.SimpleOnGestureListener() {
                @Override public boolean onSingleTapConfirmed(MotionEvent e) { showBars(!barsShown); return true; }
                @Override public boolean onDoubleTap(MotionEvent e) {
                    if (scale > 1.05f) { animateTo(1f, 0, 0); return true; }
                    float ns = 2.6f, k = ns / scale;              // точка под пальцем остаётся на месте
                    animateTo(ns, e.getX() - k * (e.getX() - tx), e.getY() - k * (e.getY() - ty));
                    return true;
                }
            });
        }

        void reset() { scale = 1f; tx = 0; ty = 0; dragX = 0; dragY = 0; mode = 0; invalidate(); }



        private void clamp() {
            Bitmap b = cache.get(cur());
            if (b == null) return;
            RectF r = frameRect(b);
            float w = vw(), h = vh();
            if (r.width() <= w) tx = 0;                        // уже влезает — держим по центру
            else {
                if (r.left + tx > 0) tx = -r.left;
                if (r.left + tx + r.width() < w) tx = w - r.left - r.width();
            }
            if (r.height() <= h) ty = 0;
            else {
                if (r.top + ty > 0) ty = -r.top;
                if (r.top + ty + r.height() < h) ty = h - r.top - r.height();
            }
        }

        /** Прямоугольник кадра при масштабе 1 и текущем увеличении, без сдвига. */
        // Ни размер вида, ни окно нас не касаются: считаем от снятых один раз размеров экрана.
        private int vw() { return SW > 0 ? SW : getWidth(); }
        private int vh() { return SH > 0 ? SH : getHeight(); }

        private RectF frameRect(Bitmap b) {
            float w = vw(), h = vh();
            float k = Math.min(w / b.getWidth(), h / b.getHeight()) * scale;
            float bw = b.getWidth() * k, bh = b.getHeight() * k;
            return new RectF((w - bw) / 2, (h - bh) / 2, (w - bw) / 2 + bw, (h - bh) / 2 + bh);
        }

        private void animateTo(final float ns, final float ntx, final float nty) {
            if (anim != null) anim.cancel();
            final float s0 = scale, x0 = tx, y0 = ty;
            anim = android.animation.ValueAnimator.ofFloat(0f, 1f);
            anim.setDuration(180);
            anim.addUpdateListener(a -> {
                float p = (float) a.getAnimatedValue();
                scale = s0 + (ns - s0) * p;
                tx = x0 + (ntx - x0) * p;
                ty = y0 + (nty - y0) * p;
                clamp();
                invalidate();
            });
            anim.start();
        }

        private void settle(final float from, final int delta) {
            if (anim != null) anim.cancel();
            final float w = vw() + dp(16);
            anim = android.animation.ValueAnimator.ofFloat(from, delta == 0 ? 0 : -delta * w);
            anim.setDuration(190);
            anim.addUpdateListener(a -> { dragX = (float) a.getAnimatedValue(); invalidate(); });
            anim.addListener(new android.animation.AnimatorListenerAdapter() {
                @Override public void onAnimationEnd(android.animation.Animator a) {
                    dragX = 0;
                    if (delta != 0) go(delta);
                    invalidate();
                }
            });
            anim.start();
        }

        @Override
        public boolean onTouchEvent(MotionEvent e) {
            sgd.onTouchEvent(e);
            gd.onTouchEvent(e);
            int act = e.getActionMasked();
            if (act == MotionEvent.ACTION_DOWN) {
                sx = e.getX(); sy = e.getY(); bTx = tx; bTy = ty; downAt = System.currentTimeMillis();
                mode = scale > 1.05f ? 3 : 0;
                if (anim != null) anim.cancel();
                return true;
            }
            if (act == MotionEvent.ACTION_MOVE) {
                if (sgd.isInProgress() || e.getPointerCount() > 1) return true;
                float dx = e.getX() - sx, dy = e.getY() - sy;
                if (mode == 3) { tx = bTx + dx; ty = bTy + dy; clamp(); invalidate(); return true; }
                if (mode == 0 && Math.hypot(dx, dy) > dp(10)) mode = Math.abs(dx) > Math.abs(dy) ? 1 : 2;
                if (mode == 1) { dragX = dx; invalidate(); }
                else if (mode == 2) { dragY = Math.max(0, dy); dragX = dx * 0.3f; invalidate(); }
                return true;
            }
            if (act == MotionEvent.ACTION_UP || act == MotionEvent.ACTION_CANCEL) {
                long dt = System.currentTimeMillis() - downAt;
                if (mode == 4) { if (scale <= 1.02f) { scale = 1f; tx = 0; ty = 0; } clamp(); invalidate(); mode = scale > 1.05f ? 3 : 0; return true; }
                if (mode == 2) {
                    if (dragY > dp(110)) { finish(); overridePendingTransition(0, android.R.anim.fade_out); }
                    else { dragY = 0; dragX = 0; invalidate(); }
                    mode = 0; return true;
                }
                if (mode == 1) {
                    float th = Math.min(dp(60), vw() * 0.12f);
                    boolean flick = dt < 260 && Math.abs(dragX) > dp(30);
                    if ((dragX < -th || (flick && dragX < 0)) && idx < paths.size() - 1) settle(dragX, 1);
                    else if ((dragX > th || (flick && dragX > 0)) && idx > 0) settle(dragX, -1);
                    else settle(dragX, 0);
                    mode = 0; return true;
                }
                mode = scale > 1.05f ? 3 : 0;
            }
            return true;
        }

        @Override
        protected void onDraw(Canvas c) {
            int alpha = (int) (255 * Math.max(0f, 1f - Math.abs(dragY) / (vh() * 0.8f)));
            c.drawColor(Color.argb(255, 0, 0, 0));
            float gap = dp(16);
            for (int d = -1; d <= 1; d++) {
                int i = idx + d;
                if (i < 0 || i >= paths.size()) continue;
                Bitmap b = cache.get(paths.get(i));
                if (b == null) continue;
                float w = vw(), h = vh();
                float k = Math.min(w / b.getWidth(), h / b.getHeight());
                float useScale = d == 0 ? scale : 1f;
                float bw = b.getWidth() * k * useScale, bh = b.getHeight() * k * useScale;
                m.reset();
                m.postScale(k * useScale, k * useScale);
                float left = (w - bw) / 2 + (d == 0 ? tx : 0) + dragX + d * (w + gap);
                float top = (h - bh) / 2 + (d == 0 ? ty : 0) + dragY;
                m.postTranslate(left, top);
                paint.setAlpha(d == 0 ? alpha : 255);
                c.drawBitmap(b, m, paint);
            }
        }
    }
}
