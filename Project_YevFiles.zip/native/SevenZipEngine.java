package leshugan.fm;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.io.RandomAccessFile;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Мост к настоящему движку 7-Zip (библиотека 7-Zip-JBinding) — тому же, на котором работает MT Manager.
 * Один движок читает и распаковывает всё: zip, 7z, rar, rar5, tar, gz, xz, bz2, iso, cab, arj, wim…
 * и, главное, умеет пароли во всех этих форматах (включая RAR5, который другие библиотеки не расшифровывают).
 *
 * Обращение к библиотеке идёт через отражение: если её нет в сборке, available() вернёт false
 * и приложение продолжит работать на прежних библиотеках, ничего не ломая.
 *
 * Чтобы движок включился, в сборку нужно добавить (build.yml → build.gradle приложения):
 *   репозиторий  maven { url 'https://jitpack.io' }
 *   зависимость  implementation 'com.github.omicronapps:7-Zip-JBinding-4Android:Release-16.02-2.03'
 */
public final class SevenZipEngine {

    public static final class NeedPassword extends Exception { public NeedPassword() { super("Требуется пароль"); } }
    public static final class WrongPassword extends Exception { public WrongPassword() { super("Неверный пароль"); } }
    public static final class NotAvailable extends Exception { public NotAvailable() { super("Движок 7-Zip недоступен"); } }

    public interface Progress { void on(String name, int done, int total); }

    /**
     * Решения по каждой записи при распаковке: куда класть файл (null — пропустить),
     * что делать при ошибке записи (true — пропустить и продолжить), учёт записанных байтов.
     */
    public interface Resolver {
        File out(String name, long size) throws Exception;
        boolean err(String name, String code) throws Exception;
        void bytes(int n);
    }

    public static final class Item {
        public String name; public long size; public boolean dir; public boolean enc; public int index;
    }

    private SevenZipEngine() {}

    /** Версия движка (строкой), если он доступен. */
    public static String version() {
        try { return String.valueOf(cSevenZip.getMethod("getSevenZipVersion").invoke(null)); }
        catch (Throwable t) { return ""; }
    }

    /**
     * Быстрая проверка пароля: открыть архив и пробно достать самый маленький файл в никуда.
     * 0 — подошёл, 1 — неверный, 2 — нужен пароль. Ошибки формата летят исключением.
     */
    public static int probe(File f, String pw) throws Exception {
        if (!available()) throw new NotAvailable();
        Handle h;
        try { h = open(f, pw); }
        catch (NeedPassword np) { return 2; }
        catch (WrongPassword wp) { return 1; }
        try {
            int n = (Integer) mNumItems.invoke(h.arch);
            int best = -1;
            for (int i = 0; i < n; i++) {
                Object dir = mGetProp.invoke(h.arch, i, pIS_FOLDER);
                if (Boolean.TRUE.equals(dir)) continue;
                best = i; break;   // первый файл потока: в сплошных архивах любой другой требует размотки до него
            }
            if (best < 0) return 0;   // одни папки — проверять нечего
            final boolean[] got = { false };
            OutputStream nul = new OutputStream() {
                @Override public void write(int b) { got[0] = true; throw new RuntimeException("__pw_ok__"); }
                @Override public void write(byte[] b, int o2, int l) { if (l > 0) { got[0] = true; throw new RuntimeException("__pw_ok__"); } }
            };
            Object sink = outProxy(nul);
            Object r;
            try { r = mExtractSlow.invoke(h.arch, best, sink, (pw == null || pw.isEmpty()) ? null : pw); }
            catch (Throwable t) {
                if (got[0]) return 0;                              // данные пошли — пароль подошёл
                if (chainHas(t, "__need_password__")) return 2;
                Throwable c = (t instanceof java.lang.reflect.InvocationTargetException && t.getCause() != null) ? t.getCause() : t;
                if (looksLikePassword(c)) return (pw == null || pw.isEmpty()) ? 2 : 1;
                throw c instanceof Exception ? (Exception) c : new Exception(String.valueOf(c));
            }
            if (got[0]) return 0;
            String rn = enumName(r);
            if (rn.equals("OK")) return 0;
            if (rn.equals("WRONG_PASSWORD")) return 1;
            if (pw != null && !pw.isEmpty() && (rn.equals("DATAERROR") || rn.equals("CRCERROR"))) return 1;
            return (pw == null || pw.isEmpty()) ? 2 : 1;
        } finally { h.close(); }
    }

    // ---------- создание 7z настоящим движком: многопоточное сжатие ----------

    public interface PackProgress { void bytes(long done); }

    /**
     * Пишет 7z средствами нативного 7-Zip (несколько ядер). paths/dirs/sizes/mtimes/files — по записям.
     * Бросает исключение, если движок недоступен или упал — тогда зовущий жмёт прежним способом.
     */
    public static void create7z(File outFile, List<String> paths, List<Boolean> dirs, List<Long> sizes,
                                List<Long> mtimes, List<File> files, int threads, PackProgress pp) throws Exception {
        if (!available()) throw new NotAvailable();
        ClassLoader cl = SevenZipEngine.class.getClassLoader();
        Class<?> cOutCb = Class.forName("net.sf.sevenzipjbinding.IOutCreateCallback", true, cl);
        Class<?> cIOutStream = Class.forName("net.sf.sevenzipjbinding.IOutStream", true, cl);
        Class<?> cRafOut = Class.forName("net.sf.sevenzipjbinding.impl.RandomAccessFileOutStream", true, cl);
        Class<?> cSeqIn = Class.forName("net.sf.sevenzipjbinding.ISequentialInStream", true, cl);
        Object outArc = cSevenZip.getMethod("openOutArchive7z").invoke(null);
        try { outArc.getClass().getMethod("setLevel", int.class).invoke(outArc, 5); } catch (Throwable ignored) {}
        try { outArc.getClass().getMethod("setThreadCount", int.class).invoke(outArc, Math.max(1, threads)); } catch (Throwable ignored) {}
        RandomAccessFile raf = new RandomAccessFile(outFile, "rw");
        Object outStream;
        try { outStream = cRafOut.getConstructor(RandomAccessFile.class).newInstance(raf); }
        catch (Throwable t) { try { raf.close(); } catch (Throwable ignored) {} throw new Exception("нет выходного потока движка"); }
        final long[] doneB = { 0 };
        final java.io.InputStream[] cur = { null };
        final Throwable[] cbEx = { null };
        InvocationHandler cb = new InvocationHandler() {
            @Override public Object invoke(Object proxy, Method m, Object[] a) throws Throwable {
                String mn = m.getName();
                if (mn.equals("getItemInformation")) {
                    int i = (Integer) a[0];
                    Object factory = a[1];
                    Object it = factory.getClass().getMethod("createOutItem").invoke(factory);
                    trySet(it, "setPropertyPath", String.class, paths.get(i));
                    trySet(it, "setPropertyIsDir", Boolean.class, dirs.get(i));
                    if (!dirs.get(i)) trySet(it, "setDataSize", Long.class, sizes.get(i));
                    Long mt = mtimes.get(i);
                    if (mt != null && mt > 0) trySet(it, "setPropertyLastModificationTime", java.util.Date.class, new java.util.Date(mt));
                    return it;
                }
                if (mn.equals("getStream")) {
                    int i = (Integer) a[0];
                    if (cur[0] != null) { try { cur[0].close(); } catch (Throwable ignored) {} cur[0] = null; }
                    if (dirs.get(i)) return null;
                    java.io.FileInputStream fis;
                    try { fis = new java.io.FileInputStream(files.get(i)); }
                    catch (Throwable t) { cbEx[0] = t; throw t; }
                    cur[0] = fis;
                    return Proxy.newProxyInstance(cl, new Class<?>[]{ cSeqIn }, (p2, m2, a2) -> {
                        String n2 = m2.getName();
                        if (n2.equals("read")) {
                            byte[] b = (byte[]) a2[0];
                            int n3 = fis.read(b);
                            if (n3 <= 0) return 0;
                            doneB[0] += n3;
                            if (pp != null) pp.bytes(doneB[0]);
                            return n3;
                        }
                        if (n2.equals("toString")) return "in";
                        if (n2.equals("hashCode")) return System.identityHashCode(p2);
                        if (n2.equals("equals")) return p2 == a2[0];
                        return null;
                    });
                }
                if (mn.equals("setOperationResult") || mn.equals("setTotal") || mn.equals("setCompleted")) return null;
                if (mn.equals("toString")) return "cb";
                if (mn.equals("hashCode")) return System.identityHashCode(proxy);
                if (mn.equals("equals")) return proxy == a[0];
                return null;
            }
        };
        Object cbProxy = Proxy.newProxyInstance(cl, new Class<?>[]{ cOutCb }, cb);
        try {
            outArc.getClass().getMethod("createArchive", cIOutStream, int.class, cOutCb)
                    .invoke(outArc, outStream, paths.size(), cbProxy);
        } catch (Throwable t) {
            Throwable c = (t instanceof java.lang.reflect.InvocationTargetException && t.getCause() != null) ? t.getCause() : t;
            if (cbEx[0] != null) c = cbEx[0];
            if (c instanceof Exception) throw (Exception) c;
            throw new Exception(String.valueOf(c));
        } finally {
            if (cur[0] != null) { try { cur[0].close(); } catch (Throwable ignored) {} }
            try { outArc.getClass().getMethod("close").invoke(outArc); } catch (Throwable ignored) {}
            try { raf.close(); } catch (Throwable ignored) {}
        }
    }

    private static void trySet(Object o, String name, Class<?> type, Object val) {
        try { o.getClass().getMethod(name, type).invoke(o, val); } catch (Throwable ignored) {}
    }

    // ---------- доступность ----------

    private static volatile Boolean avail;
    private static Class<?> cSevenZip, cFormat, cInStream, cInArchive, cPropID, cSeqOut, cExtractCb, cCrypto, cProgress, cRafStream;
    private static Method mOpen2, mOpen3, mNumItems, mGetProp, mExtract, mExtractSlow, mClose;
    private static Object pPATH, pSIZE, pIS_FOLDER, pENCRYPTED;

    public static boolean available() {
        Boolean a = avail;
        if (a != null) return a;
        synchronized (SevenZipEngine.class) {
            if (avail != null) return avail;
            boolean ok = false;
            try {
                ClassLoader cl = SevenZipEngine.class.getClassLoader();
                cSevenZip = Class.forName("net.sf.sevenzipjbinding.SevenZip", true, cl);
                cFormat = Class.forName("net.sf.sevenzipjbinding.ArchiveFormat", true, cl);
                cInStream = Class.forName("net.sf.sevenzipjbinding.IInStream", true, cl);
                cInArchive = Class.forName("net.sf.sevenzipjbinding.IInArchive", true, cl);
                cPropID = Class.forName("net.sf.sevenzipjbinding.PropID", true, cl);
                cSeqOut = Class.forName("net.sf.sevenzipjbinding.ISequentialOutStream", true, cl);
                cExtractCb = Class.forName("net.sf.sevenzipjbinding.IArchiveExtractCallback", true, cl);
                cCrypto = Class.forName("net.sf.sevenzipjbinding.ICryptoGetTextPassword", true, cl);
                cProgress = Class.forName("net.sf.sevenzipjbinding.IProgress", true, cl);
                cRafStream = Class.forName("net.sf.sevenzipjbinding.impl.RandomAccessFileInStream", true, cl);
                mOpen2 = cSevenZip.getMethod("openInArchive", cFormat, cInStream);
                mOpen3 = cSevenZip.getMethod("openInArchive", cFormat, cInStream, String.class);
                mNumItems = cInArchive.getMethod("getNumberOfItems");
                mGetProp = cInArchive.getMethod("getProperty", int.class, cPropID);
                mExtract = cInArchive.getMethod("extract", int[].class, boolean.class, cExtractCb);
                mExtractSlow = cInArchive.getMethod("extractSlow", int.class, cSeqOut, String.class);
                mClose = cInArchive.getMethod("close");
                pPATH = enumOf(cPropID, "PATH");
                pSIZE = enumOf(cPropID, "SIZE");
                pIS_FOLDER = enumOf(cPropID, "IS_FOLDER");
                pENCRYPTED = enumOf(cPropID, "ENCRYPTED");
                // поднимаем нативную часть и проверяем, что она поднялась
                cSevenZip.getMethod("getSevenZipVersion").invoke(null);
                Object init = cSevenZip.getMethod("isInitializedSuccessfully").invoke(null);
                ok = Boolean.TRUE.equals(init);
            } catch (Throwable ignored) { ok = false; }
            avail = ok;
            return ok;
        }
    }

    @SuppressWarnings({ "unchecked", "rawtypes" })
    private static Object enumOf(Class<?> c, String name) { return Enum.valueOf((Class<Enum>) c, name); }

    private static String enumName(Object e) { try { return e == null ? "" : (String) e.getClass().getMethod("name").invoke(e); } catch (Throwable t) { return String.valueOf(e); } }

    // ---------- открытие ----------

    private static final class Handle {
        Object arch; RandomAccessFile raf; Object stream;
        void close() {
            try { if (arch != null) mClose.invoke(arch); } catch (Throwable ignored) {}
            try { if (stream != null) stream.getClass().getMethod("close").invoke(stream); } catch (Throwable ignored) {}
            try { if (raf != null) raf.close(); } catch (Throwable ignored) {}
        }
    }

    private static boolean looksLikePassword(Throwable t) {
        for (Throwable e = t; e != null; e = e.getCause()) {
            String m = e.getMessage();
            if (m == null) continue;
            String l = m.toLowerCase();
            if (l.contains("password") || l.contains("encrypt") || l.contains("passphrase")) return true;
        }
        return false;
    }

    private static Handle open(File f, String password) throws Exception {
        if (!available()) throw new NotAvailable();
        Handle h = new Handle();
        try {
            h.raf = new RandomAccessFile(f, "r");
            h.stream = cRafStream.getConstructor(RandomAccessFile.class).newInstance(h.raf);
            Object[] args = (password != null && !password.isEmpty())
                    ? new Object[]{ null, h.stream, password }
                    : new Object[]{ null, h.stream };
            h.arch = (password != null && !password.isEmpty()) ? mOpen3.invoke(null, args) : mOpen2.invoke(null, args);
            if (h.arch == null) throw new Exception("не удалось открыть архив");
            return h;
        } catch (Throwable t) {
            h.close();
            Throwable c = (t instanceof java.lang.reflect.InvocationTargetException && t.getCause() != null) ? t.getCause() : t;
            // заголовок зашифрован: без пароля не открыть вовсе, с паролем — пароль не тот
            if (looksLikePassword(c)) { if (password == null || password.isEmpty()) throw new NeedPassword(); throw new WrongPassword(); }
            if (c instanceof Exception) throw (Exception) c;
            throw new Exception(String.valueOf(c));
        }
    }

    // ---------- оглавление ----------

    public static List<Item> list(File f, String password) throws Exception {
        Handle h = open(f, password);
        try {
            List<Item> out = new ArrayList<>();
            int n = (Integer) mNumItems.invoke(h.arch);
            for (int i = 0; i < n; i++) {
                Item it = new Item();
                it.index = i;
                Object p = mGetProp.invoke(h.arch, i, pPATH);
                it.name = p == null ? "" : String.valueOf(p).replace('\\', '/');
                Object d = mGetProp.invoke(h.arch, i, pIS_FOLDER);
                it.dir = Boolean.TRUE.equals(d);
                Object s = mGetProp.invoke(h.arch, i, pSIZE);
                it.size = (s instanceof Number) ? ((Number) s).longValue() : 0L;
                Object e = mGetProp.invoke(h.arch, i, pENCRYPTED);
                it.enc = Boolean.TRUE.equals(e);
                if (!it.name.isEmpty()) out.add(it);
            }
            return out;
        } finally { h.close(); }
    }

    /** Есть ли в архиве зашифрованные записи (оглавление читается без пароля). */
    public static boolean anyEncrypted(List<Item> items) {
        for (Item i : items) if (i.enc) return true;
        return false;
    }

    // ---------- распаковка ----------

    /** Одну запись — ровно в указанный файл. */
    public static void extractOne(File f, String entry, File dest, String password) throws Exception {
        Handle h = open(f, password);
        try {
            int n = (Integer) mNumItems.invoke(h.arch);
            int idx = -1;
            String want = entry.replace('\\', '/');
            for (int i = 0; i < n; i++) {
                Object p = mGetProp.invoke(h.arch, i, pPATH);
                String nm = p == null ? "" : String.valueOf(p).replace('\\', '/');
                if (nm.equals(want)) { idx = i; break; }
            }
            if (idx < 0) throw new java.io.FileNotFoundException("entry not found");
            if (dest.getParentFile() != null) dest.getParentFile().mkdirs();
            OutputStream os = new FileOutputStream(dest);
            Object sink = outProxy(os);
            Object res;
            try { res = mExtractSlow.invoke(h.arch, idx, sink, password); }
            finally { try { os.close(); } catch (Throwable ignored) {} }
            String r = enumName(res);
            if (r.equals("WRONG_PASSWORD")) { dest.delete(); throw new WrongPassword(); }
            if (!r.equals("OK")) {
                dest.delete();
                // старые сборки движка на неверный пароль отвечают ошибкой данных
                if ((password != null && !password.isEmpty()) && (r.equals("DATAERROR") || r.equals("CRCERROR"))) throw new WrongPassword();
                throw new Exception("Не удалось распаковать: " + r);
            }
        } finally { h.close(); }
    }

    /**
     * Распаковка в папку. only == null — всё; иначе только перечисленные имена.
     * Записи распаковываются одним проходом (важно для «сплошных» архивов, где файлы лежат общим куском).
     */
    public static void extract(File f, File destDir, Set<String> only, String password, final Progress prog) throws Exception {
        extract(f, destDir, only, password, prog, null);
    }

    public static void extract(File f, File destDir, Set<String> only, String password, final Progress prog, final Resolver res) throws Exception {
        Handle h = open(f, password);
        try {
            int n = (Integer) mNumItems.invoke(h.arch);
            final Map<Integer, String> names = new LinkedHashMap<>();
            final Map<Integer, Long> sizes = new LinkedHashMap<>();
            List<Integer> want = new ArrayList<>();
            List<String> onlyPs = null;   // имена папок с «/» на конце означают всё их содержимое
            if (only != null) { onlyPs = new ArrayList<>(); for (String s0 : only) if (s0.endsWith("/")) onlyPs.add(s0); if (onlyPs.isEmpty()) onlyPs = null; }
            for (int i = 0; i < n; i++) {
                Object p = mGetProp.invoke(h.arch, i, pPATH);
                String nm = p == null ? "" : String.valueOf(p).replace('\\', '/');
                if (nm.isEmpty()) continue;
                boolean dir = Boolean.TRUE.equals(mGetProp.invoke(h.arch, i, pIS_FOLDER));
                if (dir) {
                    if (only == null && res == null) {
                        try {   // папка из архива не должна выйти за папку назначения
                            File od = new File(destDir, nm);
                            String base = destDir.getCanonicalPath(), full = od.getCanonicalPath();
                            if (full.equals(base) || full.startsWith(base + File.separator)) od.mkdirs();
                        } catch (Throwable ignored) {}
                    }
                    continue;
                }
                if (only != null && !only.contains(nm)) {
                    boolean pref = false;
                    if (onlyPs != null) for (String p0 : onlyPs) if (nm.startsWith(p0)) { pref = true; break; }
                    if (!pref) continue;
                }
                names.put(i, nm);
                Object sz = mGetProp.invoke(h.arch, i, pSIZE);
                sizes.put(i, (sz instanceof Number) ? ((Number) sz).longValue() : -1L);
                want.add(i);
            }
            if (want.isEmpty()) return;
            int[] idx = new int[want.size()];
            for (int i = 0; i < idx.length; i++) idx[i] = want.get(i);

            final int total = idx.length;
            final int[] done = { 0 };
            final String[] curName = { "" };
            final OutputStream[] curOut = { null };
            final boolean[] wrongPw = { false };
            final String[] failure = { null };
            final File dd = destDir;
            final String pw = password;

            final boolean[] curSkipped = { false };
            final Throwable[] resEx = { null };   // отмена из вопроса: движок может проглотить исключение из обратного вызова
            InvocationHandler ih = new InvocationHandler() {
                @Override public Object invoke(Object proxy, Method m, Object[] a) throws Throwable {
                    String mn = m.getName();
                    if (mn.equals("getStream")) {
                        closeCur();
                        int i = (Integer) a[0];
                        String mode = enumName(a[1]);
                        if (!mode.equals("EXTRACT")) return null;
                        String nm = names.get(i);
                        if (nm == null) return null;
                        curSkipped[0] = false;
                        File out;
                        if (res != null) {
                            Long sz = sizes.get(i);
                            try { out = res.out(nm, sz == null ? -1L : sz); }   // вопрос про совпадение имён; может бросить отмену
                            catch (Throwable t) { resEx[0] = t; throw t; }
                            if (out == null) { curSkipped[0] = true; curName[0] = nm; return null; }   // ответ «пропустить»
                        } else {
                            out = new File(dd, nm);
                            String base = dd.getCanonicalPath(), full = out.getCanonicalPath();
                            if (!full.equals(base) && !full.startsWith(base + File.separator))
                                throw new java.io.IOException("Опасный путь в архиве: " + nm);
                        }
                        if (out.getParentFile() != null) out.getParentFile().mkdirs();
                        curName[0] = nm;
                        curOut[0] = new FileOutputStream(out);
                        return outProxy(curOut[0], res);
                    }
                    if (mn.equals("prepareOperation")) return null;
                    if (mn.equals("setOperationResult")) {
                        closeCur();
                        String r = enumName(a[0]);
                        if (curSkipped[0]) { curSkipped[0] = false; done[0]++; return null; }   // пропущенное не считаем ошибкой
                        if (r.equals("WRONG_PASSWORD")) wrongPw[0] = true;
                        else if (!r.equals("OK")) {
                            if (pw != null && !pw.isEmpty() && (r.equals("DATAERROR") || r.equals("CRCERROR"))) wrongPw[0] = true;
                            else if (res != null) { try { res.err(curName[0], r); } catch (Throwable t) { resEx[0] = t; throw t; } }   // вопрос «пропустить/отменить»; может бросить отмену
                            else if (failure[0] == null) failure[0] = curName[0] + ": " + r;
                        } else {
                            done[0]++;
                            if (prog != null) prog.on(curName[0], done[0], total);
                        }
                        return null;
                    }
                    if (mn.equals("cryptoGetTextPassword")) {
                        if (pw == null || pw.isEmpty()) { wrongPw[0] = false; throw new RuntimeException("__need_password__"); }
                        return pw;
                    }
                    if (mn.equals("setTotal") || mn.equals("setCompleted")) return null;
                    if (mn.equals("hashCode")) return System.identityHashCode(proxy);
                    if (mn.equals("equals")) return proxy == a[0];
                    if (mn.equals("toString")) return "yev-extract-callback";
                    return null;
                }
                private void closeCur() { if (curOut[0] != null) { try { curOut[0].close(); } catch (Throwable ignored) {} curOut[0] = null; } }
            };
            Object cb = Proxy.newProxyInstance(SevenZipEngine.class.getClassLoader(), new Class<?>[]{ cExtractCb, cCrypto, cProgress }, ih);
            try {
                mExtract.invoke(h.arch, idx, Boolean.FALSE, cb);
            } catch (Throwable t) {
                Throwable c = (t instanceof java.lang.reflect.InvocationTargetException && t.getCause() != null) ? t.getCause() : t;
                if (resEx[0] != null) { if (resEx[0] instanceof Error) throw (Error) resEx[0]; if (resEx[0] instanceof Exception) throw (Exception) resEx[0]; throw new Exception(String.valueOf(resEx[0])); }
                if (String.valueOf(c.getMessage()).contains("__need_password__")) throw new NeedPassword();
                if (wrongPw[0]) throw new WrongPassword();
                if (looksLikePassword(c)) { if (pw == null || pw.isEmpty()) throw new NeedPassword(); throw new WrongPassword(); }
                if (c instanceof Exception) throw (Exception) c;
                throw new Exception(String.valueOf(c));
            } finally { try { if (curOut[0] != null) curOut[0].close(); } catch (Throwable ignored) {} }
            if (resEx[0] != null) { if (resEx[0] instanceof Error) throw (Error) resEx[0]; if (resEx[0] instanceof Exception) throw (Exception) resEx[0]; throw new Exception(String.valueOf(resEx[0])); }
            if (wrongPw[0]) throw new WrongPassword();
            if (failure[0] != null && done[0] == 0) throw new Exception("Не удалось распаковать: " + failure[0]);
        } finally { h.close(); }
    }

    /** Есть ли текст в сообщении исключения или любой из его причин. */
    private static boolean chainHas(Throwable t, String needle) {
        int guard = 0;
        while (t != null && guard++ < 12) {
            if (String.valueOf(t.getMessage()).contains(needle)) return true;
            t = t.getCause();
        }
        return false;
    }

    private static Object outProxy(final OutputStream os) { return outProxy(os, null); }

    private static Object outProxy(final OutputStream os, final Resolver res) {
        return Proxy.newProxyInstance(SevenZipEngine.class.getClassLoader(), new Class<?>[]{ cSeqOut }, new InvocationHandler() {
            @Override public Object invoke(Object proxy, Method m, Object[] a) throws Throwable {
                String mn = m.getName();
                if (mn.equals("write")) { byte[] b = (byte[]) a[0]; os.write(b); if (res != null) res.bytes(b.length); return b.length; }
                if (mn.equals("hashCode")) return System.identityHashCode(proxy);
                if (mn.equals("equals")) return proxy == a[0];
                if (mn.equals("toString")) return "yev-out-stream";
                return null;
            }
        });
    }
}
