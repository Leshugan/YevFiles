package leshugan.fm;

import android.content.ComponentName;
import android.content.Context;
import android.content.ServiceConnection;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.IBinder;

import rikka.shizuku.Shizuku;

/**
 * Тонкая обёртка над Shizuku: состояние, запрос разрешения, подключение службы.
 * Если Shizuku не установлен или выключен — всё молча возвращает «недоступно»,
 * приложение продолжает работать как обычно.
 */
public class ShizukuBridge {

    public static final int REQ_CODE = 4711;

    private static IYevShizuku service;
    private static boolean binding;
    private static volatile String lastError;      // что помешало поднять службу — показываем в настройках
    private static volatile long bindTry;

    /** подключена ли служба внутри Shizuku */
    public static boolean bound() { return service != null; }

    public static String error() { return lastError; }

    /** Shizuku работает только с Android 6.0 — ниже функция просто выключена */
    public static boolean supported() {
        return Build.VERSION.SDK_INT >= 23;
    }

    /** установлен ли Shizuku (есть пакет) */
    public static boolean installed(Context ctx) {
        if (!supported()) return false;
        try {
            ctx.getPackageManager().getPackageInfo("moe.shizuku.privileged.api", 0);
            return true;
        } catch (PackageManager.NameNotFoundException e) {
            return false;
        } catch (Exception e) {
            return false;
        }
    }

    /** запущен ли служебный процесс */
    public static boolean running() {
        if (!supported()) return false;
        try { return Shizuku.pingBinder(); } catch (Throwable t) { return false; }
    }

    /** выдано ли нам разрешение */
    public static boolean granted() {
        if (!supported()) return false;
        try {
            if (!running()) return false;
            if (Shizuku.isPreV11()) return false;
            return Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED;
        } catch (Throwable t) { return false; }
    }

    /** показать системный запрос разрешения */
    public static void requestPermission() {
        if (!supported()) return;
        try {
            if (!running()) { lastError = "Shizuku не запущен"; return; }
            if (granted()) return;
            Shizuku.requestPermission(REQ_CODE);
        } catch (Throwable t) { lastError = t.getMessage() == null ? String.valueOf(t) : t.getMessage(); }
    }

    /** Подробности состояния — показываем в разделе разрешений, чтобы не гадать. */
    public static String detail(Context ctx) {
        StringBuilder sb = new StringBuilder();
        sb.append("установлен: ").append(installed(ctx) ? "да" : "нет");
        sb.append(", служба Shizuku: ").append(running() ? "работает" : "не запущена");
        try { sb.append(", версия: ").append(running() ? String.valueOf(Shizuku.getVersion()) : "—"); } catch (Throwable ignored) {}
        sb.append(", разрешение нам: ").append(granted() ? "выдано" : "нет");
        sb.append(", наша служба: ").append(bound() ? "подключена" : "не подключена");
        if (lastError != null) sb.append(", ошибка: ").append(lastError);
        return sb.toString();
    }

    /** служба готова к работе */
    public static boolean ready() {
        return service != null && granted();
    }

    /** быстрая самопроверка: реально ли служба отвечает */
    public static boolean alive() {
        try { return service != null && service.asBinder().pingBinder(); } catch (Throwable t) { return false; }
    }

    public static IYevShizuku get() {
        return granted() ? service : null;
    }

    /** поднять службу внутри процесса Shizuku; вызывать после выдачи разрешения */
    private static boolean listening;

    /**
     * Связь с Shizuku приходит не сразу после запуска приложения. Поэтому подписываемся:
     * как только она появилась — сразу поднимаем свою службу.
     */
    public static void listen(final Context ctx) {
        if (!supported() || listening) return;
        listening = true;
        try {
            Shizuku.addBinderReceivedListenerSticky(new Shizuku.OnBinderReceivedListener() {
                @Override public void onBinderReceived() { lastError = null; bindTry = 0; bind(ctx); }
            });
            Shizuku.addBinderDeadListener(new Shizuku.OnBinderDeadListener() {
                @Override public void onBinderDead() { service = null; lastError = "Shizuku остановлен"; }
            });
            Shizuku.addRequestPermissionResultListener(new Shizuku.OnRequestPermissionResultListener() {
                @Override public void onRequestPermissionResult(int code, int result) {
                    if (result == android.content.pm.PackageManager.PERMISSION_GRANTED) { bindTry = 0; bind(ctx); }
                    else lastError = "в Shizuku отказано";
                }
            });
        } catch (Throwable t) { lastError = String.valueOf(t.getMessage()); }
    }

    public static void bind(final Context ctx) {
        if (!supported() || !granted()) return;
        if (service != null && !alive()) service = null;            // служба отвалилась — поднимем заново
        if (service != null || binding) return;
        long now = System.currentTimeMillis();
        if (now - bindTry < 1500) return;                            // не долбим подряд
        bindTry = now;
        binding = true;
        try {
            Shizuku.UserServiceArgs args = new Shizuku.UserServiceArgs(
                    new ComponentName(ctx.getPackageName(), YevShizukuService.class.getName()))
                    .daemon(false)
                    .processNameSuffix("yevfs")
                    .debuggable(false)
                    .version(1);
            Shizuku.bindUserService(args, new ServiceConnection() {
                @Override public void onServiceConnected(ComponentName name, IBinder binder) {
                    binding = false;
                    if (binder != null && binder.pingBinder()) { service = IYevShizuku.Stub.asInterface(binder); lastError = null; }
                    else lastError = "служба не отвечает";
                }
                @Override public void onServiceDisconnected(ComponentName name) {
                    service = null; binding = false;
                }
            });
        } catch (Throwable t) {
            binding = false;
            lastError = t.getMessage() == null ? String.valueOf(t) : t.getMessage();
        }
    }

    /** Места, куда обычное приложение не пускают, а оболочка проходит. */
    private static final String[] SHELL_ONLY = {
        "/system", "/vendor", "/product", "/apex", "/system_ext", "/odm",
        "/data/app", "/data/local", "/data/media", "/data/misc", "/cache",
        "/proc", "/sys", "/mnt", "/config", "/dev", "/oem", "/metadata",
    };

    /** путь, куда Android не пускает обычное приложение — читаем через Shizuku */
    public static boolean restricted(String path) {
        if (path == null) return false;
        String p = path.replace('\\', '/');
        if (Build.VERSION.SDK_INT >= 30 && (p.contains("/Android/data") || p.contains("/Android/obb")
                || p.contains("/Android/sandbox") || p.contains("/Android/media"))) return true;
        if (p.equals("/")) return true;
        for (String s : SHELL_ONLY) if (p.equals(s) || p.startsWith(s + "/")) return true;
        // другие профили телефона: /storage/emulated/10 и подобные
        try {
            java.util.regex.Matcher m = java.util.regex.Pattern.compile("^/storage/emulated/(\\d+)(/.*)?$").matcher(p);
            if (m.matches() && !"0".equals(m.group(1))) return true;
        } catch (Throwable ignored) {}
        return false;
    }

    /** Можно ли туда писать: системные разделы смонтированы только на чтение. */
    public static boolean readOnlyArea(String path) {
        if (path == null) return false;
        String p = path.replace('\\', '/');
        for (String s : new String[]{ "/system", "/vendor", "/product", "/apex", "/system_ext", "/odm", "/proc", "/sys", "/config", "/oem" })
            if (p.equals(s) || p.startsWith(s + "/")) return true;
        return false;
    }
}
