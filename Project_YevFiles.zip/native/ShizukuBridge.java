package leshugan.fm;

import android.content.ComponentName;
import android.content.Context;
import android.content.ServiceConnection;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.IBinder;

import rikka.shizuku.Shizuku;

/**
 * Тонкая обёртка над Shizuku: состояние, запрос разрешения, подключение службы.
 * Если Shizuku не установлен или выключен — всё молча возвращает «недоступно»,
 * приложение продолжает работать как обычно.
 */
public class ShizukuBridge {

    public static final int REQ_CODE = 4711;

    private static IYevShizuku service;
    private static boolean binding;

    /** Shizuku работает только с Android 6.0 — ниже функция просто выключена */
    public static boolean supported() {
        return Build.VERSION.SDK_INT >= 23;
    }

    /** установлен ли Shizuku (есть пакет) */
    public static boolean installed(Context ctx) {
        if (!supported()) return false;
        try {
            ctx.getPackageManager().getPackageInfo("moe.shizuku.privileged.api", 0);
            return true;
        } catch (PackageManager.NameNotFoundException e) {
            return false;
        } catch (Exception e) {
            return false;
        }
    }

    /** запущен ли служебный процесс */
    public static boolean running() {
        if (!supported()) return false;
        try { return Shizuku.pingBinder(); } catch (Throwable t) { return false; }
    }

    /** выдано ли нам разрешение */
    public static boolean granted() {
        if (!supported()) return false;
        try {
            if (!running()) return false;
            if (Shizuku.isPreV11()) return false;
            return Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED;
        } catch (Throwable t) { return false; }
    }

    /** показать системный запрос разрешения */
    public static void requestPermission() {
        if (!supported()) return;
        try { if (running() && !granted()) Shizuku.requestPermission(REQ_CODE); } catch (Throwable ignored) {}
    }

    /** служба готова к работе */
    public static boolean ready() {
        return service != null && granted();
    }

    public static IYevShizuku get() {
        return granted() ? service : null;
    }

    /** поднять службу внутри процесса Shizuku; вызывать после выдачи разрешения */
    public static void bind(final Context ctx) {
        if (!supported() || service != null || binding || !granted()) return;
        binding = true;
        try {
            Shizuku.UserServiceArgs args = new Shizuku.UserServiceArgs(
                    new ComponentName(ctx.getPackageName(), YevShizukuService.class.getName()))
                    .daemon(false)
                    .processNameSuffix("yevfs")
                    .debuggable(false)
                    .version(1);
            Shizuku.bindUserService(args, new ServiceConnection() {
                @Override public void onServiceConnected(ComponentName name, IBinder binder) {
                    binding = false;
                    if (binder != null && binder.pingBinder()) service = IYevShizuku.Stub.asInterface(binder);
                }
                @Override public void onServiceDisconnected(ComponentName name) {
                    service = null; binding = false;
                }
            });
        } catch (Throwable t) {
            binding = false;
        }
    }

    /** путь, куда Android не пускает обычное приложение начиная с 11-й версии */
    public static boolean restricted(String path) {
        if (path == null || Build.VERSION.SDK_INT < 30) return false;
        String p = path.replace('\\', '/');
        return p.contains("/Android/data") || p.contains("/Android/obb");
    }
}
