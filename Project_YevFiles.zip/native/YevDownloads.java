package leshugan.fm;

import android.content.Context;

import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Слежение за качающимися файлами в открытой папке.
 *
 * Как понимаем, что файл ещё качается:
 *   - у него служебное расширение (.crdownload у Chrome, .part, .download и подобные), либо
 *   - он вырос с прошлой проверки (значит, в него прямо сейчас пишут).
 * Общий размер берём из уведомления браузера, если приложению дан доступ к уведомлениям;
 * без него показываем только накопленный вес.
 */
public final class YevDownloads {

    public interface Emitter { void emit(String event, JSObject data); }

    /** Служебные хвосты имён у качающихся файлов. */
    private static final String[] PART_EXT = {
        ".crdownload", ".part", ".download", ".partial", ".!ut", ".opdownload",
        ".filepart", ".crswap", ".tmp", ".temp", ".dctmp", ".aria2", ".td", ".unconfirmed"
    };

    /** Что сейчас говорит шторка. Заполняется службой уведомлений. */
    static final class Nf { String title; long done; long total; String extra; String pkg; long at; }
    static final Map<String, Nf> NOTIF = new ConcurrentHashMap<>();

    static void putNotif(String title, long done, long total, String extra, String pkg) {
        Nf n = new Nf();
        n.title = title; n.done = done; n.total = total; n.extra = extra; n.pkg = pkg; n.at = System.currentTimeMillis();
        NOTIF.put(norm(title), n);
    }

    static void dropNotif(String title) { NOTIF.remove(norm(title)); }

    /** Имя для сравнения: без служебных приставок и хвостов, без лишних пробелов, в нижнем регистре. */
    static String norm(String s) {
        String n = plainName(stripPending(s == null ? "" : s));
        n = n.replaceAll("\\s+", " ").trim().toLowerCase(Locale.ROOT);
        return n;
    }

    /**
     * Уведомление к файлу подбираем с запасом: браузер часто урезает имя многоточием
     * («Skyrim Remastered - Op….7z»), поэтому сверяем начало и конец.
     */
    static Nf findNotif(String fileName) {
        String want = norm(fileName);
        if (want.isEmpty()) return null;
        Nf exact = NOTIF.get(want);
        if (exact != null) return exact;
        Nf best = null;
        for (Nf n : NOTIF.values()) {
            String t = norm(n.title);
            if (t.isEmpty()) continue;
            if (want.equals(t) || want.startsWith(t) || t.startsWith(want)) { best = n; break; }
            // имя с многоточием: «начало….хвост»
            String[] parts = t.split("[….]{2,}|\\u2026");
            if (parts.length >= 2) {
                String head = parts[0].trim(), tail = parts[parts.length - 1].trim();
                if (head.length() >= 4 && want.startsWith(head) && (tail.isEmpty() || want.endsWith(tail))) { best = n; break; }
            }
            // хотя бы первые 10 символов совпали
            int k = Math.min(10, Math.min(t.length(), want.length()));
            if (k >= 6 && t.regionMatches(0, want, 0, k)) { best = n; }
        }
        return best;
    }

    /** «.pending-1788283246-имя.zip» → «имя.zip»; то же для «.trashed-…». */
    static String stripPending(String name) {
        java.util.regex.Matcher m = java.util.regex.Pattern.compile("^\\.(?:pending|trashed)-\\d+-(.*)$").matcher(name);
        return m.matches() ? m.group(1) : name;
    }

    private static final long TICK = 500;          // как часто смотрим
    private static final long GROW_WINDOW = 2500;  // рос недавно — значит качается
    private static final long STALL = 60000;       // не растёт минуту — брошен

    private final Context ctx;
    private final Emitter em;
    private Thread worker;
    private volatile String dir;

    private static final class St { long size; long grewAt; }
    private final Map<String, St> seen = new HashMap<>();

    public YevDownloads(Context ctx, Emitter em) { this.ctx = ctx.getApplicationContext(); this.em = em; }

    /** Загрузки «в процессе» из системного списка: их не видно в папке, пока браузер не закончит. */
    private void pending(String d, JSArray arr) {
        if (android.os.Build.VERSION.SDK_INT < 29) return;
        String dir = d.endsWith("/") ? d.substring(0, d.length() - 1) : d;
        android.database.Cursor c = null;
        try {
            android.os.Bundle q = new android.os.Bundle();
            q.putString(android.content.ContentResolver.QUERY_ARG_SQL_SELECTION, "_data LIKE ?");
            q.putStringArray(android.content.ContentResolver.QUERY_ARG_SQL_SELECTION_ARGS, new String[]{ dir + "/%" });
            q.putInt(android.provider.MediaStore.QUERY_ARG_MATCH_PENDING, android.provider.MediaStore.MATCH_INCLUDE);
            q.putInt(android.provider.MediaStore.QUERY_ARG_MATCH_TRASHED, android.provider.MediaStore.MATCH_EXCLUDE);
            c = ctx.getContentResolver().query(
                    android.provider.MediaStore.Downloads.getContentUri("external"),
                    new String[]{ "_data", "_display_name", "_size", "is_pending", "date_added", "date_modified" }, q, null);
            if (c == null) return;
            long now = System.currentTimeMillis();
            Map<String, JSObject> byName = new LinkedHashMap<>();
            Map<String, Long> doneByName = new HashMap<>();
            while (c.moveToNext()) {
                if (c.getInt(3) != 1) continue;                     // не «в процессе» — пропускаем
                String p = c.getString(0);
                if (p == null) continue;
                int sl = p.lastIndexOf('/');
                if (sl < 0 || !p.substring(0, sl).equals(dir)) continue;   // только эта папка, без подпапок
                String file = p.substring(sl + 1);
                // как показывать: системное имя записи, а не служебное имя файла на диске
                String shown = c.getString(1);
                String plain = plainName(shown != null && !shown.isEmpty() ? shown : file);

                long onDisk = 0;
                try { onDisk = new File(p).length(); } catch (Throwable ignored) {}
                Nf nf = findNotif(plain);
                if (nf == null) nf = findNotif(file);
                long total = nf != null && nf.total > 0 ? nf.total : -1;
                // Размер в системной записи у качающегося файла бывает заранее заявленным или
                // оставшимся от прошлой попытки, поэтому при наличии уведомления верим только ему.
                long done = nf != null && nf.done > 0 ? nf.done : (onDisk > 0 ? onDisk : c.getLong(2));
                if (total > 0 && done > total) done = total;

                // брошенные пустые записи (отменённая загрузка) не показываем
                long mod = Math.max(c.getLong(4), c.getLong(5)) * 1000L;
                boolean fresh = mod > 0 && now - mod < 60000;
                if (done <= 0 && nf == null && !fresh) continue;

                Long prevDone = doneByName.get(plain);
                if (prevDone != null && prevDone >= done) continue;   // такой же файл уже есть, оставляем больший
                doneByName.put(plain, done);

                JSObject o = new JSObject();
                o.put("file", file);
                o.put("name", plain);
                o.put("done", done);
                o.put("total", total);
                if (nf != null && nf.extra != null) o.put("extra", nf.extra);
                o.put("stalled", false);
                o.put("virtual", true);                              // на диске файла ещё не видно
                byName.put(plain, o);
            }
            for (JSObject o : byName.values()) arr.put(o);
        } catch (Throwable ignored) {
        } finally { if (c != null) try { c.close(); } catch (Throwable ignored) {} }
    }

    public static String plainName(String name) {
        String n = stripPending(name);
        for (int i = 0; i < 3; i++) {
            String low = n.toLowerCase(Locale.ROOT);
            boolean cut = false;
            for (String e : PART_EXT) {
                if (low.endsWith(e)) { n = n.substring(0, n.length() - e.length()); cut = true; break; }
            }
            if (!cut) break;
        }
        return n;
    }

    public static boolean isPartName(String name) {
        String low = name.toLowerCase(Locale.ROOT);
        for (String e : PART_EXT) if (low.endsWith(e)) return true;
        return false;
    }

    /** Начать (или прекратить, если path == null) следить за папкой. */
    public synchronized void watch(String path) {
        dir = path;
        synchronized (seen) { seen.clear(); }
        if (path == null) return;
        if (worker != null && worker.isAlive()) return;
        worker = new Thread(() -> {
            while (true) {
                String d = dir;
                if (d == null) return;
                try { scan(d); } catch (Throwable ignored) {}
                try { Thread.sleep(TICK); } catch (InterruptedException e) { return; }
            }
        }, "yev-dl");
        worker.setDaemon(true);
        worker.start();
    }

    private void scan(String d) {
        File folder = new File(d);
        String[] kids = folder.list();
        if (kids == null) return;
        long now = System.currentTimeMillis();
        JSArray arr = new JSArray();
        Map<String, St> cur = new LinkedHashMap<>();
        for (String k : kids) {
            File f = new File(folder, k);
            long len;
            boolean dirEntry;
            try {
                android.system.StructStat st = android.system.Os.lstat(f.getAbsolutePath());
                dirEntry = android.system.OsConstants.S_ISDIR(st.st_mode);
                len = st.st_size;
            } catch (Throwable t) { dirEntry = f.isDirectory(); len = f.length(); }
            if (dirEntry) continue;

            St prev;
            synchronized (seen) { prev = seen.get(k); }
            St s = new St();
            s.size = len;
            // «растёт» — только если мы своими глазами увидели прибавку между двумя проверками
            boolean grew = prev != null && len > prev.size;
            s.grewAt = grew ? now : (prev != null ? prev.grewAt : 0);
            cur.put(k, s);

            boolean part = isPartName(k);
            // качается: служебное имя, либо файл рос совсем недавно (окно, чтобы кольцо не мигало между проверками)
            boolean active = part || (s.grewAt > 0 && now - s.grewAt < GROW_WINDOW);
            if (!active) continue;

            String plain = plainName(k);
            Nf nf = findNotif(k);
            long total = nf != null && nf.total > 0 ? nf.total : -1;
            long done = nf != null && nf.done > 0 ? nf.done : len;
            if (total > 0 && done > total) done = total;

            JSObject o = new JSObject();
            o.put("file", k);                                    // как лежит на диске
            o.put("name", plain);                                // как показываем
            o.put("done", done);
            o.put("total", total);
            if (nf != null && nf.extra != null) o.put("extra", nf.extra);
            o.put("stalled", part && s.grewAt > 0 && now - s.grewAt > STALL);
            arr.put(o);
        }
        synchronized (seen) { seen.clear(); seen.putAll(cur); }

        // На Android 11+ качающийся файл системой прячется от других приложений:
        // на диске его не видно, но он числится в списке загрузок как «ожидающий».
        // Достаём такие записи и показываем как пустышки.
        try { pending(d, arr); } catch (Throwable ignored) {}

        JSObject ev = new JSObject();
        ev.put("dir", d);
        ev.put("items", arr);
        em.emit("dlProgress", ev);
    }
}
