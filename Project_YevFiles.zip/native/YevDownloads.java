package leshugan.fm;

import android.content.Context;

import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Слежение за качающимися файлами в открытой папке.
 *
 * Как понимаем, что файл ещё качается:
 *   - у него служебное расширение (.crdownload у Chrome, .part, .download и подобные), либо
 *   - он вырос с прошлой проверки (значит, в него прямо сейчас пишут).
 * Общий размер берём из уведомления браузера, если приложению дан доступ к уведомлениям;
 * без него показываем только накопленный вес.
 */
public final class YevDownloads {

    public interface Emitter { void emit(String event, JSObject data); }

    /** Служебные хвосты имён у качающихся файлов. */
    private static final String[] PART_EXT = {
        ".crdownload", ".part", ".download", ".partial", ".!ut", ".opdownload",
        ".filepart", ".crswap", ".tmp", ".temp", ".dctmp", ".aria2", ".td", ".unconfirmed"
    };

    /** Что сейчас говорит шторка: имя файла -> {сделано, всего}. Заполняется службой уведомлений. */
    static final Map<String, long[]> NOTIF = new ConcurrentHashMap<>();

    private static final long TICK = 500;          // как часто смотрим
    private static final long GROW_WINDOW = 2500;  // рос недавно — значит качается
    private static final long STALL = 60000;       // не растёт минуту — брошен

    private final Context ctx;
    private final Emitter em;
    private Thread worker;
    private volatile String dir;

    private static final class St { long size; long changed; long started; }
    private final Map<String, St> seen = new HashMap<>();

    public YevDownloads(Context ctx, Emitter em) { this.ctx = ctx.getApplicationContext(); this.em = em; }

    public static String plainName(String name) {
        String n = name;
        for (int i = 0; i < 3; i++) {
            String low = n.toLowerCase(Locale.ROOT);
            boolean cut = false;
            for (String e : PART_EXT) {
                if (low.endsWith(e)) { n = n.substring(0, n.length() - e.length()); cut = true; break; }
            }
            if (!cut) break;
        }
        return n;
    }

    public static boolean isPartName(String name) {
        String low = name.toLowerCase(Locale.ROOT);
        for (String e : PART_EXT) if (low.endsWith(e)) return true;
        return false;
    }

    /** Начать (или прекратить, если path == null) следить за папкой. */
    public synchronized void watch(String path) {
        dir = path;
        synchronized (seen) { seen.clear(); }
        if (path == null) return;
        if (worker != null && worker.isAlive()) return;
        worker = new Thread(() -> {
            while (true) {
                String d = dir;
                if (d == null) return;
                try { scan(d); } catch (Throwable ignored) {}
                try { Thread.sleep(TICK); } catch (InterruptedException e) { return; }
            }
        }, "yev-dl");
        worker.setDaemon(true);
        worker.start();
    }

    private void scan(String d) {
        File folder = new File(d);
        String[] kids = folder.list();
        if (kids == null) return;
        long now = System.currentTimeMillis();
        JSArray arr = new JSArray();
        Map<String, St> cur = new LinkedHashMap<>();
        for (String k : kids) {
            File f = new File(folder, k);
            long len;
            boolean dirEntry;
            try {
                android.system.StructStat st = android.system.Os.lstat(f.getAbsolutePath());
                dirEntry = android.system.OsConstants.S_ISDIR(st.st_mode);
                len = st.st_size;
            } catch (Throwable t) { dirEntry = f.isDirectory(); len = f.length(); }
            if (dirEntry) continue;

            St prev;
            synchronized (seen) { prev = seen.get(k); }
            St s = new St();
            if (prev == null) {
                s.size = len; s.changed = now; s.started = now;
            } else {
                s.size = len;
                s.changed = len != prev.size ? now : prev.changed;
                s.started = prev.started;
            }
            cur.put(k, s);

            boolean part = isPartName(k);
            boolean growing = prev != null && len > prev.size;
            boolean recentlyGrew = now - s.changed < GROW_WINDOW;
            // новый файл со служебным хвостом считаем качающимся сразу, не дожидаясь роста
            boolean fresh = prev == null && part;
            if (!part && !growing && !recentlyGrew) continue;
            if (!part && prev == null) continue;                 // просто новый готовый файл — не трогаем
            if (!part && !growing && !fresh && now - s.changed > GROW_WINDOW) continue;

            String plain = plainName(k);
            long[] nf = NOTIF.get(plain);
            if (nf == null) nf = NOTIF.get(k);
            long total = nf != null && nf[1] > 0 ? nf[1] : -1;
            long done = nf != null && nf[0] > 0 && nf[0] >= len ? nf[0] : len;

            JSObject o = new JSObject();
            o.put("file", k);                                    // как лежит на диске
            o.put("name", plain);                                // как показываем
            o.put("done", done);
            o.put("total", total);
            o.put("stalled", part && now - s.changed > STALL);
            arr.put(o);
        }
        synchronized (seen) { seen.clear(); seen.putAll(cur); }

        JSObject ev = new JSObject();
        ev.put("dir", d);
        ev.put("items", arr);
        em.emit("dlProgress", ev);
    }
}
