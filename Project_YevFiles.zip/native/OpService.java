package leshugan.fm;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.IBinder;

/**
 * Служба переднего плана на время долгих операций (копирование, распаковка, удаление).
 * Пока она жива, система не выгружает приложение и работа не обрывается,
 * даже если свернуть приложение или погасить экран.
 */
public class OpService extends Service {

    public static final String CH = "yev_ops";
    public static final int NOTIF_ID = 778;
    private static volatile boolean running = false;

    public static boolean isRunning() { return running; }

    public static void start(Context ctx, String title, String text, int progress, int max) {
        Intent i = new Intent(ctx, OpService.class);
        i.putExtra("title", title == null ? "Операция с файлами" : title);
        i.putExtra("text", text == null ? "" : text);
        i.putExtra("progress", progress);
        i.putExtra("max", max);
        try {
            if (Build.VERSION.SDK_INT >= 26) ctx.startForegroundService(i);
            else ctx.startService(i);
        } catch (Throwable ignored) {}
    }

    public static void stop(Context ctx) {
        try {
            Intent i = new Intent(ctx, OpService.class);
            i.putExtra("stop", true);
            if (Build.VERSION.SDK_INT >= 26) ctx.startForegroundService(i); else ctx.startService(i);
        } catch (Throwable ignored) {
            try { ctx.stopService(new Intent(ctx, OpService.class)); } catch (Throwable ignored2) {}
        }
        // подчищаем уведомление на случай, если служба уже умерла
        try {
            NotificationManager nm = (NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE);
            nm.cancel(NOTIF_ID);
        } catch (Throwable ignored) {}
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && intent.getBooleanExtra("stop", false)) {
            // остановка обрабатывается в общей очереди команд — «стоп» не обгоняет «старт»
            running = false;
            try { stopForeground(true); } catch (Throwable ignored) {}
            try { ((NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE)).cancel(NOTIF_ID); } catch (Throwable ignored) {}
            stopSelf();
            return START_NOT_STICKY;
        }
        String title = intent != null ? intent.getStringExtra("title") : "Операция с файлами";
        String text = intent != null ? intent.getStringExtra("text") : "";
        int progress = intent != null ? intent.getIntExtra("progress", 0) : 0;
        int max = intent != null ? intent.getIntExtra("max", 100) : 100;
        try {
            NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            if (Build.VERSION.SDK_INT >= 26) {
                NotificationChannel ch = new NotificationChannel(CH, "Операции с файлами", NotificationManager.IMPORTANCE_LOW);
                ch.setShowBadge(false);
                nm.createNotificationChannel(ch);
            }
            Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, CH) : new Notification.Builder(this);
            b.setContentTitle(title).setContentText(text)
             .setSmallIcon(android.R.drawable.stat_sys_download)
             .setOnlyAlertOnce(true).setOngoing(true)
             .setProgress(max > 0 ? max : 100, progress, max <= 0);
            try {
                Intent li = getPackageManager().getLaunchIntentForPackage(getPackageName());
                if (li != null) {
                    li.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    int fl = Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT : PendingIntent.FLAG_UPDATE_CURRENT;
                    b.setContentIntent(PendingIntent.getActivity(this, 0, li, fl));
                }
            } catch (Throwable ignored) {}
            Notification n = b.build();
            if (!running) {
                if (Build.VERSION.SDK_INT >= 29) startForeground(NOTIF_ID, n, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC);
                else startForeground(NOTIF_ID, n);
                running = true;
            } else {
                nm.notify(NOTIF_ID, n);   // просто обновляем ход работы
            }
        } catch (Throwable ignored) {}
        return START_NOT_STICKY;
    }

    @Override
    public void onDestroy() {
        running = false;
        try { stopForeground(true); } catch (Throwable ignored) {}
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }
}
