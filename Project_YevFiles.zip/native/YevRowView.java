package leshugan.fm;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Rect;
import android.graphics.RectF;
import android.text.TextPaint;
import android.text.TextUtils;
import android.view.View;

/**
 * Одна строка списка, нарисованная вручную — теми же размерами и цветами,
 * что и в веб-части: квадрат значка слева, имя в две строки, под ним дата,
 * справа число объектов и размер, снизу тонкая полоса.
 */
public class YevRowView extends View {

    public static class Item {
        public String name;
        public boolean dir;
        public long size;
        public long mtime;
        public int count = -1;          // объектов в папке, -1 если неизвестно
        public long bytes = -1;         // вес папки, -1 если не считаем
        public String iconKey = "file"; // какой значок рисовать
        public int iconColor;
        public Bitmap thumb;            // превью, если готово
        public boolean selected;
        public boolean here;            // отсюда только что вышли
    }

    private final YevTheme t;
    private final float d;
    private Item item;

    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final TextPaint nameP = new TextPaint(Paint.ANTI_ALIAS_FLAG);
    private final TextPaint subP = new TextPaint(Paint.ANTI_ALIAS_FLAG);
    private final TextPaint numP = new TextPaint(Paint.ANTI_ALIAS_FLAG);
    private final RectF rf = new RectF();
    private final Rect ri = new Rect();

    public YevRowView(Context c, YevTheme theme) {
        super(c);
        this.t = theme;
        this.d = c.getResources().getDisplayMetrics().density;
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeCap(Paint.Cap.ROUND);
        stroke.setStrokeJoin(Paint.Join.ROUND);
        nameP.setTextSize(YevTheme.NAME_SIZE * d);
        subP.setTextSize(YevTheme.DATE_SIZE * d);
        numP.setTextSize(YevTheme.NUM_SIZE * d);
        numP.setFakeBoldText(true);
        setMinimumHeight(Math.round(YevTheme.ROW_MIN_H * d));
    }

    public void setItem(Item it) { this.item = it; invalidate(); }

    public Item getItem() { return item; }

    private float dp(float v) { return v * d; }

    @Override
    protected void onMeasure(int wSpec, int hSpec) {
        int w = MeasureSpec.getSize(wSpec);
        setMeasuredDimension(w, Math.round(YevTheme.ROW_MIN_H * d));
    }

    @Override
    protected void onDraw(Canvas c) {
        Item it = item;
        if (it == null) return;
        int w = getWidth(), h = getHeight();

        // выделение: тем же цветом, что в веб-части
        if (it.selected) {
            fill.setColor(t.accbg);
            c.drawRect(0, 0, w, h, fill);
        }

        float left = dp(YevTheme.ROW_PAD_H);
        float icon = dp(YevTheme.ICON);
        float iconTop = (h - icon) / 2f;

        // подложка значка
        fill.setColor(t.chip);
        rf.set(left, iconTop, left + icon, iconTop + icon);
        c.drawRoundRect(rf, dp(YevTheme.ICON_RADIUS), dp(YevTheme.ICON_RADIUS), fill);

        if (it.thumb != null && !it.thumb.isRecycled()) {
            c.save();
            Path clip = new Path();
            clip.addRoundRect(rf, dp(YevTheme.ICON_RADIUS), dp(YevTheme.ICON_RADIUS), Path.Direction.CW);
            c.clipPath(clip);
            // превью вписываем «по обрезке», как objectFit: cover
            float bw = it.thumb.getWidth(), bh = it.thumb.getHeight();
            float k = Math.max(icon / bw, icon / bh);
            float dw = bw * k, dh = bh * k;
            ri.set(0, 0, (int) bw, (int) bh);
            rf.set(left + (icon - dw) / 2, iconTop + (icon - dh) / 2, left + (icon + dw) / 2, iconTop + (icon + dh) / 2);
            c.drawBitmap(it.thumb, ri, rf, fill);
            c.restore();
            rf.set(left, iconTop, left + icon, iconTop + icon);
        } else {
            // значок линиями — те же очертания, что в вебе
            stroke.setColor(it.iconColor != 0 ? it.iconColor : t.sub);
            stroke.setStrokeWidth(dp(1.8f) / (icon / dp(24)) * (icon / dp(24)));
            float scale = icon * 0.5f / 24f * 2f * 0.52f;   // значок примерно 24 из 44
            c.save();
            c.translate(left + icon / 2 - 24 * scale / 2, iconTop + icon / 2 - 24 * scale / 2);
            c.scale(scale, scale);
            stroke.setStrokeWidth(1.8f);
            for (String pd : YevIcons.get(it.iconKey)) {
                try {
                    Path p = androidx.core.graphics.PathParser.createPathFromPathData(pd);
                    if (p != null) c.drawPath(p, stroke);
                } catch (Throwable ignored) {}
            }
            c.restore();
        }

        float textLeft = left + icon + dp(YevTheme.ROW_GAP);
        float rightLimit = w - dp(YevTheme.ROW_PAD_H);

        // справа сверху — число объектов у папки
        float nameRight = rightLimit;
        if (it.dir && it.count >= 0) {
            numP.setColor(t.sub);
            numP.setTextSize(YevTheme.COUNT_SIZE * d);
            String cnt = "(" + it.count + ")";
            float cw = numP.measureText(cnt);
            c.drawText(cnt, rightLimit - cw, dp(YevTheme.ROW_PAD_V) + nameP.getTextSize(), numP);
            nameRight = rightLimit - cw - dp(8);
        }

        // имя: одна или две строки, дальше многоточие
        nameP.setColor(it.here ? t.acc : t.txt);
        nameP.setFakeBoldText(it.dir);
        float nameTop = dp(YevTheme.ROW_PAD_V) + nameP.getTextSize();
        float nameW = nameRight - textLeft - (it.here ? dp(YevTheme.HERE_DOT + 7) : 0);
        CharSequence line = TextUtils.ellipsize(it.name == null ? "" : it.name, nameP, nameW, TextUtils.TruncateAt.MIDDLE);
        c.drawText(line, 0, line.length(), textLeft, nameTop, nameP);

        // точка «отсюда вышли»
        if (it.here) {
            fill.setColor(t.acc);
            float lw = nameP.measureText(line, 0, line.length());
            c.drawCircle(textLeft + Math.min(lw, nameW) + dp(7), nameTop - nameP.getTextSize() / 2.6f, dp(YevTheme.HERE_DOT) / 2f, fill);
        }

        // вторая строка: дата слева, размер справа
        subP.setColor(t.sub);
        float subTop = nameTop + dp(6) + subP.getTextSize();
        String date = YevFmt.date(it.mtime);
        if (date != null) c.drawText(date, textLeft, subTop, subP);

        String right = it.dir ? (it.bytes >= 0 ? YevFmt.size(it.bytes) : null) : YevFmt.size(it.size);
        if (right != null) {
            numP.setColor(t.sub);
            numP.setTextSize(YevTheme.NUM_SIZE * d);
            float rw = numP.measureText(right);
            c.drawText(right, rightLimit - rw, subTop, numP);
        }

        // тонкая полоса снизу — только у файлов, как в вебе
        if (!it.dir) {
            fill.setColor(t.hair);
            c.drawRect(dp(YevTheme.LINE_LEFT), h - 1, w, h, fill);
        }
    }
}
