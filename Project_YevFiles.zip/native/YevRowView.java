package leshugan.fm;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.drawable.GradientDrawable;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

/**
 * Строка списка. Собрана из обычных полей вместо ручной отрисовки —
 * так надёжнее: ничего не может «нарисоваться в пустоту».
 * Размеры и цвета те же, что в веб-части.
 */
public class YevRowView extends LinearLayout {

    public static class Item {
        public String name;
        public boolean dir;
        public long size;
        public long mtime;
        public int count = -1;          // объектов в папке, -1 если неизвестно
        public long bytes = -1;         // вес папки, -1 если не считаем
        public String iconKey = "file";
        public int iconColor;
        public String badge;            // буквы на значке архива
        public Bitmap thumb;
        public Bitmap cover;            // уголок с обложкой у папки
        public boolean selected;
        public boolean here;            // отсюда только что вышли
        public String path;             // полный путь
    }

    private final YevTheme t;
    private final float d;

    private final FrameLayout iconBox;
    private final IconCanvas icon;
    private final ImageView thumbView;
    private final TextView nameView, countView, dateView, sizeView;
    private final CheckMark checkView;
    private final View hereDot;
    private final ImageView coverView;
    private final LinearLayout mid, nameRow;
    private boolean gridMode = false;
    private final Paint hairPaint = new Paint();
    private Item item;

    private int dp(float v) { return Math.round(d * v); }

    public YevRowView(Context c, YevTheme theme) {
        super(c);
        this.t = theme;
        this.d = c.getResources().getDisplayMetrics().density;

        setOrientation(HORIZONTAL);
        setGravity(Gravity.CENTER_VERTICAL);
        setPadding(dp(YevTheme.ROW_PAD_H), dp(YevTheme.ROW_PAD_V), dp(YevTheme.ROW_PAD_H), dp(YevTheme.ROW_PAD_V));
        setMinimumHeight(dp(YevTheme.ROW_MIN_H));
        setWillNotDraw(false);
        hairPaint.setColor(t.hair);

        iconBox = new FrameLayout(c);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(t.chip);
        bg.setCornerRadius(dp(YevTheme.ICON_RADIUS));
        iconBox.setBackground(bg);
        iconBox.setClipToOutline(true);
        icon = new IconCanvas(c);
        iconBox.addView(icon, new FrameLayout.LayoutParams(-1, -1));
        thumbView = new ImageView(c);
        thumbView.setScaleType(ImageView.ScaleType.CENTER_CROP);
        thumbView.setVisibility(GONE);
        iconBox.addView(thumbView, new FrameLayout.LayoutParams(-1, -1));
        // отметка выделения — квадрат с галочкой поверх значка, как в вебе
        checkView = new CheckMark(c);
        checkView.setVisibility(GONE);
        // уголок с обложкой папки — как в вебе, справа снизу
        coverView = new ImageView(c);
        coverView.setScaleType(ImageView.ScaleType.CENTER_CROP);
        coverView.setVisibility(GONE);
        FrameLayout.LayoutParams clp = new FrameLayout.LayoutParams(dp(YevTheme.FOLDER_THUMB), dp(YevTheme.FOLDER_THUMB), Gravity.END | Gravity.BOTTOM);
        iconBox.addView(coverView, clp);
        iconBox.addView(checkView, new FrameLayout.LayoutParams(-1, -1));
        LayoutParams ilp = new LayoutParams(dp(YevTheme.ICON), dp(YevTheme.ICON));
        ilp.rightMargin = dp(YevTheme.ROW_GAP);
        addView(iconBox, ilp);

        mid = new LinearLayout(c);
        mid.setOrientation(VERTICAL);
        addView(mid, new LayoutParams(0, -2, 1f));

        nameRow = new LinearLayout(c);
        nameRow.setOrientation(HORIZONTAL);
        nameRow.setGravity(Gravity.CENTER_VERTICAL);
        nameView = new TextView(c);
        nameView.setTextSize(TypedValue.COMPLEX_UNIT_SP, YevTheme.NAME_SIZE);
        nameView.setTextColor(t.txt);
        nameView.setMaxLines(2);
        nameView.setEllipsize(TextUtils.TruncateAt.END);
        nameRow.addView(nameView, new LayoutParams(0, -2, 1f));
        countView = new TextView(c);
        countView.setTextSize(TypedValue.COMPLEX_UNIT_SP, YevTheme.COUNT_SIZE);
        countView.setTextColor(t.sub);
        countView.setTypeface(null, android.graphics.Typeface.BOLD);
        countView.setPadding(dp(8), 0, 0, 0);
        hereDot = new View(c);
        GradientDrawable hd = new GradientDrawable();
        hd.setShape(GradientDrawable.OVAL);
        hd.setColor(t.acc);
        hereDot.setBackground(hd);
        hereDot.setVisibility(GONE);
        LayoutParams hlp = new LayoutParams(dp(YevTheme.HERE_DOT), dp(YevTheme.HERE_DOT));
        hlp.leftMargin = dp(7);
        nameRow.addView(hereDot, hlp);
        nameRow.addView(countView);
        mid.addView(nameRow, new LayoutParams(-1, -2));

        LinearLayout subRow = new LinearLayout(c);
        subRow.setOrientation(HORIZONTAL);
        subRow.setGravity(Gravity.CENTER_VERTICAL);
        LayoutParams slp = new LayoutParams(-1, -2);
        slp.topMargin = dp(3);
        dateView = new TextView(c);
        dateView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f);
        dateView.setTextColor(t.sub);
        dateView.setSingleLine(true);
        subRow.addView(dateView, new LayoutParams(-2, -2));
        View spacer = new View(c);
        subRow.addView(spacer, new LayoutParams(0, 1, 1f));
        sizeView = new TextView(c);
        sizeView.setTextSize(TypedValue.COMPLEX_UNIT_SP, YevTheme.NUM_SIZE);
        sizeView.setTextColor(t.sub);
        sizeView.setTypeface(null, android.graphics.Typeface.BOLD);
        sizeView.setSingleLine(true);
        subRow.addView(sizeView, new LayoutParams(-2, -2));
        mid.addView(subRow, slp);
    }

    public void setItem(Item it) {
        this.item = it;
        nameView.setText(it.name == null ? "" : it.name);
        nameView.setTypeface(null, it.dir ? android.graphics.Typeface.BOLD : android.graphics.Typeface.NORMAL);
        nameView.setTextColor(it.here ? t.acc : t.txt);

        String date = YevFmt.date(it.mtime);
        dateView.setText(date == null ? "" : date);

        String right = it.dir ? (it.bytes >= 0 ? YevFmt.size(it.bytes) : "") : YevFmt.size(it.size);
        sizeView.setText(right == null ? "" : right);

        countView.setText(it.dir && it.count >= 0 ? "(" + it.count + ")" : "");

        checkView.setVisibility(it.selected ? VISIBLE : GONE);
        hereDot.setVisibility(it.here ? VISIBLE : GONE);
        if (it.cover != null && !it.cover.isRecycled()) { coverView.setImageBitmap(it.cover); coverView.setVisibility(VISIBLE); }
        else coverView.setVisibility(GONE);
        if (it.thumb != null && !it.thumb.isRecycled()) {
            thumbView.setImageBitmap(it.thumb);
            thumbView.setVisibility(VISIBLE);
            icon.setVisibility(GONE);
        } else {
            thumbView.setVisibility(GONE);
            icon.setVisibility(VISIBLE);
            icon.set(it.iconKey, it.badge, it.iconColor != 0 ? it.iconColor : t.sub);
        }

        setBackgroundColor(it.selected ? t.accbg : 0);
        invalidate();
    }

    public Item getItem() { return item; }

    /** Свой шрифт, если он выбран в настройках. */
    public void setFace(android.graphics.Typeface regular, android.graphics.Typeface bold) {
        if (regular == null) return;
        nameView.setTypeface(regular);
        dateView.setTypeface(regular);
        sizeView.setTypeface(bold != null ? bold : regular);
        countView.setTypeface(bold != null ? bold : regular);
    }

    /** Мельче или крупнее — тем же набором размеров, только с множителем. */
    public void setScale(float k) {
        if (Math.abs(k - 1f) < 0.01f) return;
        nameView.setTextSize(TypedValue.COMPLEX_UNIT_SP, YevTheme.NAME_SIZE * k);
        dateView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f * k);
        sizeView.setTextSize(TypedValue.COMPLEX_UNIT_SP, YevTheme.NUM_SIZE * k);
        countView.setTextSize(TypedValue.COMPLEX_UNIT_SP, YevTheme.COUNT_SIZE * k);
        LayoutParams ilp = (LayoutParams) iconBox.getLayoutParams();
        ilp.width = dp(YevTheme.ICON * k);
        ilp.height = dp(YevTheme.ICON * k);
        iconBox.setLayoutParams(ilp);
    }

    /** Переключение между строкой и ячейкой сетки — как в вебе. */
    public void setGrid(boolean on, int cellSize) {
        if (gridMode == on) return;
        gridMode = on;
        removeAllViews();
        if (on) {
            setOrientation(VERTICAL);
            setGravity(Gravity.CENTER);
            setPadding(dp(6), dp(6), dp(6), dp(6));
            int side = Math.max(dp(48), cellSize - dp(28));
            addView(iconBox, new LayoutParams(side, side));
            nameView.setMaxLines(2);
            nameView.setGravity(Gravity.CENTER);
            nameView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
            addView(nameView, new LayoutParams(-1, -2));
        } else {
            setOrientation(HORIZONTAL);
            setGravity(Gravity.CENTER_VERTICAL);
            setPadding(dp(YevTheme.ROW_PAD_H), dp(YevTheme.ROW_PAD_V), dp(YevTheme.ROW_PAD_H), dp(YevTheme.ROW_PAD_V));
            LayoutParams ilp = new LayoutParams(dp(YevTheme.ICON), dp(YevTheme.ICON));
            ilp.rightMargin = dp(YevTheme.ROW_GAP);
            addView(iconBox, ilp);
            nameView.setGravity(Gravity.START);
            nameView.setTextSize(TypedValue.COMPLEX_UNIT_SP, YevTheme.NAME_SIZE);
            addView(mid, new LayoutParams(0, -2, 1f));
        }
    }

    @Override
    protected void onDraw(Canvas c) {
        super.onDraw(c);
        if (item == null || item.dir) return;
        c.drawRect(dp(YevTheme.LINE_LEFT), getHeight() - 1, getWidth(), getHeight(), hairPaint);
    }

    /** Отметка выделения: залитый квадрат с галочкой поверх значка. */
    private class CheckMark extends View {
        private final Paint bg = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint tick = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final RectF r = new RectF();
        CheckMark(Context c) {
            super(c);
            bg.setColor(t.acc);
            tick.setColor(0xFFFFFFFF);
            tick.setStyle(Paint.Style.STROKE);
            tick.setStrokeCap(Paint.Cap.ROUND);
            tick.setStrokeJoin(Paint.Join.ROUND);
        }
        @Override protected void onDraw(Canvas c) {
            float w = getWidth(), h = getHeight();
            float side = Math.min(w, h) * 0.5f;
            float l = (w - side) / 2, tp = (h - side) / 2;
            r.set(l, tp, l + side, tp + side);
            c.drawRoundRect(r, side * 0.27f, side * 0.27f, bg);
            tick.setStrokeWidth(side * 0.14f);
            Path p = new Path();
            p.moveTo(l + side * 0.24f, tp + side * 0.52f);
            p.lineTo(l + side * 0.44f, tp + side * 0.72f);
            p.lineTo(l + side * 0.78f, tp + side * 0.3f);
            c.drawPath(p, tick);
        }
    }

    /** Значок: линии как в вебе или рамка с буквами для архива. */
    private class IconCanvas extends View {
        private String key = "file", badge;
        private int color;
        private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final RectF rf = new RectF();

        IconCanvas(Context c) {
            super(c);
            stroke.setStyle(Paint.Style.STROKE);
            stroke.setStrokeCap(Paint.Cap.ROUND);
            stroke.setStrokeJoin(Paint.Join.ROUND);
            text.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
            text.setTextAlign(Paint.Align.CENTER);
        }

        void set(String key, String badge, int color) {
            this.key = key; this.badge = badge; this.color = color;
            invalidate();
        }

        @Override protected void onDraw(Canvas c) {
            int w = getWidth(), h = getHeight();
            if (w == 0 || h == 0) return;
            if (badge != null) {
                float side = Math.min(w, h) * 0.68f;
                float l = (w - side) / 2, tp = (h - side) / 2;
                stroke.setColor(color);
                stroke.setStrokeWidth(side * 2f / 24f);
                rf.set(l, tp, l + side, tp + side);
                c.drawRoundRect(rf, side * 4f / 24f, side * 4f / 24f, stroke);
                text.setColor(color);
                text.setTextSize(side * 7.5f / 24f);
                c.drawText(badge, w / 2f, tp + side * 15.5f / 24f, text);
                return;
            }
            float k = Math.min(w, h) * (24f / 44f) / 24f;
            boolean solid = YevIcons.filled(key);
            Paint pp = solid ? fill : stroke;
            pp.setColor(color);
            stroke.setStrokeWidth(1.8f);
            c.save();
            c.translate((w - 24 * k) / 2f, (h - 24 * k) / 2f);
            c.scale(k, k);
            for (String pd : YevIcons.get(key)) {
                try {
                    Path path = androidx.core.graphics.PathParser.createPathFromPathData(pd);
                    if (path != null) c.drawPath(path, pp);
                } catch (Throwable ignored) {}
            }
            c.restore();
        }
    }
}
