package leshugan.fm;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.drawable.GradientDrawable;
import android.media.MediaPlayer;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

/**
 * Плеер музыки: очередь из папки, обложка из самого файла, перемотка.
 * Играет родным проигрывателем, поэтому продолжает при свёрнутом приложении.
 */
public class AudioActivity extends Activity {

    public static final String EXTRA_LIST = "list";
    public static final String EXTRA_INDEX = "index";
    public static final String EXTRA_THEME = "theme";

    private YevTheme t;
    private float d;
    private final List<String> queue = new ArrayList<>();
    private int idx;
    private MediaPlayer mp;
    private final Handler ui = new Handler(Looper.getMainLooper());

    private ImageView cover;
    private TextView title, artist, timeNow, timeAll;
    private SeekBar seek;
    private TextView playBtn;
    private boolean seeking = false;

    private int dp(float v) { return Math.round(d * v); }

    @Override
    protected void onCreate(Bundle st) {
        super.onCreate(st);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        d = getResources().getDisplayMetrics().density;
        t = YevTheme.of(getIntent().getStringExtra(EXTRA_THEME));
        Window w = getWindow();
        w.setStatusBarColor(t.bg);
        w.setNavigationBarColor(t.bg);

        String[] arr = getIntent().getStringArrayExtra(EXTRA_LIST);
        if (arr != null) for (String s : arr) queue.add(s);
        idx = getIntent().getIntExtra(EXTRA_INDEX, 0);
        if (queue.isEmpty()) { finish(); return; }
        if (idx < 0 || idx >= queue.size()) idx = 0;

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(t.bg);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setPadding(dp(20), dp(30), dp(20), dp(24));

        cover = new ImageView(this);
        cover.setScaleType(ImageView.ScaleType.CENTER_CROP);
        GradientDrawable cbg = new GradientDrawable();
        cbg.setColor(t.row2);
        cbg.setCornerRadius(dp(18));
        cover.setBackground(cbg);
        cover.setClipToOutline(true);
        int side = Math.round(getResources().getDisplayMetrics().widthPixels * 0.7f);
        LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(side, side);
        clp.bottomMargin = dp(24);
        root.addView(cover, clp);

        title = new TextView(this);
        title.setTextColor(t.txt);
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 17);
        title.setGravity(Gravity.CENTER);
        title.setSingleLine(true);
        title.setEllipsize(android.text.TextUtils.TruncateAt.MIDDLE);
        root.addView(title, new LinearLayout.LayoutParams(-1, -2));

        artist = new TextView(this);
        artist.setTextColor(t.sub);
        artist.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        artist.setGravity(Gravity.CENTER);
        artist.setSingleLine(true);
        LinearLayout.LayoutParams alp = new LinearLayout.LayoutParams(-1, -2);
        alp.bottomMargin = dp(18);
        root.addView(artist, alp);

        seek = new SeekBar(this);
        seek.setMax(1000);
        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int p, boolean fromUser) {}
            @Override public void onStartTrackingTouch(SeekBar s) { seeking = true; }
            @Override public void onStopTrackingTouch(SeekBar s) {
                seeking = false;
                try { if (mp != null) mp.seekTo((int) (mp.getDuration() * (s.getProgress() / 1000f))); } catch (Throwable ignored) {}
            }
        });
        root.addView(seek, new LinearLayout.LayoutParams(-1, -2));

        LinearLayout times = new LinearLayout(this);
        times.setOrientation(LinearLayout.HORIZONTAL);
        timeNow = new TextView(this); timeNow.setTextColor(t.sub); timeNow.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
        timeAll = new TextView(this); timeAll.setTextColor(t.sub); timeAll.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
        times.addView(timeNow, new LinearLayout.LayoutParams(-2, -2));
        View sp = new View(this); times.addView(sp, new LinearLayout.LayoutParams(0, 1, 1f));
        times.addView(timeAll, new LinearLayout.LayoutParams(-2, -2));
        LinearLayout.LayoutParams tlp = new LinearLayout.LayoutParams(-1, -2);
        tlp.bottomMargin = dp(16);
        root.addView(times, tlp);

        LinearLayout ctrl = new LinearLayout(this);
        ctrl.setOrientation(LinearLayout.HORIZONTAL);
        ctrl.setGravity(Gravity.CENTER);
        ctrl.addView(circleBtn("‹‹", 50, false, () -> go(-1)));
        playBtn = circleBtn("▮▮", 60, true, () -> toggle());
        ctrl.addView(playBtn);
        ctrl.addView(circleBtn("››", 50, false, () -> go(1)));
        root.addView(ctrl, new LinearLayout.LayoutParams(-1, -2));

        setContentView(root);
        play();
        tick();
    }

    private TextView circleBtn(String label, int size, boolean accent, final Runnable fn) {
        TextView b = new TextView(this);
        b.setText(label);
        b.setGravity(Gravity.CENTER);
        b.setTextColor(accent ? 0xFFFFFFFF : t.txt);
        b.setTextSize(TypedValue.COMPLEX_UNIT_SP, accent ? 18 : 20);
        GradientDrawable bg = new GradientDrawable();
        bg.setShape(GradientDrawable.OVAL);
        bg.setColor(accent ? t.acc : t.row2);
        b.setBackground(bg);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(size), dp(size));
        lp.setMargins(dp(14), 0, dp(14), 0);
        b.setLayoutParams(lp);
        b.setOnClickListener(v -> fn.run());
        return b;
    }

    private void play() {
        stop();
        String p = queue.get(idx);
        File f = new File(p);
        title.setText(f.getName());
        artist.setText("");
        cover.setImageBitmap(null);
        try {
            mp = new MediaPlayer();
            mp.setDataSource(p);
            mp.setOnCompletionListener(m -> go(1));
            mp.prepare();
            mp.start();
            playBtn.setText("▮▮");
            timeAll.setText(time(mp.getDuration()));
        } catch (Throwable ignored) {}
        loadTags(f);
    }

    /** Название, исполнитель и обложка — из самого файла. */
    private void loadTags(final File f) {
        new Thread(() -> {
            String tt = null, ar = null;
            Bitmap art = null;
            android.media.MediaMetadataRetriever mmr = new android.media.MediaMetadataRetriever();
            try {
                mmr.setDataSource(f.getAbsolutePath());
                tt = mmr.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_TITLE);
                ar = mmr.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_ARTIST);
                byte[] pic = mmr.getEmbeddedPicture();
                if (pic != null) art = android.graphics.BitmapFactory.decodeByteArray(pic, 0, pic.length);
            } catch (Throwable ignored) {}
            finally { try { mmr.release(); } catch (Throwable ignored) {} }
            final String ft = tt, fa = ar;
            final Bitmap fart = art;
            ui.post(() -> {
                if (ft != null && !ft.isEmpty()) title.setText(ft);
                if (fa != null && !fa.isEmpty()) artist.setText(fa);
                if (fart != null) cover.setImageBitmap(fart);
            });
        }).start();
    }

    private void toggle() {
        try {
            if (mp == null) { play(); return; }
            if (mp.isPlaying()) { mp.pause(); playBtn.setText("▶"); }
            else { mp.start(); playBtn.setText("▮▮"); }
        } catch (Throwable ignored) {}
    }

    private void go(int delta) {
        int ni = idx + delta;
        if (ni < 0) ni = queue.size() - 1;
        if (ni >= queue.size()) ni = 0;
        idx = ni;
        play();
    }

    private void stop() {
        try { if (mp != null) { mp.stop(); mp.release(); } } catch (Throwable ignored) {}
        mp = null;
    }

    private void tick() {
        ui.postDelayed(() -> {
            try {
                if (mp != null && !seeking) {
                    int pos = mp.getCurrentPosition(), dur = Math.max(1, mp.getDuration());
                    seek.setProgress((int) (1000L * pos / dur));
                    timeNow.setText(time(pos));
                }
            } catch (Throwable ignored) {}
            tick();
        }, 500);
    }

    private static String time(int ms) {
        int s = ms / 1000;
        return String.format(java.util.Locale.US, "%d:%02d", s / 60, s % 60);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        stop();
        ui.removeCallbacksAndMessages(null);
    }
}
