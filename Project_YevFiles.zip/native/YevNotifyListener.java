package leshugan.fm;

import android.app.Notification;
import android.os.Bundle;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;

import java.util.Locale;

/**
 * Читает из шторки уведомления о загрузках и достаёт из них «сколько всего» и «сколько сделано».
 * Работает только если пользователь сам включил приложению доступ к уведомлениям.
 * Ничего никуда не отправляет: цифры кладутся в память приложения и показываются в списке.
 */
public class YevNotifyListener extends NotificationListenerService {

    /** Уведомления каких приложений нас интересуют. */
    private static boolean interesting(String pkg) {
        if (pkg == null) return false;
        String p = pkg.toLowerCase(Locale.ROOT);
        return p.contains("chrome") || p.contains("browser") || p.contains("quetta") || p.contains("firefox")
                || p.contains("opera") || p.contains("yandex") || p.contains("download") || p.contains("providers.downloads")
                || p.contains("kiwi") || p.contains("brave") || p.contains("samsung.android.app.sbrowser")
                || p.contains("idm") || p.contains("adm") || p.contains("torrent");
    }

    @Override
    public void onNotificationPosted(StatusBarNotification sbn) {
        try {
            if (sbn == null || !interesting(sbn.getPackageName())) return;
            Notification n = sbn.getNotification();
            if (n == null) return;
            Bundle ex = n.extras;
            if (ex == null) return;

            int max = ex.getInt(Notification.EXTRA_PROGRESS_MAX, 0);
            int cur = ex.getInt(Notification.EXTRA_PROGRESS, 0);
            boolean indet = ex.getBoolean(Notification.EXTRA_PROGRESS_INDETERMINATE, false);
            if (max <= 0 || indet) return;                       // полосы нет — брать нечего

            String title = str(ex, Notification.EXTRA_TITLE);
            if (title == null || title.isEmpty()) return;
            String name = title.trim();
            int slash = name.lastIndexOf('/');
            if (slash >= 0) name = name.substring(slash + 1);

            // проценты приводим к байтам, если в тексте видно общий размер («12,3 МБ из 320 МБ»)
            long total = -1;
            String text = str(ex, Notification.EXTRA_TEXT);
            if (text == null) text = str(ex, Notification.EXTRA_SUB_TEXT);
            if (text != null) total = parseTotal(text);
            long done;
            if (total > 0) {
                done = (long) (total * (cur / (double) max));
            } else {
                total = max; done = cur;                          // проценты как есть
            }
            YevDownloads.NOTIF.put(name, new long[]{ done, total });
        } catch (Throwable ignored) {}
    }

    @Override
    public void onNotificationRemoved(StatusBarNotification sbn) {
        try {
            if (sbn == null || !interesting(sbn.getPackageName())) return;
            Bundle ex = sbn.getNotification() != null ? sbn.getNotification().extras : null;
            String title = ex != null ? str(ex, Notification.EXTRA_TITLE) : null;
            if (title != null) YevDownloads.NOTIF.remove(title.trim());
        } catch (Throwable ignored) {}
    }

    private static String str(Bundle b, String key) {
        CharSequence cs = b.getCharSequence(key);
        return cs == null ? null : cs.toString();
    }

    /** «… из 320 МБ», «/1,2 ГБ», «of 450 MB» — вытаскиваем общий размер в байтах. */
    static long parseTotal(String text) {
        try {
            java.util.regex.Matcher m = java.util.regex.Pattern
                    .compile("(?:из|of|/)\\s*([0-9]+(?:[.,][0-9]+)?)\\s*(б|байт|кб|мб|гб|b|kb|mb|gb|kib|mib|gib)",
                            java.util.regex.Pattern.CASE_INSENSITIVE | java.util.regex.Pattern.UNICODE_CASE)
                    .matcher(text);
            if (!m.find()) return -1;
            double v = Double.parseDouble(m.group(1).replace(',', '.'));
            String u = m.group(2).toLowerCase(Locale.ROOT);
            double mul = u.startsWith("г") || u.startsWith("g") ? 1024.0 * 1024 * 1024
                    : u.startsWith("м") || u.startsWith("m") ? 1024.0 * 1024
                    : u.startsWith("к") || u.startsWith("k") ? 1024.0 : 1.0;
            return (long) (v * mul);
        } catch (Throwable t) { return -1; }
    }
}
