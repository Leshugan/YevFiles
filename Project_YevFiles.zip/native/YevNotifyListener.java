package leshugan.fm;

import android.app.Notification;
import android.os.Bundle;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;

import java.util.Locale;

/**
 * Читает из шторки уведомления о загрузках и достаёт из них «сколько всего» и «сколько сделано».
 * Работает только если пользователь сам включил приложению доступ к уведомлениям.
 * Ничего никуда не отправляет: цифры кладутся в память приложения и показываются в списке.
 */
public class YevNotifyListener extends NotificationListenerService {

    /** Уведомления каких приложений нас интересуют. */
    private static boolean interesting(String pkg) {
        if (pkg == null) return false;
        String p = pkg.toLowerCase(Locale.ROOT);
        return p.contains("chrome") || p.contains("browser") || p.contains("quetta") || p.contains("firefox")
                || p.contains("opera") || p.contains("yandex") || p.contains("download") || p.contains("providers.downloads")
                || p.contains("kiwi") || p.contains("brave") || p.contains("samsung.android.app.sbrowser")
                || p.contains("idm") || p.contains("adm") || p.contains("abdm") || p.contains("dvget")
                || p.contains("torrent") || p.contains("aria2") || p.contains("1dm") || p.contains("xdm")
                || p.contains("vivaldi") || p.contains("edge") || p.contains("via") || p.contains("mises");
    }

    @Override
    public void onNotificationPosted(StatusBarNotification sbn) { read(sbn); }

    private void read(StatusBarNotification sbn) {
        try {
            if (sbn == null || !interesting(sbn.getPackageName())) return;
            Notification n = sbn.getNotification();
            if (n == null) return;
            Bundle ex = n.extras;
            if (ex == null) return;

            int max = ex.getInt(Notification.EXTRA_PROGRESS_MAX, 0);
            int cur = ex.getInt(Notification.EXTRA_PROGRESS, 0);
            boolean indet = ex.getBoolean(Notification.EXTRA_PROGRESS_INDETERMINATE, false);
            if (max <= 0 || indet) return;                       // полосы нет — брать нечего

            String title = str(ex, Notification.EXTRA_TITLE);
            if (title == null || title.isEmpty()) return;
            String name = title.trim();
            int slash = name.lastIndexOf('/');
            if (slash >= 0) name = name.substring(slash + 1);

            // Самое точное — текст уведомления: «211,89 МБ из 8,54 ГБ». Полоса даёт только целые проценты,
            // а это для большого файла шаг в десятки мегабайт — из-за него цифры и отставали.
            long done = -1, total = -1;
            String hint = null;
            String[] cand = {
                str(ex, Notification.EXTRA_TEXT),
                str(ex, Notification.EXTRA_SUB_TEXT),
                str(ex, Notification.EXTRA_INFO_TEXT),
                str(ex, Notification.EXTRA_BIG_TEXT),
            };
            for (String t : cand) {
                if (t == null) continue;
                long[] pair = parsePair(t);
                if (pair != null) { done = pair[0]; total = pair[1]; break; }
            }
            if (total <= 0) {
                for (String t : cand) { if (t == null) continue; long tt = parseTotal(t); if (tt > 0) { total = tt; break; } }
                if (total > 0) done = (long) (total * (cur / (double) max));
                else { total = max; done = cur; }                 // проценты как есть
            }
            // подсказка вроде «Осталось 46 мин.» — то, что не про размеры
            for (String t : cand) {
                if (t == null) continue;
                if (parsePair(t) != null || parseTotal(t) > 0) continue;
                if (t.length() <= 40) { hint = t.trim(); break; }
            }
            YevDownloads.putNotif(name, done, total, hint, sbn.getPackageName());
        } catch (Throwable ignored) {}
    }

    private static YevNotifyListener LIVE;

    /** Перечитать всё, что висит в шторке (вызывается наблюдателем за папкой). */
    static void pullActive() {
        YevNotifyListener l = LIVE;
        if (l == null) return;
        try {
            StatusBarNotification[] all = l.getActiveNotifications();
            if (all != null) for (StatusBarNotification s : all) l.read(s);
        } catch (Throwable ignored) {}
    }

    @Override
    public void onDestroy() { LIVE = null; super.onDestroy(); }

    @Override
    public void onListenerConnected() {
        LIVE = this;
        // при подключении забираем всё, что уже висит в шторке
        try {
            StatusBarNotification[] all = getActiveNotifications();
            if (all != null) for (StatusBarNotification s : all) read(s);
        } catch (Throwable ignored) {}
    }

    @Override
    public void onNotificationRankingUpdate(android.service.notification.NotificationListenerService.RankingMap rankingMap) {
        // Chrome обновляет полосу без нового «posted» — перечитываем то, что висит сейчас
        try {
            StatusBarNotification[] all = getActiveNotifications();
            if (all != null) for (StatusBarNotification s : all) read(s);
        } catch (Throwable ignored) {}
    }

    @Override
    public void onNotificationRemoved(StatusBarNotification sbn) {
        try {
            if (sbn == null || !interesting(sbn.getPackageName())) return;
            Bundle ex = sbn.getNotification() != null ? sbn.getNotification().extras : null;
            String title = ex != null ? str(ex, Notification.EXTRA_TITLE) : null;
            if (title != null) YevDownloads.dropNotif(title.trim());
        } catch (Throwable ignored) {}
    }

    private static String str(Bundle b, String key) {
        CharSequence cs = b.getCharSequence(key);
        return cs == null ? null : cs.toString();
    }

    /** «211,89 МБ из 8,54 ГБ», «12.3 MB / 45.6 MB» — вытаскиваем сразу оба числа в байтах. */
    static long[] parsePair(String text) {
        try {
            java.util.regex.Matcher m = java.util.regex.Pattern
                    .compile("([0-9]+(?:[.,][0-9]+)?)\\s*(б|байт|кб|мб|гб|b|kb|mb|gb|kib|mib|gib)\\s*(?:из|of|/|\\u2044)\\s*([0-9]+(?:[.,][0-9]+)?)\\s*(б|байт|кб|мб|гб|b|kb|mb|gb|kib|mib|gib)",
                            java.util.regex.Pattern.CASE_INSENSITIVE | java.util.regex.Pattern.UNICODE_CASE)
                    .matcher(text);
            if (!m.find()) return null;
            long a = bytes(m.group(1), m.group(2)), b = bytes(m.group(3), m.group(4));
            if (b <= 0) return null;
            if (a > b) a = b;
            return new long[]{ a, b };
        } catch (Throwable t) { return null; }
    }

    private static long bytes(String num, String unit) {
        double v = Double.parseDouble(num.replace(',', '.'));
        String u = unit.toLowerCase(Locale.ROOT);
        double mul = u.startsWith("г") || u.startsWith("g") ? 1024.0 * 1024 * 1024
                : u.startsWith("м") || u.startsWith("m") ? 1024.0 * 1024
                : u.startsWith("к") || u.startsWith("k") ? 1024.0 : 1.0;
        return (long) (v * mul);
    }

    /** «… из 320 МБ», «/1,2 ГБ», «of 450 MB» — вытаскиваем общий размер в байтах. */
    static long parseTotal(String text) {
        try {
            java.util.regex.Matcher m = java.util.regex.Pattern
                    .compile("(?:из|of|/)\\s*([0-9]+(?:[.,][0-9]+)?)\\s*(б|байт|кб|мб|гб|b|kb|mb|gb|kib|mib|gib)",
                            java.util.regex.Pattern.CASE_INSENSITIVE | java.util.regex.Pattern.UNICODE_CASE)
                    .matcher(text);
            if (!m.find()) return -1;
            double v = Double.parseDouble(m.group(1).replace(',', '.'));
            String u = m.group(2).toLowerCase(Locale.ROOT);
            double mul = u.startsWith("г") || u.startsWith("g") ? 1024.0 * 1024 * 1024
                    : u.startsWith("м") || u.startsWith("m") ? 1024.0 * 1024
                    : u.startsWith("к") || u.startsWith("k") ? 1024.0 : 1.0;
            return (long) (v * mul);
        } catch (Throwable t) { return -1; }
    }
}
