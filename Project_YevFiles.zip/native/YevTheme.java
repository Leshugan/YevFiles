package leshugan.fm;

import android.graphics.Color;

/**
 * Цвета и размеры — ровно те же числа, что в веб-части.
 * Меняются только здесь, чтобы родной и веб-вид не разъезжались.
 */
public final class YevTheme {

    public final boolean light;

    public final int bg, bar, row2, acc, accbg, gold, red, txt, ink, sub, line, chip, hair, tglOff;

    private YevTheme(boolean light, String bg, String bar, String row2, String acc, int accbg,
                     String gold, String red, String txt, String ink, String sub, String line,
                     int chip, int hair, String tglOff) {
        this.light = light;
        this.bg = Color.parseColor(bg);
        this.bar = Color.parseColor(bar);
        this.row2 = Color.parseColor(row2);
        this.acc = Color.parseColor(acc);
        this.accbg = accbg;
        this.gold = Color.parseColor(gold);
        this.red = Color.parseColor(red);
        this.txt = Color.parseColor(txt);
        this.ink = Color.parseColor(ink);
        this.sub = Color.parseColor(sub);
        this.line = Color.parseColor(line);
        this.chip = chip;
        this.hair = hair;
        this.tglOff = Color.parseColor(tglOff);
    }

    public static final YevTheme DARK = new YevTheme(false,
            "#1B130B", "#2C2219", "#332619", "#EF6C00", 0x2EEF6C00,
            "#F5A623", "#E05252", "#F2EAE0", "#E0D5C8", "#B0A498", "#4A3A2A",
            0x0FFFFFFF, 0x12FFFFFF, "#4A3A2A");

    public static final YevTheme LIGHT = new YevTheme(true,
            "#EEF1F4", "#FFFFFF", "#E4E8EC", "#2F80ED", 0x242F80ED,
            "#2F80ED", "#D14343", "#1E2329", "#3D4754", "#6B7280", "#D3D8DE",
            0x0D000000, 0x14000000, "#C2C8D0");

    public static YevTheme of(String name) { return "light".equals(name) ? LIGHT : DARK; }

    // ---- размеры строки списка: те же, что в веб-части ----
    public static final int ROW_PAD_H = 14;      // отступ строки по бокам
    public static final int ROW_PAD_V = 10;      // отступ строки сверху и снизу
    public static final int ROW_GAP = 14;        // между значком и текстом
    public static final int ICON = 44;           // квадрат значка
    public static final int ICON_RADIUS = 13;
    public static final int NAME_SIZE = 15;      // размер имени
    public static final int DATE_SIZE = 12;      // дата и подписи (12.5 в вебе)
    public static final int NUM_SIZE = 13;       // размер файла
    public static final int COUNT_SIZE = 12;     // число объектов в папке
    public static final int LINE_LEFT = 72;      // где начинается разделительная полоса
    public static final int ROW_MIN_H = 68;      // минимальная высота строки
    public static final int HERE_DOT = 7;        // точка «отсюда вышли»
    public static final int FOLDER_THUMB = 28;   // уголок с обложкой папки
}
