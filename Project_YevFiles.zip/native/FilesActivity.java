package leshugan.fm;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

/**
 * Родной экран менеджера: шапка с вкладками, строка пути, список и нижняя панель.
 * Вид повторяет веб-часть — те же цвета, размеры и подписи.
 */
public class FilesActivity extends Activity {

    private YevTheme t;
    private float d;

    private LinearLayout root, tabsBar, bottom;
    private HorizontalScrollView tabsScroll;
    private LinearLayout tabsRow;
    private TextView crumb;
    private RowList list;

    private final List<String> tabs = new ArrayList<>();     // пути вкладок
    private int active = 0;
    private String path = "";                                 // текущий путь

    private int dp(float v) { return Math.round(d * v); }

    @Override
    protected void onCreate(Bundle st) {
        super.onCreate(st);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        d = getResources().getDisplayMetrics().density;
        t = YevTheme.of(getIntent().getStringExtra("theme"));

        Window w = getWindow();
        w.setStatusBarColor(t.bg);
        w.setNavigationBarColor(t.bg);
        w.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(t.bg));

        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(t.bg);

        root.addView(buildTabsBar());
        root.addView(buildCrumb());

        list = new RowList(this);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, 0, 1f);
        root.addView(list, lp);

        root.addView(buildBottom());
        setContentView(root);

        // отступы под системные полосы — как в веб-части
        root.setOnApplyWindowInsetsListener((v, ins) -> {
            int top = 0, bot = 0;
            try {
                if (Build.VERSION.SDK_INT >= 30) {
                    android.graphics.Insets in = ins.getInsets(android.view.WindowInsets.Type.systemBars());
                    top = in.top; bot = in.bottom;
                } else { top = ins.getSystemWindowInsetTop(); bot = ins.getSystemWindowInsetBottom(); }
            } catch (Throwable ignored) {}
            root.setPadding(0, top, 0, bot);
            return ins;
        });

        String start = getIntent().getStringExtra("path");
        tabs.add(start == null ? "" : start);
        openPath(tabs.get(0));
    }

    // ---------- шапка ----------

    private View buildTabsBar() {
        tabsBar = new LinearLayout(this);
        tabsBar.setOrientation(LinearLayout.HORIZONTAL);
        tabsBar.setGravity(Gravity.CENTER_VERTICAL);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(t.bar);
        bg.setCornerRadius(dp(26));
        tabsBar.setBackground(bg);
        tabsBar.setElevation(dp(6));

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(50));
        lp.setMargins(dp(8), dp(8), dp(8), dp(6));
        tabsBar.setLayoutParams(lp);

        tabsBar.addView(roundButton("bars", () -> finish()));

        tabsScroll = new HorizontalScrollView(this);
        tabsScroll.setHorizontalScrollBarEnabled(false);
        tabsRow = new LinearLayout(this);
        tabsRow.setOrientation(LinearLayout.HORIZONTAL);
        tabsRow.setGravity(Gravity.CENTER_VERTICAL);
        tabsRow.setPadding(dp(4), 0, dp(4), 0);
        tabsScroll.addView(tabsRow, new FrameLayout.LayoutParams(-2, -1));
        tabsBar.addView(tabsScroll, new LinearLayout.LayoutParams(0, -1, 1f));

        tabsBar.addView(roundButton("dots", () -> {}));
        return tabsBar;
    }

    private View roundButton(final String iconKey, final Runnable fn) {
        IconView v = new IconView(this, iconKey, t.txt, 20);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(t.light ? 0x14000000 : 0x28787880);
        bg.setCornerRadius(dp(17));
        v.setBackground(bg);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(34), dp(34));
        lp.setMargins(dp(8), 0, dp(8), 0);
        v.setLayoutParams(lp);
        v.setOnClickListener(x -> fn.run());
        return v;
    }

    private void rebuildTabs() {
        tabsRow.removeAllViews();
        for (int i = 0; i < tabs.size(); i++) {
            final int idx = i;
            String p = tabs.get(i);
            String nm = p == null || p.isEmpty() ? "Storage" : p.substring(p.lastIndexOf('/') + 1);
            TextView tv = new TextView(this);
            tv.setText(nm);
            tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13.5f);
            tv.setSingleLine(true);
            tv.setGravity(Gravity.CENTER);
            tv.setPadding(dp(12), 0, dp(12), 0);
            boolean on = i == active;
            GradientDrawable bg = new GradientDrawable();
            bg.setCornerRadius(dp(17));
            if (on) { bg.setColor(t.accbg); bg.setStroke(dp(1), t.acc); tv.setTextColor(t.acc); }
            else { bg.setColor(t.chip); tv.setTextColor(t.sub); }
            tv.setBackground(bg);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, dp(34));
            lp.setMargins(dp(3), 0, dp(3), 0);
            tv.setLayoutParams(lp);
            tv.setOnClickListener(v -> { active = idx; openPath(tabs.get(idx)); });
            tabsRow.addView(tv);
        }
    }

    private View buildCrumb() {
        crumb = new TextView(this);
        crumb.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f);
        crumb.setTextColor(t.acc);
        crumb.setSingleLine(true);
        crumb.setEllipsize(android.text.TextUtils.TruncateAt.START);
        crumb.setPadding(dp(16), 0, dp(16), 0);
        crumb.setGravity(Gravity.CENTER_VERTICAL);
        crumb.setHeight(dp(30));
        crumb.setOnClickListener(v -> goUp());
        return crumb;
    }

    // ---------- нижняя панель ----------

    private View buildBottom() {
        bottom = new LinearLayout(this);
        bottom.setOrientation(LinearLayout.HORIZONTAL);
        bottom.setGravity(Gravity.CENTER_VERTICAL);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(t.bar);
        bg.setCornerRadius(dp(30));
        bottom.setBackground(bg);
        bottom.setElevation(dp(6));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(dp(8), dp(4), dp(8), dp(8));
        bottom.setLayoutParams(lp);

        bottom.addView(bottomButton("search", "Поиск", () -> {}));
        bottom.addView(bottomButton("selectAll", "Все", () -> {}));
        bottom.addView(bottomButton("plus", "Создать", () -> {}));
        return bottom;
    }

    private View bottomButton(String iconKey, String label, final Runnable fn) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER);
        box.setPadding(dp(6), dp(6), dp(6), dp(7));
        IconView ic = new IconView(this, iconKey, t.ink, 25);
        box.addView(ic, new LinearLayout.LayoutParams(dp(28), dp(28)));
        TextView tv = new TextView(this);
        tv.setText(label);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10);
        tv.setTextColor(t.sub);
        tv.setGravity(Gravity.CENTER);
        box.addView(tv);
        box.setLayoutParams(new LinearLayout.LayoutParams(0, -2, 1f));
        box.setOnClickListener(v -> fn.run());
        return box;
    }

    // ---------- список ----------

    private void openPath(String p) {
        path = p == null ? "" : p;
        if (active < tabs.size()) tabs.set(active, path);
        rebuildTabs();
        String shown = path.isEmpty() ? "Storage" : path.substring(path.lastIndexOf('/') + 1);
        crumb.setText(path.isEmpty() ? shown : "‹  " + shown);
        list.load(path);
    }

    private void goUp() {
        if (path == null || path.isEmpty()) return;
        int i = path.lastIndexOf('/');
        openPath(i > 0 ? path.substring(0, i) : "");
    }

    @Override
    public void onBackPressed() {
        if (path != null && !path.isEmpty()) goUp();
        else super.onBackPressed();
    }

    /** Значок линиями — теми же очертаниями, что в веб-части. */
    private class IconView extends View {
        private final String key;
        private final int color, size;
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        IconView(Context c, String key, int color, int size) {
            super(c);
            this.key = key; this.color = color; this.size = size;
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeCap(Paint.Cap.ROUND);
            p.setStrokeJoin(Paint.Join.ROUND);
            p.setColor(color);
            p.setStrokeWidth(1.8f);
        }
        @Override protected void onDraw(Canvas c) {
            float k = Math.min(getWidth(), getHeight()) / 24f;
            c.save();
            c.translate((getWidth() - 24 * k) / 2, (getHeight() - 24 * k) / 2);
            c.scale(k, k);
            for (String pd : YevIcons.get(key)) {
                try {
                    Path path = androidx.core.graphics.PathParser.createPathFromPathData(pd);
                    if (path != null) c.drawPath(path, p);
                } catch (Throwable ignored) {}
            }
            c.restore();
        }
    }

    /** Простой список строк: пока обычная прокрутка, окно видимых строк — следующим заходом. */
    private class RowList extends ScrollView {
        private final LinearLayout box;
        RowList(Context c) {
            super(c);
            box = new LinearLayout(c);
            box.setOrientation(LinearLayout.VERTICAL);
            box.setGravity(Gravity.BOTTOM);            // как в вебе: список прижат к низу
            addView(box, new FrameLayout.LayoutParams(-1, -1));
            setFillViewport(true);
        }

        void load(final String p) {
            box.removeAllViews();
            new Thread(() -> {
                final List<YevRowView.Item> items = read(p);
                runOnUiThread(() -> show(items, p));
            }).start();
        }

        private List<YevRowView.Item> read(String p) {
            List<YevRowView.Item> out = new ArrayList<>();
            try {
                File dir = new File(p == null || p.isEmpty() ? "/storage/emulated/0" : p);
                File[] kids = dir.listFiles();
                if (kids == null) return out;
                final java.text.Collator coll = java.text.Collator.getInstance(new java.util.Locale("ru"));
                coll.setStrength(java.text.Collator.PRIMARY);
                Arrays.sort(kids, new Comparator<File>() {
                    @Override public int compare(File a, File b) {
                        boolean da = a.isDirectory(), db = b.isDirectory();
                        if (da != db) return da ? -1 : 1;
                        return nameCmp(a.getName(), b.getName(), coll);
                    }
                });
                for (File f : kids) {
                    if (f.getName().startsWith(".")) continue;
                    YevRowView.Item it = new YevRowView.Item();
                    it.name = f.getName();
                    it.dir = f.isDirectory();
                    it.size = it.dir ? 0 : f.length();
                    it.mtime = f.lastModified();
                    String[] ic = iconFor(it.name, it.dir);
                    it.iconKey = ic[0];
                    it.iconColor = Color.parseColor(ic[1]);
                    if (ic.length > 2) it.badge = ic[2];
                    out.add(it);
                }
            } catch (Throwable ignored) {}
            return out;
        }

        private void show(List<YevRowView.Item> items, final String base) {
            box.removeAllViews();
            for (final YevRowView.Item it : items) {
                YevRowView v = new YevRowView(FilesActivity.this, t);
                v.setItem(it);
                v.setOnClickListener(x -> {
                    String full = (base == null || base.isEmpty() ? "/storage/emulated/0" : base) + "/" + it.name;
                    if (it.dir) openPath(full);
                });
                box.addView(v, new LinearLayout.LayoutParams(-1, -2));
            }
        }
    }

    /** Значок и цвет по имени файла — та же таблица, что в веб-части. */
    static String[] iconFor(String name, boolean dir) {
        if (dir) return new String[]{ "folder", "#EF6C00" };
        String n = name.toLowerCase();
        int dot = n.lastIndexOf('.');
        String e = dot >= 0 ? n.substring(dot + 1) : "";
        if (e.equals("pdf")) return new String[]{ "pdf", "#E0574F" };
        if (e.equals("apk")) return new String[]{ "apk", "#6FD3A8" };
        if (e.equals("apks") || e.equals("xapk") || e.equals("apkm") || e.equals("apkx")) return new String[]{ "apk", "#A4C639" };
        if (e.equals("ttf") || e.equals("otf") || e.equals("woff") || e.equals("woff2")) return new String[]{ "txt", "#C9A0FF" };
        if (e.equals("lnk")) return new String[]{ "lnk", "#F5A623" };
        if (e.equals("txt") || e.equals("md") || e.equals("log") || e.equals("ini") || e.equals("cfg")) return new String[]{ "txt", "#9FD0FF" };
        if (in(e, "jpg jpeg png gif webp bmp heic heif avif tif tiff jxl dng cr2 nef arw")) return new String[]{ "img", "#7FB3FF" };
        if (in(e, "mp4 mkv avi mov webm 3gp m4v ts flv wmv mpg mpeg")) return new String[]{ "video", "#C98BFF" };
        if (in(e, "mp3 flac wav ogg m4a aac opus wma ape")) return new String[]{ "audio", "#FF9D6B" };
        if (in(e, "zip rar 7z tar gz tgz bz2 tbz xz zst iso jar war cab arj lha lzh ace z 001")) {
            String col = e.equals("zip") ? "#E3B14F" : e.equals("rar") ? "#9B59B6" : e.equals("7z") ? "#5AA9E6"
                    : (e.equals("tar") || e.equals("gz") || e.equals("xz") || e.equals("bz2")) ? "#6FD3A8"
                    : e.equals("jar") ? "#E0574F" : "#E3B14F";
            return new String[]{ "archive", col, e.toUpperCase(java.util.Locale.US) };
        }
        if (in(e, "js jsx ts tsx java kt py c cpp h cs php rb go rs swift html css json xml yml yaml sh")) return new String[]{ "code", "#6FD3A8" };
        return new String[]{ "file", "#B0A498" };
    }

    /** Порядок имён как в вебе: сперва латиница, затем кириллица, затем прочее. */
    static int nameCmp(String a, String b, java.text.Collator coll) {
        int ra = scriptRank(a), rb = scriptRank(b);
        if (ra != rb) return ra - rb;
        return coll.compare(a == null ? "" : a, b == null ? "" : b);
    }

    private static int scriptRank(String n) {
        char c = (n == null || n.isEmpty()) ? ' ' : n.charAt(0);
        if (c < 128) return 0;
        if (c >= 0x400 && c <= 0x4FF) return 1;
        return 2;
    }

    private static boolean in(String e, String list) {
        for (String s : list.split(" ")) if (s.equals(e)) return true;
        return false;
    }
}
