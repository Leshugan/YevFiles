package leshugan.fm;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

/**
 * Родной экран менеджера: шапка с вкладками, строка пути, список и нижняя панель.
 * Вид повторяет веб-часть — те же цвета, размеры и подписи.
 */
public class FilesActivity extends Activity {

    private YevTheme t;
    private String themeName = "dark";
    private android.content.SharedPreferences prefs;
    private float d;

    private LinearLayout root, tabsBar, bottom;
    private HorizontalScrollView tabsScroll;
    private LinearLayout tabsRow;
    private TextView crumb;
    private RowList list;
    private android.widget.FrameLayout themeBtn;
    private IconView themeIcon;

    private final List<String> tabs = new ArrayList<>();     // пути вкладок
    private int active = 0;
    private String path = "";                                 // текущий путь
    private String crumbBase = "";
    private boolean debug;

    private int dp(float v) { return Math.round(d * v); }

    /** Шрифт из старого вида: лежит в папке приложения, подхватываем при запуске. */
    private void loadFont() {
        if (fontName == null || fontName.isEmpty()) return;
        try {
            if (fontName.startsWith("data:")) {                 // свой шрифт пришёл данными
                int comma = fontName.indexOf(',');
                if (comma < 0) return;
                byte[] raw = android.util.Base64.decode(fontName.substring(comma + 1), android.util.Base64.DEFAULT);
                File out = new File(getCacheDir(), "ui_font.ttf");
                java.io.OutputStream os = new java.io.FileOutputStream(out);
                os.write(raw); os.close();
                faceRegular = android.graphics.Typeface.createFromFile(out);
            } else {                                            // встроенный — по имени из системы
                faceRegular = android.graphics.Typeface.create(fontName.toLowerCase(), android.graphics.Typeface.NORMAL);
            }
            if (faceRegular != null) faceBold = android.graphics.Typeface.create(faceRegular, android.graphics.Typeface.BOLD);
        } catch (Throwable ignored) {}
    }

    android.graphics.Typeface face(boolean bold) {
        return bold ? (faceBold != null ? faceBold : android.graphics.Typeface.DEFAULT_BOLD)
                    : (faceRegular != null ? faceRegular : android.graphics.Typeface.DEFAULT);
    }

    @Override
    protected void onCreate(Bundle st) {
        super.onCreate(st);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        d = getResources().getDisplayMetrics().density;
        themeName = getIntent().getStringExtra("theme");
        android.content.SharedPreferences pre = getSharedPreferences("yev_native_ui", MODE_PRIVATE);
        if (themeName == null || themeName.isEmpty()) themeName = pre.getString("theme", "dark");
        t = YevTheme.of(themeName);

        Window w = getWindow();
        w.setStatusBarColor(t.bg);
        w.setNavigationBarColor(t.bg);
        w.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(t.bg));

        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(t.bg);

        root.addView(buildTabsBar());
        buildCrumb();                 // текстовая строка остаётся для режимов выделения и поиска
        root.addView(buildCrumbBar());

        android.widget.FrameLayout listWrap = new android.widget.FrameLayout(this);
        list = new RowList(this);
        listWrap.addView(list, new android.widget.FrameLayout.LayoutParams(-1, -1));

        // круглая кнопка темы справа сверху — как в вебе
        themeBtn = new android.widget.FrameLayout(this);
        GradientDrawable tb = new GradientDrawable();
        tb.setShape(GradientDrawable.OVAL);
        tb.setColor(t.chip);
        themeBtn.setBackground(tb);
        themeIcon = new IconView(this, t.light ? "sun" : "moon", t.acc, 24);
        themeBtn.addView(themeIcon, new android.widget.FrameLayout.LayoutParams(-1, -1));
        android.widget.FrameLayout.LayoutParams tlp = new android.widget.FrameLayout.LayoutParams(dp(52), dp(52), Gravity.END | Gravity.TOP);
        tlp.rightMargin = dp(14); tlp.topMargin = dp(10);
        themeBtn.setOnClickListener(v -> switchTheme());
        listWrap.addView(themeBtn, tlp);

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, 0, 1f);
        root.addView(listWrap, lp);

        root.addView(buildBottom());
        setContentView(root);

        // отступы под системные полосы — как в веб-части
        root.setOnApplyWindowInsetsListener((v, ins) -> {
            int top = 0, bot = 0;
            try {
                if (Build.VERSION.SDK_INT >= 30) {
                    android.graphics.Insets in = ins.getInsets(android.view.WindowInsets.Type.systemBars());
                    top = in.top; bot = in.bottom;
                } else { top = ins.getSystemWindowInsetTop(); bot = ins.getSystemWindowInsetBottom(); }
            } catch (Throwable ignored) {}
            root.setPadding(0, top, 0, bot);
            return ins;
        });

        debug = getIntent().getBooleanExtra("debug", false);
        prefs = getSharedPreferences("yev_native_ui", MODE_PRIVATE);
        sortMode = prefs.getInt("sort", 0);
        fontName = prefs.getString("font", "");
        rowScale = prefs.getFloat("rowScale", 1f);
        dirSizes = prefs.getBoolean("dirsize", false);
        showHidden = prefs.getBoolean("hidden", false);
        grid = prefs.getBoolean("grid", false);
        String start = getIntent().getStringExtra("path");
        if (start == null || start.isEmpty()) start = prefs.getString("lastPath", "");
        loadFont();
        loadFolderIcons();
        list.setGrid(grid);
        try {
            org.json.JSONArray saved = new org.json.JSONArray(prefs.getString("tabs", "[]"));
            for (int i = 0; i < saved.length(); i++) tabs.add(saved.optString(i));
            active = Math.max(0, Math.min(prefs.getInt("activeTab", 0), tabs.size() - 1));
        } catch (Throwable ignored) {}
        if (tabs.isEmpty()) tabs.add(start == null ? "" : start);
        else if (start != null && !start.isEmpty()) { tabs.set(active, start); }
        openPath(tabs.get(active));
    }

    // ---------- шапка ----------

    private View buildTabsBar() {
        tabsBar = new LinearLayout(this);
        tabsBar.setOrientation(LinearLayout.HORIZONTAL);
        tabsBar.setGravity(Gravity.CENTER_VERTICAL);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(t.bar);
        bg.setCornerRadius(dp(26));
        tabsBar.setBackground(bg);
        tabsBar.setElevation(dp(6));

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(50));
        lp.setMargins(dp(8), dp(8), dp(8), dp(6));
        tabsBar.setLayoutParams(lp);

        tabsBar.addView(roundButton("bars", () -> openDrawer()));

        tabsScroll = new HorizontalScrollView(this);
        tabsScroll.setHorizontalScrollBarEnabled(false);
        tabsRow = new LinearLayout(this);
        tabsRow.setOrientation(LinearLayout.HORIZONTAL);
        tabsRow.setGravity(Gravity.CENTER_VERTICAL);
        tabsRow.setPadding(dp(4), 0, dp(4), 0);
        tabsScroll.addView(tabsRow, new FrameLayout.LayoutParams(-2, -1));
        tabsBar.addView(tabsScroll, new LinearLayout.LayoutParams(0, -1, 1f));

        tabsBar.addView(roundButton("dots", () -> openHeadMenu()));
        return tabsBar;
    }

    private View roundButton(final String iconKey, final Runnable fn) {
        IconView v = new IconView(this, iconKey, t.txt, 20);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(t.light ? 0x14000000 : 0x28787880);
        bg.setCornerRadius(dp(17));
        v.setBackground(bg);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(34), dp(34));
        lp.setMargins(dp(8), 0, dp(8), 0);
        v.setLayoutParams(lp);
        v.setOnClickListener(x -> fn.run());
        return v;
    }

    private void saveTabs() {
        try {
            org.json.JSONArray a = new org.json.JSONArray();
            for (String p2 : tabs) a.put(p2);
            prefs.edit().putString("tabs", a.toString()).putInt("activeTab", active).apply();
        } catch (Throwable ignored) {}
    }

    private void rebuildTabs() {
        tabsRow.removeAllViews();
        for (int i = 0; i < tabs.size(); i++) {
            final int idx = i;
            String p = tabs.get(i);
            String nm = p == null || p.isEmpty() ? "Storage" : p.substring(p.lastIndexOf('/') + 1);
            TextView tv = new TextView(this);
            tv.setText(nm);
            tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13.5f);
            tv.setSingleLine(true);
            tv.setGravity(Gravity.CENTER);
            tv.setPadding(dp(12), 0, dp(12), 0);
            boolean on = i == active;
            GradientDrawable bg = new GradientDrawable();
            bg.setCornerRadius(dp(17));
            if (on) { bg.setColor(t.accbg); bg.setStroke(dp(1), t.acc); tv.setTextColor(t.acc); }
            else { bg.setColor(t.chip); tv.setTextColor(t.sub); }
            tv.setBackground(bg);
            applyFace(tv, on);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, dp(34));
            lp.setMargins(dp(3), 0, dp(3), 0);
            tv.setLayoutParams(lp);
            tv.setOnClickListener(v -> { active = idx; openPath(tabs.get(idx)); });
            tv.setOnDragListener((view, ev) -> {
                switch (ev.getAction()) {
                    case android.view.DragEvent.ACTION_DRAG_ENTERED:
                        view.setAlpha(0.6f); return true;
                    case android.view.DragEvent.ACTION_DRAG_EXITED:
                    case android.view.DragEvent.ACTION_DRAG_ENDED:
                        view.setAlpha(1f); return true;
                    case android.view.DragEvent.ACTION_DROP:
                        view.setAlpha(1f);
                        String dropped = String.valueOf(ev.getClipData().getItemAt(0).getText());
                        dropOnTab(dropped, idx);
                        return true;
                    default: return true;
                }
            });
            tv.setOnLongClickListener(v -> {                   // долгое нажатие закрывает вкладку
                if (tabs.size() <= 1) return true;
                tabs.remove(idx);
                if (active >= tabs.size()) active = tabs.size() - 1;
                openPath(tabs.get(active));
                return true;
            });
            tabsRow.addView(tv);
        }
    }

    private android.widget.HorizontalScrollView crumbScroll;
    private LinearLayout crumbRow;

    private View buildCrumbBar() {
        crumbScroll = new android.widget.HorizontalScrollView(this);
        crumbScroll.setHorizontalScrollBarEnabled(false);
        crumbRow = new LinearLayout(this);
        crumbRow.setOrientation(LinearLayout.HORIZONTAL);
        crumbRow.setGravity(Gravity.CENTER_VERTICAL);
        crumbRow.setPadding(dp(16), 0, dp(16), 0);
        crumbScroll.addView(crumbRow, new android.widget.FrameLayout.LayoutParams(-2, -1));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(30));
        crumbScroll.setLayoutParams(lp);
        return crumbScroll;
    }

    /** Дорожка пути: «‹ Android / _YL_ / Games», последний кусок акцентом. */
    private void rebuildCrumbs() {
        if (crumbRow == null) return;
        crumbRow.removeAllViews();
        if (selMode || arcPath != null || searchTitle != null) {   // в этих режимах в строке своё
            TextView tv = new TextView(this);
            tv.setText(crumb.getText());
            tv.setTextColor(t.acc);
            tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f);
            crumbRow.addView(tv);
            return;
        }
        String p = path == null || path.isEmpty() ? "/storage/emulated/0" : path;
        String rest = p.replaceFirst("^/storage/emulated/0/?", "");
        final java.util.List<String> parts = new ArrayList<>();
        if (!rest.isEmpty()) for (String s2 : rest.split("/")) if (!s2.isEmpty()) parts.add(s2);

        TextView back = new TextView(this);
        back.setText("‹  ");
        back.setTextColor(t.acc);
        back.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        back.setOnClickListener(v -> goUp());
        back.setOnLongClickListener(v -> { openPath("/storage/emulated/0"); return true; });
        crumbRow.addView(back);

        addCrumb("Storage", "/storage/emulated/0", parts.isEmpty());
        StringBuilder acc = new StringBuilder("/storage/emulated/0");
        for (int i = 0; i < parts.size(); i++) {
            acc.append('/').append(parts.get(i));
            TextView sep = new TextView(this);
            sep.setText(" / ");
            sep.setTextColor(t.sub);
            sep.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f);
            crumbRow.addView(sep);
            addCrumb(parts.get(i), acc.toString(), i == parts.size() - 1);
        }
        crumbScroll.post(() -> crumbScroll.fullScroll(View.FOCUS_RIGHT));
    }

    private void addCrumb(String name, final String target, boolean last) {
        TextView tv = new TextView(this);
        tv.setText(name);
        tv.setTextColor(last ? t.acc : t.sub);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f);
        tv.setSingleLine(true);
        tv.setOnClickListener(v -> { if (!target.equals(path)) openPath(target); });
        crumbRow.addView(tv);
    }

    private View buildCrumb() {
        crumb = new TextView(this);
        crumb.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f);
        crumb.setTextColor(t.acc);
        crumb.setSingleLine(true);
        crumb.setEllipsize(android.text.TextUtils.TruncateAt.START);
        crumb.setPadding(dp(16), 0, dp(16), 0);
        crumb.setGravity(Gravity.CENTER_VERTICAL);
        crumb.setHeight(dp(30));
        crumb.setOnClickListener(v -> goUp());
        crumb.setOnLongClickListener(v -> { list.toTop(); return true; });
        crumb.setOnLongClickListener(v -> {          // долгое нажатие — показать числа
            debug = !debug;
            list.load(path);
            return true;
        });
        return crumb;
    }

    // ---------- нижняя панель ----------

    private void rebuildBottom() {
        bottom.removeAllViews();
        if (selMode && arcPath != null) {
            bottom.addView(bottomButton("x", "Отмена", () -> exitSel()));
            bottom.addView(bottomButton("selectAll", "Все", () -> selectAll()));
            bottom.addView(bottomButton("dl", "Распаковать (" + sel.size() + ")", () -> extractArchive(new java.util.HashSet<>(sel))));
        } else if (selMode) {
            bottom.addView(bottomButton("x", "Отмена", () -> exitSel()));
            bottom.addView(bottomButton("cut", "Вырезать", () -> grab(true)));
            bottom.addView(bottomButton("copy", "Копир.", () -> grab(false)));
            bottom.addView(bottomButton("trash", "Удалить", () -> confirmDelete()));
            bottom.addView(bottomButton("rename", "Имя", () -> renameOne()));
            bottom.addView(bottomButton("info", "Свойства", () -> propsSelection()));
            bottom.addView(bottomButton("archive", "Сжать", () -> compressSelection()));
        } else if (arcPath != null) {
            bottom.addView(bottomButton("x", "Выйти", () -> { arcPath = null; arcAll = new ArrayList<>(); openPath(path); }));
            bottom.addView(bottomButton("selectAll", "Все", () -> selectAll()));
            bottom.addView(bottomButton("dl", "Распаковать", () -> extractArchive(sel.isEmpty() ? null : new java.util.HashSet<>(sel))));
        } else if (!clip.isEmpty()) {
            bottom.addView(bottomButton("x", "Отмена", () -> { clip.clear(); rebuildBottom(); }));
            bottom.addView(bottomButton("plus", "Создать", () -> createMenu()));
            bottom.addView(bottomButton("paste", "Вставить (" + clip.size() + ")", () -> paste()));
        } else {
            bottom.addView(bottomButton("search", "Поиск", () -> searchDialog()));
            bottom.addView(bottomButton("selectAll", "Все", () -> selectAll()));
            bottom.addView(bottomButton("plus", "Создать", () -> createMenu()));
        }
    }

    private View buildBottom() {
        bottom = new LinearLayout(this);
        bottom.setOrientation(LinearLayout.HORIZONTAL);
        bottom.setGravity(Gravity.CENTER_VERTICAL);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(t.bar);
        bg.setCornerRadius(dp(30));
        bottom.setBackground(bg);
        bottom.setElevation(dp(6));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(dp(8), dp(4), dp(8), dp(8));
        bottom.setLayoutParams(lp);

        rebuildBottom();
        return bottom;
    }

    private void applyFace(TextView tv, boolean bold) {
        if (faceRegular != null) tv.setTypeface(bold && faceBold != null ? faceBold : faceRegular);
    }

    private View bottomButton(String iconKey, String label, final Runnable fn) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER);
        box.setPadding(dp(6), dp(6), dp(6), dp(7));
        IconView ic = new IconView(this, iconKey, t.ink, 25);
        box.addView(ic, new LinearLayout.LayoutParams(dp(28), dp(28)));
        TextView tv = new TextView(this);
        tv.setText(label);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10);
        tv.setTextColor(t.sub);
        tv.setGravity(Gravity.CENTER);
        box.addView(tv);
        box.setLayoutParams(new LinearLayout.LayoutParams(0, -2, 1f));
        box.setOnClickListener(v -> fn.run());
        return box;
    }

    // ---------- список ----------

    private final java.util.HashMap<String, Integer> scrollMemo = new java.util.HashMap<>();

    private void openPath(String p) {
        searchTitle = null;
        if (prefs != null && p != null) prefs.edit().putString("lastPath", p).apply();
        if (list != null && path != null) scrollMemo.put(path, list.scrollY());   // где стояли в этой папке
        if (p != null && !p.equals(path)) cameFrom.remove(p);
        if (selMode) { selMode = false; sel.clear(); rebuildBottom(); }
        path = p == null ? "" : p;
        if (active < tabs.size()) tabs.set(active, path);
        rebuildTabs();
        String shown = path.isEmpty() ? "Storage" : path.substring(path.lastIndexOf('/') + 1);
        crumbBase = path.isEmpty() ? shown : "‹  " + shown;
        crumb.setText(crumbBase);
        rebuildCrumbs();
        watchFolder(path);
        list.load(path, scrollMemo.containsKey(path) ? scrollMemo.get(path) : -1);
    }

    /** Смена темы — сразу пересобираем экран теми же цветами. */
    private void switchTheme() {
        themeName = "light".equals(themeName) ? "dark" : "light";
        prefs.edit().putString("theme", themeName).apply();
        Intent i = new Intent(this, FilesActivity.class);
        i.putExtra("theme", themeName);
        i.putExtra("path", path);
        i.putExtra("debug", debug);
        startActivity(i);
        overridePendingTransition(0, 0);
        finish();
    }

    private final java.util.HashMap<String, String> cameFrom = new java.util.HashMap<>();

    private void goUp() {
        if (path == null || path.isEmpty()) return;
        int i = path.lastIndexOf('/');
        String parent = i > 0 ? path.substring(0, i) : "";
        cameFrom.put(parent, shortName(path));     // отметим, откуда вернулись
        openPath(parent);
    }

    @Override
    public void onTrimMemory(int level) {
        super.onTrimMemory(level);
        if (level >= TRIM_MEMORY_UI_HIDDEN) {           // ушли с экрана — освободим превью
            for (Bitmap b : thumbs.values()) if (b != null && !b.isRecycled()) b.recycle();
            thumbs.clear();
        }
    }

    // следим за открытой папкой: появился или пропал файл — правим список, не перечитывая всё
    private android.os.FileObserver watcher;
    private final Handler fsHandler = new Handler(Looper.getMainLooper());
    private final Runnable fsFlush = new Runnable() {
        @Override public void run() {
            if (arcPath == null && searchTitle == null && path != null) list.load(path, list.scrollY());
        }
    };

    private void watchFolder(String p) {
        try { if (watcher != null) watcher.stopWatching(); } catch (Throwable ignored) {}
        watcher = null;
        final String dir = p == null || p.isEmpty() ? "/storage/emulated/0" : p;
        try {
            watcher = new android.os.FileObserver(dir,
                    android.os.FileObserver.CREATE | android.os.FileObserver.DELETE
                            | android.os.FileObserver.MOVED_FROM | android.os.FileObserver.MOVED_TO
                            | android.os.FileObserver.CLOSE_WRITE) {
                @Override public void onEvent(int event, String name) {
                    fsHandler.removeCallbacks(fsFlush);
                    fsHandler.postDelayed(fsFlush, 350);      // копим события и обновляем разом
                }
            };
            watcher.startWatching();
        } catch (Throwable ignored) {}
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (path != null && arcPath == null) list.load(path, list.scrollY());   // вернулись — перечитаем
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        try { if (watcher != null) watcher.stopWatching(); } catch (Throwable ignored) {}
        fsHandler.removeCallbacksAndMessages(null);
        if (thumbPool != null) thumbPool.shutdownNow();
        for (Bitmap b : thumbs.values()) if (b != null && !b.isRecycled()) b.recycle();
        thumbs.clear();
    }

    @Override
    public void onBackPressed() {
        if (drawerLayer != null) { closeDrawer(); return; }
        if (selMode) { exitSel(); return; }
        if (gdFolder != null) { driveUp(); return; }
        if (searchTitle != null) { searchTitle = null; openPath(path); return; }
        if (arcPath != null) { arcUp(); return; }
        if (path != null && !path.isEmpty()) goUp();
        else super.onBackPressed();
    }

    /** Значок линиями — теми же очертаниями, что в веб-части. */
    private class IconView extends View {
        private final String key;
        private final int color, size;
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        IconView(Context c, String key, int color, int size) {
            super(c);
            this.key = key; this.color = color; this.size = size;
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeCap(Paint.Cap.ROUND);
            p.setStrokeJoin(Paint.Join.ROUND);
            p.setColor(color);
            p.setStrokeWidth(1.8f);
        }
        @Override protected void onDraw(Canvas c) {
            float k = Math.min(getWidth(), getHeight()) / 24f;
            c.save();
            c.translate((getWidth() - 24 * k) / 2, (getHeight() - 24 * k) / 2);
            c.scale(k, k);
            for (String pd : YevIcons.get(key)) {
                try {
                    Path path = androidx.core.graphics.PathParser.createPathFromPathData(pd);
                    if (path != null) c.drawPath(path, p);
                } catch (Throwable ignored) {}
            }
            c.restore();
        }
    }

    /**
     * Список: держим в разметке только видимые строки и переиспользуем их при прокрутке —
     * так же, как окно строк в веб-части.
     */
    private class RowList extends android.widget.FrameLayout {
        private final android.widget.ScrollView sv;
        private final android.widget.FrameLayout canvas;
        private final java.util.ArrayList<YevRowView> pool = new java.util.ArrayList<>();
        private List<YevRowView.Item> data = new ArrayList<>();
        private int rowH;
        private int firstShown = -1, lastShown = -1;
        int count = 0;

        void setRowScale(float k) { rowH = Math.round(YevTheme.ROW_MIN_H * d * k); }

        RowList(Context c) {
            super(c);
            rowH = Math.round(YevTheme.ROW_MIN_H * d * rowScale);
            sv = new android.widget.ScrollView(c) {
                @Override protected void onScrollChanged(int l, int t2, int ol, int ot) {
                    super.onScrollChanged(l, t2, ol, ot);
                    layoutWindow();
                }
                @Override protected void onSizeChanged(int w, int h, int ow, int oh) {
                    super.onSizeChanged(w, h, ow, oh);
                    layoutWindow();
                }
            };
            sv.setVerticalScrollBarEnabled(true);
            canvas = new android.widget.FrameLayout(c);
            sv.addView(canvas, new android.widget.FrameLayout.LayoutParams(-1, -2));
            addView(sv, new android.widget.FrameLayout.LayoutParams(-1, -1));
            empty = new TextView(c);
            empty.setText("Пусто");
            empty.setTextColor(t.sub);
            empty.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
            empty.setGravity(Gravity.CENTER);
            empty.setVisibility(GONE);
            addView(empty, new android.widget.FrameLayout.LayoutParams(-1, -1));
            canvas.setOnLongClickListener(v -> { if (arcPath == null && !selMode) createMenu(); return true; });
            canvas.setLongClickable(true);
        }

        int scrollY() { return sv.getScrollY(); }

        void toTop() { sv.smoothScrollTo(0, 0); }

        void load(final String p) { load(p, -1); }

        void load(final String p, final int restore) {
            pendingScroll = restore;
            new Thread(() -> {
                List<YevRowView.Item> got = readViaCore(p);
                if (got == null || got.isEmpty()) {
                    List<YevRowView.Item> viaShz = readRestricted(p == null || p.isEmpty() ? "/storage/emulated/0" : p);
                    if (viaShz != null) got = viaShz;
                }
                if (got == null) got = read(p);          // движок не смог — читаем сами
                final List<YevRowView.Item> items = got;
                runOnUiThread(() -> show(items, p));
            }).start();
        }

        private void show(List<YevRowView.Item> items, final String base) {
            data = items;
            count = items.size();
            if (empty != null) {
                boolean noAccess = items.isEmpty() && base != null && !base.isEmpty() && !new File(base).canRead();
                empty.setText(noAccess ? "Нет доступа к этой папке" : "Пусто");
                empty.setVisibility(items.isEmpty() ? VISIBLE : GONE);
            }
            if (debug) crumb.setText(crumbBase + "   ·   строк: " + items.size());
            if (base != null) {
                String mark = cameFrom.get(base);
                for (YevRowView.Item it : data) {
                    it.path = (base.isEmpty() ? "/storage/emulated/0" : base) + "/" + it.name;
                    it.here = mark != null && mark.equals(it.name);
                }
                fillFolderCounts(data);
            }
            // высота полотна: все строки плюс пустое место сверху, если список короткий
            int cellH = gridMode ? Math.round(getWidth() / (float) cols) : rowH;
            int rows = gridMode ? (int) Math.ceil(data.size() / (float) cols) : data.size();
            int total = rows * cellH;
            int free = Math.max(0, sv.getHeight() - total);
            android.view.ViewGroup.LayoutParams lp = canvas.getLayoutParams();
            lp.height = total + free;
            canvas.setLayoutParams(lp);
            topPad = free;
            firstShown = lastShown = -1;
            for (YevRowView v : pool) v.setVisibility(GONE);
            final int want = pendingScroll;
            pendingScroll = -1;
            sv.post(() -> { sv.scrollTo(0, want > 0 ? want : 0); layoutWindow(); });
            layoutWindow();
        }

        private int topPad = 0;
        private int pendingScroll = -1;
        private TextView empty;
        private boolean gridMode = false;
        private int cols = 3;

        void setGrid(boolean on) { gridMode = on; }

        List<YevRowView.Item> items() { return data; }

        /** Какая строка под пальцем — нужно для выделения протяжкой. */
        YevRowView rowAt(float rawX, float rawY) {
            int[] loc = new int[2];
            for (YevRowView v : pool) {
                if (v.getVisibility() != VISIBLE) continue;
                v.getLocationOnScreen(loc);
                if (rawY >= loc[1] && rawY <= loc[1] + v.getHeight()
                        && rawX >= loc[0] && rawX <= loc[0] + v.getWidth()) return v;
            }
            return null;
        }

        /** Показать готовый список — например, найденное. */
        void showExternal(List<YevRowView.Item> items) { show(items, null); }

        /** Перерисовать видимые строки, не трогая прокрутку. */
        void refreshVisible() { firstShown = -1; layoutWindow(); }

        /** Держим в разметке только то, что видно, плюс по одной строке сверху и снизу. */
        private void layoutWindow() {
            if (data.isEmpty()) { for (YevRowView v : pool) v.setVisibility(GONE); return; }
            int cellH = gridMode ? Math.round(getWidth() / (float) cols) : rowH;
            int perRow = gridMode ? cols : 1;
            int top = sv.getScrollY() - topPad;
            int h = sv.getHeight();
            int firstRow = Math.max(0, top / cellH - 1);
            int lastRow = (top + h) / cellH + 1;
            int first = Math.max(0, firstRow * perRow);
            int last = Math.min(data.size() - 1, (lastRow + 1) * perRow - 1);
            if (first == firstShown && last == lastShown) return;
            firstShown = first; lastShown = last;

            int need = last - first + 1;
            while (pool.size() < need) {
                YevRowView v = new YevRowView(FilesActivity.this, t);
                v.setOnClickListener(x -> {
                    YevRowView.Item it = v.getItem();
                    if (it == null) return;
                    if (selMode) { toggleSel(it); return; }
                    if (gdFolder != null) {                      // мы на Диске
                        if (it.dir) { gdFolder = it.path.substring(3); gdStack.add(new String[]{ gdFolder, it.name }); loadDrive(); }
                        else driveOpen(it);
                        return;
                    }
                    if (arcPath != null) {                       // мы внутри архива
                        if (it.dir) { arcPrefix = it.path.substring(4); showArcLevel(null); }
                        else toast("Распакуйте файл, чтобы открыть");
                        return;
                    }
                    if (it.dir) openPath(it.path);
                    else if (isArchive(it.name)) openArchive(it.path);
                    else openFile(it);
                });
                v.setOnLongClickListener(x -> {
                    YevRowView.Item it = v.getItem();
                    if (it == null) return false;
                    if (selMode) {                                  // уже выделяем — начинаем перетаскивание
                        android.content.ClipData cd = android.content.ClipData.newPlainText("path", it.path);
                        View.DragShadowBuilder shadow = new View.DragShadowBuilder(v);
                        if (Build.VERSION.SDK_INT >= 24) v.startDragAndDrop(cd, shadow, null, 0);
                        else v.startDrag(cd, shadow, null, 0);
                        return true;
                    }
                    selMode = true; rebuildBottom();
                    toggleSel(it);
                    return true;
                });
                // касание двумя пальцами по строке — меню объекта, как «Открыть с помощью» в вебе
                v.setOnTouchListener((view, ev) -> {
                    if (ev.getPointerCount() >= 2 && ev.getActionMasked() == android.view.MotionEvent.ACTION_POINTER_DOWN) {
                        YevRowView.Item it = v.getItem();
                        if (it != null) itemMenu(it);
                        return true;
                    }
                    // протяжка по строкам в режиме выделения — отмечает всё, по чему провели
                    if (selMode && ev.getActionMasked() == android.view.MotionEvent.ACTION_MOVE) {
                        int[] loc = new int[2];
                        v.getLocationOnScreen(loc);
                        float y = ev.getRawY();
                        YevRowView under = list.rowAt(ev.getRawX(), y);
                        if (under != null && under.getItem() != null) {
                            YevRowView.Item it = under.getItem();
                            if (!dragMarked.contains(it.path)) {
                                dragMarked.add(it.path);
                                toggleSel(it);
                            }
                        }
                        return true;
                    }
                    if (ev.getActionMasked() == android.view.MotionEvent.ACTION_UP
                            || ev.getActionMasked() == android.view.MotionEvent.ACTION_CANCEL) dragMarked.clear();
                    return false;
                });
                // долгое нажатие с движением — перетаскивание на вкладку
                v.setOnDragListener(null);
                canvas.addView(v, new android.widget.FrameLayout.LayoutParams(-1, rowH));
                v.setScale(rowScale);
                v.setFace(faceRegular, faceBold);
                pool.add(v);
            }
            for (int k = 0; k < pool.size(); k++) {
                YevRowView v = pool.get(k);
                int idx = first + k;
                if (k < need && idx < data.size()) {
                    YevRowView.Item it = data.get(idx);
                    if (it.thumb == null && it.path != null) it.thumb = thumbs.get(it.path);
                    v.setVisibility(VISIBLE);
                    v.setItem(it);
                    v.setGrid(gridMode, cellH);
                    android.view.ViewGroup.LayoutParams vlp = v.getLayoutParams();
                    int wantW = gridMode ? Math.round(getWidth() / (float) cols) : -1;
                    if (vlp.height != cellH || vlp.width != wantW) { vlp.height = cellH; vlp.width = wantW; v.setLayoutParams(vlp); }
                    if (gridMode) {
                        v.setTranslationX((idx % cols) * (getWidth() / (float) cols));
                        v.setTranslationY(topPad + (idx / cols) * cellH);
                    } else {
                        v.setTranslationX(0);
                        v.setTranslationY(topPad + idx * rowH);
                    }
                    requestThumb(it, () -> { firstShown = -1; layoutWindow(); });
                } else v.setVisibility(GONE);
            }
        }
    }

    /** Значок и цвет по имени файла — та же таблица, что в веб-части. */
    static String[] iconFor(String name, boolean dir) {
        if (dir) return new String[]{ "folder", "#EF6C00" };
        String n = name.toLowerCase();
        int dot = n.lastIndexOf('.');
        String e = dot >= 0 ? n.substring(dot + 1) : "";
        if (e.equals("pdf")) return new String[]{ "pdf", "#E0574F" };
        if (e.equals("apk")) return new String[]{ "apk", "#6FD3A8" };
        if (e.equals("apks") || e.equals("xapk") || e.equals("apkm") || e.equals("apkx")) return new String[]{ "apk", "#A4C639" };
        if (e.equals("ttf") || e.equals("otf") || e.equals("woff") || e.equals("woff2")) return new String[]{ "txt", "#C9A0FF" };
        if (e.equals("lnk")) return new String[]{ "lnk", "#F5A623" };
        if (e.equals("txt") || e.equals("md") || e.equals("log") || e.equals("ini") || e.equals("cfg")) return new String[]{ "txt", "#9FD0FF" };
        if (in(e, "jpg jpeg png gif webp bmp heic heif avif tif tiff jxl dng cr2 nef arw")) return new String[]{ "img", "#7FB3FF" };
        if (in(e, "mp4 mkv avi mov webm 3gp m4v ts flv wmv mpg mpeg")) return new String[]{ "video", "#C98BFF" };
        if (in(e, "mp3 flac wav ogg m4a aac opus wma ape")) return new String[]{ "audio", "#FF9D6B" };
        if (in(e, "zip rar 7z tar gz tgz bz2 tbz xz zst iso jar war cab arj lha lzh ace z 001")) {
            String col = e.equals("zip") ? "#E3B14F" : e.equals("rar") ? "#9B59B6" : e.equals("7z") ? "#5AA9E6"
                    : (e.equals("tar") || e.equals("gz") || e.equals("xz") || e.equals("bz2")) ? "#6FD3A8"
                    : e.equals("jar") ? "#E0574F" : "#E3B14F";
            return new String[]{ "archive", col, e.toUpperCase(java.util.Locale.US) };
        }
        if (in(e, "js jsx ts tsx java kt py c cpp h cs php rb go rs swift html css json xml yml yaml sh")) return new String[]{ "code", "#6FD3A8" };
        return new String[]{ "file", "#B0A498" };
    }

    // превью: держим готовые в памяти и просим нативную часть для видимых строк
    private final java.util.Map<String, Bitmap> thumbs = new java.util.concurrent.ConcurrentHashMap<>();
    private final java.util.Set<String> thumbBusy = java.util.Collections.newSetFromMap(new java.util.concurrent.ConcurrentHashMap<String, Boolean>());
    private java.util.concurrent.ExecutorService thumbPool;

    private void requestThumb(final YevRowView.Item it, final Runnable done) {
        if (it == null || it.path == null || it.dir) return;
        if (thumbs.containsKey(it.path) || thumbBusy.contains(it.path)) return;
        if (!wantsThumb(it.name)) return;
        thumbBusy.add(it.path);
        if (thumbPool == null) thumbPool = java.util.concurrent.Executors.newFixedThreadPool(2);
        thumbPool.execute(() -> {
            Bitmap b = null;
            try { b = AppsPlugin.thumbBitmap(FilesActivity.this, new File(it.path), Math.round(YevTheme.ICON * d * 1.6f)); }
            catch (Throwable ignored) {}
            final Bitmap fb = b;
            thumbBusy.remove(it.path);
            if (fb != null) {
                thumbs.put(it.path, fb);
                runOnUiThread(done);
            }
        });
    }

    private static boolean wantsThumb(String name) {
        String n = name.toLowerCase();
        int dot = n.lastIndexOf('.');
        String e = dot >= 0 ? n.substring(dot + 1) : "";
        return in(e, "jpg jpeg png gif webp bmp heic heif avif tif tiff jxl dng cr2 nef arw mp4 mkv avi mov webm 3gp m4v ts pdf apk");
    }

    /** Меню в шапке — простое, теми же пунктами, что нужны сейчас. */
    /** Файл перетащили на вкладку: спрашиваем, копировать или перенести. */
    private void dropOnTab(final String srcPath, final int tabIndex) {
        if (srcPath == null || tabIndex < 0 || tabIndex >= tabs.size()) return;
        final String dest = tabs.get(tabIndex).isEmpty() ? "/storage/emulated/0" : tabs.get(tabIndex);
        final java.util.List<String> what = sel.isEmpty() ? java.util.Collections.singletonList(srcPath) : new ArrayList<>(sel);
        new android.app.AlertDialog.Builder(this)
                .setTitle("В «" + shortName(dest) + "»")
                .setItems(new String[]{ "Копировать", "Переместить" }, (dlg, which) -> {
                    clip.clear();
                    clip.addAll(what);
                    clipCut = which == 1;
                    String keep = path;
                    path = dest;
                    paste();
                    path = keep;
                    exitSel();
                }).show();
    }

    /** Размер строк списка: мельче, обычный, крупнее. */
    private void rowSizeMenu() {
        final String[] base = { "Компактно", "Обычный", "Крупно" };
        final int cur = rowScale < 0.95f ? 0 : rowScale > 1.05f ? 2 : 1;
        String[] items = new String[3];
        Runnable[] acts = new Runnable[3];
        for (int i = 0; i < 3; i++) {
            final int which = i;
            items[i] = (i == cur ? "•  " : "     ") + base[i];
            acts[i] = () -> {
                rowScale = which == 0 ? 0.85f : which == 2 ? 1.2f : 1f;
                prefs.edit().putFloat("rowScale", rowScale).apply();
                list.setRowScale(rowScale);
                openPath(path);
            };
        }
        themedList("Размер строк", items, acts);
    }

    /** Добавить текущую папку в закладки — в тот же список, что у старого вида. */
    private void addBookmark() {
        try {
            String pth = path.isEmpty() ? "/storage/emulated/0" : path;
            org.json.JSONArray arr = new org.json.JSONArray(prefs.getString("bookmarks", "[]"));
            for (int i = 0; i < arr.length(); i++) {
                if (pth.equals(arr.getJSONObject(i).optString("path"))) { toast("Уже в закладках"); return; }
            }
            org.json.JSONObject b = new org.json.JSONObject();
            b.put("id", "bm" + System.currentTimeMillis());
            b.put("name", pth.substring(pth.lastIndexOf('/') + 1));
            b.put("path", pth);
            arr.put(b);
            prefs.edit().putString("bookmarks", arr.toString()).apply();
            toast("Добавлено в закладки");
        } catch (Throwable t2) { toast("Не вышло"); }
    }

    /** Все снимки папки — родным просмотрщиком, с первого. */
    private void openGallery() {
        java.util.List<String> imgs = new ArrayList<>();
        for (YevRowView.Item x : list.items()) if (!x.dir && isImage(x.name) && x.path != null) imgs.add(x.path);
        if (imgs.isEmpty()) { toast("Здесь нет снимков"); return; }
        Intent pi = new Intent(this, PhotoActivity.class);
        pi.putExtra(PhotoActivity.EXTRA_LIST, imgs.toArray(new String[0]));
        pi.putExtra(PhotoActivity.EXTRA_INDEX, 0);
        pi.putExtra(PhotoActivity.EXTRA_DEBUG, debug);
        startActivity(pi);
    }

    /** Настройки родного вида — отдельным окном, теми же пунктами. */
    private void openSettings() {
        final java.util.List<String> names = new ArrayList<>();
        final java.util.List<Runnable> acts = new ArrayList<>();

        names.add("Тема: " + ("light".equals(themeName) ? "светлая" : "тёмная"));
        acts.add(() -> switchTheme());

        names.add("Сортировка");
        acts.add(() -> sortMenu());

        names.add("Размер строк");
        acts.add(() -> rowSizeMenu());

        names.add("Вид: " + (grid ? "сетка" : "список"));
        acts.add(() -> { grid = !grid; prefs.edit().putBoolean("grid", grid).apply(); list.setGrid(grid); openPath(path); });

        names.add("Скрытые файлы: " + (showHidden ? "видны" : "скрыты"));
        acts.add(() -> { showHidden = !showHidden; prefs.edit().putBoolean("hidden", showHidden).apply(); openPath(path); });

        names.add("Отладка: " + (debug ? "включена" : "выключена"));
        acts.add(() -> { debug = !debug; openPath(path); });

        names.add("Открывать этот вид сразу: " + (prefs.getBoolean("startNative", false) ? "да" : "нет"));
        acts.add(() -> {
            boolean v = !prefs.getBoolean("startNative", false);
            prefs.edit().putBoolean("startNative", v).apply();
            toast(v ? "Теперь приложение будет открывать родной вид" : "Будет открываться старый вид");
        });

        names.add("Требуемые разрешения");
        acts.add(() -> {
            try {
                Intent i = new Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                        android.net.Uri.parse("package:" + getPackageName()));
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(i);
            } catch (Throwable ignored) {}
        });

        themedList("Настройки", names.toArray(new String[0]), acts.toArray(new Runnable[0]));
    }

    /** Меню шапки — своим окном в цветах темы, как в вебе. */
    private void openHeadMenu() {
        final String[][] items = {
                { "plus", "Новая вкладка" },
                { "sort", "Обновить" },
                { "sort", "Сортировка" },
                { grid ? "file" : "img", grid ? "Вид: список" : "Вид: сетка" },
                { "info", "Скрытые файлы: " + (showHidden ? "видны" : "скрыты") },
                { "img", "Смотреть все снимки" },
                { "star", "В закладки" },
                { "dl", "Задачи" },
                { "info", "Настройки" },
                { "back", "Вернуться в старый вид" },
        };
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setBackgroundColor(t.bar);
        col.setPadding(0, dp(8), 0, dp(8));

        final android.app.AlertDialog dlg = new android.app.AlertDialog.Builder(this).setView(col).create();
        for (int i = 0; i < items.length; i++) {
            final int which = i;
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(dp(16), dp(11), dp(16), dp(11));
            IconView ic = new IconView(this, items[i][0], t.ink, 20);
            LinearLayout.LayoutParams ilp = new LinearLayout.LayoutParams(dp(22), dp(22));
            ilp.rightMargin = dp(14);
            row.addView(ic, ilp);
            TextView tv = new TextView(this);
            tv.setText(items[i][1]);
            tv.setTextColor(t.txt);
            tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14.5f);
            applyFace(tv, false);
            row.addView(tv);
            row.setOnClickListener(v -> {
                dlg.dismiss();
                if (which == 0) { tabs.add(path); active = tabs.size() - 1; openPath(path); }
                else if (which == 1) openPath(path);
                else if (which == 2) sortMenu();
                else if (which == 3) { grid = !grid; prefs.edit().putBoolean("grid", grid).apply(); list.setGrid(grid); openPath(path); }
                else if (which == 4) { showHidden = !showHidden; prefs.edit().putBoolean("hidden", showHidden).apply(); openPath(path); }
                else if (which == 5) openGallery();
                else if (which == 6) addBookmark();
                else if (which == 7) showTasks();
                else if (which == 8) openSettings();
                else finish();
            });
            col.addView(row);
        }
        dlg.show();
        try {
            android.view.Window w = dlg.getWindow();
            if (w != null) {
                w.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(0));
                w.setGravity(Gravity.TOP | Gravity.END);
                android.view.WindowManager.LayoutParams lp = w.getAttributes();
                lp.y = dp(64);
                lp.x = dp(10);
                w.setAttributes(lp);
            }
            GradientDrawable bg = new GradientDrawable();
            bg.setColor(t.bar);
            bg.setCornerRadius(dp(18));
            col.setBackground(bg);
        } catch (Throwable ignored) {}
    }

    // ---- сортировка: те же правила, что в веб-части ----
    private int sortMode = 0;      // 0 А-Я, 1 Я-А, 2 больше, 3 меньше, 4 новые, 5 старые
    private boolean showHidden = false;
    private boolean grid = false;
    private float rowScale = 1f;
    private String fontName = "";
    private boolean dirSizes = false;
    private android.graphics.Typeface faceRegular, faceBold;

    private void sortMenu() {
        final String[] base = { "Имя: А-Я / A-Z", "Имя: Я-А / Z-A", "Размер: больше → меньше",
                "Размер: меньше → больше", "Дата: новые сверху", "Дата: старые сверху" };
        String[] items = new String[base.length];
        Runnable[] acts = new Runnable[base.length];
        for (int i = 0; i < base.length; i++) {
            final int which = i;
            items[i] = (i == sortMode ? "•  " : "     ") + base[i];
            acts[i] = () -> {
                sortMode = which;
                prefs.edit().putInt("sort", which).apply();
                openPath(path);
            };
        }
        themedList("Сортировка", items, acts);
    }

    /** Поиск по имени в текущей папке и вложенных. */
    private void searchDialog() {
        askName("Поиск", "", "Искать", raw -> {
                    final String q = raw.trim().toLowerCase();
                    if (q.isEmpty()) return;
                    final String base = path.isEmpty() ? "/storage/emulated/0" : path;
                    toast("Ищу…");
                    new Thread(() -> {
                        final List<YevRowView.Item> found = new ArrayList<>();
                        searchWalk(new File(base), q, found, System.currentTimeMillis() + 8000);
                        sortItems(found);
                        runOnUiThread(() -> {
                            searchTitle = "Найдено: " + found.size();
                            list.showExternal(found);
                            crumb.setText(searchTitle);
                            rebuildCrumbs();
                        });
                    }).start();
        });
    }

    private String searchTitle;

    private void searchWalk(File dir, String q, List<YevRowView.Item> out, long deadline) {
        if (System.currentTimeMillis() > deadline || out.size() > 500) return;
        File[] kids = dir.listFiles();
        if (kids == null) return;
        for (File f : kids) {
            try {
                if (!showHidden && f.getName().startsWith(".")) continue;
                if (f.getName().toLowerCase().contains(q)) {
                    YevRowView.Item it = new YevRowView.Item();
                    it.name = f.getName();
                    it.dir = f.isDirectory();
                    it.size = it.dir ? 0 : f.length();
                    it.mtime = f.lastModified();
                    it.path = f.getAbsolutePath();
                    String[] ic = iconFor(it.name, it.dir);
                    it.iconKey = ic[0];
                    try { it.iconColor = Color.parseColor(ic[1]); } catch (Throwable t2) { it.iconColor = 0; }
                    if (ic.length > 2) it.badge = ic[2];
                    out.add(it);
                }
                if (f.isDirectory()) searchWalk(f, q, out, deadline);
            } catch (Throwable ignored) {}
        }
    }

    // ---- шторка ----
    private android.widget.FrameLayout drawerLayer;

    private void openDrawer() {
        if (drawerLayer != null) return;
        drawerLayer = new android.widget.FrameLayout(this);
        drawerLayer.setBackgroundColor(0x80000000);
        drawerLayer.setOnClickListener(v -> closeDrawer());

        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setBackgroundColor(t.bar);
        panel.setClickable(true);
        int width = Math.min(Math.round(getResources().getDisplayMetrics().widthPixels * 0.82f), dp(330));
        android.widget.FrameLayout.LayoutParams plp = new android.widget.FrameLayout.LayoutParams(width, -1, Gravity.START);
        panel.setLayoutParams(plp);

        android.widget.ScrollView sv = new android.widget.ScrollView(this);
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(0, dp(40), 0, dp(20));
        sv.addView(col, new android.widget.FrameLayout.LayoutParams(-1, -2));
        panel.addView(sv, new LinearLayout.LayoutParams(-1, 0, 1f));

        java.util.Set<String> hidden = new java.util.HashSet<>();
        try {
            org.json.JSONArray h = new org.json.JSONArray(prefs.getString("hidden", "[]"));
            for (int i = 0; i < h.length(); i++) hidden.add(h.optString(i));
        } catch (Throwable ignored) {}
        for (String[] d : drawerItems()) {
            String id = "Data".equals(d[0]) ? "data" : "OBB".equals(d[0]) ? "obb" : d[0];
            if (hidden.contains(id)) continue;
            col.addView(drawerRow(d[0], d[1], d[2], Color.parseColor(d[3]), d[4]));
        }

        // подпись приложения снизу и кнопка обновления, как в вебе
        LinearLayout foot = new LinearLayout(this);
        foot.setOrientation(LinearLayout.HORIZONTAL);
        foot.setGravity(Gravity.CENTER_VERTICAL);
        foot.setPadding(dp(16), dp(10), dp(10), dp(10));
        TextView nm = new TextView(this);
        nm.setText("YevFiles");
        nm.setTextColor(t.txt);
        nm.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        foot.addView(nm, new LinearLayout.LayoutParams(0, -2, 1f));
        IconView refresh = new IconView(this, "sort", t.sub, 20);
        refresh.setOnClickListener(v -> { closeDrawer(); openPath(path); });
        foot.addView(refresh, new LinearLayout.LayoutParams(dp(36), dp(36)));
        panel.addView(foot);

        drawerLayer.addView(panel);
        addContentOverlay(drawerLayer);
        panel.setTranslationX(-width);
        panel.animate().translationX(0).setDuration(220).start();
    }

    private void closeDrawer() {
        if (drawerLayer == null) return;
        final android.widget.FrameLayout layer = drawerLayer;
        drawerLayer = null;
        View panel = layer.getChildAt(0);
        if (panel != null) panel.animate().translationX(-panel.getWidth()).setDuration(180).start();
        layer.animate().alpha(0f).setDuration(180).withEndAction(() -> {
            android.view.ViewGroup vg = (android.view.ViewGroup) layer.getParent();
            if (vg != null) vg.removeView(layer);
        }).start();
    }

    /** Разделы шторки: имя, подпись, значок, цвет, путь. Те же, что в вебе. */
    private List<String[]> drawerItems() {
        List<String[]> out = new ArrayList<>();
        // съёмные носители и второй раздел памяти
        try {
            File[] roots = new File("/storage").listFiles();
            if (roots != null) for (File r : roots) {
                String nm = r.getName();
                if ("emulated".equals(nm) || "self".equals(nm)) continue;
                if (!r.isDirectory() || !r.canRead()) continue;
                out.add(new String[]{ nm, r.getAbsolutePath(), "folder", "#E58A4F", r.getAbsolutePath() });
            }
        } catch (Throwable ignored) {}
        out.add(new String[]{ "Google Drive", "облако", "gdrive", "#EF6C00", "@gd" });
        out.add(new String[]{ "Storage", "/storage/emulated/0", "folder", "#4FC3D9", "/storage/emulated/0" });
        out.add(new String[]{ "Download", "Download", "dl", "#7F9FD9", "/storage/emulated/0/Download" });
        out.add(new String[]{ "DCIM", "DCIM", "cam", "#6FD3A8", "/storage/emulated/0/DCIM" });
        out.add(new String[]{ "Pictures", "Pictures", "img", "#6FD3A8", "/storage/emulated/0/Pictures" });
        out.add(new String[]{ "Movies", "Movies", "video", "#C98BFF", "/storage/emulated/0/Movies" });
        out.add(new String[]{ "Music", "Music", "audio", "#FF9D6B", "/storage/emulated/0/Music" });
        out.add(new String[]{ "Documents", "Documents", "txt", "#9FD0FF", "/storage/emulated/0/Documents" });
        // закладки, добавленные в старом виде
        try {
            String raw = prefs.getString("bookmarks", "[]");
            org.json.JSONArray arr = new org.json.JSONArray(raw);
            for (int i = 0; i < arr.length(); i++) {
                org.json.JSONObject b = arr.getJSONObject(i);
                String nm = b.optString("name", "");
                String pth = b.optString("path", "");
                if (nm.isEmpty() || pth.isEmpty()) continue;
                out.add(new String[]{ nm, pth.replaceFirst("^/storage/emulated/0/?", ""), "star", "#E3B14F", pth });
            }
        } catch (Throwable ignored) {}
        out.add(new String[]{ "Data", "data", "android", "#8FB84A", "/storage/emulated/0/Android/data" });
        out.add(new String[]{ "OBB", "obb", "android", "#E3B14F", "/storage/emulated/0/Android/obb" });
        return out;
    }

    /** Сколько занято на носителе — подпись под названием, как в вебе. */
    private String volumeSpace(String path) {
        try {
            android.os.StatFs st = new android.os.StatFs(path);
            long total = st.getTotalBytes(), free = st.getAvailableBytes();
            if (total <= 0) return null;
            return YevFmt.size(total - free) + " из " + YevFmt.size(total);
        } catch (Throwable t2) { return null; }
    }

    private View drawerRow(String name, String sub, String iconKey, int color, final String target) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(14), dp(11), dp(14), dp(11));

        android.widget.FrameLayout circle = new android.widget.FrameLayout(this);
        GradientDrawable cbg = new GradientDrawable();
        cbg.setShape(GradientDrawable.OVAL);
        cbg.setColor(t.chip);
        circle.setBackground(cbg);
        IconView ic = new IconView(this, iconKey, color, 22);
        circle.addView(ic, new android.widget.FrameLayout.LayoutParams(-1, -1));
        LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(dp(40), dp(40));
        clp.rightMargin = dp(12);
        row.addView(circle, clp);

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        TextView n = new TextView(this);
        n.setText(name);
        n.setTextColor(t.txt);
        n.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
        n.setTypeface(null, android.graphics.Typeface.BOLD);
        col.addView(n);
        TextView sb = new TextView(this);
        String space = target.startsWith("/storage/") && new File(target).isDirectory() && target.split("/").length <= 4 ? volumeSpace(target) : null;
        sb.setText(space != null ? space : sub);
        sb.setTextColor(t.sub);
        sb.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        sb.setSingleLine(true);
        sb.setEllipsize(android.text.TextUtils.TruncateAt.MIDDLE);
        col.addView(sb);
        row.addView(col, new LinearLayout.LayoutParams(0, -2, 1f));

        row.setOnClickListener(v -> {
            closeDrawer();
            if ("@gd".equals(target)) { gdStack.clear(); openDrive("root", "Google Drive"); }
            else openPath(target);
        });
        return row;
    }

    /** Слой поверх экрана — для шторки и окон. */
    private void addContentOverlay(View v) {
        android.widget.FrameLayout wrap = overlayHost();
        wrap.addView(v, new android.widget.FrameLayout.LayoutParams(-1, -1));
    }

    private android.widget.FrameLayout overlayHost;

    private android.widget.FrameLayout overlayHost() {
        if (overlayHost == null) {
            overlayHost = new android.widget.FrameLayout(this);
            android.view.ViewGroup decor = (android.view.ViewGroup) getWindow().getDecorView();
            decor.addView(overlayHost, new android.view.ViewGroup.LayoutParams(-1, -1));
        }
        return overlayHost;
    }

    // ---- выделение ----
    private final java.util.HashSet<String> dragMarked = new java.util.HashSet<>();
    private boolean selMode = false;
    private final java.util.LinkedHashSet<String> sel = new java.util.LinkedHashSet<>();

    private void toggleSel(YevRowView.Item it) {
        if (sel.contains(it.path)) sel.remove(it.path); else sel.add(it.path);
        it.selected = sel.contains(it.path);
        if (sel.isEmpty()) { selMode = false; rebuildBottom(); }
        list.refreshVisible();
        updateSelTitle();
    }

    private void exitSel() {
        selMode = false;
        sel.clear();
        for (YevRowView.Item it : list.items()) it.selected = false;
        rebuildBottom();
        list.refreshVisible();
        crumb.setText(crumbBase);
    }

    private void selectAll() {
        for (YevRowView.Item it : list.items()) { it.selected = true; sel.add(it.path); }
        if (!selMode) { selMode = true; rebuildBottom(); }
        list.refreshVisible();
        updateSelTitle();
    }

    private void updateSelTitle() {
        if (!selMode) { crumb.setText(crumbBase); rebuildCrumbs(); return; }
        crumb.setText("Выбрано: " + sel.size());
        rebuildCrumbs();
    }

    // ---- буфер и операции ----
    private final java.util.ArrayList<String> clip = new java.util.ArrayList<>();
    private boolean clipCut = false;

    private void grab(boolean cut) {
        clip.clear();
        clip.addAll(sel);
        clipCut = cut;
        exitSel();
        rebuildBottom();
        toast((cut ? "Вырезать: " : "Копировать: ") + clip.size() + " об.");
    }

    private void paste() {
        final java.util.List<String> src = new ArrayList<>(clip);
        final boolean cut = clipCut;
        final String dest = path.isEmpty() ? "/storage/emulated/0" : path;
        clip.clear();
        rebuildBottom();
        askAll = -1;
        showProgress(cut ? "Перемещение" : "Копирование");
        new Thread(() -> {
            int ok = 0, bad = 0, skip = 0;
            long total = 0, done = 0;
            for (String p : src) total += treeSize(new File(p));
            for (int i = 0; i < src.size(); i++) {
                if (opCancel) break;
                File from = new File(src.get(i));
                File to = new File(dest, from.getName());
                try {
                    if (from.getAbsolutePath().equals(to.getAbsolutePath())) { skip++; continue; }
                    if (from.isDirectory() && to.getAbsolutePath().startsWith(from.getAbsolutePath() + "/")) { skip++; continue; }   // папка в саму себя
                    if (to.exists()) {
                        int answer = askConflict(from, to);       // ждём ответа так же, как в вебе
                        if (answer == ASK_SKIP) { skip++; done += treeSize(from); updateProgress(from.getName(), done, total); continue; }
                        if (answer == ASK_CANCEL) { opCancel = true; break; }
                        if (answer == ASK_KEEP_BOTH) to = freeName(to);
                        else if (answer == ASK_REPLACE) deleteTree(to);      // и файл, и папку заменяем целиком
                        // ASK_MERGE: ничего не удаляем — копирование само дольёт содержимое
                    }
                    updateProgress(from.getName(), done, total);
                    boolean res = cut && !to.exists() ? from.renameTo(to) : false;
                    if (!res) { res = copyTree(from, to); if (res && cut) deleteTree(from); }
                    done += treeSize(to.exists() ? to : from);
                    updateProgress(from.getName(), done, total);
                    if (res) ok++; else bad++;
                } catch (Throwable t2) { bad++; }
            }
            final int o = ok, b = bad, sk = skip;
            runOnUiThread(() -> {
                hideProgress();
                String msg = "Готово: " + o + (b > 0 ? ", с ошибками: " + b : "") + (sk > 0 ? ", пропущено: " + sk : "");
                addTask((cut ? "Перемещение" : "Копирование") + " → " + shortName(dest) + ": " + msg);
                toast(msg);
                openPath(path);
            });
        }).start();
    }

    private long treeSize(File f) {
        if (f == null || !f.exists()) return 0;
        if (!f.isDirectory()) return f.length();
        long s2 = 0;
        File[] kids = f.listFiles();
        if (kids != null) for (File k : kids) s2 += treeSize(k);
        return s2;
    }

    private File freeName(File to) {
        String nm = to.getName();
        String base = nm, ext = "";
        int dot = nm.lastIndexOf('.');
        if (dot > 0 && !to.isDirectory()) { base = nm.substring(0, dot); ext = nm.substring(dot); }
        for (int i = 2; i < 999; i++) {
            File cand = new File(to.getParentFile(), base + " (" + i + ")" + ext);
            if (!cand.exists()) return cand;
        }
        return to;
    }

    // ---- очередь задач: что уже сделано за эту сессию ----
    private final java.util.ArrayList<String> taskLog = new java.util.ArrayList<>();

    private void addTask(String line) {
        taskLog.add(0, YevFmt.date(System.currentTimeMillis()) + "  ·  " + line);
        while (taskLog.size() > 40) taskLog.remove(taskLog.size() - 1);
    }

    private void showTasks() {
        if (taskLog.isEmpty()) { toast("Задач пока не было"); return; }
        Runnable[] noop = new Runnable[taskLog.size()];
        themedList("Задачи", taskLog.toArray(new String[0]), noop);
    }

    // ---- уведомление о ходе: видно и при свёрнутом приложении ----
    private static final String CH_ID = "yev_ops";
    private android.app.NotificationManager nm;

    private void notifyProgress(String title, String text, int percent) {
        try {
            if (nm == null) {
                nm = (android.app.NotificationManager) getSystemService(NOTIFICATION_SERVICE);
                if (Build.VERSION.SDK_INT >= 26) {
                    android.app.NotificationChannel ch = new android.app.NotificationChannel(CH_ID, "Операции", android.app.NotificationManager.IMPORTANCE_LOW);
                    nm.createNotificationChannel(ch);
                }
            }
            android.app.Notification.Builder b = Build.VERSION.SDK_INT >= 26
                    ? new android.app.Notification.Builder(this, CH_ID)
                    : new android.app.Notification.Builder(this);
            b.setContentTitle(title).setContentText(text).setSmallIcon(android.R.drawable.stat_sys_download).setOnlyAlertOnce(true);
            if (percent >= 0) b.setProgress(100, percent, false);
            nm.notify(701, b.build());
        } catch (Throwable ignored) {}
    }

    private void notifyDone(String text) {
        try { if (nm != null) nm.cancel(701); } catch (Throwable ignored) {}
    }

    // ---- окно хода ----
    private android.app.AlertDialog progDlg;
    private TextView progText;
    private android.widget.ProgressBar progBar;
    private boolean opCancel = false;

    private void showProgress(final String title) {
        opCancel = false;
        progTitle = title;
        runOnUiThread(() -> {
            LinearLayout box = new LinearLayout(this);
            box.setOrientation(LinearLayout.VERTICAL);
            box.setPadding(dp(20), dp(18), dp(20), dp(12));
            GradientDrawable bg = new GradientDrawable();
            bg.setColor(t.bar);
            bg.setCornerRadius(dp(20));
            box.setBackground(bg);

            TextView h = new TextView(this);
            h.setText(title);
            h.setTextColor(t.txt);
            h.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
            applyFace(h, true);
            box.addView(h);

            progText = new TextView(this);
            progText.setTextColor(t.sub);
            progText.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f);
            applyFace(progText, false);
            LinearLayout.LayoutParams plp = new LinearLayout.LayoutParams(-1, -2);
            plp.topMargin = dp(8);
            box.addView(progText, plp);

            progBar = new android.widget.ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
            progBar.setMax(1000);
            try {
                progBar.setProgressTintList(android.content.res.ColorStateList.valueOf(t.acc));
                progBar.setProgressBackgroundTintList(android.content.res.ColorStateList.valueOf(t.line));
            } catch (Throwable ignored) {}
            LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(-1, -2);
            blp.topMargin = dp(10);
            box.addView(progBar, blp);

            TextView stop = new TextView(this);
            stop.setText("Прервать");
            stop.setTextColor(t.red);
            stop.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14.5f);
            stop.setPadding(dp(10), dp(12), dp(10), dp(4));
            stop.setGravity(Gravity.END);
            applyFace(stop, true);
            stop.setOnClickListener(v -> opCancel = true);
            box.addView(stop, new LinearLayout.LayoutParams(-1, -2));

            progDlg = new android.app.AlertDialog.Builder(this).setView(box).setCancelable(false).create();
            progDlg.show();
            try {
                android.view.Window w = progDlg.getWindow();
                if (w != null) w.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(0));
            } catch (Throwable ignored) {}
        });
    }

    private long lastNotify = 0;

    private void updateProgress(final String name, final long done, final long total) {
        runOnUiThread(() -> {
            if (progText == null) return;
            progText.setText(name + "\n" + YevFmt.size(done) + " из " + YevFmt.size(total));
            if (progBar != null && total > 0) progBar.setProgress((int) (1000L * done / total));
        });
        long now = System.currentTimeMillis();
        if (now - lastNotify > 400) {          // уведомление обновляем пореже, чтобы не мигало
            lastNotify = now;
            notifyProgress(progTitle, name + "  ·  " + YevFmt.size(done) + " из " + YevFmt.size(total),
                    total > 0 ? (int) (100L * done / total) : -1);
        }
    }

    private String progTitle = "";

    private void hideProgress() {
        notifyDone(null);
        runOnUiThread(() -> {
            try { if (progDlg != null) progDlg.dismiss(); } catch (Throwable ignored) {}
            progDlg = null; progText = null; progBar = null;
        });
    }

    // ---- вопрос при совпадении имён ----
    private static final int ASK_REPLACE = 0, ASK_SKIP = 1, ASK_KEEP_BOTH = 2, ASK_CANCEL = 3, ASK_MERGE = 4;
    private int askAll = -1;

    private int askConflict(final File from, final File to) {
        if (askAll >= 0) return askAll;
        final int[] res = new int[]{ ASK_SKIP };
        final boolean[] done = new boolean[]{ false };
        final boolean[] remember = new boolean[]{ false };
        runOnUiThread(() -> {
            LinearLayout col = new LinearLayout(this);
            col.setOrientation(LinearLayout.VERTICAL);
            col.setPadding(dp(18), dp(16), dp(18), dp(10));
            GradientDrawable bg = new GradientDrawable();
            bg.setColor(t.bar);
            bg.setCornerRadius(dp(20));
            col.setBackground(bg);

            TextView h = new TextView(this);
            h.setText(from.getName());
            h.setTextColor(t.txt);
            h.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
            h.setSingleLine(true);
            h.setEllipsize(android.text.TextUtils.TruncateAt.MIDDLE);
            applyFace(h, true);
            col.addView(h);

            TextView sub = new TextView(this);
            sub.setText(from.isDirectory() ? "Папка уже существует" : "Файл уже существует");
            sub.setTextColor(t.sub);
            sub.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f);
            applyFace(sub, false);
            col.addView(sub);

            TextView where = new TextView(this);
            where.setText(to.getAbsolutePath());
            where.setTextColor(t.sub);
            where.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11.5f);
            LinearLayout.LayoutParams wlp = new LinearLayout.LayoutParams(-1, -2);
            wlp.topMargin = dp(8);
            col.addView(where, wlp);

            final android.app.AlertDialog dlg = new android.app.AlertDialog.Builder(this).setView(col).setCancelable(false).create();

            final String[] labels = from.isDirectory()
                    ? new String[]{ "Объединить", "Заменить папку", "Пропустить", "Сохранить оба" }
                    : new String[]{ "Заменить", "Пропустить", "Сохранить оба" };
            final int[] codes = from.isDirectory()
                    ? new int[]{ ASK_MERGE, ASK_REPLACE, ASK_SKIP, ASK_KEEP_BOTH }
                    : new int[]{ ASK_REPLACE, ASK_SKIP, ASK_KEEP_BOTH };

            final boolean[] rememberBox = new boolean[]{ false };
            for (int i = 0; i < labels.length; i++) {
                final int code = codes[i];
                TextView tv = new TextView(this);
                tv.setText(labels[i]);
                tv.setTextColor(code == ASK_REPLACE ? t.red : t.txt);
                tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
                tv.setPadding(dp(4), dp(12), dp(4), dp(12));
                applyFace(tv, false);
                tv.setOnClickListener(v -> {
                    res[0] = code;
                    remember[0] = rememberBox[0];
                    dlg.dismiss();
                    synchronized (done) { done[0] = true; done.notifyAll(); }
                });
                col.addView(tv);
            }

            LinearLayout foot = new LinearLayout(this);
            foot.setOrientation(LinearLayout.HORIZONTAL);
            foot.setGravity(Gravity.CENTER_VERTICAL);
            LinearLayout.LayoutParams flp = new LinearLayout.LayoutParams(-1, -2);
            flp.topMargin = dp(6);
            col.addView(foot, flp);

            final TextView mem = new TextView(this);
            mem.setText("☐  Запомнить");
            mem.setTextColor(t.sub);
            mem.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
            mem.setPadding(dp(4), dp(10), dp(4), dp(10));
            mem.setOnClickListener(v -> {
                rememberBox[0] = !rememberBox[0];
                mem.setText((rememberBox[0] ? "☑" : "☐") + "  Запомнить");
                mem.setTextColor(rememberBox[0] ? t.acc : t.sub);
            });
            foot.addView(mem, new LinearLayout.LayoutParams(0, -2, 1f));

            TextView stop = new TextView(this);
            stop.setText("Прервать");
            stop.setTextColor(t.red);
            stop.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
            stop.setPadding(dp(10), dp(10), dp(4), dp(10));
            stop.setOnClickListener(v -> {
                res[0] = ASK_CANCEL;
                dlg.dismiss();
                synchronized (done) { done[0] = true; done.notifyAll(); }
            });
            foot.addView(stop);

            dlg.show();
            try {
                android.view.Window w = dlg.getWindow();
                if (w != null) w.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(0));
            } catch (Throwable ignored) {}
        });
        synchronized (done) {
            while (!done[0]) {
                try { done.wait(); } catch (InterruptedException e) { return ASK_CANCEL; }
            }
        }
        if (remember[0] && res[0] != ASK_CANCEL) askAll = res[0];
        return res[0];
    }

    private boolean copyTree(File from, File to) {
        try {
            if (from.isDirectory()) {
                if (!to.exists() && !to.mkdirs()) return false;
                File[] kids = from.listFiles();
                if (kids != null) for (File k : kids) if (!copyTree(k, new File(to, k.getName()))) return false;
                return true;
            }
            java.io.InputStream in = new java.io.FileInputStream(from);
            java.io.OutputStream out = new java.io.FileOutputStream(to);
            byte[] buf = new byte[1 << 16];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            in.close(); out.close();
            to.setLastModified(from.lastModified());
            return true;
        } catch (Throwable t2) { return false; }
    }

    private boolean deleteTree(File f) {
        if (f.isDirectory()) {
            File[] kids = f.listFiles();
            if (kids != null) for (File k : kids) deleteTree(k);
        }
        return f.delete();
    }

    private void confirmDelete() {
        final java.util.List<String> victims = new ArrayList<>(sel);
        if (victims.isEmpty()) return;
        themedList("Удалить " + victims.size() + " об.?", new String[]{ "Удалить", "Отмена" }, new Runnable[]{
                () -> {
                    exitSel();
                    new Thread(() -> {
                        int ok = 0;
                        for (String p : victims) { try { if (deleteTree(new File(p))) ok++; } catch (Throwable ignored) {} }
                        final int o = ok;
                        runOnUiThread(() -> { addTask("Удаление: " + o + " об."); toast("Удалено: " + o); openPath(path); });
                    }).start();
                }, null });
    }

    private void renameOne() {
        if (sel.size() != 1) { toast("Выберите один объект"); return; }
        final File f = new File(sel.iterator().next());
        askName("Новое имя", f.getName(), "Готово", nm -> {
            boolean ok = f.renameTo(new File(f.getParentFile(), nm));
            exitSel();
            toast(ok ? "Переименовано" : "Не вышло");
            openPath(path);
        });
    }

    private interface OnName { void run(String name); }

    /** Ввод имени в цветах темы — вместо системного окна. */
    private void askName(String title, String value, String okText, final OnName cb) {
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(18), dp(16), dp(18), dp(10));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(t.bar);
        bg.setCornerRadius(dp(20));
        col.setBackground(bg);

        TextView h = new TextView(this);
        h.setText(title);
        h.setTextColor(t.txt);
        h.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
        applyFace(h, true);
        col.addView(h);

        final android.widget.EditText in = new android.widget.EditText(this);
        in.setText(value);
        in.setSelectAllOnFocus(true);
        in.setSingleLine(true);
        in.setTextColor(t.txt);
        in.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        GradientDrawable ibg = new GradientDrawable();
        ibg.setColor(t.row2);
        ibg.setCornerRadius(dp(12));
        in.setBackground(ibg);
        in.setPadding(dp(12), dp(10), dp(12), dp(10));
        applyFace(in, false);
        LinearLayout.LayoutParams ilp = new LinearLayout.LayoutParams(-1, -2);
        ilp.topMargin = dp(12);
        col.addView(in, ilp);

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.END);
        LinearLayout.LayoutParams rlp = new LinearLayout.LayoutParams(-1, -2);
        rlp.topMargin = dp(10);
        col.addView(row, rlp);

        final android.app.AlertDialog dlg = new android.app.AlertDialog.Builder(this).setView(col).create();

        TextView cancel = new TextView(this);
        cancel.setText("Отмена");
        cancel.setTextColor(t.sub);
        cancel.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14.5f);
        cancel.setPadding(dp(14), dp(10), dp(14), dp(10));
        cancel.setOnClickListener(v -> dlg.dismiss());
        row.addView(cancel);

        TextView ok = new TextView(this);
        ok.setText(okText);
        ok.setTextColor(t.acc);
        ok.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14.5f);
        ok.setPadding(dp(14), dp(10), dp(14), dp(10));
        applyFace(ok, true);
        ok.setOnClickListener(v -> {
            String nm = in.getText().toString().trim();
            dlg.dismiss();
            if (!nm.isEmpty() && cb != null) cb.run(nm);
        });
        row.addView(ok);

        dlg.show();
        try {
            android.view.Window w = dlg.getWindow();
            if (w != null) {
                w.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(0));
                w.setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE);
            }
        } catch (Throwable ignored) {}
    }

    private void createMenu() {
        themedList("Создать", new String[]{ "Папку", "Текстовый файл" }, new Runnable[]{
                () -> createNamed(0), () -> createNamed(1) });
    }

    private void createNamed(final int which) {
        askName(which == 0 ? "Имя папки" : "Имя файла", which == 0 ? "Новая папка" : "новый.txt", "Создать", nm -> {
            File base = new File(path.isEmpty() ? "/storage/emulated/0" : path);
            File f = new File(base, nm);
            try {
                if (which == 0) f.mkdirs();
                else { f.getParentFile().mkdirs(); new java.io.FileOutputStream(f).close(); }
            } catch (Throwable ignored) {}
            openPath(path);
        });
    }

    // ---- Google Диск ----
    private String gdFolder;                 // если открыт Диск, тут его папка
    private final java.util.ArrayList<String[]> gdStack = new java.util.ArrayList<>();   // путь по папкам Диска

    private void openDrive(String folderId, String name) {
        gdFolder = folderId == null ? "root" : folderId;
        gdStack.add(new String[]{ gdFolder, name == null ? "Google Drive" : name });
        loadDrive();
    }

    private void loadDrive() {
        toast("Читаю Диск…");
        final String folder = gdFolder;
        new Thread(() -> {
            final List<YevRowView.Item> items = new ArrayList<>();
            try {
                org.json.JSONArray arr = AppsPlugin.driveList(this, folder);
                if (arr != null) for (int i = 0; i < arr.length(); i++) {
                    org.json.JSONObject o = arr.getJSONObject(i);
                    YevRowView.Item it = new YevRowView.Item();
                    it.name = o.optString("name");
                    it.dir = "directory".equals(o.optString("type"));
                    it.size = o.optLong("size", 0);
                    it.mtime = o.optLong("mtime", 0);
                    it.path = "gd:" + o.optString("id");
                    String[] ic = iconFor(it.name, it.dir);
                    it.iconKey = ic[0];
                    try { it.iconColor = Color.parseColor(ic[1]); } catch (Throwable t2) {}
                    if (ic.length > 2) it.badge = ic[2];
                    items.add(it);
                }
            } catch (Throwable ignored) {}
            runOnUiThread(() -> {
                sortItems(items);
                list.showExternal(items);
                String nm = gdStack.isEmpty() ? "Google Drive" : gdStack.get(gdStack.size() - 1)[1];
                crumb.setText("‹  " + nm);
                rebuildCrumbs();
                rebuildBottom();
                if (items.isEmpty()) toast("Пусто или нет входа в аккаунт");
            });
        }).start();
    }

    private void driveUp() {
        if (gdStack.size() <= 1) { gdFolder = null; gdStack.clear(); openPath(path); return; }
        gdStack.remove(gdStack.size() - 1);
        gdFolder = gdStack.get(gdStack.size() - 1)[0];
        loadDrive();
    }

    // ---- архивы ----
    private String arcPath;                               // открытый архив, если мы внутри
    private String arcPrefix = "";                        // путь внутри архива

    private static boolean isArchive(String name) {
        String n = name.toLowerCase();
        int dot = n.lastIndexOf('.');
        String e = dot >= 0 ? n.substring(dot + 1) : "";
        return in(e, "zip rar 7z tar gz tgz bz2 tbz xz apk jar war iso");
    }

    /** Открыть архив: список записей читаем тем же движком, что и старый вид. */
    private void openArchive(final String p) {
        toast("Открываю архив…");
        new Thread(() -> {
            final List<YevRowView.Item> items = new ArrayList<>();
            try {
                java.util.List<SevenZipEngine.Item> its = SevenZipEngine.list(new File(p), null);
                for (SevenZipEngine.Item e : its) {
                    YevRowView.Item it = new YevRowView.Item();
                    it.name = e.name;
                    it.dir = e.dir;
                    it.size = e.size;
                    it.mtime = 0;
                    String[] ic = iconFor(shortName(e.name), e.dir);
                    it.iconKey = ic[0];
                    try { it.iconColor = Color.parseColor(ic[1]); } catch (Throwable t2) { it.iconColor = 0; }
                    if (ic.length > 2) it.badge = ic[2];
                    items.add(it);
                }
            } catch (Throwable ignored) {}
            runOnUiThread(() -> {
                if (items.isEmpty()) { toast("Не удалось прочитать архив"); return; }
                arcPath = p; arcPrefix = "";
                showArcLevel(items);
            });
        }).start();
    }

    private java.util.List<YevRowView.Item> arcAll = new ArrayList<>();

    private static String shortName(String p) {
        String s2 = p.endsWith("/") ? p.substring(0, p.length() - 1) : p;
        int i = s2.lastIndexOf('/');
        return i >= 0 ? s2.substring(i + 1) : s2;
    }

    /** Показать один уровень архива — так же, как папку. */
    private void showArcLevel(List<YevRowView.Item> all) {
        if (all != null) arcAll = all;
        java.util.LinkedHashMap<String, YevRowView.Item> level = new java.util.LinkedHashMap<>();
        for (YevRowView.Item e : arcAll) {
            String full = e.name;
            if (!full.startsWith(arcPrefix)) continue;
            String rest = full.substring(arcPrefix.length());
            if (rest.isEmpty()) continue;
            int slash = rest.indexOf('/');
            YevRowView.Item it = new YevRowView.Item();
            if (slash >= 0 && slash < rest.length() - 1) {          // это вложенная папка
                String nm = rest.substring(0, slash);
                if (level.containsKey(nm)) continue;
                it.name = nm; it.dir = true; it.size = 0; it.mtime = e.mtime;
                String[] ic = iconFor(nm, true);
                it.iconKey = ic[0];
                try { it.iconColor = Color.parseColor(ic[1]); } catch (Throwable t2) {}
                it.path = "arc:" + arcPrefix + nm + "/";
                level.put(nm, it);
            } else {
                String nm = rest.endsWith("/") ? rest.substring(0, rest.length() - 1) : rest;
                if (nm.contains("/")) continue;
                it.name = nm; it.dir = e.dir; it.size = e.size; it.mtime = e.mtime;
                String[] ic = iconFor(nm, e.dir);
                it.iconKey = ic[0];
                try { it.iconColor = Color.parseColor(ic[1]); } catch (Throwable t2) {}
                if (ic.length > 2) it.badge = ic[2];
                it.path = "arc:" + arcPrefix + nm;
                level.put(nm, it);
            }
        }
        List<YevRowView.Item> out = new ArrayList<>(level.values());
        sortItems(out);
        list.showExternal(out);
        crumb.setText("‹  " + shortName(arcPath) + (arcPrefix.isEmpty() ? "" : " / " + arcPrefix.replaceAll("/$", "")));
        rebuildCrumbs();
        rebuildBottom();
    }

    private void arcUp() {
        if (arcPrefix.isEmpty()) { arcPath = null; arcAll = new ArrayList<>(); openPath(path); return; }
        String p = arcPrefix.substring(0, arcPrefix.length() - 1);
        int i = p.lastIndexOf('/');
        arcPrefix = i >= 0 ? p.substring(0, i + 1) : "";
        showArcLevel(null);
    }

    /** Распаковать выбранное или весь архив рядом с ним. */
    private void extractArchive(final java.util.Set<String> only) {
        final String src = arcPath;
        final File dest = new File(new File(src).getParentFile(), shortName(src).replaceAll("\\.[^.]+$", ""));
        showProgress("Распаковка");
        new Thread(() -> {
            boolean ok = false;
            try {
                dest.mkdirs();
                java.util.Set<String> want = only == null || only.isEmpty() ? null : new java.util.HashSet<>();
                if (want != null) for (String p : only) want.add(p.startsWith("arc:") ? p.substring(4) : p);
                SevenZipEngine.extract(new File(src), dest, want, null, null);
                ok = true;
            } catch (Throwable ignored) {}
            final boolean res = ok;
            runOnUiThread(() -> {
                hideProgress();
                addTask("Распаковка → " + dest.getName() + (res ? "" : " (не вышло)"));
                toast(res ? "Распаковано в " + dest.getName() : "Не получилось");
                arcPath = null; arcAll = new ArrayList<>();
                openPath(path);
            });
        }).start();
    }

    /** Файл с Диска: снимки — родным просмотрщиком потоком, остальное скачиваем. */
    private void driveOpen(final YevRowView.Item it) {
        if (isImage(it.name)) {
            java.util.List<String> ids = new ArrayList<>();
            java.util.List<String> names = new ArrayList<>();
            int at = 0;
            for (YevRowView.Item x : list.items()) {
                if (!x.dir && isImage(x.name) && x.path != null) {
                    if (x.path.equals(it.path)) at = ids.size();
                    ids.add(x.path);
                    names.add(x.name);
                }
            }
            if (!ids.isEmpty()) {
                AppsPlugin.prepareDriveStreamer(this);
                Intent pi = new Intent(this, PhotoActivity.class);
                pi.putExtra(PhotoActivity.EXTRA_LIST, ids.toArray(new String[0]));
                pi.putExtra(PhotoActivity.EXTRA_NAMES, names.toArray(new String[0]));
                pi.putExtra(PhotoActivity.EXTRA_INDEX, at);
                pi.putExtra(PhotoActivity.EXTRA_DEBUG, debug);
                startActivity(pi);
                return;
            }
        }
        showProgress("Загрузка с Диска");
        new Thread(() -> {
            final String local = AppsPlugin.driveDownload(this, it.path.substring(3), it.name);
            runOnUiThread(() -> {
                hideProgress();
                if (local == null) { toast("Не скачалось"); return; }
                YevRowView.Item tmp = new YevRowView.Item();
                tmp.name = it.name; tmp.path = local; tmp.dir = false;
                openWith(tmp);
            });
        }).start();
    }

    /** Список действий в цветах темы — вместо системного окна. */
    private void themedList(String title, final String[] labels, final Runnable[] acts) {
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(0, dp(10), 0, dp(10));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(t.bar);
        bg.setCornerRadius(dp(20));
        col.setBackground(bg);

        if (title != null) {
            TextView h = new TextView(this);
            h.setText(title);
            h.setTextColor(t.sub);
            h.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f);
            h.setPadding(dp(18), dp(4), dp(18), dp(8));
            h.setSingleLine(true);
            h.setEllipsize(android.text.TextUtils.TruncateAt.MIDDLE);
            applyFace(h, false);
            col.addView(h);
        }

        final android.app.AlertDialog dlg = new android.app.AlertDialog.Builder(this).setView(col).create();
        for (int i = 0; i < labels.length; i++) {
            final int idx2 = i;
            TextView tv = new TextView(this);
            tv.setText(labels[i]);
            tv.setTextColor(labels[i].startsWith("Удалить") ? t.red : t.txt);
            tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
            tv.setPadding(dp(18), dp(12), dp(18), dp(12));
            applyFace(tv, false);
            tv.setOnClickListener(v -> { dlg.dismiss(); if (acts[idx2] != null) acts[idx2].run(); });
            col.addView(tv);
        }
        dlg.show();
        try {
            android.view.Window w = dlg.getWindow();
            if (w != null) w.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(0));
        } catch (Throwable ignored) {}
    }

    /** Меню одного объекта: открыть, свойства, поделиться, переименовать, удалить. */
    private void itemMenu(final YevRowView.Item it) {
        final java.util.List<String> labels = new ArrayList<>();
        final java.util.List<Runnable> acts = new ArrayList<>();
        if (!it.dir) {
            labels.add("Открыть"); acts.add(() -> openFile(it));
            labels.add("Открыть с помощью"); acts.add(() -> openWith(it));
            labels.add("Поделиться"); acts.add(() -> shareOne(it));
        }
        labels.add("Свойства"); acts.add(() -> showProps(it));
        labels.add("Переименовать"); acts.add(() -> { sel.clear(); sel.add(it.path); renameOne(); });
        labels.add("Удалить"); acts.add(() -> { sel.clear(); sel.add(it.path); confirmDelete(); });
        themedList(it.name, labels.toArray(new String[0]), acts.toArray(new Runnable[0]));
    }

    /** Системное окно выбора приложения для файла. */
    private void openWith(YevRowView.Item it) {
        try {
            File f = new File(it.path);
            android.net.Uri u = androidx.core.content.FileProvider.getUriForFile(this, getPackageName() + ".appsfp", f);
            String ext = android.webkit.MimeTypeMap.getFileExtensionFromUrl(f.getName().toLowerCase());
            String mime = android.webkit.MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext);
            Intent i = new Intent(Intent.ACTION_VIEW);
            i.setDataAndType(u, mime == null ? "*/*" : mime);
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(Intent.createChooser(i, "Открыть с помощью").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
        } catch (Throwable t2) { toast("Не открылось"); }
    }

    private void shareOne(YevRowView.Item it) {
        try {
            File f = new File(it.path);
            android.net.Uri u = androidx.core.content.FileProvider.getUriForFile(this, getPackageName() + ".appsfp", f);
            Intent i = new Intent(Intent.ACTION_SEND);
            i.setType("*/*");
            i.putExtra(Intent.EXTRA_STREAM, u);
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(Intent.createChooser(i, "Поделиться").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
        } catch (Throwable ignored) {}
    }

    /** Сжать выделенное в zip рядом. */
    private void compressSelection() {
        if (sel.isEmpty()) return;
        final java.util.List<String> what = new ArrayList<>(sel);
        String def = what.size() == 1 ? shortName(what.get(0)) : shortName(path.isEmpty() ? "/storage/emulated/0" : path);
        askName("Имя архива", def + ".zip", "Сжать", nm -> {
                    exitSel();
                    showProgress("Сжатие");
                    new Thread(() -> {
                        boolean ok = false;
                        try {
                            File out = new File(path.isEmpty() ? "/storage/emulated/0" : path, nm);
                            net.lingala.zip4j.ZipFile z = new net.lingala.zip4j.ZipFile(out);
                            net.lingala.zip4j.model.ZipParameters pp = new net.lingala.zip4j.model.ZipParameters();
                            for (String p2 : what) {
                                File f = new File(p2);
                                updateProgress(f.getName(), 0, 1);
                                if (f.isDirectory()) z.addFolder(f, pp); else z.addFile(f, pp);
                            }
                            ok = true;
                        } catch (Throwable ignored) {}
                        final boolean res = ok;
                        runOnUiThread(() -> { hideProgress(); addTask("Сжатие → " + nm); toast(res ? "Готово" : "Не вышло"); openPath(path); });
                    }).start();
        });
    }

    /** Свойства для всего выделенного разом. */
    private void propsSelection() {
        if (sel.isEmpty()) return;
        if (sel.size() == 1) {
            for (YevRowView.Item it : list.items()) if (it.path != null && it.path.equals(sel.iterator().next())) { showProps(it); return; }
        }
        final java.util.List<String> all = new ArrayList<>(sel);
        final TextView body2 = new TextView(this);
        body2.setTextColor(t.txt);
        body2.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        body2.setText("Считаю…");
        applyFace(body2, false);
        LinearLayout box2 = new LinearLayout(this);
        box2.setOrientation(LinearLayout.VERTICAL);
        box2.setPadding(dp(20), dp(16), dp(20), dp(14));
        GradientDrawable b2 = new GradientDrawable();
        b2.setColor(t.bar);
        b2.setCornerRadius(dp(20));
        box2.setBackground(b2);
        TextView h2 = new TextView(this);
        h2.setText("Выбрано: " + all.size());
        h2.setTextColor(t.txt);
        h2.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
        applyFace(h2, true);
        box2.addView(h2);
        box2.addView(body2);
        final android.app.AlertDialog dlg = new android.app.AlertDialog.Builder(this).setView(box2).create();
        dlg.show();
        try {
            android.view.Window w = dlg.getWindow();
            if (w != null) w.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(0));
        } catch (Throwable ignored) {}
        new Thread(() -> {
            long[] acc = new long[]{ 0, 0, 0 };
            for (String p : all) {
                File f = new File(p);
                if (f.isDirectory()) { acc[2]++; walk(f, acc); }
                else { acc[1]++; acc[0] += f.length(); }
            }
            final String text = "Файлов: " + acc[1] + ", папок: " + acc[2] + "\nОбщий вес: " + YevFmt.size(acc[0]);
            runOnUiThread(() -> { try { body2.setText(text); } catch (Throwable ignored) {} });
        }).start();
    }

    /** Свойства: имя, путь, размер, дата, обложка для снимков и что внутри для папок. */
    private void showProps(final YevRowView.Item it) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(20), dp(12), dp(20), dp(8));
        final ImageView pic = new ImageView(this);
        pic.setScaleType(ImageView.ScaleType.CENTER_CROP);
        pic.setVisibility(View.GONE);
        LinearLayout.LayoutParams plp = new LinearLayout.LayoutParams(-1, dp(180));
        plp.bottomMargin = dp(12);
        box.addView(pic, plp);
        final TextView body = new TextView(this);
        body.setTextColor(t.txt);
        body.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        body.setText("Считаю…");
        box.addView(body);

        GradientDrawable pbg = new GradientDrawable();
        pbg.setColor(t.bar);
        pbg.setCornerRadius(dp(20));
        box.setBackground(pbg);
        TextView ph = new TextView(this);
        ph.setText(it.name);
        ph.setTextColor(t.txt);
        ph.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
        ph.setSingleLine(true);
        ph.setEllipsize(android.text.TextUtils.TruncateAt.MIDDLE);
        applyFace(ph, true);
        box.addView(ph, 0);
        applyFace(body, false);

        final android.app.AlertDialog dlg = new android.app.AlertDialog.Builder(this).setView(box).create();
        dlg.show();
        try {
            android.view.Window w = dlg.getWindow();
            if (w != null) w.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(0));
        } catch (Throwable ignored) {}

        if (!it.dir && (isImage(it.name) || isVideo(it.name))) {
            new Thread(() -> {
                Bitmap b = thumbs.get(it.path);
                if (b == null) { try { b = AppsPlugin.thumbBitmap(this, new File(it.path), 720); } catch (Throwable ignored) {} }
                final Bitmap fb = b;
                if (fb != null) runOnUiThread(() -> { pic.setImageBitmap(fb); pic.setVisibility(View.VISIBLE); });
            }).start();
        }
        new Thread(() -> {
            File f = new File(it.path);
            StringBuilder b = new StringBuilder();
            b.append("Путь: ").append(f.getParent()).append("\n");
            if (it.dir) {
                long[] acc = new long[]{ 0, 0, 0 };
                walk(f, acc);
                b.append("Внутри: ").append(acc[1]).append(" файлов, ").append(acc[2]).append(" папок\n");
                b.append("Вес: ").append(YevFmt.size(acc[0])).append("\n");
            } else {
                b.append("Размер: ").append(YevFmt.size(f.length())).append("\n");
                if (isImage(f.getName())) {
                    try {
                        android.graphics.BitmapFactory.Options o = new android.graphics.BitmapFactory.Options();
                        o.inJustDecodeBounds = true;
                        android.graphics.BitmapFactory.decodeFile(f.getAbsolutePath(), o);
                        if (o.outWidth > 0) b.append("Кадр: ").append(o.outWidth).append(" × ").append(o.outHeight).append("\n");
                    } catch (Throwable ignored) {}
                }
            }
            b.append("Изменён: ").append(YevFmt.date(f.lastModified()));
            final String text = b.toString();
            runOnUiThread(() -> { try { body.setText(text); } catch (Throwable ignored) {} });
        }).start();
    }

    private void walk(File dir, long[] acc) {
        File[] kids = dir.listFiles();
        if (kids == null) return;
        for (File k : kids) {
            if (k.isDirectory()) { acc[2]++; walk(k, acc); }
            else { acc[1]++; acc[0] += k.length(); }
        }
    }

    private void toast(String s) { android.widget.Toast.makeText(this, s, android.widget.Toast.LENGTH_SHORT).show(); }

    /** Открытие файла — тем же способом, что и старый вид. */
    private void openFile(YevRowView.Item it) {
        try {
            if (isVideo(it.name)) {                       // видео уходит в твой плеер
                openWith(it);
                return;
            }
            if (it.name.toLowerCase().endsWith(".apk")) {  // установка приложения
                File f = new File(it.path);
                android.net.Uri u = androidx.core.content.FileProvider.getUriForFile(this, getPackageName() + ".appsfp", f);
                Intent ii = new Intent(Intent.ACTION_VIEW);
                ii.setDataAndType(u, "application/vnd.android.package-archive");
                ii.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(ii);
                return;
            }
            if (isAudio(it.name)) {                       // музыка — родным плеером, очередь из папки
                java.util.List<String> q = new ArrayList<>();
                int at = 0;
                for (YevRowView.Item x : list.items()) {
                    if (!x.dir && isAudio(x.name) && x.path != null) {
                        if (x.path.equals(it.path)) at = q.size();
                        q.add(x.path);
                    }
                }
                if (!q.isEmpty()) {
                    Intent ai = new Intent(this, AudioActivity.class);
                    ai.putExtra(AudioActivity.EXTRA_LIST, q.toArray(new String[0]));
                    ai.putExtra(AudioActivity.EXTRA_INDEX, at);
                    ai.putExtra(AudioActivity.EXTRA_THEME, themeName);
                    startActivity(ai);
                    return;
                }
            }
            if (isText(it.name)) {                        // текст — родным окном
                Intent ti = new Intent(this, TextActivity.class);
                ti.putExtra(TextActivity.EXTRA_PATH, it.path);
                ti.putExtra(TextActivity.EXTRA_THEME, themeName);
                startActivity(ti);
                return;
            }
            if (isImage(it.name)) {                       // снимки — родным просмотрщиком
                java.util.List<String> imgs = new ArrayList<>();
                int idx = 0;
                for (YevRowView.Item x : list.items()) {
                    if (!x.dir && isImage(x.name) && x.path != null) {
                        if (x.path.equals(it.path)) idx = imgs.size();
                        imgs.add(x.path);
                    }
                }
                if (!imgs.isEmpty()) {
                    Intent pi = new Intent(this, PhotoActivity.class);
                    pi.putExtra(PhotoActivity.EXTRA_LIST, imgs.toArray(new String[0]));
                    pi.putExtra(PhotoActivity.EXTRA_INDEX, idx);
                    pi.putExtra(PhotoActivity.EXTRA_DEBUG, debug);
                    startActivity(pi);
                    return;
                }
            }
            File f = new File(it.path);
            Intent i = new Intent(Intent.ACTION_VIEW);
            android.net.Uri u = androidx.core.content.FileProvider.getUriForFile(this, getPackageName() + ".appsfp", f);
            String mime = android.webkit.MimeTypeMap.getSingleton().getMimeTypeFromExtension(
                    android.webkit.MimeTypeMap.getFileExtensionFromUrl(f.getName().toLowerCase()));
            i.setDataAndType(u, mime == null ? "*/*" : mime);
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(Intent.createChooser(i, "Открыть").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
        } catch (Throwable ignored) {}
    }

    /** Число объектов в папках — как в вебе, в фоне и по одной. */
    /** Свои иконки папок, заданные в старом виде. */
    private java.util.HashMap<String, String> folderIcons;

    private void loadFolderIcons() {
        folderIcons = new java.util.HashMap<>();
        try {
            String raw = prefs.getString("foldericons", "{}");
            org.json.JSONObject o = new org.json.JSONObject(raw);
            java.util.Iterator<String> it = o.keys();
            while (it.hasNext()) { String k = it.next(); folderIcons.put(k, o.optString(k)); }
        } catch (Throwable ignored) {}
    }

    private void applyFolderIcon(YevRowView.Item it) {
        if (folderIcons == null || folderIcons.isEmpty() || !it.dir || it.path == null) return;
        String data = folderIcons.get(it.path);
        if (data == null) data = folderIcons.get(it.path.replaceFirst("^/storage/emulated/0/?", ""));
        if (data == null || !data.startsWith("data:")) return;
        try {
            int comma = data.indexOf(',');
            byte[] raw = android.util.Base64.decode(data.substring(comma + 1), android.util.Base64.DEFAULT);
            it.thumb = android.graphics.BitmapFactory.decodeByteArray(raw, 0, raw.length);
        } catch (Throwable ignored) {}
    }

    private void fillFolderCounts(final List<YevRowView.Item> items) {
        new Thread(() -> {
            for (final YevRowView.Item it : items) {
                if (it == null || !it.dir || it.path == null) continue;
                applyFolderIcon(it);
                try {
                    String[] kids = new File(it.path).list();
                    if (kids == null) continue;
                    int n = 0;
                    String cover = null;
                    for (String k : kids) {
                        if (!showHidden && k.startsWith(".")) continue;
                        n++;
                        if (cover == null && (isImage(k) || isVideo(k))) cover = it.path + "/" + k;
                    }
                    it.count = n;
                    if (dirSizes) it.bytes = treeSize(new File(it.path));   // вес папки, если включён
                    if (it.thumb == null && cover != null) {           // обложка папки — первый снимок внутри
                        Bitmap b = AppsPlugin.thumbBitmap(FilesActivity.this, new File(cover), Math.round(YevTheme.ICON * d));
                        if (b != null) it.cover = b;
                    }
                } catch (Throwable ignored) {}
            }
            runOnUiThread(() -> list.refreshVisible());
        }).start();
    }

    /** Закрытая системой папка: пробуем прочитать правами Shizuku, как это делает старый вид. */
    private List<YevRowView.Item> readRestricted(String p) {
        try {
            if (!ShizukuBridge.restricted(p) || !ShizukuBridge.granted()) return null;
            String out = ShizukuBridge.shellList(p);
            if (out == null || out.trim().isEmpty()) return null;
            List<YevRowView.Item> res = new ArrayList<>();
            for (String line : out.split("\n")) {
                String[] p4 = line.split("\\|", 4);
                if (p4.length < 4) continue;
                String full = p4[3].trim();
                int sl = full.lastIndexOf('/');
                String nm = sl >= 0 ? full.substring(sl + 1) : full;
                if (nm.isEmpty() || nm.equals(".") || nm.equals("..")) continue;
                if (!showHidden && nm.startsWith(".")) continue;
                YevRowView.Item it = new YevRowView.Item();
                it.name = nm;
                it.dir = p4[0].contains("directory");
                try { it.size = it.dir ? 0 : Long.parseLong(p4[1].trim()); } catch (Throwable t2) {}
                try { it.mtime = Long.parseLong(p4[2].trim()) * 1000L; } catch (Throwable t2) {}
                String[] ic = iconFor(nm, it.dir);
                it.iconKey = ic[0];
                try { it.iconColor = Color.parseColor(ic[1]); } catch (Throwable t2) {}
                if (ic.length > 2) it.badge = ic[2];
                res.add(it);
            }
            sortItems(res);
            return res.isEmpty() ? null : res;
        } catch (Throwable t2) { return null; }
    }

    /** Чтение папки тем же движком, что и в веб-части. */
    private List<YevRowView.Item> readViaCore(String p) {
        List<YevRowView.Item> out = new ArrayList<>();
        try {
            java.util.List<YevCore.Ent> ents = YevCore.readDir(new File(p == null || p.isEmpty() ? "/storage/emulated/0" : p));
            if (ents == null) return null;
            for (YevCore.Ent e : ents) {
                try {
                    if (!showHidden && e.name.startsWith(".")) continue;
                    YevRowView.Item it = new YevRowView.Item();
                    it.name = e.name;
                    it.dir = e.dir;
                    it.size = e.dir ? 0 : e.size;
                    it.mtime = e.mtime;
                    String[] ic = iconFor(it.name, it.dir);
                    it.iconKey = ic[0];
                    try { it.iconColor = Color.parseColor(ic[1]); } catch (Throwable t2) { it.iconColor = 0; }
                    if (ic.length > 2) it.badge = ic[2];
                    out.add(it);
                } catch (Throwable ignored) {}
            }
            sortItems(out);
            return out;
        } catch (Throwable t2) { return null; }
    }

    /** Запасное чтение, если движок не ответил. */
    private List<YevRowView.Item> read(String p) {
        List<YevRowView.Item> out = new ArrayList<>();
        try {
            File dir = new File(p == null || p.isEmpty() ? "/storage/emulated/0" : p);
            File[] kids = dir.listFiles();
            if (kids == null) return out;
            for (File f : kids) {
                try {
                    if (!showHidden && f.getName().startsWith(".")) continue;
                    YevRowView.Item it = new YevRowView.Item();
                    it.name = f.getName();
                    it.dir = f.isDirectory();
                    it.size = it.dir ? 0 : f.length();
                    it.mtime = f.lastModified();
                    String[] ic = iconFor(it.name, it.dir);
                    it.iconKey = ic[0];
                    try { it.iconColor = Color.parseColor(ic[1]); } catch (Throwable t2) { it.iconColor = 0; }
                    if (ic.length > 2) it.badge = ic[2];
                    out.add(it);
                } catch (Throwable ignored) {}
            }
            sortItems(out);
        } catch (Throwable ignored) {}
        return out;
    }

    /** Порядок как в вебе: папки сверху, дальше по имени. */
    void sortItems(List<YevRowView.Item> items) {
        final java.text.Collator coll = java.text.Collator.getInstance(new java.util.Locale("ru"));
        coll.setStrength(java.text.Collator.PRIMARY);
        final int mode = sortMode;
        java.util.Collections.sort(items, new Comparator<YevRowView.Item>() {
            @Override public int compare(YevRowView.Item a, YevRowView.Item b) {
                if (a.dir != b.dir) return a.dir ? -1 : 1;      // папки всегда сверху, как в вебе
                switch (mode) {
                    case 1: return nameCmp(b.name, a.name, coll);
                    case 2: return Long.compare(b.size, a.size);
                    case 3: return Long.compare(a.size, b.size);
                    case 4: return Long.compare(b.mtime, a.mtime);
                    case 5: return Long.compare(a.mtime, b.mtime);
                    default: return nameCmp(a.name, b.name, coll);
                }
            }
        });
    }

    /** Порядок имён как в вебе: сперва латиница, затем кириллица, затем прочее. */
    static int nameCmp(String a, String b, java.text.Collator coll) {
        int ra = scriptRank(a), rb = scriptRank(b);
        if (ra != rb) return ra - rb;
        return coll.compare(a == null ? "" : a, b == null ? "" : b);
    }

    private static int scriptRank(String n) {
        char c = (n == null || n.isEmpty()) ? ' ' : n.charAt(0);
        if (c < 128) return 0;
        if (c >= 0x400 && c <= 0x4FF) return 1;
        return 2;
    }

    static boolean isVideo(String name) {
        String n = name.toLowerCase();
        int dot = n.lastIndexOf('.');
        String e = dot >= 0 ? n.substring(dot + 1) : "";
        return in(e, "mp4 mkv avi mov webm 3gp m4v ts flv wmv mpg mpeg m2ts");
    }

    static boolean isAudio(String name) {
        String n = name.toLowerCase();
        int dot = n.lastIndexOf('.');
        String e = dot >= 0 ? n.substring(dot + 1) : "";
        return in(e, "mp3 flac wav ogg m4a aac opus wma ape");
    }

    static boolean isText(String name) {
        String n = name.toLowerCase();
        int dot = n.lastIndexOf('.');
        String e = dot >= 0 ? n.substring(dot + 1) : "";
        return in(e, "txt md log ini cfg conf json xml yml yaml csv js jsx ts tsx java kt py c cpp h cs php rb go rs sh gradle properties srt lrc");
    }

    static boolean isImage(String name) {
        String n = name.toLowerCase();
        int dot = n.lastIndexOf('.');
        String e = dot >= 0 ? n.substring(dot + 1) : "";
        return in(e, "jpg jpeg png webp gif bmp");
    }

    private static boolean in(String e, String list) {
        for (String s : list.split(" ")) if (s.equals(e)) return true;
        return false;
    }
}
