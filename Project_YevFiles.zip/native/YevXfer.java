package leshugan.fm;

import android.content.Context;
import android.net.Uri;
import android.os.Build;
import android.system.Os;
import android.system.StructStat;

import androidx.documentfile.provider.DocumentFile;

import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.RandomAccessFile;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.zip.CRC32;

/**
 * Движок копирования/перемещения.
 *  - задание = запись на диске (переживает перезапуск, продолжается с места обрыва)
 *  - чтение и запись в двух потоках кусками по 256 КБ, очередь из 3 кусков
 *  - прогресс по байтам: скорость, остаток времени
 *  - перезапись через временный файл рядом и обмен имён — оригинал не портится при обрыве
 *  - дата файла сохраняется; хвост файла сверяется с источником; по желанию — полная контрольная сумма
 *  - вопросы к пользователю (конфликт имени, ошибка) уходят в интерфейс и ждут ответа
 */
public final class YevXfer {

    public interface Emitter { void emit(String event, JSObject data); }

    private static final int CHUNK = 262144;
    private static final long SMALL = 2L * 1024 * 1024;   // «мелкий» файл — до 2 МБ
    private static final int SMALL_THREADS = 4;
    private static final int QUEUE_DEPTH = 3;
    private static final long CHECKPOINT_MS = 2000;
    private static final long TAIL_CHECK = 65536;

    private final Context ctx;
    private final Emitter em;
    private final File jobsDir;
    private final ExecutorService worker = Executors.newSingleThreadExecutor(r -> { Thread t = new Thread(r, "yev-xfer"); t.setDaemon(true); return t; });
    private final ArrayDeque<String> queue = new ArrayDeque<>();
    private volatile Job current;
    private volatile boolean serviceUp = false;
    private long lastNotif = 0, startedAt = 0;

    // вопрос интерфейсу
    private final Object askLock = new Object();
    private volatile JSObject pendingAsk;
    private volatile String answer;
    private volatile boolean answerFiles;    // ответ запомнить для всех файлов
    private volatile boolean answerDirs;     // ответ запомнить для всех папок
    private volatile String answerName;      // своё имя для «сохранить оба»
    private volatile int askCount;           // какой это по счёту вопрос в задании

    public YevXfer(Context ctx, Emitter em) {
        this.ctx = ctx.getApplicationContext();
        this.em = em;
        this.jobsDir = new File(this.ctx.getFilesDir(), "jobs");
        if (!jobsDir.exists()) jobsDir.mkdirs();
    }

    // ============================== модель задания ==============================

    static final class Item { String uri; String name; String type; }

    static final class Job {
        String id; String mode = "copy"; String dest; List<Item> items = new ArrayList<>();
        String fileRule = "ask", dirRule = "ask"; boolean verify = false;
        boolean keepTime = true;        // дата оригинала сохраняется всегда
        boolean keepAttrs = true;       // права доступа и ссылки переносятся всегда
        boolean parallel = true;        // мелкие файлы копируются пачкой
        String state = "queued"; long created = System.currentTimeMillis();
        long bytesDone, bytesTotal; int filesDone, filesTotal, failed, skipped;
        Set<String> doneItems = new LinkedHashSet<>();
        String curSrc, curTmp;
        String error;
        String errRule;          // правило на ошибки после «ко всем»: skip
        boolean resumed = false; // продолжение после перезапуска: одинаковые файлы не копируем заново

        JSONObject toJson() throws Exception {
            JSONObject j = new JSONObject();
            j.put("id", id); j.put("mode", mode); j.put("dest", dest);
            JSONArray a = new JSONArray();
            for (Item it : items) { JSONObject o = new JSONObject(); o.put("uri", it.uri); o.put("name", it.name); o.put("type", it.type); a.put(o); }
            j.put("items", a);
            j.put("fileRule", fileRule); j.put("dirRule", dirRule); j.put("verify", verify);
            j.put("keepTime", keepTime); j.put("keepAttrs", keepAttrs); j.put("parallel", parallel);
            j.put("state", state); j.put("created", created);
            j.put("bytesDone", bytesDone); j.put("bytesTotal", bytesTotal); j.put("filesDone", filesDone); j.put("filesTotal", filesTotal);
            j.put("failed", failed); j.put("skipped", skipped);
            j.put("doneItems", new JSONArray(doneItems));
            if (curSrc != null) j.put("curSrc", curSrc);
            if (curTmp != null) j.put("curTmp", curTmp);
            if (error != null) j.put("error", error);
            if (errRule != null) j.put("errRule", errRule);
            j.put("resumed", resumed);
            return j;
        }

        static Job fromJson(JSONObject j) throws Exception {
            Job b = new Job();
            b.id = j.getString("id"); b.mode = j.optString("mode", "copy"); b.dest = j.optString("dest", null);
            JSONArray a = j.optJSONArray("items");
            if (a != null) for (int i = 0; i < a.length(); i++) { JSONObject o = a.getJSONObject(i); Item it = new Item(); it.uri = o.optString("uri"); it.name = o.optString("name"); it.type = o.optString("type", "file"); b.items.add(it); }
            b.fileRule = j.optString("fileRule", "ask"); b.dirRule = j.optString("dirRule", "ask"); b.verify = j.optBoolean("verify", false);
            b.keepTime = j.optBoolean("keepTime", true); b.keepAttrs = j.optBoolean("keepAttrs", true);
            b.parallel = j.optBoolean("parallel", true);
            b.state = j.optString("state", "queued"); b.created = j.optLong("created", 0);
            b.bytesDone = j.optLong("bytesDone", 0); b.bytesTotal = j.optLong("bytesTotal", 0);
            b.filesDone = j.optInt("filesDone", 0); b.filesTotal = j.optInt("filesTotal", 0);
            b.failed = j.optInt("failed", 0); b.skipped = j.optInt("skipped", 0);
            JSONArray d = j.optJSONArray("doneItems");
            if (d != null) for (int i = 0; i < d.length(); i++) b.doneItems.add(d.getString(i));
            b.curSrc = j.optString("curSrc", null); b.curTmp = j.optString("curTmp", null);
            b.error = j.optString("error", null);
            b.errRule = j.optString("errRule", null);
            b.resumed = j.optBoolean("resumed", false);
            return b;
        }

        JSObject summary() {
            JSObject o = new JSObject();
            o.put("id", id); o.put("mode", mode); o.put("dest", dest); o.put("state", state); o.put("created", created);
            o.put("items", items.size()); o.put("bytesDone", bytesDone); o.put("bytesTotal", bytesTotal);
            o.put("filesDone", filesDone); o.put("filesTotal", filesTotal); o.put("failed", failed); o.put("skipped", skipped);
            JSArray names = new JSArray(); int n = 0; for (Item it : items) { if (n++ >= 6) break; names.put(it.name); }
            o.put("names", names);
            // откуда и куда — интерфейс показывает это в разделе «Ещё»
            o.put("destPath", plainPath(dest));
            if (!items.isEmpty()) {
                String p0 = plainPath(items.get(0).uri);
                int sl = p0.lastIndexOf('/');
                o.put("srcPath", sl > 0 ? p0.substring(0, sl) : p0);
            }
            if (error != null) o.put("error", error);
            return o;
        }
    }

    /** file:// или content:// -> читаемый путь. */
    static String plainPath(String u) {
        if (u == null) return "";
        String p = u.startsWith("file://") ? u.substring(7) : u;
        if (p.indexOf('%') >= 0) { try { p = java.net.URLDecoder.decode(p, "UTF-8"); } catch (Throwable ignored) {} }
        return p;
    }

    private File jobFile(String id) { return new File(jobsDir, id + ".json"); }

    private void save(Job j) {
        try {
            File f = jobFile(j.id), t = new File(jobsDir, j.id + ".tmp");
            FileOutputStream o = new FileOutputStream(t);
            o.write(j.toJson().toString().getBytes("UTF-8")); o.close();
            t.renameTo(f);
        } catch (Throwable ignored) {}
    }

    private Job load(File f) {
        try {
            byte[] b = new byte[(int) f.length()];
            FileInputStream in = new FileInputStream(f); int off = 0, r;
            while (off < b.length && (r = in.read(b, off, b.length - off)) > 0) off += r;
            in.close();
            return Job.fromJson(new JSONObject(new String(b, 0, off, "UTF-8")));
        } catch (Throwable t) { return null; }
    }

    /** Незавершённые задания на диске (для вопроса «продолжить?»). */
    public JSArray listUnfinished() {
        JSArray arr = new JSArray();
        File[] fs = jobsDir.listFiles();
        if (fs == null) return arr;
        Arrays.sort(fs);
        for (File f : fs) {
            if (!f.getName().endsWith(".json")) continue;
            Job j = load(f);
            if (j == null) { f.delete(); continue; }
            if (current != null && j.id.equals(current.id)) continue;
            if (queue.contains(j.id)) continue;
            arr.put(j.summary());
        }
        return arr;
    }

    public void forget(String id) {
        Job j = load(jobFile(id));
        if (j != null && j.curTmp != null) { try { new File(j.curTmp).delete(); } catch (Throwable ignored) {} }
        jobFile(id).delete();
    }

    // ============================== запуск / очередь ==============================

    public String enqueue(Job j) {
        if (j.id == null) j.id = Long.toString(System.currentTimeMillis(), 36) + Integer.toString((int) (Math.random() * 1679616), 36);
        j.state = "queued";
        save(j);
        synchronized (queue) { queue.add(j.id); }
        emitQueued(j);
        worker.execute(() -> runJob(j.id));
        return j.id;
    }

    public boolean resume(String id) {
        Job j = load(jobFile(id));
        if (j == null) return false;
        j.state = "queued"; j.error = null; j.resumed = true;
        save(j);
        synchronized (queue) { queue.add(j.id); }
        emitQueued(j);
        worker.execute(() -> runJob(j.id));
        return true;
    }

    private void emitQueued(Job j) {
        JSObject ev = j.summary(); ev.put("queued", queueSize());
        em.emit("xfer", ev);
    }

    private int queueSize() { synchronized (queue) { return queue.size(); } }

    private volatile boolean cancelFlag = false;
    private volatile boolean pauseFlag = false;
    private final Object pauseLock = new Object();

    public void cancel(String id) {
        Job c = current;
        if (c != null && (id == null || id.equals(c.id))) { cancelFlag = true; unpauseInternal(); synchronized (askLock) { answer = "cancel"; askLock.notifyAll(); } return; }
        if (id != null) { synchronized (queue) { queue.remove(id); } jobFile(id).delete(); JSObject ev = new JSObject(); ev.put("id", id); ev.put("state", "cancelled"); ev.put("queued", queueSize()); em.emit("xfer", ev); }
    }

    public void pause(boolean on) {
        pauseFlag = on;
        if (!on) unpauseInternal();
        Job c = current;
        if (c != null) { JSObject ev = progressJson(c); ev.put("state", on ? "paused" : "run"); em.emit("xfer", ev); notify(c, true); }
    }

    private void unpauseInternal() { pauseFlag = false; synchronized (pauseLock) { pauseLock.notifyAll(); } }

    private void waitIfPaused() throws Cancelled {
        while (pauseFlag && !cancelFlag) { synchronized (pauseLock) { try { pauseLock.wait(300); } catch (InterruptedException ignored) {} } }
        if (cancelFlag) throw new Cancelled();
    }

    /** Все задания: текущее и стоящие в очереди — для окна со списком задач. */
    public JSArray jobsActive() {
        JSArray arr = new JSArray();
        Job c = current;
        if (c != null) { JSObject o = progressJson(c); o.put("active", true); arr.put(o); }
        List<String> ids;
        synchronized (queue) { ids = new ArrayList<>(queue); }
        for (String id : ids) {
            Job j = load(jobFile(id));
            if (j == null) continue;
            JSObject o = j.summary(); o.put("active", false); arr.put(o);
        }
        return arr;
    }

    public JSObject state() {
        Job c = current;
        JSObject o = new JSObject();
        o.put("queued", queueSize());
        if (c != null) { o.put("job", progressJson(c)); JSObject ask = pendingAsk; if (ask != null) o.put("ask", ask); }
        return o;
    }

    public void resolve(String action, boolean all) { resolve(action, all, all, null); }

    public void resolve(String action, boolean allFiles, boolean allDirs, String newName) {
        synchronized (askLock) { answer = action; answerFiles = allFiles; answerDirs = allDirs; answerName = newName; askLock.notifyAll(); }
    }

    // ============================== узлы источника ==============================

    abstract static class Src {
        String name; boolean dir; long size; long mtime;
        String link;        // если это ссылка — куда она указывает
        int mode = -1;      // права доступа у источника
        abstract List<Src> children();
        abstract InputStream open(long offset) throws IOException;
        abstract boolean delete();
        abstract String key();
        File file() { return null; }
    }

    final class FSrc extends Src {
        final File f;
        FSrc(File f, YevCore.Ent e) {
            this.f = f; name = f.getName();
            if (e != null) { dir = e.dir; size = e.size; mtime = e.mtime; } else { dir = f.isDirectory(); size = dir ? 0 : f.length(); mtime = f.lastModified(); }
            try {
                android.system.StructStat st = Os.lstat(f.getAbsolutePath());
                mode = st.st_mode & 07777;
                if (android.system.OsConstants.S_ISLNK(st.st_mode)) { try { link = Os.readlink(f.getAbsolutePath()); } catch (Throwable ignored) {} }
            } catch (Throwable ignored) {}
        }
        @Override File file() { return f; }
        @Override String key() { return f.getAbsolutePath(); }
        @Override List<Src> children() {
            List<Src> out = new ArrayList<>();
            List<YevCore.Ent> ents = YevCore.readDir(f);
            if (ents == null) {
                DocumentFile d = docFor(f.getAbsolutePath(), false);
                if (d != null) { for (DocumentFile k : d.listFiles()) out.add(new DSrc(k)); }
                return out;
            }
            for (YevCore.Ent e : ents) out.add(new FSrc(new File(f, e.name), e));
            return out;
        }
        @Override InputStream open(long offset) throws IOException {
            FileInputStream in = new FileInputStream(f);
            if (offset > 0) { long s = 0; while (s < offset) { long k = in.skip(offset - s); if (k <= 0) break; s += k; } }
            return in;
        }
        @Override boolean delete() { if (f.delete()) return true; DocumentFile d = docFor(f.getAbsolutePath(), false); return d != null && d.delete(); }
    }

    final class DSrc extends Src {
        final DocumentFile d;
        DSrc(DocumentFile d) { this.d = d; name = d.getName() == null ? "file" : d.getName(); dir = d.isDirectory(); size = dir ? 0 : d.length(); mtime = d.lastModified(); }
        @Override String key() { return d.getUri().toString(); }
        @Override List<Src> children() { List<Src> out = new ArrayList<>(); for (DocumentFile k : d.listFiles()) out.add(new DSrc(k)); return out; }
        @Override InputStream open(long offset) throws IOException {
            InputStream in = ctx.getContentResolver().openInputStream(d.getUri());
            if (in == null) throw new IOException("Не удалось открыть " + name);
            if (offset > 0) { long s = 0; while (s < offset) { long k = in.skip(offset - s); if (k <= 0) break; s += k; } }
            return in;
        }
        @Override boolean delete() { return d.delete(); }
    }

    /** Источник в закрытой папке: читаем через службу Shizuku. */
    final class ZSrc extends Src {
        final String path;
        ZSrc(String path, boolean dir, long size, long mtime) { this.path = path; this.dir = dir; this.size = size; this.mtime = mtime; int sl = path.lastIndexOf('/'); name = sl >= 0 ? path.substring(sl + 1) : path; }
        @Override String key() { return "shizuku:" + path; }
        @Override List<Src> children() {
            List<Src> out = new ArrayList<>();
            try {
                String js = ShizukuBridge.get().list(path);
                org.json.JSONArray a = new org.json.JSONArray(js);
                for (int i = 0; i < a.length(); i++) {
                    org.json.JSONObject o = a.getJSONObject(i);
                    out.add(new ZSrc(o.optString("uri"), "directory".equals(o.optString("type")), o.optLong("size"), o.optLong("mtime")));
                }
            } catch (Throwable ignored) {}
            return out;
        }
        @Override InputStream open(long offset) throws IOException {
            try {
                android.os.ParcelFileDescriptor pfd = ShizukuBridge.get().open(path, "r");
                if (pfd == null) throw new IOException("Нет доступа к " + name);
                InputStream in = new android.os.ParcelFileDescriptor.AutoCloseInputStream(pfd);
                if (offset > 0) { long sk = 0; while (sk < offset) { long k = in.skip(offset - sk); if (k <= 0) break; sk += k; } }
                return in;
            } catch (IOException e) { throw e; } catch (Throwable t) { throw new IOException(String.valueOf(t.getMessage())); }
        }
        @Override boolean delete() { try { return ShizukuBridge.get().delete(path); } catch (Throwable t) { return false; } }
    }

    /** Приёмник в закрытой папке: пишем через службу Shizuku. */
    final class ZDst extends Dst {
        final String dir;
        ZDst(String dir) { this.dir = dir.endsWith("/") ? dir.substring(0, dir.length() - 1) : dir; }
        private org.json.JSONObject find(String name) {
            try {
                org.json.JSONArray a = new org.json.JSONArray(ShizukuBridge.get().list(dir));
                for (int i = 0; i < a.length(); i++) { org.json.JSONObject o = a.getJSONObject(i); if (name.equals(o.optString("name"))) return o; }
            } catch (Throwable ignored) {}
            return null;
        }
        @Override String path() { return dir; }
        @Override boolean exists(String name) { return find(name) != null; }
        @Override boolean isDir(String name) { org.json.JSONObject o = find(name); return o != null && "directory".equals(o.optString("type")); }
        @Override long size(String name) { org.json.JSONObject o = find(name); return o == null ? 0 : o.optLong("size"); }
        @Override long mtime(String name) { org.json.JSONObject o = find(name); return o == null ? 0 : o.optLong("mtime"); }
        @Override Dst childDir(String name, boolean create) throws IOException {
            String p = dir + "/" + name;
            if (!isDir(name)) {
                if (!create) return null;
                try { if (!ShizukuBridge.get().mkdirs(p)) throw new IOException("Не удалось создать папку " + name); }
                catch (IOException e) { throw e; } catch (Throwable t) { throw new IOException("Не удалось создать папку " + name); }
            }
            return new ZDst(p);
        }
        @Override OutputStream openWrite(String name, boolean append) throws IOException {
            try {
                android.os.ParcelFileDescriptor pfd = ShizukuBridge.get().open(dir + "/" + name, "w");
                if (pfd == null) throw new IOException("Нет доступа для записи: " + name);
                return new android.os.ParcelFileDescriptor.AutoCloseOutputStream(pfd);
            } catch (IOException e) { throw e; } catch (Throwable t) { throw new IOException(String.valueOf(t.getMessage())); }
        }
        @Override boolean delete(String name) { try { return ShizukuBridge.get().delete(dir + "/" + name); } catch (Throwable t) { return false; } }
        @Override boolean rename(String from, String to) { try { return ShizukuBridge.get().rename(dir + "/" + from, dir + "/" + to); } catch (Throwable t) { return false; } }
        @Override Set<String> names() {
            Set<String> out = new HashSet<>();
            try { org.json.JSONArray a = new org.json.JSONArray(ShizukuBridge.get().list(dir)); for (int i = 0; i < a.length(); i++) out.add(a.getJSONObject(i).optString("name")); } catch (Throwable ignored) {}
            return out;
        }
    }

    private boolean zReady(String path) {
        try { return ShizukuBridge.restricted(path) && ShizukuBridge.ready(); } catch (Throwable t) { return false; }
    }

    private Src srcFor(Item it) {
        String u = it.uri == null ? "" : it.uri;
        if (u.startsWith("content://")) {
            DocumentFile d = "directory".equals(it.type) ? DocumentFile.fromTreeUri(ctx, Uri.parse(u)) : DocumentFile.fromSingleUri(ctx, Uri.parse(u));
            if (d == null || !d.exists()) return null;
            DSrc s = new DSrc(d); if (it.name != null && !it.name.isEmpty()) s.name = it.name; return s;
        }
        String p = u.startsWith("file://") ? u.substring(7) : u;
        if (p.indexOf('%') >= 0) { try { p = java.net.URLDecoder.decode(p, "UTF-8"); } catch (Throwable ignored) {} }
        File f = new File(p);
        if (!f.exists() || (f.isDirectory() && f.list() == null)) {
            if (zReady(p)) {
                boolean dir = "directory".equals(it.type);
                long size = 0, mt = 0;
                try {
                    String parent = p.substring(0, Math.max(0, p.lastIndexOf('/')));
                    org.json.JSONArray a = new org.json.JSONArray(ShizukuBridge.get().list(parent));
                    String nm = p.substring(p.lastIndexOf('/') + 1);
                    for (int i = 0; i < a.length(); i++) {
                        org.json.JSONObject o = a.getJSONObject(i);
                        if (nm.equals(o.optString("name"))) { dir = "directory".equals(o.optString("type")); size = o.optLong("size"); mt = o.optLong("mtime"); break; }
                    }
                } catch (Throwable ignored) {}
                return new ZSrc(p, dir, size, mt);
            }
            DocumentFile d = docFor(p, false);
            if (d == null) return null;
            DSrc s = new DSrc(d); return s;
        }
        return new FSrc(f, null);
    }

    // ============================== приёмник ==============================

    abstract static class Dst {
        abstract String path();
        abstract boolean exists(String name);
        abstract boolean isDir(String name);
        abstract long size(String name);
        abstract long mtime(String name);
        abstract Dst childDir(String name, boolean create) throws IOException;
        abstract OutputStream openWrite(String name, boolean append) throws IOException;
        abstract boolean delete(String name);
        abstract boolean rename(String from, String to);
        File file(String name) { return null; }
        abstract Set<String> names();
    }

    final class FDst extends Dst {
        final File dir;
        FDst(File dir) { this.dir = dir; }
        @Override String path() { return dir.getAbsolutePath(); }
        @Override boolean exists(String name) { return new File(dir, name).exists(); }
        @Override boolean isDir(String name) { return new File(dir, name).isDirectory(); }
        @Override long size(String name) { return new File(dir, name).length(); }
        @Override long mtime(String name) { return new File(dir, name).lastModified(); }
        @Override File file(String name) { return new File(dir, name); }
        @Override Dst childDir(String name, boolean create) throws IOException {
            File d = new File(dir, name);
            if (!d.isDirectory()) { if (!create) return null; if (!d.mkdirs() && !d.isDirectory()) throw new IOException("Не удалось создать папку " + name); }
            return new FDst(d);
        }
        @Override OutputStream openWrite(String name, boolean append) throws IOException { return new FileOutputStream(new File(dir, name), append); }
        @Override boolean delete(String name) { return deleteTree(new File(dir, name)); }
        @Override boolean rename(String from, String to) {
            File a = new File(dir, from), b = new File(dir, to);
            try { Os.rename(a.getAbsolutePath(), b.getAbsolutePath()); return true; } catch (Throwable t) { return a.renameTo(b); }
        }
        @Override Set<String> names() { String[] l = dir.list(); return l == null ? new HashSet<String>() : new HashSet<>(Arrays.asList(l)); }
    }

    final class DDst extends Dst {
        final DocumentFile dir; final String p;
        DDst(DocumentFile dir, String p) { this.dir = dir; this.p = p; }
        private DocumentFile find(String name) { return dir.findFile(name); }
        @Override String path() { return p; }
        @Override boolean exists(String name) { return find(name) != null; }
        @Override boolean isDir(String name) { DocumentFile d = find(name); return d != null && d.isDirectory(); }
        @Override long size(String name) { DocumentFile d = find(name); return d == null ? 0 : d.length(); }
        @Override long mtime(String name) { DocumentFile d = find(name); return d == null ? 0 : d.lastModified(); }
        @Override Dst childDir(String name, boolean create) throws IOException {
            DocumentFile d = find(name);
            if (d == null || !d.isDirectory()) { if (!create) return null; d = dir.createDirectory(name); if (d == null) throw new IOException("Не удалось создать папку " + name); }
            return new DDst(d, p + "/" + name);
        }
        @Override OutputStream openWrite(String name, boolean append) throws IOException {
            DocumentFile ex = find(name);
            if (ex == null) {
                String mime = mimeOf(name);
                ex = dir.createFile(mime, name);
                if (ex == null) throw new IOException("Не удалось создать файл " + name);
                // некоторые провайдеры добавляют расширение по типу — приводим имя к нужному
                if (!name.equals(ex.getName())) { try { ex.renameTo(name); } catch (Throwable ignored) {} }
            }
            OutputStream out = ctx.getContentResolver().openOutputStream(ex.getUri(), append ? "wa" : "w");
            if (out == null) throw new IOException("Не удалось записать " + name);
            return out;
        }
        @Override boolean delete(String name) { DocumentFile d = find(name); return d != null && d.delete(); }
        @Override boolean rename(String from, String to) { DocumentFile d = find(from); return d != null && d.renameTo(to); }
        @Override Set<String> names() { Set<String> s = new HashSet<>(); for (DocumentFile d : dir.listFiles()) { String n = d.getName(); if (n != null) s.add(n); } return s; }
    }

    private static String mimeOf(String name) {
        String ext = android.webkit.MimeTypeMap.getFileExtensionFromUrl(name.replace(" ", "_"));
        if (ext == null || ext.isEmpty()) { int d = name.lastIndexOf('.'); if (d >= 0) ext = name.substring(d + 1); }
        String m = (ext == null || ext.isEmpty()) ? null : android.webkit.MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext.toLowerCase());
        return m != null ? m : "application/octet-stream";
    }

    /** DocumentFile для пути на съёмном томе (по выданному системному доступу). */
    private DocumentFile docFor(String absPath, boolean create) {
        try {
            String p = absPath.startsWith("file://") ? absPath.substring(7) : absPath;
            java.util.regex.Matcher m = java.util.regex.Pattern.compile("/storage/([^/]+)").matcher(p);
            if (!m.find()) return null;
            String id = m.group(1);
            String tree = ctx.getSharedPreferences("yf_saf", Context.MODE_PRIVATE).getString(id, null);
            if (tree == null) return null;
            DocumentFile cur = DocumentFile.fromTreeUri(ctx, Uri.parse(tree));
            if (cur == null) return null;
            int idx = p.indexOf("/storage/" + id);
            String rel = idx >= 0 ? p.substring(idx + ("/storage/" + id).length()) : "";
            for (String seg : rel.split("/")) {
                if (seg.isEmpty()) continue;
                DocumentFile next = cur.findFile(seg);
                if (next == null) { if (!create) return null; next = cur.createDirectory(seg); if (next == null) return null; }
                cur = next;
            }
            return cur;
        } catch (Throwable t) { return null; }
    }

    private Dst dstFor(String dest) throws IOException {
        String p = dest.startsWith("file://") ? dest.substring(7) : dest;
        if (p.indexOf('%') >= 0) { try { p = java.net.URLDecoder.decode(p, "UTF-8"); } catch (Throwable ignored) {} }
        File f = new File(p);
        // закрытая системой папка (Android/data, Android/obb) — пишем через Shizuku
        if (zReady(p) && (!f.isDirectory() || f.list() == null || !f.canWrite())) {
            try { ShizukuBridge.get().mkdirs(p); } catch (Throwable ignored) {}
            return new ZDst(p);
        }
        boolean saf = Build.VERSION.SDK_INT >= 30 && p.startsWith("/storage/") && !p.startsWith("/storage/emulated") && !p.startsWith("/storage/self");
        if (saf) {
            DocumentFile d = docFor(p, true);
            if (d == null) throw new IOException("Нет доступа к носителю");
            return new DDst(d, p);
        }
        if (!f.isDirectory() && !f.mkdirs()) {
            DocumentFile d = docFor(p, true);
            if (d != null) return new DDst(d, p);
            throw new IOException("Папка-приёмник недоступна");
        }
        // проверка записи: на Android 11+ прямой доступ к флешке бывает только на чтение
        if (!f.canWrite()) { DocumentFile d = docFor(p, true); if (d != null) return new DDst(d, p); }
        return new FDst(f);
    }

    static boolean deleteTree(File f) {
        try {
            if (f.isDirectory() && !isLink(f)) { File[] k = f.listFiles(); if (k != null) for (File x : k) deleteTree(x); }
        } catch (Throwable ignored) {}
        return f.delete();
    }

    static boolean isLink(File f) {
        try { return android.system.OsConstants.S_ISLNK(Os.lstat(f.getAbsolutePath()).st_mode); } catch (Throwable t) { return false; }
    }

    // ============================== выполнение ==============================

    static final class Cancelled extends Exception { }
    static final class Skipped extends Exception { }

    private void runJob(String id) {
        Job j = load(jobFile(id));
        synchronized (queue) { queue.remove(id); }
        if (j == null) return;
        current = j; cancelFlag = false; pauseFlag = false; answer = null; pendingAsk = null;
        startedAt = System.currentTimeMillis(); serviceUp = false; lastNotif = 0;
        touched.clear(); samples.clear();
        j.state = "scan"; j.error = null;
        em.emit("xfer", progressJson(j));
        boolean done = false;
        if (core != null) core.batchBegin();
        try {
            if ("delete".equals(j.mode)) { runDelete(j); done = true; }
            else {
            Dst dst = dstFor(j.dest);
            // подобрать хвосты прошлого обрыва в папке-приёмнике
            restoreLeftovers(dst);
            // просчёт объёма
            scan(j);
            // хватит ли места на приёмнике
            checkSpace(j, dst);
            j.state = "run"; save(j);
            em.emit("xfer", progressJson(j));
            for (Item it : new ArrayList<>(j.items)) {
                if (cancelFlag) throw new Cancelled();
                if (j.doneItems.contains(it.uri)) continue;
                Src s = srcFor(it);
                if (s == null) { j.failed++; continue; }
                boolean moveOk = false;
                try {
                    transfer(j, s, dst, true);
                    moveOk = true;
                } catch (Skipped sk) { j.skipped++; countSkipped(j, s); moveOk = true; }
                if (moveOk) { j.doneItems.add(it.uri); save(j); }
            }
            done = true;
            }
        } catch (Cancelled c) {
            j.state = "cancelled";
        } catch (Throwable t) {
            j.state = "error"; j.error = t.getMessage() == null ? t.toString() : t.getMessage();
        } finally { if (core != null) core.batchEnd(); }
        if (done) j.state = "done";
        // при отмене/ошибке недописанный файл не трогаем: по нему можно продолжить («Дописать»)
        if ("cancelled".equals(j.state) && j.curTmp != null) {
            File t = new File(j.curTmp);
            String nm = t.getName().startsWith(".yev_tmp_") ? t.getName().substring(9) : null;
            if (nm != null && t.exists()) { File back = new File(t.getParentFile(), nm); if (!back.exists()) t.renameTo(back); }
            j.curTmp = null;
        }
        if ("done".equals(j.state) || "cancelled".equals(j.state)) jobFile(j.id).delete(); else save(j);
        mediaScan();
        if (serviceUp) { try { OpService.stop(ctx); } catch (Throwable ignored) {} serviceUp = false; }
        JSObject ev = progressJson(j); ev.put("queued", queueSize());
        current = null; pendingAsk = null;
        em.emit("xfer", ev);
    }

    /** Свободно ли на приёмнике столько, сколько нужно. Не хватает — спрашиваем, продолжать ли. */
    private void checkSpace(Job j, Dst dst) throws Exception {
        if ("move".equals(j.mode)) {
            // перемещение по тому же тому места не занимает
            try {
                File d = dst.file("x");
                if (d != null && !j.items.isEmpty()) {
                    File s0 = new File(plainPath(j.items.get(0).uri));
                    if (s0.exists() && sameVolume(s0, d.getParentFile())) return;
                }
            } catch (Throwable ignored) {}
        }
        long need = j.bytesTotal - j.bytesDone;
        if (need <= 0) return;
        long free = freeSpace(dst);
        if (free < 0 || free >= need + 8L * 1024 * 1024) return;
        JSObject p = new JSObject();
        p.put("id", j.id); p.put("kind", "space"); p.put("need", need); p.put("free", free);
        p.put("name", dst.path());
        String a;
        synchronized (askLock) {
            answer = null; answerFiles = false; answerDirs = false; pendingAsk = p;
            j.state = "ask"; em.emit("xfer", progressJson(j));
            em.emit("xferAsk", p);
            while (answer == null && !cancelFlag) askLock.wait(500);
            a = answer; pendingAsk = null; answer = null;
        }
        if (cancelFlag || a == null || !a.equals("continue")) throw new Cancelled();
        j.state = "run"; em.emit("xfer", progressJson(j));
    }

    private long freeSpace(Dst dst) {
        try {
            String p = dst.path();
            File f = new File(p);
            while (f != null && !f.exists()) f = f.getParentFile();
            if (f == null) return -1;
            android.os.StatFs st = new android.os.StatFs(f.getAbsolutePath());
            return st.getAvailableBytes();
        } catch (Throwable t) { return -1; }
    }

    /**
     * Хвосты прошлого обрыва: «.yev_bak_имя» — это оригинал, уведённый в сторону перед заменой.
     * Если самого файла нет, возвращаем его на место; если есть — просто убираем хвост.
     * Недописанные «.yev_tmp_имя» старше трёх суток удаляем, свежие оставляем для докачки.
     */
    private void restoreLeftovers(Dst dst) {
        try {
            File d = new File(dst.path());
            if (!d.isDirectory()) return;
            String[] kids = d.list();
            if (kids == null) return;
            long now = System.currentTimeMillis();
            for (String k : kids) {
                if (k.startsWith(".yev_bak_")) {
                    String real = k.substring(9);
                    File bak = new File(d, k), rf = new File(d, real);
                    if (!rf.exists()) bak.renameTo(rf); else bak.delete();
                } else if (k.startsWith(".yev_tmp_")) {
                    File t = new File(d, k);
                    if (now - t.lastModified() > 3L * 24 * 3600 * 1000) t.delete();
                }
            }
        } catch (Throwable ignored) {}
    }

    // ============================== удаление ==============================

    /** Удаление как обычное задание: очередь, пауза, отмена, уведомление, счётчики. */
    private void runDelete(Job j) throws Exception {
        // просчёт: сколько объектов и байт
        long bytes = 0; int files = 0;
        for (Item it : j.items) {
            if (cancelFlag) throw new Cancelled();
            if (j.doneItems.contains(it.uri)) continue;
            Src s = srcFor(it);
            if (s == null) continue;
            long[] acc = new long[2]; count(s, acc);
            bytes += acc[0]; files += acc[1];
        }
        j.bytesTotal = bytes; j.filesTotal = files;
        j.state = "run"; save(j);
        em.emit("xfer", progressJson(j));
        for (Item it : new ArrayList<>(j.items)) {
            if (cancelFlag) throw new Cancelled();
            waitIfPaused();
            if (j.doneItems.contains(it.uri)) continue;
            Src s = srcFor(it);
            if (s == null) { j.failed++; continue; }
            boolean ok;
            try {
                ok = deleteRec(j, s);
            } catch (Cancelled c) { throw c;
            } catch (Exception e) {
                String act = j.errRule != null ? j.errRule : ask(j, "error", s.name, s.dir, s, null, e.getMessage() == null ? e.toString() : e.getMessage());
                if (act.equals("retry")) { continue; }
                if (act.equals("skip")) { j.failed++; j.doneItems.add(it.uri); save(j); continue; }
                throw new Cancelled();
            }
            if (!ok) j.failed++;
            j.doneItems.add(it.uri);
            long nowS = System.currentTimeMillis();
            if (nowS - lastSave >= 1000) { lastSave = nowS; save(j); }
        }
        save(j);
    }
    private long lastSave = 0;

    /** Рекурсивное удаление с прогрессом. */
    private boolean deleteRec(Job j, Src s) throws Exception {
        if (cancelFlag) throw new Cancelled();
        waitIfPaused();
        if (s.dir) {
            boolean all = true;
            for (Src k : s.children()) all &= deleteRec(j, k);
            boolean ok = s.delete();
            progress(j, s.name, false);
            return ok && all;
        }
        long sz = s.size;
        boolean ok = s.delete();
        if (ok && core != null && s instanceof FSrc) core.addBytes(((FSrc) s).f.getAbsolutePath(), -sz, -1);
        j.filesDone++; j.bytesDone += s.size;
        if (ok) touched.add(s instanceof FSrc ? ((FSrc) s).f.getAbsolutePath() : s.name);
        progress(j, s.name, false);
        return ok;
    }

    private void scan(Job j) throws Cancelled {
        long bytes = 0; int files = 0;
        for (Item it : j.items) {
            if (cancelFlag) throw new Cancelled();
            if (j.doneItems.contains(it.uri)) continue;
            Src s = srcFor(it);
            if (s == null) continue;
            long[] acc = new long[2];
            count(s, acc);
            bytes += acc[0]; files += acc[1];
        }
        j.bytesTotal = bytes + j.bytesDone; j.filesTotal = files + j.filesDone;
    }

    /** Пропущенное всё равно засчитываем в сделанное — иначе полоса и «осталось» врут. */
    private void countSkipped(Job j, Src s) {
        try {
            long[] acc = new long[2];
            count(s, acc);
            j.bytesDone += acc[0]; j.filesDone += (int) acc[1];
            progress(j, s.name, true);
        } catch (Throwable ignored) {}
    }

    private void count(Src s, long[] acc) throws Cancelled {
        if (cancelFlag) throw new Cancelled();
        if (!s.dir) { acc[0] += s.size; acc[1]++; return; }
        File f = s.file();
        if (f != null && Build.VERSION.SDK_INT >= 26) {
            try {
                java.nio.file.Files.walkFileTree(f.toPath(), new java.nio.file.SimpleFileVisitor<java.nio.file.Path>() {
                    @Override public java.nio.file.FileVisitResult visitFile(java.nio.file.Path p, java.nio.file.attribute.BasicFileAttributes a) { if (!a.isDirectory()) { acc[0] += a.size(); acc[1]++; } return cancelFlag ? java.nio.file.FileVisitResult.TERMINATE : java.nio.file.FileVisitResult.CONTINUE; }
                    @Override public java.nio.file.FileVisitResult visitFileFailed(java.nio.file.Path p, IOException e) { return java.nio.file.FileVisitResult.CONTINUE; }
                });
                if (acc[1] > 0 || f.list() != null) return;
            } catch (Throwable ignored) {}
        }
        for (Src c : s.children()) count(c, acc);
    }

    /** Один элемент (файл или папка) в папку-приёмник. */
    private void transfer(Job j, Src s, Dst dst, boolean top) throws Exception {
        waitIfPaused();
        String name = s.name;
        if (s.dir) {
            // защита: папку в саму себя
            File sf = s.file();
            if (sf != null && dst.path().equals(sf.getAbsolutePath())) throw new Skipped();
            if (sf != null && (dst.path() + "/").startsWith(sf.getAbsolutePath() + "/")) throw new IOException("Нельзя переместить папку в саму себя: " + name);
            String rule = j.dirRule;
            if (dst.exists(name)) {
                if (!dst.isDir(name)) {
                    // на месте папки лежит файл — спрашиваем как про файл
                    String a = decideFile(j, name, s, dst);
                    if (a.equals("skip")) throw new Skipped();
                    if (a.equals("keepBoth")) name = freeName(dst, name);
                    else dst.delete(name);
                } else {
                    String a = rule.equals("ask") ? ask(j, "conflict", name, true, s, dst) : rule;
                    if (a.equals("skip")) throw new Skipped();
                    if (a.equals("keepBoth")) {
                        String want = lastAskName; lastAskName = null;
                        name = (want != null && !want.trim().isEmpty() && !dst.exists(want.trim())) ? want.trim() : freeName(dst, name);
                    } else if (a.equals("replaceDir")) {
                        // настоящая замена папки: то, чего нет в источнике, тоже уходит
                        if (!dst.delete(name)) throw new IOException("Не удалось очистить папку " + name);
                    }
                    // merge — досыпаем в существующую папку
                }
            }
            // перемещение папки одним переименованием, если приёмник на том же томе и папки с таким именем ещё нет
            if ("move".equals(j.mode) && sf != null && !dst.exists(name) && dst.file(name) != null && sameVolume(sf, dst.file(name).getParentFile())) {
                long[] acc = new long[2]; count(s, acc);
                try { Os.rename(sf.getAbsolutePath(), dst.file(name).getAbsolutePath()); } catch (Throwable t) { if (!sf.renameTo(dst.file(name))) throw new IOException("Не удалось переместить " + name); }
                j.filesDone += (int) acc[1]; j.bytesDone += acc[0]; touched.add(dst.file(name).getAbsolutePath());
                progress(j, name, true);
                return;
            }
            Dst sub = dst.childDir(name, true);
            List<Src> kids = s.children();
            // мелочь без конфликтов копируем пачкой в несколько потоков — так быстрее на тысячах файлов
            List<Src> small = smallBatch(j, kids, sub);
            if (!small.isEmpty()) { copySmallBatch(j, small, sub); kids.removeAll(small); }
            for (Src k : kids) {
                if (cancelFlag) throw new Cancelled();
                try { transfer(j, k, sub, false); }
                catch (Skipped sk) { j.skipped++; countSkipped(j, k); }
            }
            // время и права самой папки — после того, как в неё всё сложено
            try {
                File df = dst.file(name);
                if (df != null && df.isDirectory()) {
                    if (j.keepAttrs && s.mode > 0) { try { Os.chmod(df.getAbsolutePath(), s.mode); } catch (Throwable ignored) {} }
                    if (j.keepTime && s.mtime > 0) df.setLastModified(s.mtime);
                }
            } catch (Throwable ignored) {}
            if ("move".equals(j.mode)) { try { if (s.children().isEmpty()) s.delete(); } catch (Throwable ignored) {} }
            return;
        }
        // ---- ссылка: воссоздаём саму ссылку, а не её содержимое ----
        if (j.keepAttrs && s.link != null && dst.file(name) != null) {
            File out = dst.file(name);
            if (out.exists() || isLink(out)) {
                String a = decideFile(j, name, s, dst);
                if (a.equals("skip")) throw new Skipped();
                if (a.equals("keepBoth")) { name = freeName(dst, name); out = dst.file(name); }
                else { out.delete(); }
            }
            try {
                Os.symlink(s.link, out.getAbsolutePath());
                j.filesDone++; progress(j, name, true);
                if ("move".equals(j.mode)) s.delete();
                return;
            } catch (Throwable t) { /* не вышло — копируем как обычный файл */ }
        }
        // ---- файл ----
        if (dst.exists(name)) {
            if ("move".equals(j.mode) && s.file() != null && dst.file(name) != null && s.file().getAbsolutePath().equals(dst.file(name).getAbsolutePath())) throw new Skipped();
            // уже скопирован в прошлый раз (тот же размер и дата) — не повторяем
            if (j.resumed && !dst.isDir(name) && dst.size(name) == s.size && Math.abs(dst.mtime(name) - s.mtime) < 2000) {
                j.filesDone++; j.bytesDone += s.size; progress(j, name, true); return;
            }
            String a = decideFile(j, name, s, dst);
            if (a.equals("skip")) throw new Skipped();
            if (a.equals("keepBoth")) {
                String want = lastAskName; lastAskName = null;
                name = (want != null && !want.trim().isEmpty() && !dst.exists(want.trim())) ? want.trim() : freeName(dst, name);
            } else if (a.equals("resume")) {
                // дописываем то, что уже лежит: уводим файл во временный и продолжаем с его конца
                File ff = dst.file(name);
                if (ff != null && ff.isFile()) {
                    File t = new File(dst.path(), ".yev_tmp_" + name);
                    if (t.exists()) t.delete();
                    if (ff.renameTo(t)) { j.curSrc = s.key(); j.curTmp = t.getAbsolutePath(); }
                }
            }
            // overwrite — пишем через временный файл и меняем местами
        }
        for (int attempt = 0; ; attempt++) {
            try {
                copyFile(j, s, dst, name);
                break;
            } catch (Cancelled c) { throw c;
            } catch (Skipped sk) { throw sk;
            } catch (Exception e) {
                String act = j.errRule != null ? j.errRule : ask(j, "error", name, false, s, dst, e.getMessage() == null ? e.toString() : e.getMessage());
                if (act.equals("retry")) { if (attempt < 20) continue; throw e; }
                if (act.equals("skip")) { j.failed++; throw new Skipped(); }
                throw new Cancelled();
            }
        }
    }

    private String decideFile(Job j, String name, Src s, Dst dst) throws Exception {
        String rule = j.fileRule;
        if (rule.equals("ask")) rule = ask(j, "conflict", name, false, s, dst);
        // «перезаписать, только если различаются»: одинаковые по размеру и дате пропускаем
        if (rule.equals("overwriteDiff")) return sameFile(s, dst, name) ? "skip" : "overwrite";
        return rule;
    }

    /** Ответ на вопрос о папке, применённый ко всем папкам. */
    private static String dirRuleOf(String a) {
        if (a.equals("overwriteDiff")) return "merge";
        if (a.equals("resume")) return "merge";
        return a;                                  // merge | replaceDir | skip | keepBoth
    }

    /** Тот же ответ, применённый ко всем файлам внутри. */
    private static String fileRuleOf(String a) {
        if (a.equals("merge") || a.equals("replaceDir")) return "overwrite";
        if (a.equals("resume")) return "overwrite";
        return a;                                  // overwrite | overwriteDiff | skip | keepBoth
    }

    /** Файлы считаем одинаковыми при совпадении размера и даты (как это делают файловые менеджеры). */
    private static boolean sameFile(Src s, Dst dst, String name) {
        try { return dst.exists(name) && !dst.isDir(name) && dst.size(name) == s.size && Math.abs(dst.mtime(name) - s.mtime) < 2000; }
        catch (Throwable t) { return false; }
    }

    private static String freeName(Dst dst, String name) {
        int dot = name.lastIndexOf('.');
        String base = dot > 0 ? name.substring(0, dot) : name, ext = dot > 0 ? name.substring(dot) : "";
        Set<String> taken = dst.names();
        for (int i = 1; i < 100000; i++) { String c = base + " (" + i + ")" + ext; if (!taken.contains(c)) return c; }
        return base + " (" + System.currentTimeMillis() + ")" + ext;
    }

    private static boolean sameVolume(File a, File b) {
        try { return Os.stat(a.getAbsolutePath()).st_dev == Os.stat(b.getAbsolutePath()).st_dev; } catch (Throwable t) { return false; }
    }

    // ---- копирование одного файла: конвейер чтение/запись, контрольные точки, обмен имён ----

    private void copyFile(Job j, Src s, Dst dst, String name) throws Exception {
        waitIfPaused();
        long size = s.size;
        boolean plain = dst.file(name) != null;
        File finalFile = plain ? dst.file(name) : null;
        String tmpName = plain ? ".yev_tmp_" + name : name;
        long offset = 0;
        // продолжение с места обрыва: временный файл уже есть и его хвост совпадает с источником
        if (plain && j.curTmp != null && j.curSrc != null && j.curSrc.equals(s.key())) {
            File t = new File(j.curTmp);
            if (t.exists() && t.getAbsolutePath().equals(new File(dst.path(), tmpName).getAbsolutePath()) && t.length() <= size && tailMatches(s, t, t.length())) offset = t.length();
            else t.delete();
        } else if (plain) {
            File t = new File(dst.path(), tmpName);
            if (t.exists()) t.delete();
        }
        // перемещение внутри закрытой папки — переименованием через службу
        if ("move".equals(j.mode) && dst instanceof ZDst && s instanceof ZSrc) {
            try {
                if (dst.exists(name)) dst.delete(name);
                if (ShizukuBridge.get().rename(((ZSrc) s).path, ((ZDst) dst).dir + "/" + name)) {
                    j.filesDone++; j.bytesDone += size; progress(j, name, true); return;
                }
            } catch (Throwable ignored) {}
        }
        // перемещение на том же томе — одно переименование
        if ("move".equals(j.mode) && plain && s.file() != null && sameVolume(s.file(), finalFile.getParentFile())) {
            if (finalFile.exists()) finalFile.delete();
            try { Os.rename(s.file().getAbsolutePath(), finalFile.getAbsolutePath()); }
            catch (Throwable t) { if (!s.file().renameTo(finalFile)) throw new IOException("Не удалось переместить " + name); }
            j.filesDone++; j.bytesDone += size; touched.add(finalFile.getAbsolutePath());
            if (core != null) core.addBytes(finalFile.getAbsolutePath(), size, 1);          // вес папок правим на разницу
            progress(j, name, true);
            return;
        }
        j.curSrc = s.key(); j.curTmp = plain ? new File(dst.path(), tmpName).getAbsolutePath() : null;
        j.bytesDone += offset;
        save(j);
        CRC32 crc = j.verify ? new CRC32() : null;
        InputStream in = s.open(offset);
        OutputStream out;
        try { out = dst.openWrite(tmpName, offset > 0); } catch (Exception e) { try { in.close(); } catch (Throwable ignored) {} throw e; }
        if (!plain) { /* SAF: без временного файла — пишем напрямую (перезапись = удалить и создать) */ }
        final ArrayBlockingQueue<Object> q = new ArrayBlockingQueue<>(QUEUE_DEPTH);
        final Object EOF = new Object();
        final Throwable[] readErr = { null };
        final InputStream fin = in;
        Thread reader = new Thread(() -> {
            try {
                while (true) {
                    if (cancelFlag || Thread.currentThread().isInterrupted()) return;
                    byte[] buf = new byte[CHUNK];
                    int n = 0, r;
                    while (n < CHUNK && (r = fin.read(buf, n, CHUNK - n)) > 0) n += r;
                    if (n <= 0) break;
                    q.put(new Chunk(buf, n));
                    if (n < CHUNK) break;
                }
            } catch (InterruptedException ie) { return;
            } catch (Throwable t) { readErr[0] = t; }
            try { q.offer(EOF, 5, java.util.concurrent.TimeUnit.SECONDS); } catch (InterruptedException ignored) {}
        }, "yev-xfer-read");
        reader.setDaemon(true); reader.start();
        long written = offset, lastCk = System.currentTimeMillis();
        boolean ok = false;
        try {
            while (true) {
                waitIfPaused();
                Object o = q.take();
                if (o == EOF) break;
                Chunk c = (Chunk) o;
                out.write(c.buf, 0, c.len);
                if (crc != null) crc.update(c.buf, 0, c.len);
                written += c.len; j.bytesDone += c.len;
                progress(j, name, false);
                long now = System.currentTimeMillis();
                if (now - lastCk > CHECKPOINT_MS) { lastCk = now; save(j); }
            }
            if (readErr[0] != null) throw new IOException("Ошибка чтения: " + readErr[0].getMessage());
            out.flush();
            ok = true;
        } finally {
            try { out.close(); } catch (Throwable ignored) {}
            try { in.close(); } catch (Throwable ignored) {}
            try { reader.interrupt(); } catch (Throwable ignored) {}
            if (!ok && cancelFlag && plain) {
                File t = new File(dst.path(), tmpName);
                // дописывали уже лежавший файл — возвращаем его на место, чтобы работа не пропала
                if (offset > 0 && t.exists()) { File back = new File(dst.path(), name); if (!back.exists()) t.renameTo(back); }
                else { try { t.delete(); } catch (Throwable ignored) {} }
            }
        }
        if (cancelFlag) throw new Cancelled();
        if (plain) {
            File tmp = new File(dst.path(), tmpName);
            if (size > 0 && tmp.length() != size) throw new IOException("Записано " + tmp.length() + " из " + size + " байт");
            // сверка: хвост файла всегда, полная контрольная сумма — по желанию
            if (size >= 1048576 && offset == 0 && !tailMatches(s, tmp, size)) throw new IOException("Файл записан с ошибкой (не совпадает содержимое)");
            if (crc != null) {
                long src = crcOf(s, size);
                if (src != crc.getValue()) throw new IOException("Контрольная сумма не совпала");
            }
            try { tmp.setLastModified(j.keepTime && s.mtime > 0 ? s.mtime : System.currentTimeMillis()); } catch (Throwable ignored) {}
            if (j.keepAttrs && s.mode > 0) { try { Os.chmod(tmp.getAbsolutePath(), s.mode); } catch (Throwable ignored) {} }
            // обмен имён: старый файл уходит в сторону, новый встаёт на место, старый удаляется
            if (finalFile.exists()) {
                File bak = new File(dst.path(), ".yev_bak_" + name);
                if (bak.exists()) bak.delete();
                if (!dst.rename(name, bak.getName())) { if (!finalFile.delete()) throw new IOException("Не удалось заменить " + name); }
                if (!dst.rename(tmpName, name)) { dst.rename(bak.getName(), name); throw new IOException("Не удалось записать " + name); }
                bak.delete();
            } else if (!dst.rename(tmpName, name)) throw new IOException("Не удалось записать " + name);
            touched.add(finalFile.getAbsolutePath());
        } else {
            if (crc != null) { long src = crcOf(s, size); if (src != crc.getValue()) throw new IOException("Контрольная сумма не совпала"); }
        }
        j.curSrc = null; j.curTmp = null;
        j.filesDone++;
        if ("move".equals(j.mode)) { if (!s.delete()) throw new IOException("Скопировано, но не удалось удалить источник: " + name); }
        progress(j, name, true);
        save(j);
    }

    static final class Chunk { final byte[] buf; final int len; Chunk(byte[] b, int l) { buf = b; len = l; } }

    /** Какие из детей — мелкие обычные файлы, которых нет в приёмнике (значит, вопросов не будет). */
    private List<Src> smallBatch(Job j, List<Src> kids, Dst dst) {
        List<Src> out = new ArrayList<>();
        if (!j.parallel) return out;                           // выключено в настройках
        if ("move".equals(j.mode)) return out;                 // перемещение и так идёт переименованием
        if (dst.file("x") == null) return out;                 // не обычная папка — без выкрутасов
        int candidates = 0;
        for (Src k : kids) if (!k.dir && k.size <= SMALL) candidates++;
        if (candidates < 8) return out;                        // ради пары файлов не затеваемся
        Set<String> taken = dst.names();
        for (Src k : kids) {
            if (k.dir || k.size > SMALL || k.link != null) continue;
            if (taken.contains(k.name)) continue;              // есть в приёмнике — пойдёт обычным путём с вопросом
            out.add(k);
        }
        return out;
    }

    /** Копирование пачки мелких файлов несколькими потоками. */
    private void copySmallBatch(final Job j, List<Src> list, final Dst dst) throws Exception {
        final java.util.concurrent.ConcurrentLinkedQueue<Src> q = new java.util.concurrent.ConcurrentLinkedQueue<>(list);
        final Throwable[] err = { null };
        int n = Math.min(SMALL_THREADS, Math.max(1, list.size() / 4));
        Thread[] ts = new Thread[n];
        for (int i = 0; i < n; i++) {
            ts[i] = new Thread(() -> {
                Src k;
                byte[] buf = new byte[65536];
                while ((k = q.poll()) != null) {
                    if (cancelFlag || err[0] != null) return;
                    final Src kk = k;
                    try {
                        waitIfPaused();
                        File out = dst.file(kk.name);
                        InputStream in = kk.open(0);
                        OutputStream os = new FileOutputStream(out);
                        long wrote = 0;
                        try { int r; while ((r = in.read(buf)) > 0) { os.write(buf, 0, r); wrote += r; } }
                        finally { try { in.close(); } catch (Throwable ignored) {} try { os.close(); } catch (Throwable ignored) {} }
                        if (cancelFlag) { out.delete(); return; }
                        if (kk.size > 0 && wrote != kk.size) { out.delete(); throw new IOException("Записано " + wrote + " из " + kk.size + " байт: " + kk.name); }
                        try { out.setLastModified(j.keepTime && kk.mtime > 0 ? kk.mtime : System.currentTimeMillis()); } catch (Throwable ignored) {}
                        if (j.keepAttrs && kk.mode > 0) { try { Os.chmod(out.getAbsolutePath(), kk.mode); } catch (Throwable ignored) {} }
                        synchronized (j) { j.filesDone++; j.bytesDone += wrote; }
                        touched.add(out.getAbsolutePath());
                        progress(j, kk.name, false);
                    } catch (Throwable t) {
                        try { File bad = dst.file(kk.name); if (bad != null && bad.exists()) bad.delete(); } catch (Throwable ignored) {}
                        if (err[0] == null) err[0] = t;
                        return;
                    }
                }
            }, "yev-small-" + i);
            ts[i].setDaemon(true); ts[i].start();
        }
        for (Thread t : ts) t.join();
        if (cancelFlag) throw new Cancelled();
        if (err[0] != null) {
            // упало на пачке — остаток докопируем обычным путём, а про ошибку спросим как всегда
            throw err[0] instanceof Exception ? (Exception) err[0] : new IOException(String.valueOf(err[0].getMessage()));
        }
        save(j);
    }

    private boolean tailMatches(Src s, File t, long len) {
        if (len <= 0) return true;
        long n = Math.min(TAIL_CHECK, len);
        long off = len - n;
        try {
            byte[] a = new byte[(int) n], b = new byte[(int) n];
            InputStream in = s.open(off);
            try { int r, k = 0; while (k < n && (r = in.read(a, k, (int) n - k)) > 0) k += r; if (k < n) return false; } finally { in.close(); }
            RandomAccessFile raf = new RandomAccessFile(t, "r");
            try { raf.seek(off); raf.readFully(b); } finally { raf.close(); }
            return Arrays.equals(a, b);
        } catch (Throwable e) { return false; }
    }

    private long crcOf(Src s, long size) throws IOException {
        CRC32 c = new CRC32();
        InputStream in = s.open(0);
        try { byte[] b = new byte[CHUNK]; int r; while ((r = in.read(b)) > 0) { c.update(b, 0, r); if (cancelFlag) break; } } finally { in.close(); }
        return c.getValue();
    }

    // ---- вопросы интерфейсу ----

    private String ask(Job j, String kind, String name, boolean isDir, Src s, Dst dst) throws Exception { return ask(j, kind, name, isDir, s, dst, null); }

    private String ask(Job j, String kind, String name, boolean isDir, Src s, Dst dst, String msg) throws Exception {
        JSObject p = new JSObject();
        p.put("id", j.id); p.put("kind", kind); p.put("name", name); p.put("isDir", isDir);
        p.put("srcSize", s.size); p.put("srcMtime", s.mtime);
        p.put("num", ++askCount);
        p.put("mode", j.mode);
        try { p.put("srcPath", s.key()); } catch (Throwable ignored) {}
        if (dst != null) {
            try { p.put("dstPath", dst.path() + "/" + name); } catch (Throwable ignored) {}
            if (dst.exists(name)) {
                p.put("dstSize", dst.size(name)); p.put("dstMtime", dst.mtime(name));
                p.put("same", sameFile(s, dst, name));
                // дописать можно, если на месте лежит начало того же файла
                try {
                    File ff = dst.file(name);
                    if (!isDir && ff != null && ff.isFile() && ff.length() > 0 && ff.length() < s.size && tailMatches(s, ff, ff.length())) p.put("canResume", true);
                } catch (Throwable ignored) {}
            }
        }
        if (msg != null) p.put("msg", msg);
        String a;
        synchronized (askLock) {
            answer = null; answerFiles = false; answerDirs = false; pendingAsk = p;
            j.state = "ask"; em.emit("xfer", progressJson(j));
            em.emit("xferAsk", p);
            while (answer == null && !cancelFlag) { askLock.wait(500); }
            a = answer; boolean aF = answerFiles, aD = answerDirs; lastAskName = answerName;
            pendingAsk = null; answer = null; answerName = null;
            if (cancelFlag || a == null || a.equals("cancel")) throw new Cancelled();
            if (kind.equals("conflict")) {
                if (aD) j.dirRule = dirRuleOf(a);
                if (aF) j.fileRule = fileRuleOf(a);
            } else if (aF || aD) j.errRule = a;
        }
        j.state = "run"; em.emit("xfer", progressJson(j));
        return a;
    }

    // ---- прогресс ----

    private YevCore core;                  // кому сообщать об изменении веса папок
    public void setCore(YevCore c) { core = c; }
    private volatile String lastAskName;   // имя, которое пользователь ввёл в ответе на вопрос
    private final ArrayDeque<long[]> samples = new ArrayDeque<>();
    private long lastEmit = 0;
    private final Set<String> touched = Collections.synchronizedSet(new LinkedHashSet<String>());
    private String curName = "";

    private void progress(Job j, String name, boolean force) {
        curName = name;
        long now = System.currentTimeMillis();
        if (samples.isEmpty() || now - samples.peekLast()[0] >= 50) samples.addLast(new long[]{ now, j.bytesDone });
        while (samples.size() > 2 && now - samples.peekFirst()[0] > 3000) samples.pollFirst();
        if (!force && now - lastEmit < 150) return;
        lastEmit = now;
        em.emit("xfer", progressJson(j));
        notify(j, false);
    }

    private double speed() {
        if (samples.size() < 2) return 0;
        long[] a = samples.peekFirst(), b = samples.peekLast();
        long dt = b[0] - a[0];
        return dt <= 0 ? 0 : (b[1] - a[1]) * 1000.0 / dt;
    }

    private JSObject progressJson(Job j) {
        JSObject o = j.summary();
        o.put("name", curName);
        double sp = speed();
        o.put("speed", (long) sp);
        long left = j.bytesTotal - j.bytesDone;
        o.put("eta", sp > 1 ? (long) (left / sp) : -1);
        o.put("queued", queueSize());
        o.put("paused", pauseFlag);
        return o;
    }

    private void notify(Job j, boolean force) {
        long now = System.currentTimeMillis();
        if (!serviceUp) { if (now - startedAt < 1500) return; serviceUp = true; }
        if (!force && now - lastNotif < 700) return;
        lastNotif = now;
        int pct = j.bytesTotal > 0 ? (int) Math.min(100, j.bytesDone * 100 / j.bytesTotal) : 0;
        String title = ("delete".equals(j.mode) ? "Удаление" : "move".equals(j.mode) ? "Перемещение" : "Копирование") + (pauseFlag ? " — пауза" : "");
        String text = curName + (j.filesTotal > 0 ? "  " + j.filesDone + "/" + j.filesTotal : "");
        try { OpService.start(ctx, title, text, pct, 100); } catch (Throwable ignored) {}
    }

    private void mediaScan() {
        try {
            List<String> l = new ArrayList<>();
            synchronized (touched) { for (String t : touched) { if (l.size() >= 300) break; l.add(t); } }
            if (!l.isEmpty()) android.media.MediaScannerConnection.scanFile(ctx, l.toArray(new String[0]), null, null);
        } catch (Throwable ignored) {}
    }

    // ---- разбор задания из вызова интерфейса ----

    public Job jobFrom(JSObject o) throws Exception {
        Job j = new Job();
        String md = o.optString("mode");
        j.mode = "move".equals(md) ? "move" : "delete".equals(md) ? "delete" : "copy";
        j.dest = "delete".equals(j.mode) ? o.optString("dest", "") : o.getString("dest");
        j.fileRule = o.optString("fileRule", "ask");
        j.dirRule = o.optString("dirRule", "ask");
        j.verify = o.optBoolean("verify", false);
        j.keepTime = o.optBoolean("keepTime", true);
        j.keepAttrs = o.optBoolean("keepAttrs", true);
        j.parallel = o.optBoolean("parallel", true);
        if ("delete".equals(j.mode)) j.dest = j.dest == null ? "" : j.dest;
        JSONArray a = o.optJSONArray("items");
        if (a != null) for (int i = 0; i < a.length(); i++) { JSONObject it = a.getJSONObject(i); Item x = new Item(); x.uri = it.optString("uri"); x.name = it.optString("name"); x.type = it.optString("type", "file"); j.items.add(x); }
        return j;
    }
}
