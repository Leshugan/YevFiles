package leshugan.fm;

import android.content.res.AssetFileDescriptor;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.graphics.Bitmap;
import android.graphics.Point;
import android.graphics.BitmapFactory;
import android.os.Build;
import android.os.CancellationSignal;
import android.os.Environment;
import android.os.ParcelFileDescriptor;
import android.provider.DocumentsContract.Document;
import android.provider.DocumentsContract.Root;
import android.provider.DocumentsProvider;
import android.webkit.MimeTypeMap;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.List;

/**
 * Делает YevFiles доступным в системных диалогах "Сохранить в..." и "Открыть".
 * Корень — внутреннее хранилище. Полностью read/write через SAF.
 */
public class YevDocumentsProvider extends DocumentsProvider {

    private static final String[] DEFAULT_ROOT_PROJECTION = new String[]{
            Root.COLUMN_ROOT_ID, Root.COLUMN_MIME_TYPES, Root.COLUMN_FLAGS,
            Root.COLUMN_ICON, Root.COLUMN_TITLE, Root.COLUMN_SUMMARY,
            Root.COLUMN_DOCUMENT_ID, Root.COLUMN_AVAILABLE_BYTES
    };
    private static final String[] DEFAULT_DOCUMENT_PROJECTION = new String[]{
            Document.COLUMN_DOCUMENT_ID, Document.COLUMN_MIME_TYPE, Document.COLUMN_DISPLAY_NAME,
            Document.COLUMN_LAST_MODIFIED, Document.COLUMN_FLAGS, Document.COLUMN_SIZE
    };

    private File baseDir;

    @Override
    public boolean onCreate() {
        baseDir = Environment.getExternalStorageDirectory();
        return true;
    }

    // ---- Корни: внутренняя память и все съёмные носители ----
    private static class Vol { String id; String title; File dir; boolean removable; }

    private List<Vol> volumes() {
        List<Vol> out = new ArrayList<>();
        Vol primary = new Vol();
        primary.id = "root"; primary.title = "YevFiles"; primary.dir = baseDir; primary.removable = false;
        out.add(primary);
        try {
            File[] mounts = new File("/storage").listFiles();
            if (mounts != null) for (File m : mounts) {
                String nm = m.getName();
                if (nm.equals("self") || nm.equals("emulated") || nm.equals("enc_emulated") || nm.equals("knox-emulated")) continue;
                if (!m.canRead() || m.listFiles() == null) continue;     // не смонтирован или нет доступа
                Vol v = new Vol();
                v.id = "vol_" + nm;
                v.title = nm.matches("(?i).*(usb|otg).*") ? "USB-накопитель" : ("Носитель " + nm);
                v.dir = m; v.removable = true;
                out.add(v);
            }
        } catch (Throwable ignored) {}
        return out;
    }

    private Vol volById(String rootId) {
        for (Vol v : volumes()) if (v.id.equals(rootId)) return v;
        return null;
    }

    @Override
    public Cursor queryRoots(String[] projection) {
        MatrixCursor result = new MatrixCursor(projection != null ? projection : DEFAULT_ROOT_PROJECTION);
        for (Vol v : volumes()) {
            final MatrixCursor.RowBuilder row = result.newRow();
            row.add(Root.COLUMN_ROOT_ID, v.id);
            row.add(Root.COLUMN_SUMMARY, v.removable ? "YevFiles · съёмный" : "YevFiles");
            row.add(Root.COLUMN_FLAGS, Root.FLAG_SUPPORTS_CREATE | Root.FLAG_SUPPORTS_IS_CHILD | Root.FLAG_LOCAL_ONLY | Root.FLAG_SUPPORTS_SEARCH);
            row.add(Root.COLUMN_TITLE, v.title);
            row.add(Root.COLUMN_DOCUMENT_ID, v.id);
            row.add(Root.COLUMN_MIME_TYPES, "*/*");
            try { row.add(Root.COLUMN_AVAILABLE_BYTES, v.dir.getFreeSpace()); } catch (Throwable t) { row.add(Root.COLUMN_AVAILABLE_BYTES, 0); }
            row.add(Root.COLUMN_ICON, getContext().getApplicationInfo().icon);
        }
        return result;
    }

    @Override
    public Cursor queryDocument(String documentId, String[] projection) throws FileNotFoundException {
        MatrixCursor result = new MatrixCursor(projection != null ? projection : DEFAULT_DOCUMENT_PROJECTION);
        includeFile(result, documentId, null);
        return result;
    }

    @Override
    public Cursor queryChildDocuments(String parentDocumentId, String[] projection, String sortOrder) throws FileNotFoundException {
        MatrixCursor result = new MatrixCursor(projection != null ? projection : DEFAULT_DOCUMENT_PROJECTION);
        final File parent = fileForDocId(parentDocumentId);
        final String rootId = rootOf(parentDocumentId);
        File[] kids = parent.listFiles();
        if (kids != null) for (File f : kids) includeFile(result, docIdFor(rootId, f), f);
        return result;
    }

    // ---- Поиск по имени внутри тома ----
    @Override
    public Cursor querySearchDocuments(String rootId, String query, String[] projection) throws FileNotFoundException {
        MatrixCursor result = new MatrixCursor(projection != null ? projection : DEFAULT_DOCUMENT_PROJECTION);
        Vol v = volById(rootId);
        if (v == null) return result;
        final String q = query == null ? "" : query.toLowerCase();
        ArrayDeque<File> queue = new ArrayDeque<>();
        queue.add(v.dir);
        int found = 0;
        long deadline = System.currentTimeMillis() + 8000;     // системное окно не должно висеть
        while (!queue.isEmpty() && found < 200 && System.currentTimeMillis() < deadline) {
            File dir = queue.poll();
            File[] kids = dir.listFiles();
            if (kids == null) continue;
            for (File f : kids) {
                if (f.isDirectory()) queue.add(f);
                if (f.getName().toLowerCase().contains(q)) {
                    try { includeFile(result, docIdFor(rootId, f), f); found++; } catch (Exception ignored) {}
                    if (found >= 200) break;
                }
            }
        }
        return result;
    }

    // ---- Превью: картинки и кадр из видео ----
    @Override
    public AssetFileDescriptor openDocumentThumbnail(String documentId, Point sizeHint, CancellationSignal signal) throws FileNotFoundException {
        File f = fileForDocId(documentId);
        String mime = getMimeType(f);
        try {
            int w = sizeHint != null && sizeHint.x > 0 ? sizeHint.x : 256;
            int h = sizeHint != null && sizeHint.y > 0 ? sizeHint.y : 256;
            File cacheDir = new File(getContext().getCacheDir(), "safthumb");
            if (!cacheDir.exists()) cacheDir.mkdirs();
            File out = new File(cacheDir, Integer.toHexString((f.getAbsolutePath() + "|" + f.lastModified() + "|" + f.length()).hashCode()) + ".jpg");
            if (!out.exists() || out.length() == 0) {
                Bitmap bmp = null;
                if (mime.startsWith("image/")) {
                    BitmapFactory.Options o = new BitmapFactory.Options();
                    o.inJustDecodeBounds = true;
                    BitmapFactory.decodeFile(f.getAbsolutePath(), o);
                    int scale = 1;
                    while (o.outWidth / (scale * 2) >= w && o.outHeight / (scale * 2) >= h) scale *= 2;
                    BitmapFactory.Options o2 = new BitmapFactory.Options();
                    o2.inSampleSize = scale;
                    bmp = BitmapFactory.decodeFile(f.getAbsolutePath(), o2);
                } else if (mime.startsWith("video/")) {
                    android.media.MediaMetadataRetriever mmr = new android.media.MediaMetadataRetriever();
                    try {
                        mmr.setDataSource(f.getAbsolutePath());
                        if (Build.VERSION.SDK_INT >= 27) bmp = mmr.getScaledFrameAtTime(1000000, android.media.MediaMetadataRetriever.OPTION_CLOSEST_SYNC, w, h);
                        if (bmp == null) bmp = mmr.getFrameAtTime(1000000, android.media.MediaMetadataRetriever.OPTION_CLOSEST_SYNC);
                    } finally { try { mmr.release(); } catch (Exception ignored) {} }
                }
                if (bmp == null) throw new FileNotFoundException("нет превью");
                FileOutputStream fos = new FileOutputStream(out);
                try { bmp.compress(Bitmap.CompressFormat.JPEG, 82, fos); } finally { fos.close(); bmp.recycle(); }
            }
            return new AssetFileDescriptor(ParcelFileDescriptor.open(out, ParcelFileDescriptor.MODE_READ_ONLY), 0, AssetFileDescriptor.UNKNOWN_LENGTH);
        } catch (FileNotFoundException e) { throw e; }
        catch (Exception e) { throw new FileNotFoundException("нет превью: " + e.getMessage()); }
    }

    @Override
    public ParcelFileDescriptor openDocument(String documentId, String mode, CancellationSignal signal) throws FileNotFoundException {
        final File file = fileForDocId(documentId);
        final int accessMode = ParcelFileDescriptor.parseMode(mode);
        return ParcelFileDescriptor.open(file, accessMode);
    }

    @Override
    public String createDocument(String parentDocumentId, String mimeType, String displayName) throws FileNotFoundException {
        File parent = fileForDocId(parentDocumentId);
        File f = new File(parent, displayName);
        try {
            if (Document.MIME_TYPE_DIR.equals(mimeType)) {
                if (!f.mkdir()) throw new FileNotFoundException("Не удалось создать папку " + f);
            } else {
                int n = 0; String base = displayName, ext = "";
                int dot = displayName.lastIndexOf('.');
                if (dot > 0) { base = displayName.substring(0, dot); ext = displayName.substring(dot); }
                while (f.exists()) { n++; f = new File(parent, base + " (" + n + ")" + ext); }
                if (!f.createNewFile()) throw new FileNotFoundException("Не удалось создать файл " + f);
            }
        } catch (Exception e) { throw new FileNotFoundException("Ошибка создания: " + e.getMessage()); }
        return docIdFor(rootOf(parentDocumentId), f);
    }

    @Override
    public void deleteDocument(String documentId) throws FileNotFoundException {
        File f = fileForDocId(documentId);
        if (!deleteRecursive(f)) throw new FileNotFoundException("Не удалось удалить " + documentId);
    }

    @Override
    public String renameDocument(String documentId, String displayName) throws FileNotFoundException {
        File f = fileForDocId(documentId);
        File target = new File(f.getParentFile(), displayName);
        if (!f.renameTo(target)) throw new FileNotFoundException("Не удалось переименовать " + documentId);
        return docIdFor(rootOf(documentId), target);
    }

    @Override
    public boolean isChildDocument(String parentDocumentId, String documentId) {
        return documentId.startsWith(parentDocumentId);
    }

    private boolean deleteRecursive(File f) {
        if (f.isDirectory()) { File[] k = f.listFiles(); if (k != null) for (File c : k) deleteRecursive(c); }
        return f.delete();
    }

    private void includeFile(MatrixCursor result, String docId, File file) throws FileNotFoundException {
        if (file == null) file = fileForDocId(docId);
        int flags = 0;
        if (file.isDirectory()) {
            if (file.canWrite()) flags |= Document.FLAG_DIR_SUPPORTS_CREATE;
        } else if (file.canWrite()) {
            flags |= Document.FLAG_SUPPORTS_WRITE;
        }
        if (file.getParentFile() != null && file.getParentFile().canWrite())
            flags |= Document.FLAG_SUPPORTS_DELETE | Document.FLAG_SUPPORTS_RENAME;

        final String displayName = file.getName();
        final String mimeType = getMimeType(file);
        if (mimeType.startsWith("image/") || mimeType.startsWith("video/")) flags |= Document.FLAG_SUPPORTS_THUMBNAIL;

        final MatrixCursor.RowBuilder row = result.newRow();
        row.add(Document.COLUMN_DOCUMENT_ID, docId);
        row.add(Document.COLUMN_DISPLAY_NAME, displayName.isEmpty() ? "YevFiles" : displayName);
        row.add(Document.COLUMN_SIZE, file.length());
        row.add(Document.COLUMN_MIME_TYPE, mimeType);
        row.add(Document.COLUMN_LAST_MODIFIED, file.lastModified());
        row.add(Document.COLUMN_FLAGS, flags);
    }

    // id документа: "<идТома>:<путь внутри тома>"
    private String rootOf(String docId) {
        if (docId == null) return "root";
        int c = docId.indexOf(':');
        return c > 0 ? docId.substring(0, c) : docId;
    }

    private String docIdFor(String rootId, File file) {
        Vol v = volById(rootId);
        File base = v != null ? v.dir : baseDir;
        String path = file.getAbsolutePath(), root = base.getAbsolutePath();
        if (path.equals(root)) return rootId;
        if (path.startsWith(root + "/")) return rootId + ":" + path.substring(root.length() + 1);
        return rootId;
    }

    private File fileForDocId(String docId) throws FileNotFoundException {
        if (docId == null) return baseDir;
        Vol v = volById(rootOf(docId));
        File base = v != null ? v.dir : baseDir;
        int c = docId.indexOf(':');
        if (c < 0) return base;
        String rel = docId.substring(c + 1);
        return rel.isEmpty() ? base : new File(base, rel);
    }

    private static String getMimeType(File file) {
        if (file.isDirectory()) return Document.MIME_TYPE_DIR;
        String name = file.getName();
        int dot = name.lastIndexOf('.');
        if (dot >= 0) {
            String ext = name.substring(dot + 1).toLowerCase();
            String m = MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext);
            if (m != null) return m;
        }
        return "application/octet-stream";
    }
}
