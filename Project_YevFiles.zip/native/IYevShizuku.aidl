// Интерфейс службы, которая работает внутри процесса Shizuku с правами оболочки.
// destroy() с этим номером транзакции требует сам Shizuku — не менять.
package leshugan.fm;

interface IYevShizuku {
    String list(String path);
    boolean mkdirs(String path);
    boolean delete(String path);
    boolean rename(String from, String to);
    ParcelFileDescriptor open(String path, String mode);
    void destroy() = 16777114;
}
